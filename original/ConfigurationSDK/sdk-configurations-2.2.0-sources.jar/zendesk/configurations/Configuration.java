package zendesk.configurations;

import java.io.Serializable;
import java.util.List;

/**
 * Configuration for a screen of the SDK.
 */
public interface Configuration extends Serializable {

    /**
     * A list of configurations that gets passed through screens and is
     * used for configuring activities that get started from the initial entry point.
     */
    List<Configuration> getConfigurations();
}
