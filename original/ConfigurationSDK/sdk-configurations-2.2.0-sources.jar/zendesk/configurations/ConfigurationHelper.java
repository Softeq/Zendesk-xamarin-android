package zendesk.configurations;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * Util class for handling {@link Configuration}. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY_GROUP)
public class ConfigurationHelper {

    @VisibleForTesting
    static String ZENDESK_CONFIGURATION = "ZENDESK_CONFIGURATION";

    private static ConfigurationHelper INSTANCE = new ConfigurationHelper();

    /**
     * Returns a statically held instance of ConfigurationHelper. Injection through DI should be preferred over using
     * this where possible, this should only be used in situations where DI is impossible or unsuitable. 
     */
    public static ConfigurationHelper get() {
        return INSTANCE;
    }

    /**
     * Adds a {@link Configuration} to an {@link Intent} as an extra. Retrieving the {@link Configuration} from
     * the {@link Intent} should be done using {@link ConfigurationHelper#fromBundle(Bundle, Class)}.
     *
     * @param intent the {@link Intent} to add the {@link Configuration} to.
     * @param configuration the {@link Configuration} to add.
     */
    public void addToIntent(Intent intent, Configuration configuration) {
        intent.putExtra(ZENDESK_CONFIGURATION, configuration);
    }

    /**
     * Adds a {@link Configuration} to a {@link Bundle}. Retrieving the {@link Configuration} from
     * the {@link Bundle} should be done using {@link ConfigurationHelper#fromBundle(Bundle, Class)}.
     *
     * @param bundle the {@link Bundle} to add the {@link Configuration} to.
     * @param configuration the {@link Configuration} to add.
     */
    public void addToBundle(Bundle bundle, Configuration configuration) {
        bundle.putSerializable(ZENDESK_CONFIGURATION, configuration);
    }

    /**
     * Adds a {@link Configuration} to a {@link Map}. Retrieving the {@link Configuration} should be
     * done using {@link ConfigurationHelper#fromMap(Map, Class)}.
     *
     * @param stringObjectMap the {@link Map} to add the {@link Configuration} to.
     * @param configuration the {@link Configuration} to add.
     */
    public void addToMap(@NonNull Map<String, Object> stringObjectMap, Configuration configuration) {
        stringObjectMap.put(ZENDESK_CONFIGURATION, configuration);
    }

    /**
     * Extracts and returns a {@link Configuration} from a {@link Bundle} after the Configuration has been added to
     * the Bundle using {@link ConfigurationHelper#addToBundle(Bundle, Configuration)}.
     *
     * @param bundle the {@link Bundle} to extract the {@link Configuration} of the given type from.
     * @param clazz the class type to extract.
     * @param <E> the type of the {@link Configuration} that will be returned.
     * @return the {@link Configuration} of the specified class type retrieved from the {@link Bundle}
     */
    @Nullable
    public <E extends Configuration> E fromBundle(Bundle bundle, Class<E> clazz) {
        if (bundle != null && bundle.containsKey(ZENDESK_CONFIGURATION)) {
            final Serializable s = bundle.getSerializable(ZENDESK_CONFIGURATION);
            if (clazz.isInstance(s)) {
                //noinspection unchecked
                return (E) s;
            }
        }

        return null;
    }

    /**
     * Extracts and returns a {@link Configuration} from a {@link Map} after the Configuration has been added to
     * the Map using {@link ConfigurationHelper#addToMap(Map, Configuration)}.
     *
     * @param stringObjectMap the {@link Map} to extract a {@link Configuration} from.
     * @param clazz the class type to extract.
     * @param <E> the type of the {@link Configuration} that will be returned.
     * @return the {@link Configuration} of the specified class type retrieved from the {@link Map}
     */
    @Nullable
    public <E extends Configuration> E fromMap(Map<String, Object> stringObjectMap, Class<E> clazz) {
        if (stringObjectMap != null && stringObjectMap.containsKey(ZENDESK_CONFIGURATION)) {
            final Object object = stringObjectMap.get(ZENDESK_CONFIGURATION);
            if (clazz.isInstance(object)) {
                //noinspection unchecked
                return (E) object;
            }
        }

        return null;
    }

    /**
     * Extracts and returns a list of {@link Configuration}s from a {@link Map}.
     *
     * @param data the Map to extract Configurations from.
     * @return a list of the Configurations extracted from the Map, or null if none are found.
     */
    @Nullable
    public List<Configuration> extractConfigsFromMap(Map<String, Object> data) {
        Configuration configuration = fromMap(data, Configuration.class);
        return configuration != null ? configuration.getConfigurations() : null;
    }

    /**
     * Finds and returns a {@link Configuration} of the given type in the given list.
     *
     * @param configs the list of {@link Configuration} to search.
     * @param clazz the class type to search for.
     * @param <E> the type of {@link Configuration} to search for.
     * @return a {@link Configuration} of the given type in the given list, or null if none are found.
     */
    @Nullable
    public <E extends Configuration> E findConfigForType(List<Configuration> configs, Class<E> clazz) {
        for (Configuration configuration : configs) {
            if (clazz.isInstance(configuration)) {
                //noinspection unchecked
                return (E) configuration;
            }
        }
        return null;
    }

    /**
     * Takes a list of {@link Configuration}s and a single Configuration, and adds the single
     * Configuration to the list if it is not already in the list.
     *
     * Use this method to ensure that a given {@link Configuration} is in a list of Configurations
     * without adding a duplicate.
     *
     * @param configs the list of {@link Configuration} to add to.
     * @param configuration the {@link Configuration} to add.
     * @return a copy of the configs list passed to the method, with the {@link Configuration} added
     * if it was not already in the list.
     */
    @NonNull
    public List<Configuration> addSelfIfNotInList(List<Configuration> configs, Configuration configuration) {
        final List<Configuration> result = new ArrayList<>(configs);
        final Configuration config = findConfigForType(configs, configuration.getClass());

        if (config == null) {
            result.add(configuration);
        }

        return result;
    }
}
