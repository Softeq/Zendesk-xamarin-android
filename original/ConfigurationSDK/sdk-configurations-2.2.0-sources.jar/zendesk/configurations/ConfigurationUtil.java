package zendesk.configurations;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import java.util.List;
import java.util.Map;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;


/**
 * Util class for handling {@link Configuration}. For Zendesk internal use only.
 *
 * @deprecated Please use {@link ConfigurationHelper} instead.
 */
@RestrictTo(LIBRARY_GROUP)
@Deprecated
public class ConfigurationUtil {

    private static ConfigurationHelper helper = new ConfigurationHelper();

    private ConfigurationUtil() {
        // intentionally empty
    }

    /**
     * Adds a {@link Configuration} to an {@link Intent} as an extra. Retrieving the {@link Configuration} from
     * the {@link Intent} should be done using {@link ConfigurationHelper#fromBundle(Bundle, Class)}.
     *
     * @param intent the {@link Intent} to add the {@link Configuration} to.
     * @param configuration the {@link Configuration} to add.
     *
     * @deprecated Please use {@link ConfigurationHelper#addToIntent(Intent, Configuration)} instead.
     */
    public static void addToIntent(Intent intent, Configuration configuration) {
        helper.addToIntent(intent, configuration);
    }

    /**
     * Adds a {@link Configuration} to a {@link Bundle}. Retrieving the {@link Configuration} from
     * the {@link Bundle} should be done using {@link ConfigurationHelper#fromBundle(Bundle, Class)}.
     *
     * @param bundle the {@link Bundle} to add the {@link Configuration} to.
     * @param configuration the {@link Configuration} to add.
     *
     * @deprecated Please use {@link ConfigurationHelper#addToBundle(Bundle, Configuration)} instead.
     */
    public static void addToBundle(Bundle bundle, Configuration configuration) {
        helper.addToBundle(bundle, configuration);
    }

    /**
     * Adds a {@link Configuration} to a {@link Map}. Retrieving the {@link Configuration} should be
     * done using {@link ConfigurationHelper#fromMap(Map, Class)}.
     *
     * @param stringObjectMap the {@link Map} to add the {@link Configuration} to.
     * @param configuration the {@link Configuration} to add.
     *
     * @deprecated Please use {@link ConfigurationHelper#addToMap(Map, Configuration)} instead.
     */
    public static void addToMap(@NonNull Map<String, Object> stringObjectMap, Configuration configuration) {
        helper.addToMap(stringObjectMap, configuration);
    }

    /**
     * Extracts and returns a {@link Configuration} from a {@link Bundle} after the Configuration has been added to
     * the Bundle using {@link ConfigurationHelper#addToBundle(Bundle, Configuration)}.
     *
     * @param bundle the {@link Bundle} to extract the {@link Configuration} of the given type from.
     * @param clazz the class type to extract.
     * @param <E> the type of the {@link Configuration} that will be returned.
     * @return the {@link Configuration} of the specified class type retrieved from the {@link Bundle}
     *
     * @deprecated Please use {@link ConfigurationHelper#fromBundle(Bundle, Class)} instead.
     */
    @Nullable
    public static <E extends Configuration> E fromBundle(Bundle bundle, Class<E> clazz) {
        return helper.fromBundle(bundle, clazz);
    }

    /**
     * Extracts and returns a {@link Configuration} from a {@link Map} after the Configuration has been added to
     * the Map using {@link ConfigurationHelper#addToMap(Map, Configuration)}.
     *
     * @param stringObjectMap the {@link Map} to extract a {@link Configuration} from.
     * @param clazz the class type to extract.
     * @param <E> the type of the {@link Configuration} that will be returned.
     * @return the {@link Configuration} of the specified class type retrieved from the {@link Map}
     *
     * @deprecated Please use {@link ConfigurationHelper#fromMap(Map, Class)} instead.
     */
    @Nullable
    public static <E extends Configuration> E fromMap(Map<String, Object> stringObjectMap, Class<E> clazz) {
        return helper.fromMap(stringObjectMap, clazz);
    }

    /**
     * Extracts and returns a list of {@link Configuration}s from a {@link Map}.
     *
     * @param data the Map to extract Configurations from.
     * @return a list of the Configurations extracted from the Map, or null if none are found.
     *
     * @deprecated Please use {@link ConfigurationHelper#extractConfigsFromMap(Map)} instead.
     */
    @Nullable
    public static List<Configuration> extractConfigsFromMap(Map<String, Object> data) {
        return helper.extractConfigsFromMap(data);
    }

    /**
     * Finds and returns a {@link Configuration} of the given type in the given list.
     *
     * @param configs the list of {@link Configuration} to search.
     * @param clazz the class type to search for.
     * @param <E> the type of {@link Configuration} to search for.
     * @return a {@link Configuration} of the given type in the given list, or null if none are found.
     *
     * @deprecated Please use {@link ConfigurationHelper#findConfigForType(List, Class)} instead.
     */
    @Nullable
    public static <E extends Configuration> E findConfigForType(List<Configuration> configs, Class<E> clazz) {
        return helper.findConfigForType(configs, clazz);
    }

    /**
     * Takes a list of {@link Configuration}s and a single Configuration, and adds the single
     * Configuration to the list if it is not already in the list.
     *
     * Use this method to ensure that a given {@link Configuration} is in a list of Configurations
     * without adding a duplicate.
     *
     * @param configs the list of {@link Configuration} to add to.
     * @param configuration the {@link Configuration} to add.
     * @return a copy of the configs list passed to the method, with the {@link Configuration} added
     * if it was not already in the list.
     *
     * @deprecated Please use {@link ConfigurationHelper#addSelfIfNotInList(List, Configuration)} instead.
     */
    public static List<Configuration> addSelfIfNotInList(List<Configuration> configs, Configuration configuration) {
        return helper.addSelfIfNotInList(configs, configuration);
    }
}
