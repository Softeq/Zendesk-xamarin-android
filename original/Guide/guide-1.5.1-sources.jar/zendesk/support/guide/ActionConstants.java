package zendesk.support.guide;

interface ActionConstants {

    /**
     * Action string for Action Handlers which allow the user to contact
     */
    String ACTION_CONTACT_OPTION = "action_contact_option";

    /**
     * Action string for opening a conversation list UI (such as Support SDK's RequestListActivity).
     */
    String ACTION_CONVERSATION_LIST = "action_conversation_list";
}
