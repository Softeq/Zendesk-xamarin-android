package zendesk.support.guide;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.google.gson.JsonElement;
import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationUtil;
import zendesk.core.ActionDescription;
import zendesk.core.ActionHandler;

import okhttp3.HttpUrl;

class ViewArticleActionHandler implements ActionHandler {

    private static final String LOG_TAG = "ViewArticleActionHandle";

    @NonNull
    public static Map<String, Object> data(long id, @NonNull String title) {
        final Map<String, Object> data = new HashMap<>();
        data.put(HELP_CENTER_ARTICLE_ID, id);
        data.put(HELP_CENTER_ARTICLE_TITLE, title);

        return data;
    }

    static final String HELP_CENTER_VIEW_ARTICLE = "help_center_view_article";
    private static final String HELP_CENTER_ARTICLE_ID = "help_center_article_id";
    private static final String HELP_CENTER_ARTICLE_TITLE = "help_center_article_title";

    private static final String HC_PATH_ELEMENT_HC = "hc";
    private static final String HC_PATH_ELEMENT_ARTICLE = "articles";
    private static final String HC_PATH_ELEMENT_NAME_SEPARATOR = "-";

    @Override
    public boolean canHandle(String s) {
        HttpUrl httpUrl = HttpUrl.parse(s);
        if (httpUrl == null) {
            return false;
        }
        ActionPayload payload = parse(httpUrl);
        return payload.isValid();
    }

    @Override
    public void handle(@Nullable Map<String, Object> map, @NonNull Context context) {
        if (map == null) {
            Logger.w(LOG_TAG, "Property map is null, cannot open article.");
            return;
        }

        String action = (String) map.get(HELP_CENTER_VIEW_ARTICLE);
        if (StringUtils.isEmpty(action)) {
            return;
        }

        HttpUrl httpUrl = HttpUrl.parse(action);
        if (httpUrl == null) {
            return;
        }
        ActionPayload payload = parse(httpUrl);
        if (!payload.isValid()) {
            return;
        }
        long articleId;
        if (payload.payload.containsKey(HELP_CENTER_ARTICLE_ID)) {
            articleId = (long) payload.payload.get(HELP_CENTER_ARTICLE_ID);
        } else {
            return;
        }

        @SuppressLint("RestrictedApi")
        Configuration configuration = ConfigurationUtil.fromMap(map, Configuration.class);
        List<Configuration> configurations = configuration != null
                ? configuration.getConfigurations()
                : Collections.<Configuration>emptyList();

        ViewArticleActivity.builder(articleId)
                .show(context, configurations);
    }

    @Override
    public int getPriority() {
        return 0;
    }

    @Override
    public ActionDescription getActionDescription() {
        return null;
    }

    @Override
    public void updateSettings(Map<String, JsonElement> settings) {
        // Intentionally empty
    }

    @VisibleForTesting
    ActionPayload parse(@NonNull HttpUrl httpUrl) {
        final List<String> pathSegments = httpUrl.pathSegments();

        // A help center link consists of 3 or 4 segments.
        if (pathSegments.size() < 3 || pathSegments.size() > 4) {
            return ActionPayload.invalid(HELP_CENTER_VIEW_ARTICLE);
        }

        final int articleKeywordPathIndex = pathSegments.indexOf(HC_PATH_ELEMENT_ARTICLE);
        if (!(HC_PATH_ELEMENT_HC.equals(pathSegments.get(0)) && (articleKeywordPathIndex == 1
                || articleKeywordPathIndex == 2))) {
            return ActionPayload.invalid(HELP_CENTER_VIEW_ARTICLE);
        }

        if (articleKeywordPathIndex + 2 != pathSegments.size()) {
            return ActionPayload.invalid(HELP_CENTER_VIEW_ARTICLE);
        }

        final String pathSegment = pathSegments.get(articleKeywordPathIndex + 1);
        final String[] split = pathSegment.split(HC_PATH_ELEMENT_NAME_SEPARATOR);

        if (CollectionUtils.isEmpty(split)) {
            return ActionPayload.invalid(HELP_CENTER_VIEW_ARTICLE);
        }

        final Long articleId;

        try {
            articleId = Long.parseLong(split[0]);
        } catch (NumberFormatException e) {
            return ActionPayload.invalid(HELP_CENTER_VIEW_ARTICLE);
        }

        String articleName = "";

        final StringBuilder articleNameBuilder = new StringBuilder(pathSegment.length());
        if (split.length > 1) {
            for (int i = 1, len = split.length; i < len; i++) {
                articleNameBuilder.append(split[i]);
                articleNameBuilder.append(' ');
            }
            articleName = articleNameBuilder.toString().trim();
        }

        return ActionPayload.valid(HELP_CENTER_VIEW_ARTICLE,
                ViewArticleActionHandler.data(articleId, articleName));
    }

    static class ActionPayload {

        static ActionPayload invalid(String action) {
            return new ActionPayload(action, null);
        }

        static ActionPayload valid(String action, Map<String, Object> payload) {
            return new ActionPayload(action, payload);
        }

        private final String action;
        private final Map<String, Object> payload;

        private ActionPayload(String action, Map<String, Object> payload) {
            this.action = action;
            this.payload = payload;
        }

        public String getAction() {
            return action;
        }

        public Map<String, Object> getPayload() {
            return payload;
        }

        boolean isValid() {
            return StringUtils.hasLength(action) && payload != null;
        }
    }
}
