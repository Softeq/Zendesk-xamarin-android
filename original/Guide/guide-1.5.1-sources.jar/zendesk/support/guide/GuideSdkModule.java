package zendesk.support.guide;

import javax.inject.Singleton;

import zendesk.configurations.ConfigurationHelper;
import zendesk.core.ActionHandler;

import dagger.Module;
import dagger.Provides;

@Module
class GuideSdkModule {

    @Provides
    @Singleton
    static ActionHandler viewArticleActionHandler() {
        return new ViewArticleActionHandler();
    }

    @Provides
    ConfigurationHelper configurationHelper() {
        return new ConfigurationHelper();
    }
}
