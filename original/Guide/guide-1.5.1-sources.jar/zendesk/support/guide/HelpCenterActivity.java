package zendesk.support.guide;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;

import com.zendesk.guide.sdk.R;
import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import zendesk.commonui.InsetType;
import zendesk.commonui.SystemWindowInsets;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.ActionDescription;
import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.core.NetworkInfoProvider;
import zendesk.core.RetryAction;
import zendesk.classic.messaging.Engine;
import zendesk.classic.messaging.MessagingActivity;
import zendesk.support.HelpCenterProvider;
import zendesk.support.HelpCenterSettingsProvider;
import zendesk.support.SearchArticle;

/**
 * This Activity is the main entry point for showing Help Center content in the SDK.
 * <p>
 * This Activity is designed to be started with the {@link HelpCenterActivity#builder()}
 * </p>
 */
public class HelpCenterActivity extends AppCompatActivity implements HelpCenterMvp.View {

    /**
     * Create a new builder for HelpCenterActivity.
     */
    public static HelpCenterConfiguration.Builder builder() {
        return new HelpCenterConfiguration.Builder();
    }

    static final String LOG_TAG = "HelpCenterActivity";

    private HelpCenterMvp.Presenter presenter;

    private AppBarLayout appBarLayout ;
    private Toolbar toolbar;

    private FloatingActionButton contactUsButton;
    private View loadingView;

    private Snackbar errorSnackbar;
    private MenuItem conversationsMenuItem;
    private MenuItem searchViewMenuItem;

    private HelpCenterConfiguration helpCenterConfiguration;

    private SnackbarStatus snackbarStatus = SnackbarStatus.NONE;

    private List<Engine> engines;

    @Inject
    HelpCenterProvider helpCenterProvider;

    @Inject
    HelpCenterSettingsProvider settingsProvider;

    @Inject
    NetworkInfoProvider networkInfoProvider;

    @Inject
    ActionHandlerRegistry actionHandlerRegistry;

    @Inject
    ConfigurationHelper configurationHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Resources.Theme theme = getTheme();
        theme.applyStyle(R.style.ZendeskActivityDefaultTheme, true);
        theme.applyStyle(R.style.ZendeskSupportActivityThemeDefaultIcon, false);

        setContentView(R.layout.zs_activity_help_center);

        if (!GuideSdkDependencyProvider.INSTANCE.isInitialized()) {
            Logger.e(LOG_TAG, GuideSdkDependencyProvider.NOT_INITIALIZED_LOG);
            finish();
            return;
        }

        GuideSdkDependencyProvider.INSTANCE.provideGuideSdkComponent().inject(this);

        helpCenterConfiguration = configurationHelper
                .fromBundle(getIntent().getExtras(), HelpCenterConfiguration.class);

        if (helpCenterConfiguration == null) {
            Logger.e(LOG_TAG, "No configuration found. Please use HelpCenterActivity.builder()");
            finish();
            return;
        }

        engines = helpCenterConfiguration.getEngines();

        ActionBar actionBar = initToolbar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        loadingView = findViewById(R.id.loading_view);

        contactUsButton = findViewById(R.id.contact_us_button);
        contactUsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showContactZendesk();
            }
        });

        presenter = new HelpCenterPresenter(this, new HelpCenterModel(helpCenterProvider, settingsProvider),
                networkInfoProvider, actionHandlerRegistry);
        presenter.init(helpCenterConfiguration, engines);

        addOnBackStackChangedListener();

        applyWindowInsets();
    }

    private ActionBar initToolbar() {
        appBarLayout = findViewById(R.id.appbar_help_center);
        toolbar = findViewById(R.id.support_toolbar);
        View toolbarShadow = findViewById(R.id.support_compat_shadow);
        toolbarShadow.setVisibility(View.GONE);

        setSupportActionBar(toolbar);
        return getSupportActionBar();
    }

    /**
     * The HelpCenterFragment is hidden in a FragmentTransaction in {@link HelpCenterActivity#showLoadingState()},
     * so that the loading spinner can show without the Help Center content being displayed behind
     * it. Search results are displayed in a HelpSearchFragment, which replaces the HelpCenterFragment
     * in a FragmentTransaction which is added to the back stack. This listener listens for that
     * back stack change, and resets the visibility of the HelpCenterFragment so that it is no
     * longer hidden.
     */
    private void addOnBackStackChangedListener() {
        getSupportFragmentManager()
                .addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
                    @Override
                    public void onBackStackChanged() {
                        if (getCurrentFragment().isHidden()) {
                            getSupportFragmentManager()
                                    .beginTransaction()
                                    .show(getCurrentFragment())
                                    .commit();
                            if (getCurrentFragment() instanceof HelpCenterFragment) {
                                ((HelpCenterFragment) getCurrentFragment()).setPresenter(presenter);
                            }
                        }
                    }
                });
    }


    private boolean noFragmentAdded() {
        return getCurrentFragment() == null;
    }

    @Override
    protected void onStart() {
        super.onStart();
        //show snack bar on return to screen if it was previously shown
        if (snackbarStatus != SnackbarStatus.NONE && errorSnackbar != null) {
            errorSnackbar.show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (presenter != null) {
            presenter.onResume(this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (presenter != null) {
            presenter.onPause();
        }
    }

    private void applyWindowInsets() {
        SystemWindowInsets.applyWindowInsets(appBarLayout, InsetType.TOP);
        SystemWindowInsets.applyWindowInsets(toolbar, InsetType.HORIZONTAL);
        SystemWindowInsets.applyWindowInsets(findViewById(R.id.fragment_container),
                InsetType.BOTTOM, InsetType.HORIZONTAL
        );
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.

        getMenuInflater().inflate(R.menu.zs_fragment_help_menu_conversations, menu);

        conversationsMenuItem = menu.findItem(R.id.fragment_help_menu_contact);
        searchViewMenuItem = menu.findItem(R.id.fragment_help_menu_search);

        if (searchViewMenuItem != null) {

            if (!networkInfoProvider.isNetworkAvailable()) {
                searchViewMenuItem.setEnabled(false);
            }

            SearchView searchView = (SearchView) searchViewMenuItem.getActionView();

            // Add the IME_FLAG_NO_EXTRACT_UI for a better experience in landscape mode
            searchView.setImeOptions(searchView.getImeOptions() | EditorInfo.IME_FLAG_NO_EXTRACT_UI);

            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {

                    if (presenter != null) {
                        presenter.onSearchSubmit(query);
                        return true;
                    } else {
                        return false;
                    }
                }

                @Override
                public boolean onQueryTextChange(String newText) {
                    return false;
                }
            });
        }

        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {

        if (presenter != null && searchViewMenuItem != null) {
            searchViewMenuItem.setVisible(presenter.shouldShowSearchMenuItem());
        }

        if (presenter != null && conversationsMenuItem != null) {
            boolean hasConversationsActionHandler = actionHandlerRegistry
                    .handlerByAction(ActionConstants.ACTION_CONVERSATION_LIST) != null;

            conversationsMenuItem.setVisible(presenter.shouldShowConversationsMenuItem()
                    && hasConversationsActionHandler);
        }

        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        if (id == R.id.fragment_help_menu_contact) {
            showRequestList();
            return true;
        }

        return false;
    }

    @Override
    public void showContactUsButton() {
        contactUsButton.setVisibility(View.VISIBLE);
    }

    @Override
    public void showHelp(HelpCenterConfiguration helpCenterUiConfig) {
        if (noFragmentAdded()) {
            HelpCenterFragment fragment = HelpCenterFragment.newInstance(helpCenterUiConfig);

            fragment.setPresenter(presenter);
            addFragment(fragment);

        } else if (getCurrentFragment() instanceof HelpCenterFragment) {
            ((HelpCenterFragment) getCurrentFragment()).setPresenter(presenter);
        }

        invalidateOptionsMenu();
    }

    private void addFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.fragment_container, fragment, fragment.getClass().getSimpleName())
                .commit();
    }

    @Override
    public void showLoadingState() {
        Fragment fragment = getCurrentFragment();
        if (fragment != null && fragment.isVisible()) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .hide(getCurrentFragment())
                    .commit();
        }
        loadingView.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideLoadingState() {
        loadingView.setVisibility(View.GONE);
    }

    @Override
    public void showSearchResults(List<SearchArticle> searchArticles, String query) {
        HelpSearchFragment searchFragment = getSearchFragment();
        searchFragment.updateResults(searchArticles, query);
    }

    private Fragment getCurrentFragment() {
        return getSupportFragmentManager().findFragmentById(R.id.fragment_container);
    }

    /**
     * Gets a HelpSearchFragment. If one already exists, it will be returned.
     *
     * @return an instance of HelpSearchFragment
     */
    private HelpSearchFragment getSearchFragment() {

        if (getCurrentFragment() instanceof HelpSearchFragment) {
            Logger.d(LOG_TAG, "showSearchResults: current fragment is a HelpSearchFragment");
            return (HelpSearchFragment) getCurrentFragment();
        }

        HelpSearchFragment searchFragment =
                HelpSearchFragment.newInstance(helpCenterConfiguration, helpCenterProvider);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, searchFragment)
                .addToBackStack(null)
                .commit();

        return searchFragment;
    }

    @Override
    public void clearSearchResults() {
        if (getCurrentFragment() instanceof HelpSearchFragment) {
            ((HelpSearchFragment) getCurrentFragment()).clearResults();
        }
    }

    @Override
    public void setSearchEnabled(boolean enabled) {
        searchViewMenuItem.setEnabled(enabled);
    }

    @Override
    public boolean isShowingHelp() {
        return getCurrentFragment() instanceof HelpCenterFragment;
    }

    @Override
    public void showRequestList() {
        ActionHandler actionHandler = actionHandlerRegistry.handlerByAction(ActionConstants.ACTION_CONVERSATION_LIST);

        if (actionHandler != null) {
            Map<String, Object> data = new HashMap<>();

            configurationHelper.addToMap(data, helpCenterConfiguration);

            actionHandler.handle(data, this);
        }
    }

    @Override
    public void showContactZendesk() {
        Map<String, Object> configurationMap = new HashMap<>();
        configurationHelper.addToMap(configurationMap, helpCenterConfiguration);

        if (CollectionUtils.isNotEmpty(engines)) {
            MessagingActivity.builder()
                    .withEngines(engines)
                    .show(this, helpCenterConfiguration.getConfigurations());
        } else {
            showCreateRequest(configurationMap);
        }
    }

    private void showCreateRequest(Map<String, Object> uiConfigMap) {
        ActionHandler contactActionHandler = actionHandlerRegistry
                .handlerByAction(ActionConstants.ACTION_CONTACT_OPTION);
        if (contactActionHandler != null) {
            ActionDescription actionDescription = contactActionHandler.getActionDescription();
            String actionName = actionDescription != null
                    ? actionDescription.getLocalizedLabel() : contactActionHandler.getClass().getSimpleName();
            Logger.d(LOG_TAG, "No Deflection ActionHandler Available, opening %s", actionName);
            contactActionHandler.handle(uiConfigMap, this);
        }
    }

    @Override
    public void showLoadArticleErrorWithRetry(HelpCenterMvp.ErrorType errorType, final RetryAction action) {

        String errorMessage;

        if (errorType == null) {
            Logger.w(LOG_TAG, "ErrorType was null, falling back to 'retry' as label");
            errorMessage = getString(R.string.zui_retry_button_label);
        } else {
            switch (errorType) {
                case CATEGORY_LOAD:
                    errorMessage = getString(R.string.support_categories_list_fragment_error_message);
                    break;
                case SECTION_LOAD:
                    errorMessage = getString(R.string.support_sections_list_fragment_error_message);
                    break;
                case ARTICLES_LOAD:
                    errorMessage = getString(R.string.support_articles_list_fragment_error_message);
                    break;
                default:
                    Logger.w(LOG_TAG, "Unknown or unhandled error type, falling back to error type name as label");
                    errorMessage = getString(R.string.support_help_search_no_results_label) + " " + errorType.name();
                    break;
            }
        }

        if (snackbarStatus == SnackbarStatus.NONE) {
            errorSnackbar = Snackbar.make(contactUsButton, errorMessage, Snackbar.LENGTH_INDEFINITE);
            errorSnackbar.setAction(R.string.zui_retry_button_label, new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    errorSnackbar.dismiss();
                    snackbarStatus = SnackbarStatus.NONE;
                    action.onRetry();
                }
            });
            errorSnackbar.show();
            snackbarStatus = SnackbarStatus.CONTENT_ERROR;
        }
    }

    @Override
    public void showNoConnectionError() {
        if (snackbarStatus != SnackbarStatus.NO_CONNECTION) {
            errorSnackbar = Snackbar.make(contactUsButton, R.string.zg_general_no_connection_message, Snackbar
                    .LENGTH_INDEFINITE);
            errorSnackbar.show();
            snackbarStatus = SnackbarStatus.NO_CONNECTION;
        }
    }

    @Override
    public void dismissError() {
        if (errorSnackbar != null) {
            errorSnackbar.dismiss();
        }
        snackbarStatus = SnackbarStatus.NONE;
    }

    @Override
    public Context getContext() {
        return getApplicationContext();
    }

    @Override
    public void exitActivity() {
        finish();
    }

    @Override
    public void announceContentLoaded() {
        contactUsButton.announceForAccessibility(getString(R.string.zs_help_center_content_loaded_accessibility));
    }

    private enum SnackbarStatus {
        NO_CONNECTION, NONE, CONTENT_ERROR
    }
}
