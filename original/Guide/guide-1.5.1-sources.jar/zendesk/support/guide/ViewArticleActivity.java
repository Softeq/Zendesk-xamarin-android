package zendesk.support.guide;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.os.ConfigurationCompat;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.zendesk.guide.sdk.R;
import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.SafeZendeskCallback;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.FileUtils;
import com.zendesk.util.StringUtils;

import java.io.InputStream;
import java.nio.charset.Charset;
import java.text.DateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.inject.Inject;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import zendesk.commonui.InsetType;
import zendesk.commonui.SystemWindowInsets;
import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.ActionDescription;
import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.core.AnonymousIdentity;
import zendesk.core.ApplicationConfiguration;
import zendesk.core.Identity;
import zendesk.core.NetworkAware;
import zendesk.core.NetworkInfoProvider;
import zendesk.core.UrlHelper;
import zendesk.core.Zendesk;
import zendesk.classic.messaging.Engine;
import zendesk.classic.messaging.MessagingActivity;
import zendesk.support.Article;
import zendesk.support.ArticleVoteStorage;
import zendesk.support.AttachmentType;
import zendesk.support.HelpCenterAttachment;
import zendesk.support.HelpCenterProvider;
import zendesk.support.HelpCenterSettings;
import zendesk.support.HelpCenterSettingsProvider;

/**
 * Activity used to render a Help Center article
 * <p>
 * The recommended method of creating the activity is by using the following
 * <ul>
 * <li>{@link ViewArticleActivity#builder(Article)}</li> or
 * <li>{@link ViewArticleActivity#builder(long)}</li>
 * </ul>
 * methods.
 * </p>
 */
public class ViewArticleActivity extends AppCompatActivity implements ListView.OnItemClickListener {

    /**
     * Create a new builder for ViewArticleActivity.
     *
     * @param article an article model loaded from {@link HelpCenterProvider}
     */
    public static ArticleConfiguration.Builder builder(@NonNull Article article) {
        return new ArticleConfiguration.Builder(article);
    }

    /**
     * Create a new builder for ViewArticleActivity.
     *
     * @param articleId the id of the article to display
     */
    public static ArticleConfiguration.Builder builder(long articleId) {
        return new ArticleConfiguration.Builder(articleId);
    }

    /**
     * Create a new builder for ViewArticleActivity.
     * <p>
     * Only use this for creating a {@link Configuration} for ViewArticleActivity
     * </p>
     */
    public static ArticleConfiguration.Builder builder() {
        return new ArticleConfiguration.Builder();
    }

    static final String LOG_TAG = "ViewArticleActivity";

    private static final String ARTICLE_DETAIL_FORMAT_STRING = "%s %s <span dir=\"auto\">%s</span>";
    private static final String TYPE_TEXT_HTML = "text/html";
    private static final String UTF_8_ENCODING_TYPE = "UTF-8";
    private static final String CSS_FILE = "file:///android_asset/help_center_article_style.css";
    private static final long FETCH_ATTACHMENTS_DELAY_MILLIS = 250L;
    private static final Integer NETWORK_AWARE_ID = 57564;

    private Long articleId;
    private ArticleViewModel article;

    private SafeZendeskCallback<List<HelpCenterAttachment>> attachmentRequestCallback;
    private final AggregatedCallback<HelpCenterSettings> settingsAggregatedCallback = new AggregatedCallback<>();
    private ArticleAttachmentAdapter adapter;

    private ProgressBar progressView;
    private WebView articleContentWebView;
    private ListView attachmentListView;
    private CoordinatorLayout coordinatorLayout;

    private final Handler handler = new Handler();
    private ArticleVotingView articleVotingView;

    private AppBarLayout appBarLayout;
    private Toolbar toolbar;
    private View viewArticleFrame;

    private ArticleConfiguration config;
    private List<Engine> engines;

    private Snackbar snackbar;

    @Inject
    OkHttpClient okHttpClient;

    @Inject
    ApplicationConfiguration applicationConfiguration;

    @Inject
    HelpCenterProvider helpCenterProvider;

    @Inject
    ArticleVoteStorage articleVoteStorage;

    @Inject
    NetworkInfoProvider networkInfoProvider;

    @Inject
    HelpCenterSettingsProvider settingsProvider;

    @Inject
    ActionHandlerRegistry actionHandlerRegistry;

    @Inject
    ConfigurationHelper configurationHelper;


    @SuppressLint({"SetJavaScriptEnabled", "RestrictedApi"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getTheme().applyStyle(R.style.ZendeskActivityDefaultTheme, true);
        setContentView(R.layout.zs_activity_view_article);

        if (!GuideSdkDependencyProvider.INSTANCE.isInitialized()) {
            Logger.e(LOG_TAG, GuideSdkDependencyProvider.NOT_INITIALIZED_LOG);
            finish();
            return;
        }

        GuideSdkDependencyProvider.INSTANCE.provideGuideSdkComponent().inject(this);

        ActionBar actionBar = initToolbar();
        config = configurationHelper.fromBundle(getIntent().getExtras(), ArticleConfiguration.class);

        if (config == null || config.getConfigurationState() == ArticleConfiguration.UNKNOWN) {
            Logger.e(LOG_TAG, "No configuration found. Please use ViewArticleActivity.builder()");
            finish();
            return;
        }
        engines = config.getEngines();

        viewArticleFrame = findViewById(R.id.view_article_frame);

        attachmentListView = findViewById(R.id.view_article_attachment_list);
        adapter = new ArticleAttachmentAdapter(this);
        attachmentListView.setAdapter(adapter);
        attachmentListView.setOnItemClickListener(ViewArticleActivity.this);

        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        articleContentWebView = findViewById(R.id.view_article_content_webview);
        articleContentWebView.setWebChromeClient(new WebChromeClient());
        articleContentWebView.getSettings().setJavaScriptEnabled(true);

        setupRequestInterceptor();

        /*
          This is insecure but it is required in order to load the css from a file:/// URI.
          I think we are safer than would be normal when enabling this because we are presenting
          a sanitised set of data in the first instance.  Without this the local CSS is not served
          to the webview on Lollipop and later.
         */
        articleContentWebView.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        progressView = findViewById(R.id.view_article_progress);
        coordinatorLayout = findViewById(R.id.view_article_attachment_coordinator);

        if (config.getConfigurationState() == ArticleConfiguration.ARTICLE_MODEL) {
            article = config.getArticle();
            if (article != null) {
                articleId = article.getId();
            }
            loadArticleBody();
        } else {
            fetchArticle(config.getArticleId());
            articleId = config.getArticleId();
        }


        if (shouldShowContactUsButton()) {

            FloatingActionButton contactUsButton = findViewById(R.id.contact_us_button);
            contactUsButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showContactZendesk();
                }
            });
            contactUsButton.setVisibility(View.VISIBLE);
        }

        articleVotingView = findViewById(R.id.article_voting_container);
        articleVotingView.bindTo(articleId, articleVoteStorage, helpCenterProvider);
        articleVotingView.setVisibility(View.GONE);
        applyVoteButtonSettings();
        applyWindowInsets();
    }

    private ActionBar initToolbar() {
        appBarLayout = findViewById(R.id.appbar_view_article);
        toolbar = findViewById(R.id.view_article_toolbar);
        View toolbarShadow = findViewById(R.id.view_article_compat_shadow);
        toolbarShadow.setVisibility(View.GONE);

        setSupportActionBar(toolbar);
        return getSupportActionBar();
    }

    private void applyWindowInsets() {
        SystemWindowInsets.applyWindowInsets(appBarLayout, InsetType.TOP);
        SystemWindowInsets.applyWindowInsets(toolbar, InsetType.HORIZONTAL);
        SystemWindowInsets.applyWindowInsets(
                viewArticleFrame,
                InsetType.HORIZONTAL
        );
    }

    private boolean shouldShowContactUsButton() {
        boolean hasContactUsActionHandler = actionHandlerRegistry
                .handlerByAction(ActionConstants.ACTION_CONTACT_OPTION) != null;
        boolean hasEngines = CollectionUtils.isNotEmpty(engines);

        return config.isContactUsButtonVisible() && (hasContactUsActionHandler || hasEngines);
    }

    public void showContactZendesk() {
        Map<String, Object> uiConfigMap = new HashMap<>();
        configurationHelper.addToMap(uiConfigMap, config);

        if (CollectionUtils.isNotEmpty(engines)) {
            MessagingActivity.builder()
                    .withEngines(engines)
                    .show(this, config.getConfigurations());
        } else {
            showCreateRequest(uiConfigMap);
        }
    }

    private void showCreateRequest(Map<String, Object> uiConfigMap) {
        ActionHandler contactActionHandler = actionHandlerRegistry
                .handlerByAction(ActionConstants.ACTION_CONTACT_OPTION);
        if (contactActionHandler != null) {
            ActionDescription actionDescription = contactActionHandler.getActionDescription();
            String actionName = actionDescription != null
                    ? actionDescription.getLocalizedLabel() : contactActionHandler.getClass().getSimpleName();
            Logger.d(LOG_TAG, "No Deflection ActionHandler Available, opening %s", actionName);
            contactActionHandler.handle(uiConfigMap, this);
        }
    }

    private void setupRequestInterceptor() {


        if (articleContentWebView == null) {
            Logger.w(LOG_TAG, "The webview is null. Make sure you initialise it before trying to add the interceptor");
            return;
        }

        articleContentWebView.setWebViewClient(new WebViewClient() {

            /**
             * I am suppressing the deprecation warnings because using the non deprecated versions
             * require API 21 and above.
             *
             * We should periodically review this.
             *
             *      Today I reviewed it. No change - Borry
             *      Today I reviewed it. No change - Richard
             */
            @SuppressWarnings("deprecation")
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {

                @SuppressLint("RestrictedApi")
                final String subDomain = applicationConfiguration.getZendeskUrl();
                if (StringUtils.isEmpty(subDomain) || !url.startsWith(subDomain)) {
                    Logger.w(LOG_TAG, "Will not intercept request because the url is not hosted by Zendesk" + url);
                    return super.shouldInterceptRequest(view, url);
                }

                InputStream content = null;
                String contentType = null;
                String contentEncoding = null;

                Identity identity = Zendesk.INSTANCE.getIdentity();

                if (UrlHelper.isGuideRequest(url) && identity instanceof AnonymousIdentity) {
                    Logger.w(LOG_TAG, "Will not intercept request because it is anonymous guide request");
                    return super.shouldInterceptRequest(view, url);
                }

                try {
                    final Request request = new Request.Builder().url(url).build();
                    final Response response = okHttpClient.newCall(request).execute();

                    if (response != null && response.isSuccessful() && response.body() != null) {
                        content = response.body().byteStream();

                        final MediaType mediaType = response.body().contentType();
                        if (mediaType != null) {

                            if (StringUtils.hasLength(mediaType.type()) && StringUtils.hasLength(mediaType.subtype())) {
                                contentType = String.format(Locale.US, "%s/%s", mediaType.type(), mediaType.subtype());
                            }

                            final Charset charset = mediaType.charset();
                            if (charset != null) {
                                contentEncoding = charset.name();
                            }
                        }
                    }

                } catch (Exception e) {
                    Logger.e(LOG_TAG, "Exception encountered when trying to intercept request", e);
                }

                return new WebResourceResponse(contentType, contentEncoding, content);
            }

            @Override
            public boolean shouldOverrideUrlLoading(final WebView view, final String url) {
                // return true --> leave WebView
                // return false --> load in WebView
                ActionHandler handler = actionHandlerRegistry.handlerByAction(url);
                if (handler != null && url.contains(applicationConfiguration.getZendeskUrl())) {
                    Map<String, Object> data = new HashMap<>();
                    data.put(ViewArticleActionHandler.HELP_CENTER_VIEW_ARTICLE, url);
                    configurationHelper.addToMap(data, config);
                    handler.handle(data, ViewArticleActivity.this);
                    return true;
                } else {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    PackageManager packageManager = view.getContext().getPackageManager();
                    if (browserIntent.resolveActivity(packageManager) != null) {
                        view.getContext().startActivity(browserIntent);
                        return true;
                    } else {
                        Logger.d(LOG_TAG, "No browser available to open url: " + url);
                        return false;
                    }
                }
            }
        });
    }

    /**
     * Goal of this code is to calculate the height of the list view, as it is part of a scroll view,
     * we need to manually tell the view to resize accordingly
     *
     * @param listView listview to be sized and re-laid out
     */
    private static void setListViewHeightBasedOnChildren(ListView listView) {
        ListAdapter listAdapter = listView.getAdapter();
        if (listAdapter == null) {
            return;
        }

        int desiredWidth = View.MeasureSpec.makeMeasureSpec(listView.getWidth(), View.MeasureSpec.UNSPECIFIED);
        int totalHeight = 0;
        View view = null;
        for (int i = 0; i < listAdapter.getCount(); i++) {
            view = listAdapter.getView(i, view, listView);
            if (i == 0) {
                view.setLayoutParams(new ViewGroup.LayoutParams(desiredWidth, ViewGroup.LayoutParams.WRAP_CONTENT));
            }

            view.measure(desiredWidth, View.MeasureSpec.UNSPECIFIED);
            totalHeight += view.getMeasuredHeight();
        }
        ViewGroup.LayoutParams params = listView.getLayoutParams();
        params.height = totalHeight + (listView.getDividerHeight() * (listAdapter.getCount() - 1));
        listView.setLayoutParams(params);
        listView.requestLayout();
    }

    @Override
    protected void onStart() {
        super.onStart();
        this.attachmentRequestCallback = SafeZendeskCallback.from(new AttachmentRequestCallback());
        networkInfoProvider.addNetworkAwareListener(NETWORK_AWARE_ID, networkConnectionCallbacks);
        networkInfoProvider.register();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (attachmentRequestCallback != null) {
            attachmentRequestCallback.cancel();
            attachmentRequestCallback = null;
        }
        networkInfoProvider.removeNetworkAwareListener(NETWORK_AWARE_ID);
        networkInfoProvider.unregister();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Fetch attachments for the current Article from Help Center instance
     */
    private void fetchAttachmentsForArticle(long articleId) {
        setLoadingState(LoadingState.LOADING);
        helpCenterProvider.getAttachments(articleId, AttachmentType.BLOCK, attachmentRequestCallback);
    }

    private void fetchArticle(final long articleId) {
        setLoadingState(LoadingState.LOADING);
        helpCenterProvider.getArticle(articleId, new ZendeskCallback<Article>() {
            @Override
            public void onSuccess(Article result) {
                article = new ArticleViewModel(result);
                loadArticleBody();
            }

            @Override
            public void onError(ErrorResponse error) {
                setLoadingState(LoadingState.ERRORED);
            }
        });
    }

    @SuppressLint("RestrictedApi")
    private void loadArticleBody() {
        //Check if loading is finished before rendering content
        setTitle(getString(R.string.zs_view_article_loaded_accessibility, article.getTitle()));
        setLoadingState(LoadingState.DISPLAYING);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(UiUtils.decodeHtmlEntities(article.getTitle()));
        }

        String dateFormatted = null;
        String authorName = article.getAuthorName();

        if (article.getCreatedAt() != null) {
            Locale locale = ConfigurationCompat.getLocales(getResources().getConfiguration()).get(0);
            DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG, locale);
            dateFormatted = dateFormat.format(article.getCreatedAt());
        }

        String details = (dateFormatted != null && authorName != null)
                ? String.format(
                Locale.US, ARTICLE_DETAIL_FORMAT_STRING, authorName,
                getString(R.string.view_article_seperator), dateFormatted)
                : "";

        // Build article HTML content
        String html = getString(R.string.view_article_html_body, CSS_FILE, article.getTitle(), article.getBody(),
                details);

        articleContentWebView.loadDataWithBaseURL(
                applicationConfiguration.getZendeskUrl(),
                html,
                TYPE_TEXT_HTML,
                UTF_8_ENCODING_TYPE,
                null);

        //Lazy loading of web view was causing an issue with how we load attachments.
        //Using a postDelay handler instead
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                fetchAttachmentsForArticle(article.getId());
                applyVoteButtonSettings();
            }
        }, FETCH_ATTACHMENTS_DELAY_MILLIS);
    }

    /**
     * Sets the loading state of this fragment.
     * <p>
     * This controls the visibility of the views in this fragment and starts / stops progress
     * indicators.
     * </p>
     *
     * @param loadingState The loading state to set.
     */
    protected void setLoadingState(LoadingState loadingState) {
        if (loadingState == null) {
            Logger.w(LOG_TAG, "LoadingState was null, nothing to do");
            return;
        }

        switch (loadingState) {
            case LOADING: {
                UiUtils.setVisibility(progressView, View.VISIBLE);
                UiUtils.setVisibility(attachmentListView, View.GONE);
                break;
            }
            case DISPLAYING: {
                UiUtils.setVisibility(progressView, View.GONE);
                UiUtils.setVisibility(attachmentListView, View.VISIBLE);
                break;
            }
            case ERRORED: {
                showLoadingErrorState(R.string.zs_view_article_error);
                break;
            }
            case ERRORED_ATTACHMENT: {
                showLoadingErrorState(R.string.view_article_attachments_error);
                break;
            }
        }
    }

    public void showLoadingErrorState(@StringRes int snackbarText) {
        UiUtils.setVisibility(progressView, View.GONE);
        UiUtils.setVisibility(attachmentListView, View.GONE);

        dimissSnackBar();
        snackbar = Snackbar.make(coordinatorLayout, snackbarText, Snackbar.LENGTH_INDEFINITE)
                .setAction(R.string.zui_retry_button_label, new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (articleId != null && article == null) {
                            fetchArticle(articleId);
                        } else if (article != null) {
                            fetchAttachmentsForArticle(article.getId());
                        }
                        dimissSnackBar();
                    }
                });
        snackbar.show();
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Object item = parent.getItemAtPosition(position);
        //In absence of a story, I am just getting the HelpCenterAttachment URL and passing it to the Intent
        //VIEW_ACTION
        if (item instanceof HelpCenterAttachment) {
            HelpCenterAttachment attachment = (HelpCenterAttachment) item;

            if (attachment.getContentUrl() != null) {

                Uri attachmentUri = Uri.parse(attachment.getContentUrl());

                Intent viewAttachment = new Intent();
                viewAttachment.setAction(Intent.ACTION_VIEW);
                viewAttachment.setData(attachmentUri);
                startActivity(viewAttachment);
            } else {
                Logger.w(LOG_TAG, "Unable to launch viewer, unable to parse URI for attachment");
            }
        }
    }

    private void dimissSnackBar() {
        if (snackbar != null) {
            snackbar.dismiss();
            snackbar = null;
        }
    }

    private final NetworkAware networkConnectionCallbacks = new NetworkAware() {

        boolean connected = true;

        @Override
        public void onNetworkAvailable() {
            //prevents jitter two networks connecting at the same time (wifi & mobile)
            if (NetworkUtils.isConnectedOrConnecting(ViewArticleActivity.this)) {
                dimissSnackBar();
                connected = true;
                if (articleId != null && article == null) {
                    fetchArticle(articleId);
                } else if (article != null) {
                    fetchAttachmentsForArticle(article.getId());
                }
            }
        }

        //Permission handled by core
        @SuppressLint("MissingPermission")
        @Override
        public void onNetworkUnavailable() {
            //prevents jitter due to two networks connecting at the same time (wifi & mobile)
            if (!NetworkUtils.isConnectedOrConnecting(ViewArticleActivity.this) && connected) {
                connected = false;
                dimissSnackBar();
                snackbar = Snackbar.make(coordinatorLayout, R.string.zg_general_no_connection_message, Snackbar
                        .LENGTH_INDEFINITE);
                snackbar.show();
            }
        }
    };

    class AttachmentRequestCallback extends ZendeskCallback<List<HelpCenterAttachment>> {

        @Override
        public void onSuccess(List<HelpCenterAttachment> result) {
            adapter.clear();
            adapter.addAll(result);
            setListViewHeightBasedOnChildren(attachmentListView);
            setLoadingState(LoadingState.DISPLAYING);
        }

        @Override
        public void onError(ErrorResponse error) {
            adapter.clear();
            setLoadingState(LoadingState.ERRORED_ATTACHMENT);
            Logger.e(LOG_TAG, error);
        }
    }

    /**
     * ArticleAttachmentAdapter is the List Adapter to be used to render a list of Help Center Attachments associated
     * with an Article
     * For more information see
     * <a href="https://developer.zendesk.com/rest_api/docs/help_center/article_attachments"> Article Attachments in
     * Help Center</a>
     * Created by Zendesk on 23/09/2014.
     */
    private static class ArticleAttachmentAdapter extends ArrayAdapter<HelpCenterAttachment> {

        ArticleAttachmentAdapter(Context context) {
            super(context, R.layout.zs_row_article_attachment);
        }

        @NonNull
        @Override
        public View getView(int position, View convertView, @NonNull ViewGroup parent) {

            ArticleAttachmentRow sectionRow;

            if (convertView instanceof ArticleAttachmentRow) {
                sectionRow = (ArticleAttachmentRow) convertView;
            } else {
                sectionRow = new ArticleAttachmentRow(getContext());
            }

            sectionRow.bind(getItem(position));

            return sectionRow;
        }

    }

    /**
     * This is a custom {@link android.view.ViewGroup} that represents a row in the list as part of
     * {@link ViewArticleActivity}.
     * Created by Zendesk on 23/09/2014.
     */
    private static class ArticleAttachmentRow extends RelativeLayout {

        private final TextView fileName;
        private final TextView fileSize;

        public ArticleAttachmentRow(Context context) {
            super(context);
            inflate(context, R.layout.zs_row_article_attachment, this);
            fileName = findViewById(R.id.article_attachment_row_filename_text);
            fileSize = findViewById(R.id.article_attachment_row_filesize_text);
        }

        public void bind(HelpCenterAttachment attachment) {
            fileName.setText(attachment.getFileName());
            fileSize.setText(FileUtils.humanReadableFileSize(attachment.getSize()));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        settingsAggregatedCallback.cancel();
        if (articleContentWebView != null) {
            articleContentWebView.destroy();
        }
    }

    /**
     * Loads the settings
     *
     * @param callback the callback for the settings to be passed to
     */
    private void loadSettings(ZendeskCallback<HelpCenterSettings> callback) {
        if (settingsAggregatedCallback.add(callback)) {
            settingsProvider.getSettings(settingsAggregatedCallback);
        }
    }

    private void applyVoteButtonSettings() {
        loadSettings(new ZendeskCallback<HelpCenterSettings>() {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (helpCenterSettings.isArticleVotingEnabled()) {
                    articleVotingView.setVisibility(View.VISIBLE);
                } else {
                    articleVotingView.setVisibility(View.GONE);
                }
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                articleVotingView.setVisibility(View.GONE);
            }
        });
    }

    /**
     * This enum represents loading states that our UI elements can be in.
     * <p>
     * <ul>
     * <li>{@link #LOADING} An API call is currently taking place</li>
     * <li>{@link #DISPLAYING} We are displaying the results of an API call</li>
     * <li>{@link #ERRORED} A connection error occurred</li>
     * </ul>
     */
    private enum LoadingState {
        LOADING, DISPLAYING, ERRORED, ERRORED_ATTACHMENT
    }
}
