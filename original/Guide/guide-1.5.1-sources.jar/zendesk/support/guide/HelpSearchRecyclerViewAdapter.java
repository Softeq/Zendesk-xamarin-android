package zendesk.support.guide;

import android.content.Context;
import android.graphics.Typeface;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.zendesk.guide.sdk.R;
import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.LocaleUtil;
import com.zendesk.util.StringUtils;

import java.util.Collections;
import java.util.List;
import java.util.Locale;

import zendesk.support.HelpCenterProvider;
import zendesk.support.SearchArticle;

import static zendesk.support.guide.HelpCenterActivity.LOG_TAG;

/**
 * The adapter used in the Help search view
 */
class HelpSearchRecyclerViewAdapter extends RecyclerView.Adapter {

    private static final int TYPE_ARTICLE = 531;
    private static final int TYPE_NO_RESULTS = 441;
    private static final int TYPE_PADDING = 423;

    private List<SearchArticle> searchArticles;

    private String query;

    private boolean resultsCleared = false;

    private final HelpCenterConfiguration helpCenterUiConfig;
    private final HelpCenterProvider helpCenterProvider;

    /**
     * Creates an instance from the specified list of articles and the search query
     *
     * @param searchArticles The list of search articles to display
     * @param query          The query text corresponding to the list of articles
     */
    HelpSearchRecyclerViewAdapter(List<SearchArticle> searchArticles, String query, HelpCenterConfiguration
            helpCenterUiConfig, HelpCenterProvider helpCenterProvider) {
        this.searchArticles = searchArticles;
        this.query = query;
        this.helpCenterUiConfig = helpCenterUiConfig;
        this.helpCenterProvider = helpCenterProvider;
    }

    /**
     * Updates the backing data with new values
     *
     * @param searchArticles the new list of articles to display
     * @param query          The query text corresponding to the list of articles
     */
    void update(List<SearchArticle> searchArticles, String query) {
        this.resultsCleared = false;
        this.searchArticles = searchArticles;
        this.query = query;
        notifyDataSetChanged();
    }

    /**
     * clears the backing data, returning the view to an empty state
     */
    void clearResults() {
        this.resultsCleared = true;
        this.searchArticles = Collections.emptyList();
        this.query = StringUtils.EMPTY_STRING;
        notifyDataSetChanged();
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;
        switch (viewType) {
            case TYPE_ARTICLE:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.zs_row_search_article, parent, false);
                return new HelpSearchViewHolder(view, parent.getContext());
            case TYPE_NO_RESULTS:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.zs_row_no_articles_found, parent, false);
                return new NoResultsViewHolder(view);
            case TYPE_PADDING:
                view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.zs_row_padding, parent, false);
                return new PaddingViewHolder(view);

        }
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (TYPE_ARTICLE == getItemViewType(position)) {
            ((HelpSearchViewHolder) holder).bindTo(searchArticles.get(position));
        }
    }

    @Override
    public int getItemCount() {
        if (resultsCleared) {
            return 0;
        } else {
            // Minimum of 1, for no results, and an extra 1 if we're showing a FAB, for the padding below the last item.
            return Math.max(searchArticles.size() + getPaddingExtraItem(), 1);
        }
    }

    private int getPaddingExtraItem() {
        return helpCenterUiConfig.isContactUsButtonVisible() ? 1 : 0;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0 && searchArticles.size() == 0) {
            return TYPE_NO_RESULTS;
        } else if (position > 0 && position == searchArticles.size()) {
            return TYPE_PADDING;
        } else {
            return TYPE_ARTICLE;
        }
    }

    /**
     * View holder for items in a list of search results
     */
    private class HelpSearchViewHolder extends RecyclerView.ViewHolder {

        private TextView titleTextView;
        private TextView subtitleTextView;
        private Context context;

        HelpSearchViewHolder(View itemView, Context context) {
            super(itemView);

            titleTextView = itemView.findViewById(R.id.title);
            subtitleTextView = itemView.findViewById(R.id.subtitle);
            this.context = context;
        }

        void bindTo(final SearchArticle searchArticle) {

            if (searchArticle == null || searchArticle.getArticle() == null) {
                Logger.e(LOG_TAG, "The article was null, cannot bind the view.");
                return;
            }

            String title = (searchArticle.getArticle().getTitle() != null)
                    ? searchArticle.getArticle().getTitle()
                    : StringUtils.EMPTY_STRING;

            int startIndex = (query == null)
                    ? -1
                    : title.toLowerCase(Locale.getDefault()).indexOf(query.toLowerCase(Locale.getDefault()));

            if (startIndex != -1) {
                SpannableString spannableString = new SpannableString(title);

                spannableString.setSpan(
                        new StyleSpan(Typeface.BOLD),
                        startIndex, startIndex + query.length(),
                        Spannable.SPAN_INCLUSIVE_INCLUSIVE);

                titleTextView.setText(spannableString);
            } else {
                titleTextView.setText(title);
            }

            subtitleTextView.setText(context.getString(
                    R.string.help_search_subtitle_format,
                    searchArticle.getCategory().getName(), searchArticle.getSection().getName()));

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    helpCenterProvider.submitRecordArticleView(
                            searchArticle.getArticle(),
                            LocaleUtil.forLanguageTag(searchArticle.getArticle().getLocale()),
                            new ZendeskCallback<Void>() {
                                @Override
                                public void onSuccess(final Void result) {
                                    // intentionally empty
                                }

                                @Override
                                public void onError(final ErrorResponse error) {
                                    Logger.e(LOG_TAG,
                                            "Error submitting Help Center reporting: [reason] %s [isNetworkError] %s "
                                                    + "[status]"
                                                    + " %d",
                                            error.getReason(), error.isNetworkError(), error.getStatus());
                                }
                            }
                    );
                    ViewArticleActivity.builder(searchArticle.getArticle())
                            .show(itemView.getContext(), helpCenterUiConfig.getConfigurations());
                }
            });
        }
    }

    /**
     * View holder to use when there are no search results.
     */
    private class NoResultsViewHolder extends RecyclerView.ViewHolder {

        NoResultsViewHolder(View itemView) {
            super(itemView);
        }
    }

    private class PaddingViewHolder extends RecyclerView.ViewHolder {

        PaddingViewHolder(View itemView) {
            super(itemView);
        }
    }

}
