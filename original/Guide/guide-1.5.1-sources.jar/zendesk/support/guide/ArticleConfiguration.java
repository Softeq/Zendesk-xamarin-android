package zendesk.support.guide;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationHelper;
import zendesk.classic.messaging.Engine;
import zendesk.classic.messaging.EngineListRegistry;
import zendesk.classic.messaging.MessagingActivity;
import zendesk.support.Article;


/**
 * Data class, that represents the initial configuration of {@link ViewArticleActivity}. Use the
 * {@link Builder} to create an instance.
 */
public class ArticleConfiguration implements Configuration {

    static final int UNKNOWN = -1;
    static final int ARTICLE_ID = 1;
    static final int ARTICLE_MODEL = 2;

    private final int configurationState;
    private final ArticleViewModel article;
    private final long articleId;
    private final boolean contactUsVisible;
    private final List<Configuration> configurations;

    private final String engineRegistryId;

    private ArticleConfiguration(Builder builder, String engineRegistryId) {
        this.configurationState = builder.configurationState;
        this.article = builder.article;
        this.articleId = builder.articleId;
        this.contactUsVisible = builder.contactUsVisible;
        this.configurations = builder.configurations;
        this.engineRegistryId = engineRegistryId;
    }

    int getConfigurationState() {
        return configurationState;
    }

    ArticleViewModel getArticle() {
        return article;
    }

    long getArticleId() {
        return articleId;
    }

    public boolean isContactUsButtonVisible() {
        return contactUsVisible;
    }

    @SuppressLint("RestrictedApi")
    @Override
    public List<Configuration> getConfigurations() {
        return ConfigurationHelper.get().addSelfIfNotInList(configurations, this);
    }

    /**
     * Returns the list of {@link Engine}s that was set on {@link Builder#withEngines(Engine...)}.
     *
     * This method should not be called more than once, as retrieving the Engine list removes it from the internal
     * storage. As such, every subsequent call to this method  will return null.
     *
     * Note also that the {@link Builder} starts with an empty list rather than null.
     *
     * @return a List of {@link Engine}, or null.
     */
    @Nullable
    public List<Engine> getEngines() {
        return EngineListRegistry.INSTANCE.retrieveEngineList(engineRegistryId);
    }

    /**
     * This builder is used to generate an instance of {@link ArticleConfiguration}
     */
    public static class Builder {

        private int configurationState;
        private ArticleViewModel article;
        private long articleId;
        private boolean contactUsVisible = true;
        private List<Configuration> configurations = Collections.emptyList();
        private List<Engine> engines = Collections.emptyList();

        /**
         * Constructs an instance from the given articleId and title
         *
         * @param articleId The ID of the article you want to display
         */
        public Builder(long articleId) {
            this.articleId = articleId;
            this.configurationState = ARTICLE_ID;
        }

        /**
         * Constructs an instance from the given article model
         *
         * @param article The article that you want to display
         */
        public Builder(@NonNull Article article) {
            this.article = new ArticleViewModel(article);
            this.configurationState = ARTICLE_MODEL;
        }

        /**
         * Constructs an instance with a blank configuration
         */
        public Builder() {
            this.configurationState = UNKNOWN;
        }

        /**
         * Define which screens the "ContactUs" Floating Action Button should be shown on.
         *
         * @param contactUsVisible Boolean value to determine where the contact button is visible
         */
        public Builder withContactUsButtonVisible(boolean contactUsVisible) {
            this.contactUsVisible = contactUsVisible;
            return this;
        }

        /**
         * Specifies a list of {@link Engine}s to be used to drive a follow up conversation if the
         * user presses the contact FAB. They will be passed to the
         * {@link MessagingActivity#builder()#withEngines(List)} method. If no engines are provided,
         * the user will be shown the {@link zendesk.support.request.RequestActivity} instead.
         * <p>
         * The button may be hidden using the {@link #withContactUsButtonVisible(boolean)} method
         *
         * @param engines the List of Engines which will be used to start
         * {@link MessagingActivity}
         * @return The Builder
         */
        public Builder withEngines(List<Engine> engines) {
            this.engines = engines;
            return this;
        }

        /**
         * Specifies a list of {@link Engine}s to be used to drive a follow up conversation if the
         * user presses the contact FAB. They will be passed to the
         * {@link MessagingActivity#builder()#withEngines(List)} method. If no engines are provided,
         * the user will be shown the {@link zendesk.support.request.RequestActivity} instead.
         * <p>
         * The button may be hidden using the {@link #withContactUsButtonVisible(boolean)} method
         *
         * @param engines the List of Engines which will be used to start
         * {@link MessagingActivity}
         * @return The Builder
         */
        public Builder withEngines(Engine... engines) {
            return withEngines(Arrays.asList(engines));
        }

        /**
         * Configurations for screen that can be started from ViewArticleActivity.
         */
        private void setConfigurations(@NonNull List<Configuration> configurations) {
            if (CollectionUtils.isNotEmpty(configurations)) {

                this.configurations = configurations;

                final ArticleConfiguration config =
                        ConfigurationHelper.get().findConfigForType(configurations, ArticleConfiguration.class);

                if (config != null) {
                    this.contactUsVisible = config.isContactUsButtonVisible();
                    this.engines = EngineListRegistry.INSTANCE.retrieveEngineList(config.engineRegistryId);
                }
            }
        }

        /**
         * Shows the activity.
         *
         * @param context   The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for Activities that can be started from ViewArticleActivity.
         */
        public void show(@NonNull Context context, Configuration... configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Shows the activity.
         *
         * @param context   The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for Activities that can be started from ViewArticleActivity.
         */
        public void show(@NonNull Context context, List<Configuration> configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Create an {@link Intent} to start the {@link ViewArticleActivity} with the specified configuration
         * options.
         *
         * @param context   The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for Activities that can be started from ViewArticleActivity.
         * @return an {@link} Intent for {@link ViewArticleActivity} with the specified configuration
         * options
         */
        public Intent intent(@NonNull Context context, Configuration... configurations) {
            return intent(context, Arrays.asList(configurations));
        }

        /**
         * Create an {@link Intent} to start the {@link ViewArticleActivity} with the specified configuration
         * options.
         *
         * @param context   The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for Activities that can be started from ViewArticleActivity.
         * @return an {@link} Intent for {@link ViewArticleActivity} with the specified configuration
         * options
         */
        public Intent intent(@NonNull Context context, List<Configuration> configurations) {
            setConfigurations(configurations);

            final Configuration config = config();
            final Intent intent = new Intent(context, ViewArticleActivity.class);
            ConfigurationHelper.get().addToIntent(intent, config);

            return intent;
        }

        /**
         * Create a {@link Configuration} for the passed in configuration options.
         */
        @NonNull
        public Configuration config() {
            String engineRegistryId = EngineListRegistry.INSTANCE.register(engines);
            return new ArticleConfiguration(this, engineRegistryId);
        }

    }
}