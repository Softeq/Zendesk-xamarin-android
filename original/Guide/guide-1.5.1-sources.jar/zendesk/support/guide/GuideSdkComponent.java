package zendesk.support.guide;

import javax.inject.Singleton;

import zendesk.core.CoreModule;
import zendesk.support.GuideModule;

import dagger.Component;

@Singleton
@Component(modules = {
        CoreModule.class,
        GuideModule.class,
        GuideSdkModule.class
})
interface GuideSdkComponent {

    void inject(GuideSdkDependencyProvider guideSdkDependencyProvider);

    void inject(ViewArticleActivity viewArticleActivity);

    void inject(HelpCenterActivity helpCenterActivity);

    void inject(HelpCenterFragment helpCenterFragment);

}
