package zendesk.support.guide;

import androidx.annotation.NonNull;

import java.io.Serializable;
import java.util.Date;

import zendesk.support.Article;


class ArticleViewModel implements Serializable {

    private final long id;
    private final String title;
    private final String body;
    private final String authorName;
    private final Date createdAt;

    ArticleViewModel(@NonNull Article article) {
        this.id = article.getId();
        this.title = article.getTitle();
        this.body = article.getBody();
        this.createdAt = article.getCreatedAt();
        this.authorName = (article.getAuthor() == null) ? null : article.getAuthor().getName();
    }

    long getId() {
        return id;
    }

    String getTitle() {
        return title;
    }

    String getBody() {
        return body;
    }

    String getAuthorName() {
        return authorName;
    }

    Date getCreatedAt() {
        return createdAt;
    }
}
