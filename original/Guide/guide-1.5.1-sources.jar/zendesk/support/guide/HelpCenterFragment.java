package zendesk.support.guide;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zendesk.guide.sdk.R;

import javax.inject.Inject;

import zendesk.configurations.ConfigurationUtil;
import zendesk.core.NetworkInfoProvider;
import zendesk.support.HelpCenterProvider;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * A fragment to display Help Center content. The fragment is generally initialised with the
 * static factory method {@link HelpCenterFragment#newInstance(HelpCenterConfiguration)}. For Zendesk
 * internal use only.
 */
@RestrictTo(LIBRARY)
public class HelpCenterFragment extends Fragment {

    public static final String LOG_TAG = "HelpCenterFragment";

    private RecyclerView recyclerView;

    private HelpCenterMvp.Presenter presenter;

    private HelpRecyclerViewAdapter adapter;

    @Inject
    HelpCenterProvider helpCenterProvider;

    @Inject
    NetworkInfoProvider networkInfoProvider;

    /**
     * Sets the presenter which is used to communicate with the containing Activity. This method is
     * called when the Fragment is first created, and also when the Activity is recreated, as in an
     * orientation change, since the Fragment is retained (see {@code setRetainInstance(true)} in
     * {@code onCreate}.
     *
     * @param presenter the presenter which is used to communicate with the containing Activity
     */
    public void setPresenter(HelpCenterMvp.Presenter presenter) {
        this.presenter = presenter;

        if (adapter != null) {
            adapter.setContentUpdateListener(presenter);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);

        if (GuideSdkDependencyProvider.INSTANCE.isInitialized()) {
            @SuppressLint("RestrictedApi")
            final HelpCenterConfiguration config =
                    ConfigurationUtil.fromBundle(getArguments(), HelpCenterConfiguration.class);
            GuideSdkDependencyProvider.INSTANCE.provideGuideSdkComponent().inject(this);

            // Create the adapter only once, when the Fragment is created.
            adapter = new HelpRecyclerViewAdapter(config, helpCenterProvider, networkInfoProvider);

            if (presenter != null) {
                adapter.setContentUpdateListener(presenter);
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(R.layout.zs_fragment_help, container, false);

        recyclerView = view.findViewById(R.id.help_center_article_list);

        setupRecyclerView();

        return view;
    }

    private void setupRecyclerView() {
        recyclerView.setLayoutManager(
                new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        recyclerView.addItemDecoration(
                new SeparatorDecoration(ContextCompat.getDrawable(getContext(), R.drawable.zs_help_separator)));

        recyclerView.setAdapter(adapter);
    }

    /**
     * Creates an instance of the fragment with the given configuration
     *
     * @param helpCenterUiConfig the configuration to create the Fragment with
     * @return An instance of the fragment with the given configuration
     */
    @SuppressLint("RestrictedApi")
    public static HelpCenterFragment newInstance(HelpCenterConfiguration helpCenterUiConfig) {

        final Bundle args = new Bundle();
        ConfigurationUtil.addToBundle(args, helpCenterUiConfig);

        final HelpCenterFragment fragment = new HelpCenterFragment();
        fragment.setArguments(args);

        return fragment;
    }
}
