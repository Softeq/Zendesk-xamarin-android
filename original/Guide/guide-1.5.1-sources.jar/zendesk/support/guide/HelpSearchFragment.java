package zendesk.support.guide;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zendesk.guide.sdk.R;
import com.zendesk.util.StringUtils;

import java.util.Collections;
import java.util.List;

import zendesk.configurations.ConfigurationUtil;
import zendesk.support.HelpCenterProvider;
import zendesk.support.SearchArticle;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Fragment for the Help search results. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class HelpSearchFragment extends Fragment {

    private RecyclerView recyclerView;
    private HelpSearchRecyclerViewAdapter adapter;
    private List<SearchArticle> searchArticles = Collections.emptyList();
    private String query = StringUtils.EMPTY_STRING;
    private HelpCenterProvider helpCenterProvider;

    /**
     * Creates an instance of the Fragment using the given configuration and API provider
     *
     * @param helpCenterUiConfig The configuration for the Support screen
     * @param helpCenterProvider The API provider used to fetch content from Help Center
     * @return an instance of the Fragment using the given configuration and API provider
     */
    @SuppressLint("RestrictedApi")
    public static HelpSearchFragment newInstance(HelpCenterConfiguration helpCenterUiConfig, HelpCenterProvider
            helpCenterProvider) {

        final Bundle args = new Bundle();
        ConfigurationUtil.addToBundle(args, helpCenterUiConfig);

        final HelpSearchFragment fragment = new HelpSearchFragment();
        fragment.setArguments(args);
        fragment.helpCenterProvider = helpCenterProvider;

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setRetainInstance(true); // TODO: 14/11/2017 memory leak? investigate...
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.zs_fragment_help, container, false);

        recyclerView = view.findViewById(R.id.help_center_article_list);

        setupRecyclerView();

        return view;
    }

    /**
     * Updates the search results
     *
     * @param searchArticles The new search results to display
     * @param query          The query which was executed
     */
    public void updateResults(List<SearchArticle> searchArticles, String query) {
        this.searchArticles = searchArticles;
        this.query = query;

        if (adapter != null && recyclerView != null) {
            recyclerView.setVisibility(View.VISIBLE);
            adapter.update(searchArticles, query);

            recyclerView.announceForAccessibility(getString(R.string.zs_help_center_search_loaded_accessibility));
        }
    }

    /**
     * Clears the current results
     */
    public void clearResults() {
        if (adapter != null) {
            adapter.clearResults();
        }
    }

    private void setupRecyclerView() {
        @SuppressLint("RestrictedApi")
        HelpCenterConfiguration helpCenterUiConfig =
                ConfigurationUtil.fromBundle(getArguments(), HelpCenterConfiguration.class);

        recyclerView.setLayoutManager(
                new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));

        adapter = new HelpSearchRecyclerViewAdapter(searchArticles, query, helpCenterUiConfig, helpCenterProvider);

        recyclerView.setAdapter(adapter);
    }
}
