package zendesk.support.guide;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationHelper;
import zendesk.classic.messaging.Engine;
import zendesk.classic.messaging.EngineListRegistry;
import zendesk.classic.messaging.MessagingActivity;

import static zendesk.support.guide.HelpCenterActivity.LOG_TAG;

/**
 * Data class, that represents the initial configuration of {@link HelpCenterActivity}. Use the
 * {@link Builder} to create an instance.
 */
public class HelpCenterConfiguration implements Configuration {

    private final List<Long> categoryIds;
    private final List<Long> sectionIds;
    private final String[] labelNames;

    private final boolean contactUsButtonVisibility;
    private final boolean collapseCategories;
    private final boolean showConversationsMenuButton;

    private List<Configuration> configurations;

    private final String engineRegistryId;

    private HelpCenterConfiguration(Builder builder, String engineRegistryId) {
        this.categoryIds = builder.categoryIds;
        this.sectionIds = builder.sectionIds;
        this.labelNames = builder.labelNames;
        this.contactUsButtonVisibility = builder.contactUsButtonVisible;
        this.collapseCategories = builder.collapseCategories;
        this.showConversationsMenuButton = builder.showConversationsMenuButton;
        this.configurations = builder.configurations;
        this.engineRegistryId = engineRegistryId;
    }

    public List<Long> getCategoryIds() {
        return categoryIds;
    }

    public List<Long> getSectionIds() {
        return sectionIds;
    }

    public String[] getLabelNames() {
        return labelNames;
    }

    /**
     * Returns the list of {@link Engine}s that was set on {@link Builder#withEngines(Engine...)}.
     *
     * This method should not be called more than once, as retrieving the Engine list removes it from the internal
     * storage. As such, every subsequent call to this method  will return null.
     *
     * Note also that the {@link Builder} starts with an empty list rather than null.
     *
     * @return a List of {@link Engine}, or null.
     */
    @Nullable
    public List<Engine> getEngines() {
        return EngineListRegistry.INSTANCE.retrieveEngineList(engineRegistryId);
    }

    public boolean isContactUsButtonVisible() {
        return contactUsButtonVisibility;
    }

    public boolean isCollapseCategories() {
        return collapseCategories;
    }

    public boolean isShowConversationsMenuButton() {
        return showConversationsMenuButton;
    }

    @SuppressLint("RestrictedApi")
    @Override
    public List<Configuration> getConfigurations() {
        return ConfigurationHelper.get().addSelfIfNotInList(configurations, this);
    }

    /**
     * This builder is used to generate the startup configuration for the Activity. Note that
     * only one of the following may be specified. If you specify both, then the last to be
     * specified is used:
     *
     * <ul>
     * <li>withArticlesForCategoryIds</li>
     * <li>withArticlesForSectionIds</li>
     * </ul>
     */
    @SuppressWarnings("unused")
    public static class Builder {

        private List<Long> categoryIds = Collections.emptyList();
        private List<Long> sectionIds = Collections.emptyList();
        private String[] labelNames = new String[0];
        private List<Engine> engines = Collections.emptyList();

        private boolean contactUsButtonVisible = true;
        private boolean collapseCategories = false;
        private boolean showConversationsMenuButton = true;
        private List<Configuration> configurations = new ArrayList<>();

        /**
         * Creates a new Builder. Call {@link #show(Context, Configuration...)} or {@link #show(Context, List)} to start
         * the Activity
         */
        public Builder() {
            // intentionally empty
        }

        /**
         * Specifies a startup configuration which will show articles for a given set of category IDs
         *
         * @param categoryIds the category Ids to list articles for
         * @return the builder
         */
        public Builder withArticlesForCategoryIds(@NonNull Long... categoryIds) {
            return withArticlesForCategoryIds(Arrays.asList(categoryIds));
        }

        /**
         * Specifies a startup configuration which will show articles for a given set of category IDs
         *
         * @param categoryIds the category Ids to list articles for
         * @return the builder
         */
        public Builder withArticlesForCategoryIds(@NonNull List<Long> categoryIds) {
            if (sectionIds.size() > 0) {
                Logger.w(LOG_TAG, "Builder: sections have already been specified. Removing section IDs to set "
                        + "category IDs.");
                this.sectionIds = Collections.emptyList();
            }
            this.categoryIds = CollectionUtils.copyOf(categoryIds);

            return this;
        }

        /**
         * Specifies a startup configuration which will show articles for a given set of section IDs
         *
         * @param sectionIds the section IDs to list articles for
         * @return the builder
         */
        public Builder withArticlesForSectionIds(@NonNull Long... sectionIds) {
            return withArticlesForSectionIds(Arrays.asList(sectionIds));
        }

        /**
         * Specifies a startup configuration which will show articles for a given set of section IDs
         *
         * @param sectionIds the section IDs to list articles for
         * @return the builder
         */
        public Builder withArticlesForSectionIds(@NonNull List<Long> sectionIds) {
            if (categoryIds.size() > 0) {
                Logger.w(LOG_TAG, "Builder: categories have already been specified. Removing category IDs to set "
                        + "section IDs.");
                this.categoryIds = Collections.emptyList();
            }
            this.sectionIds = CollectionUtils.copyOf(sectionIds);

            return this;
        }

        /**
         * Define whether or not to display the "ContactUs" Floating Action Button.
         *
         * @param showContactUsButton Boolean value to determine whether the contact button is visible
         * @return The Builder
         */
        public Builder withContactUsButtonVisible(boolean showContactUsButton) {
            this.contactUsButtonVisible = showContactUsButton;
            return this;
        }

        /**
         * Specifies a startup configuration which will restrict the shown articles to ones that
         * match the provided label names.
         *
         * @param labelNames the array of label names to which the Help Center will be restricted.
         * @return The Builder
         */
        public Builder withLabelNames(@NonNull String... labelNames) {
            if (CollectionUtils.isNotEmpty(labelNames)) {
                this.labelNames = labelNames;
            }

            return this;
        }

        /**
         * Specifies a startup configuration which will restrict the shown articles to ones that
         * match the provided label names.
         *
         * @param labelNames the array of label names to which the Help Center will be restricted.
         * @return The Builder
         */
        public Builder withLabelNames(@NonNull List<String> labelNames) {
            return withLabelNames(labelNames.toArray(new String[0]));
        }

        /**
         * Specifies a list of {@link Engine}s to be used to drive a follow up conversation if the
         * user presses the contact FAB. They will be passed to the
         * {@link MessagingActivity#builder()#withEngines(List)} method. If no engines are provided,
         * the user will be shown the {@link zendesk.support.request.RequestActivity} instead.
         * <p>
         * The button may be hidden using the {@link #withContactUsButtonVisible(boolean)} method
         *
         * @param engines the List of Engines which will be used to start
         * {@link zendesk.classic.messaging.MessagingActivity}
         * @return The Builder
         */
        public Builder withEngines(List<Engine> engines) {
            this.engines = engines;
            return this;
        }

        /**
         * Specifies a list of {@link Engine}s to be used to drive a follow up conversation if the
         * user presses the contact FAB. They will be passed to the
         * {@link MessagingActivity#builder()#withEngines(List)} method. If no engines are provided,
         * the user will be shown the {@link zendesk.support.request.RequestActivity} instead.
         * <p>
         * The button may be hidden using the {@link #withContactUsButtonVisible(boolean)} method
         *
         * @param engines the List of Engines which will be used to start
         * {@link zendesk.classic.messaging.MessagingActivity}
         * @return The Builder
         */
        public Builder withEngines(Engine... engines) {
            return withEngines(Arrays.asList(engines));
        }

        /**
         * Specifies whether or not to show all categories in the Help Center in their collapsed
         * state when the content loads. If not specified, a default value of false is used.
         *
         * @param categoriesCollapsed true if the Help Center should initially show all categories
         *                            in their collapsed state, false if categories should be
         *                            shown in their expanded state, with sections and articles
         *                            listed underneath.
         * @return The Builder
         */
        public Builder withCategoriesCollapsed(boolean categoriesCollapsed) {
            this.collapseCategories = categoriesCollapsed;
            return this;
        }

        /**
         * Client-side API to specify whether or not to show the conversations button in the Toolbar
         * of the {@link HelpCenterActivity}. If not specified, a default value of {@code true} is used.
         * <p>
         * The value is used in conjunction with the conversations settings from the server. If
         * conversations are not enabled on the server, the value provided here will not be taken
         * into account. Only if both values evaluate to {@code true} will the menu item will be
         * shown in the Toolbar.
         *
         * @param showConversationsMenuButton true if the conversations menu item should be shown in
         *                                    the Toolbar, false if not.
         * @return The Builder
         */
        public Builder withShowConversationsMenuButton(boolean showConversationsMenuButton) {
            this.showConversationsMenuButton = showConversationsMenuButton;
            return this;
        }

        /**
         * Configurations for screen that can be started from HelpCenterActivity.
         */
        private void setConfigurations(@NonNull List<Configuration> configurations) {
            this.configurations = configurations;

            @SuppressLint("RestrictedApi")
            final HelpCenterConfiguration config = ConfigurationHelper.get()
                    .findConfigForType(configurations, HelpCenterConfiguration.class);

            if (config != null) {
                this.contactUsButtonVisible = config.contactUsButtonVisibility;
                this.categoryIds = config.categoryIds;
                this.sectionIds = config.sectionIds;
                this.collapseCategories = config.collapseCategories;
                this.labelNames = config.labelNames;
                this.engines = EngineListRegistry.INSTANCE.retrieveEngineList(config.engineRegistryId);
                this.showConversationsMenuButton = config.showConversationsMenuButton;
            }
        }

        /**
         * Starts the {@link HelpCenterActivity}.
         *
         * @param context        The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for Activities that can be started from HelpCenterActivity.
         */
        public void show(@NonNull Context context, Configuration... configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Starts the {@link HelpCenterActivity}.
         *
         * @param context        The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for Activities that can be started from HelpCenterActivity.
         */
        public void show(@NonNull Context context, List<Configuration> configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Creates an {@link Intent} for the {@link HelpCenterActivity} with the specified configuration
         * options.
         *
         * @param context        The {@link Context} which {@code startActivity} will be invoked on
         * @param configurations Configurations for Activities that can be started from HelpCenterActivity.
         * @return An {@link Intent} for {@link HelpCenterActivity} with the specified configuration options
         */
        public Intent intent(@NonNull Context context, Configuration... configurations) {
            return intent(context, Arrays.asList(configurations));
        }

        /**
         * Creates an {@link Intent} for the {@link HelpCenterActivity} with the specified configuration
         * options.
         *
         * @param context        The {@link Context} which {@code startActivity} will be invoked on
         * @param configurations Configurations for Activities that can be started from HelpCenterActivity.
         * @return An {@link Intent} for {@link HelpCenterActivity} with the specified configuration options
         */
        @SuppressLint("RestrictedApi")
        public Intent intent(@NonNull Context context, List<Configuration> configurations) {
            setConfigurations(configurations);

            final Intent intent = new Intent(context, HelpCenterActivity.class);
            final Configuration config = config();
            ConfigurationHelper.get().addToIntent(intent, config);

            return intent;
        }

        /**
         * Create a {@link Configuration} for the passed in configuration options.
         */
        @NonNull
        public Configuration config() {
            String registryId = EngineListRegistry.INSTANCE.register(engines);
            return new HelpCenterConfiguration(this, registryId);
        }

    }
}
