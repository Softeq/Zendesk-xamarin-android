package zendesk.support.guide;

import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;

import java.util.List;

import zendesk.support.ArticleItem;
import zendesk.support.CategoryItem;
import zendesk.support.HelpItem;
import zendesk.support.HelpRequest;
import zendesk.support.SectionItem;
import zendesk.support.SeeAllArticlesItem;

/**
 * Defines MVP behaviour for the overview of content that are in a Help UI
 */
interface HelpMvp {

    /**
     * Defines model behaviours
     * <p>
     * These model behaviours generally fetch lists of {@link HelpItem HelpItems}, using
     * the given category IDs, section IDs, and label names. These lists are a flattened
     * representation of the Category -> Section -> Article hierarchy, in which the first
     * element of the list is a {@link CategoryItem} representing the first category, the next
     * element is a {@link SectionItem} representing that category's first section, the next
     * element is a {@link ArticleItem} representing that section's first article, and so on.
     * </p>
     * <p>
     * The list also includes {@link SeeAllArticlesItem} objects as appropriate, according to
     * the {@link HelpRequest#articlesPerPageLimit articlesPerPageLimit} specified in the
     * {@link HelpRequest}, or its {@link HelpRequest#DEFAULT_ARTICLES_PER_SECTION default value}
     * </p>
     */
    interface Model {

        /**
         * Fetches {@link HelpItem HelpItems} for the specified category and section IDs
         *
         * @param categoryIds The category IDs to fetch items for
         * @param sectionIds  The section IDs to fetch items for
         * @param labelNames  The label names which to filter the items by
         * @param callback    The callback which will return the items, or an error
         */
        void getArticles(List<Long> categoryIds, List<Long> sectionIds, String[] labelNames,
                         ZendeskCallback<List<HelpItem>> callback);

        /**
         * Fetches articles for the specified SectionItem
         *
         * @param section    The section item for which Articles will be fetched
         * @param labelNames The label names which to filter the items by
         * @param callback   The callback which will return the articles, or an error
         */
        void getArticlesForSection(SectionItem section, String[] labelNames, ZendeskCallback<List<ArticleItem>>
                callback);
    }

    /**
     * Defines view behaviours
     */
    interface View {

        /**
         * Shows the specified items
         *
         * @param items the items to show
         */
        void showItems(List<HelpItem> items);

        /**
         * Adds an item to the view
         *
         * @param position The position where the item will be added
         * @param item     The item to add
         */
        void addItem(int position, HelpItem item);

        /**
         * Removes an item from the list
         *
         * @param position the position of the item to remove
         */
        void removeItem(int position);
    }

    /**
     * Defines presenter behaviours
     */
    interface Presenter {

        /**
         * Called when the view is attached to the RecyclerView with the Context to which it
         * is attached.
         */
        void onAttached();

        /**
         * Called when the view is detached from the RecyclerView.
         */
        void onDetached();

        /**
         * Sets the content presenter, which is used to communicate messages to a higher level in
         * the hierarchy
         *
         * @param presenter The presenter to set
         */
        void setContentPresenter(HelpCenterMvp.Presenter presenter);

        /**
         * Called when the see all action is clicked
         *
         * @param item The item that generated the event
         */
        void onSeeAllClick(SeeAllArticlesItem item);

        /**
         * Called when a category is clicked
         *
         * @param item     The item that generated the event
         * @param position The position of the item
         * @return true if the result of the click made the category expanded, false if contracted
         */
        boolean onCategoryClick(CategoryItem item, int position);

        /**
         * Gets the item at the specified position.
         *
         * @param position The position of the item to return
         * @return The item at the specified position
         */
        HelpItem getItem(int position);

        /**
         * Gets the number of items in the RecyclerView
         *
         * @return the number of items in the RecyclerView
         */
        int getItemCount();

        /**
         * Gets the type of the view at the specified position
         *
         * @param position The position to get the view type for
         * @return The type of the view at the specified position
         */
        int getItemViewType(int position);

        /**
         * Gets the {@link HelpItem} at the specified position
         *
         * @param position The position to get the item for
         * @return the item, or null if it is not found.
         */
        @Nullable
        HelpItem getItemForBinding(int position);
    }
}
