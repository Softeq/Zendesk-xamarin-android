package zendesk.support.guide;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ErrorResponseAdapter;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

import zendesk.support.Article;
import zendesk.support.ArticleItem;
import zendesk.support.HelpCenterProvider;
import zendesk.support.HelpItem;
import zendesk.support.HelpRequest;
import zendesk.support.SectionItem;

/**
 * This is the reference implementation of {@link HelpMvp.Model}
 */
class HelpModel implements HelpMvp.Model {

    private HelpCenterProvider provider;

    /**
     * Creates a HelpModel with the specified API provider
     *
     * @param provider The provider used to fetch Help resources
     */
    HelpModel(HelpCenterProvider provider) {
        this.provider = provider;
    }

    @Override
    public void getArticles(List<Long> categoryIds,
                            List<Long> sectionIds,
                            String[] labelNames,
                            ZendeskCallback<List<HelpItem>> callback) {
        provider.getHelp(
                new HelpRequest.Builder()
                        .withCategoryIds(categoryIds)
                        .withSectionIds(sectionIds)
                        .withLabelNames(labelNames)
                        .includeCategories()
                        .includeSections()
                        .build(),
                callback);
    }

    @Override
    public void getArticlesForSection(SectionItem section,
                                      String[] labelNames,
                                      final ZendeskCallback<List<ArticleItem>> callback) {

        if (section == null || section.getId() == null) {
            callback.onError(new ErrorResponseAdapter("SectionItem or its ID was null, cannot load more articles."));
            return;
        }

        provider.getArticles(section.getId(),
                StringUtils.toCsvString(labelNames),
                new ZendeskCallback<List<Article>>() {
                    @Override
                    public void onSuccess(List<Article> articles) {
                        List<ArticleItem> articleItems = new ArrayList<>(articles.size());
                        for (Article article : articles) {
                            articleItems.add(convertArticle(article));
                        }

                        if (callback != null) {
                            callback.onSuccess(articleItems);
                        }
                    }

                    @Override
                    public void onError(ErrorResponse errorResponse) {
                        if (callback != null) {
                            callback.onError(errorResponse);
                        }
                    }
                });
    }

    private ArticleItem convertArticle(Article article) {
        return new ArticleItem(article.getId(),
                article.getSectionId(),
                article.getTitle());
    }

}
