package zendesk.support.guide;

import com.zendesk.service.ZendeskCallback;

import java.util.List;

import zendesk.support.HelpCenterProvider;
import zendesk.support.HelpCenterSearch;
import zendesk.support.HelpCenterSettings;
import zendesk.support.HelpCenterSettingsProvider;
import zendesk.support.SearchArticle;

class HelpCenterModel implements HelpCenterMvp.Model {

    private final HelpCenterProvider provider;
    private final HelpCenterSettingsProvider settingsProvider;

    /**
     * Creates the HelpCenterModel.
     * <p>
     * Note that the SDK must be initialised for this model to function correctly.
     * </p>
     */
    HelpCenterModel(HelpCenterProvider helpCenterProvider, HelpCenterSettingsProvider settingsProvider) {
        this.provider = helpCenterProvider;
        this.settingsProvider = settingsProvider;
    }

    @Override
    public void search(List<Long> categoryIds, List<Long> sectionIds, String query,
                       String[] labelNames, ZendeskCallback<List<SearchArticle>> callback) {
        provider.searchArticles(
                new HelpCenterSearch.Builder()
                        .withQuery(query)
                        .withCategoryIds(categoryIds)
                        .withSectionIds(sectionIds)
                        .withLabelNames(labelNames)
                        .build(),
                callback);
    }

    @Override
    public void getSettings(ZendeskCallback<HelpCenterSettings> callback) {
        settingsProvider.getSettings(callback);
    }
}
