package zendesk.support.guide;

import android.annotation.SuppressLint;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;

import java.util.UUID;

import javax.inject.Inject;

import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.core.Zendesk;
import zendesk.support.Guide;
import zendesk.support.GuideModule;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
enum GuideSdkDependencyProvider {

    INSTANCE;

    public static final String NOT_INITIALIZED_LOG = "Zendesk is not initialized or no identity was set. Make sure"
            + " Zendesk.INSTANCE.init(...), Zendesk.INSTANCE.setIdentity(...), Guide.INSTANCE.init(...)"
            + " was called ";

    @Inject
    ActionHandlerRegistry registry;
    @Inject
    ActionHandler actionHandler;

    private GuideSdkComponent guideSdkComponent;
    private UUID id;

    @SuppressLint("RestrictedApi")
    public GuideSdkComponent provideGuideSdkComponent() {
        final GuideModule guideModule = Guide.INSTANCE.guideModule();
        final UUID id = guideModule.getId();

        if (guideModule == null || !id.equals(this.id)) {
            guideSdkComponent = DaggerGuideSdkComponent.builder()
                    .coreModule(Zendesk.INSTANCE.coreModule())
                    .guideModule(guideModule)
                    .build();

            this.id = guideModule.getId();

            guideSdkComponent.inject(this);

            registry.add(actionHandler);
        }

        return guideSdkComponent;
    }

    /**
     * Initialise the Guide SDK Ui module with a component built for testing
     */
    @VisibleForTesting
    public void initForTesting(GuideSdkComponent sdkComponent, UUID coreId) {
        this.guideSdkComponent = sdkComponent;
        this.id = coreId;
    }

    public boolean isInitialized() {
        return Zendesk.INSTANCE.isInitialized()
                && Guide.INSTANCE.isInitialized();
    }
}
