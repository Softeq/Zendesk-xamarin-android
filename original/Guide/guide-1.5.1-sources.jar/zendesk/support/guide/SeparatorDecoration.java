package zendesk.support.guide;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import androidx.annotation.VisibleForTesting;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

/**
 * A separator item used in Help fragments. This class contains the logic that determines how
 * it should be drawn, which can depend on whether items near it are expanded.
 */
class SeparatorDecoration extends RecyclerView.ItemDecoration {

    private Drawable divider;

    /**
     * @param divider The drawable resource for the divider
     */
    SeparatorDecoration(Drawable divider) {
        this.divider = divider;
    }

    @Override
    public void onDrawOver(Canvas c, RecyclerView parent, RecyclerView.State state) {
        super.onDraw(c, parent, state);

        /*
         * This magic bit of code makes the SeparatorDecoration display after the animations
         * have completed.
         */
        if (parent.getItemAnimator() != null && parent.getItemAnimator().isRunning()) {
            return;
        }

        int childCount = parent.getChildCount();
        for (int i = 0; i < childCount; i++) {

            View child = parent.getChildAt(i);

            if (shouldShowTopSeparator(parent, i)) {
                int dividerLeft = parent.getPaddingLeft();
                int dividerRight = parent.getWidth() - parent.getPaddingRight();

                RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) child.getLayoutParams();

                int dividerTop = child.getTop() + params.topMargin;
                int dividerBottom = dividerTop + divider.getIntrinsicHeight();

                divider.setBounds(dividerLeft, dividerTop, dividerRight, dividerBottom);
                divider.draw(c);
            }
        }
    }

    /**
     * Determines whether a top separator should be shown or not.
     * <p>
     * A top separator is generally shown when an category is expanded
     * </p>
     *
     * @param parent   The RecyclerView containing the view
     * @param position The position of the item in the RecyclerView
     * @return true if the top separator should be shown, false otherwise
     */
    @VisibleForTesting
    boolean shouldShowTopSeparator(RecyclerView parent, int position) {
        boolean itemIsACategory = isItemACategory(parent.getChildViewHolder(parent.getChildAt(position)));
        boolean itemIsAnExpandedCategory =
                isItemAnExpandedCategory(parent.getChildViewHolder(parent.getChildAt(position)));
        boolean previousItemIsAnUnexpandedCategory = (position > 0)
                && isItemAnUnexpandedCategory(parent.getChildViewHolder(parent.getChildAt(position - 1)));

        return (itemIsACategory && (itemIsAnExpandedCategory || !previousItemIsAnUnexpandedCategory));
    }

    /**
     * Determine whether the item held by the ViewHolder is a category
     *
     * @param viewHolder The ViewHolder containing the view
     * @return true if the item is a category, false otherwise
     */
    private boolean isItemACategory(RecyclerView.ViewHolder viewHolder) {
        return viewHolder instanceof HelpRecyclerViewAdapter.CategoryViewHolder;
    }

    /**
     * Determine whether the item held by the ViewHolder is an unexpanded category
     *
     * @param viewHolder The ViewHolder containing the view
     * @return true if the item is an unexpanded category, false otherwise
     */
    private boolean isItemAnExpandedCategory(RecyclerView.ViewHolder viewHolder) {
        return viewHolder instanceof HelpRecyclerViewAdapter.CategoryViewHolder
                && ((HelpRecyclerViewAdapter.CategoryViewHolder) viewHolder).isExpanded();
    }

    /**
     * Determine whether the item held by the ViewHolder is an unexpanded category
     *
     * @param viewHolder The ViewHolder containing the view
     * @return true if the item is an unexpanded category, false otherwise
     */
    private boolean isItemAnUnexpandedCategory(RecyclerView.ViewHolder viewHolder) {
        return viewHolder instanceof HelpRecyclerViewAdapter.CategoryViewHolder
                && !((HelpRecyclerViewAdapter.CategoryViewHolder) viewHolder).isExpanded();
    }
}
