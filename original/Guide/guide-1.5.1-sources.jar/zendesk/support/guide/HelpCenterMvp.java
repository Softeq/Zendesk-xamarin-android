package zendesk.support.guide;

import android.content.Context;

import com.zendesk.service.ZendeskCallback;

import java.util.List;

import zendesk.core.RetryAction;
import zendesk.classic.messaging.Engine;
import zendesk.support.HelpCenterSettings;
import zendesk.support.SearchArticle;

/**
 * Defines the MVP model for {@link HelpCenterActivity}
 */
interface HelpCenterMvp {

    /**
     * The types of errors that can occur. These are used by the presenter layer, so that the
     * view layer can resolve the correct message.
     */
    enum ErrorType {
        CATEGORY_LOAD,
        SECTION_LOAD,
        ARTICLES_LOAD
    }

    /**
     * Defines behaviour for model operations
     */
    interface Model {

        /**
         * Performs a Help search
         *
         * @param categoryIds The category IDs to search in
         * @param sectionIds  The section IDs to search in
         * @param query       The query text
         * @param labelNames  The label names to which to restrict the search
         * @param callback    The callback for the search results
         */
        void search(List<Long> categoryIds, List<Long> sectionIds, String query, String[] labelNames,
                    ZendeskCallback<List<SearchArticle>> callback);

        /**
         * Fetches the application's settings
         *
         * @param callback The callback for the settings
         */
        void getSettings(ZendeskCallback<HelpCenterSettings> callback);
    }

    /**
     * Defines behaviour for view operations
     */
    interface View {

        /**
         * Shows the contact us button as a FAB
         */
        void showContactUsButton();

        /**
         * Shows Help for the given SDK UI configuration.
         *
         * @param helpCenterUiConfig The HelpCenterConfiguration containing the category and section IDs, label names,
         *                           and configuration flags to be used in displaying the UI.
         */
        void showHelp(HelpCenterConfiguration helpCenterUiConfig);

        /**
         * Shows Help search results for the given query text
         *
         * @param searchArticles The List of articles returned for the search
         * @param query          The query text that was used in the search
         */
        void showSearchResults(List<SearchArticle> searchArticles, String query);

        /**
         * Clears any currently shown search results from the view.
         */
        void clearSearchResults();

        /**
         * Set the enabled state of the search menuitem
         */
        void setSearchEnabled(boolean enabled);

        /**
         * Shows a loading state
         */
        void showLoadingState();

        /**
         * Hides the loading state
         */
        void hideLoadingState();

        /**
         * Shows the list of requests that the user has created
         */
        void showRequestList();

        /**
         * Shows the contact Zendesk component
         */
        void showContactZendesk();

        /**
         * Shows a snackbar with an error message and a retry action
         *
         * @param errorType The type of error to display a message for
         * @param action    The retry action to perform
         */
        void showLoadArticleErrorWithRetry(ErrorType errorType, RetryAction action);

        /**
         * Shows a Snackbar with an error message
         */
        void showNoConnectionError();

        /**
         * Dismiss the error Snackbar if it is currently displayed.
         */
        void dismissError();

        /**
         * Gets the View's context.
         *
         * @return The Context of the View implementation.
         */
        Context getContext();

        /**
         * Tells whether the view is currently showing the Help Center, or Search results.
         * While this is the kind of logical decision normally calculated by the presenter, in this
         * case, with state changes etc, the view is the ultimate source of truth.
         *
         * @return true if the currently displayed view is the Help Center, false if it's
         * search results.
         */
        boolean isShowingHelp();

        /**
         * Exits the activity immediately
         */
        void exitActivity();

        /**
         * Announce that the content has loaded, for accessibility purposes.
         */
        void announceContentLoaded();
    }

    /**
     * Defines behaviour for presenter operations
     */
    interface Presenter {

        /**
         * Informs the presenter that the onResume method of the View has been called.
         *
         * @param view The resumed View.
         */
        void onResume(View view);

        /**
         * Informs the presenter that the onPause method of the View has been called.
         */
        void onPause();

        /**
         * Fired when a search has been requested from the UI
         *
         * @param query The query text
         */
        void onSearchSubmit(String query);

        /**
         * Fired when content from Help has been loaded from the network
         */
        void onLoad();

        /**
         * Fired when a error has been encountered when loading help content
         * from the network, but where retrying is supported
         *
         * @param errorType The type of error that occurred
         * @param action    The action which will be invoked when retry is attempted
         */
        void onErrorWithRetry(ErrorType errorType, RetryAction action);

        /**
         * Initialises the presenter with configuration from the provided {@link HelpCenterConfiguration},
         * and determines the first screen to show. This could be a screen with Help Center content, the
         * conversations screen, or the contact Zendesk screen.
         *
         * @param helpCenterUiConfig The saved instance state from the view
         * @param engines The list of Engines to start MessagingActivity with if user clicks the FAB
         */
        void init(HelpCenterConfiguration helpCenterUiConfig, List<Engine> engines);

        /**
         * Determines whether the conversations menu item should be shown.
         *
         * @return true if the conversations menu item should be shown, false otherwise
         */
        boolean shouldShowConversationsMenuItem();

        /**
         * Determines whether the search menu item should be shown.
         *
         * @return true if the search menu item should be shown, false otherwise
         */
        boolean shouldShowSearchMenuItem();
    }
}
