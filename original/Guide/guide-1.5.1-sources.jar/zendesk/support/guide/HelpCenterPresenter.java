package zendesk.support.guide;

import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.core.NetworkAware;
import zendesk.core.NetworkInfoProvider;
import zendesk.core.RetryAction;
import zendesk.classic.messaging.Engine;
import zendesk.support.HelpCenterSettings;
import zendesk.support.SearchArticle;

import static zendesk.support.guide.HelpCenterActivity.LOG_TAG;

/**
 * HelpCenterPresenter is the reference implementation of Presenter
 */
class HelpCenterPresenter implements HelpCenterMvp.Presenter, NetworkAware {

    private static final Integer NETWORK_AWARE_ID = 31;
    private static final Integer RETRY_ACTION_ID = 8642;

    private HelpCenterMvp.View view;

    private HelpCenterMvp.Model model;

    private HelpCenterSettings helpCenterSettings;

    private HelpCenterConfiguration config;

    private NetworkInfoProvider networkInfoProvider;

    private ActionHandlerRegistry actionHandlerRegistry;

    private boolean networkPreviouslyUnavailable;

    private Set<RetryAction> internalRetryActions = new HashSet<>();

    private List<Engine> engines;

    /**
     * Creates a HelpCenterPresenter
     *
     * @param view                The view
     * @param model               The model
     * @param networkInfoProvider The {@link NetworkInfoProvider} to use to supply information on
     *                            network availability.
     */
    HelpCenterPresenter(HelpCenterMvp.View view, HelpCenterMvp.Model model, NetworkInfoProvider networkInfoProvider,
                        ActionHandlerRegistry actionHandlerRegistry) {
        this.view = view;
        this.model = model;
        this.networkInfoProvider = networkInfoProvider;
        this.actionHandlerRegistry = actionHandlerRegistry;
    }

    @Override
    public void onResume(HelpCenterMvp.View view) {
        this.view = view;

        networkInfoProvider.addNetworkAwareListener(NETWORK_AWARE_ID, this);
        networkInfoProvider.register();

        if (!networkInfoProvider.isNetworkAvailable()) {
            view.showNoConnectionError();
            view.hideLoadingState();
            networkPreviouslyUnavailable = true;
        }

        invokeRetryActions();
    }

    private void invokeRetryActions() {
        for (RetryAction retryAction : internalRetryActions) {
            retryAction.onRetry();
        }
        internalRetryActions.clear();
    }

    @Override
    public void onPause() {
        this.view = null;

        networkInfoProvider.removeNetworkAwareListener(NETWORK_AWARE_ID);
        networkInfoProvider.removeRetryAction(RETRY_ACTION_ID);
        networkInfoProvider.unregister();
    }

    @Override
    public void onSearchSubmit(final String query) {
        if (networkInfoProvider.isNetworkAvailable()) {
            view.dismissError();
            view.showLoadingState();
            view.clearSearchResults();

            model.search(config.getCategoryIds(), config.getSectionIds(), query,
                    config.getLabelNames(), new ViewSafeRetryZendeskCallback(query));
        } else {
            RetryAction retryAction = new RetryAction() {
                @Override
                public void onRetry() {
                    onSearchSubmit(query);
                }
            };
            networkInfoProvider.addRetryAction(RETRY_ACTION_ID, retryAction);
        }
    }

    @VisibleForTesting
    class ViewSafeRetryZendeskCallback extends ZendeskCallback<List<SearchArticle>> {

        private String query;

        ViewSafeRetryZendeskCallback(String query) {
            this.query = query;
        }

        @Override
        public void onSuccess(final List<SearchArticle> searchArticles) {
            if (view != null) {
                view.hideLoadingState();
                view.showSearchResults(searchArticles, query);
                if (shouldShowContactUsButton()) {
                    view.showContactUsButton();
                }
            } else {
                internalRetryActions.add(new RetryAction() {
                    @Override
                    public void onRetry() {
                        onSuccess(searchArticles);
                    }
                });
            }
        }

        @Override
        public void onError(final ErrorResponse errorResponse) {
            if (view != null) {
                view.hideLoadingState();
                view.showLoadArticleErrorWithRetry(HelpCenterMvp.ErrorType.ARTICLES_LOAD, new RetryAction() {
                    @Override
                    public void onRetry() {
                        onSearchSubmit(query);
                    }
                });
            } else {
                internalRetryActions.add(new RetryAction() {
                    @Override
                    public void onRetry() {
                        onError(errorResponse);
                    }
                });
            }
        }
    }

    @Override
    public void onLoad() {
        if (shouldShowContactUsButton()) {
            if (view != null) {
                view.showContactUsButton();
            } else {
                internalRetryActions.add(new RetryAction() {
                    @Override
                    public void onRetry() {
                        view.showContactUsButton();
                    }
                });
            }
        }
        if (view != null) {
            view.announceContentLoaded();
        }
    }

    @VisibleForTesting
    boolean shouldShowContactUsButton() {
        boolean hasContactUsActionHandler = actionHandlerRegistry
                .handlerByAction(ActionConstants.ACTION_CONTACT_OPTION) != null;
        boolean hasEngines = CollectionUtils.isNotEmpty(engines);

        return config.isContactUsButtonVisible() && (hasContactUsActionHandler || hasEngines);
    }

    @Override
    public void onErrorWithRetry(final HelpCenterMvp.ErrorType errorType, final RetryAction action) {
        if (view != null) {
            if (view.isShowingHelp()) {
                view.hideLoadingState();
                view.showLoadArticleErrorWithRetry(errorType, action);
            }
        } else {
            internalRetryActions.add(new RetryAction() {
                @Override
                public void onRetry() {
                    if (view != null && view.isShowingHelp()) {
                        view.hideLoadingState();
                        view.showLoadArticleErrorWithRetry(errorType, action);
                    }
                }
            });
        }
    }

    @Override
    public void onNetworkAvailable() {
        Logger.d(LOG_TAG, "Network is available.");

        if (!networkPreviouslyUnavailable) {
            Logger.d(LOG_TAG, "Network was not previously unavailable, no need to dismiss Snackbar");
            return;
        }

        networkPreviouslyUnavailable = false;

        if (view != null) {
            view.setSearchEnabled(true);
            view.dismissError();  // FIXME Will this dismiss it in some cases we don't want it to?
        } else {
            internalRetryActions.add(new RetryAction() {
                @Override
                public void onRetry() {
                    view.dismissError();
                }
            });
        }
    }

    @Override
    public void onNetworkUnavailable() {
        Logger.d(LOG_TAG, "Network is unavailable.");
        networkPreviouslyUnavailable = true;

        if (view != null) {
            view.setSearchEnabled(false);
            view.showNoConnectionError();
            view.hideLoadingState();
        }
    }

    @Override
    public void init(final HelpCenterConfiguration helpCenterUiConfig, final List<Engine> engines) {
        this.config = helpCenterUiConfig;
        this.engines = engines;

        view.showLoadingState();
        model.getSettings(new ZendeskCallback<HelpCenterSettings>() {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {

                if (view != null) {
                    view.hideLoadingState();
                } else {
                    internalRetryActions.add(new RetryAction() {
                        @Override
                        public void onRetry() {
                            view.hideLoadingState();
                        }
                    });
                }
                HelpCenterPresenter.this.helpCenterSettings = helpCenterSettings;

                if (helpCenterSettings.isEnabled()) {

                    Logger.d(LOG_TAG, "Help center is enabled. starting with Help Center");

                    if (view != null) {
                        view.showHelp(config);
                    } else {
                        internalRetryActions.add(new RetryAction() {
                            @Override
                            public void onRetry() {
                                view.showHelp(config);
                            }
                        });
                    }

                    if (shouldShowContactUsButton()) {
                        Logger.d(LOG_TAG, "Saved instance states that we should show the contact FAB");
                        if (view != null) {
                            view.showContactUsButton();
                        } else {
                            internalRetryActions.add(new RetryAction() {
                                @Override
                                public void onRetry() {
                                    view.showContactUsButton();
                                }
                            });
                        }
                    }
                } else {

                    Logger.d(LOG_TAG, "Help center is disabled");

                    ActionHandler convListHandler = actionHandlerRegistry
                            .handlerByAction(ActionConstants.ACTION_CONVERSATION_LIST);

                    if (convListHandler != null) {
                        Logger.d(LOG_TAG, "Starting with conversations");
                        if (view != null) {
                            view.showRequestList();
                            view.exitActivity();
                        } else {
                            internalRetryActions.add(new RetryAction() {
                                @Override
                                public void onRetry() {
                                    view.showRequestList();
                                    view.exitActivity();
                                }
                            });
                        }
                    } else {
                        ActionHandler contactUsHandler = actionHandlerRegistry
                                .handlerByAction(ActionConstants.ACTION_CONTACT_OPTION);

                        if (contactUsHandler != null) {
                            Logger.d(LOG_TAG, "Starting with contact");

                            if (view != null) {
                                view.showContactZendesk();
                                view.exitActivity();
                            } else {
                                internalRetryActions.add(new RetryAction() {
                                    @Override
                                    public void onRetry() {
                                        view.showContactZendesk();
                                        view.exitActivity();
                                    }
                                });
                            }
                        } else {
                            Logger.d(LOG_TAG, "Support SDK is not present, nothing to fall back to. "
                                    + "Closing Activity.");

                            if (view != null) {
                                view.exitActivity();
                            } else {
                                internalRetryActions.add(new RetryAction() {
                                    @Override
                                    public void onRetry() {
                                        view.exitActivity();
                                    }
                                });
                            }
                        }
                    }
                }
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.e(LOG_TAG, "Failed to get mobile settings. Cannot determine start screen.");
                Logger.e(LOG_TAG, errorResponse);
                if (view != null) {
                    view.hideLoadingState();
                    view.exitActivity();
                } else {
                    internalRetryActions.add(new RetryAction() {
                        @Override
                        public void onRetry() {
                            view.hideLoadingState();
                            view.exitActivity();
                        }
                    });
                }
            }
        });
    }

    @Override
    public boolean shouldShowConversationsMenuItem() {
        return (actionHandlerRegistry.handlerByAction(ActionConstants.ACTION_CONVERSATION_LIST) != null)
                && config.isShowConversationsMenuButton();
    }

    @Override
    public boolean shouldShowSearchMenuItem() {
        return helpCenterSettings != null && helpCenterSettings.isEnabled();
    }
}
