package zendesk.support.guide;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import zendesk.core.ActionHandlerRegistry;
import zendesk.core.SdkStartUpProvider;
import zendesk.core.Zendesk;

@SuppressLint("RestrictedApi")
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class GuideSdkStartupProvider extends SdkStartUpProvider {

    @Nullable
    ViewArticleActionHandler articleActionHandler;

    @Override
    protected void onStartUp(Context context) {
        final ActionHandlerRegistry handlerRegistry = Zendesk.INSTANCE.actionHandlerRegistry();

        //make sure there are no duplicates in case the onStartUp is called twice
        if (articleActionHandler != null) {
            handlerRegistry.remove(articleActionHandler);
        }

        articleActionHandler = new ViewArticleActionHandler();
        handlerRegistry.add(articleActionHandler);
    }
}
