package zendesk.support.guide;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import androidx.annotation.RestrictTo;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.core.view.ViewCompat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

import com.zendesk.guide.sdk.R;
import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

import zendesk.support.Article;
import zendesk.support.ArticleVote;
import zendesk.support.ArticleVoteStorage;
import zendesk.support.HelpCenterProvider;
import zendesk.support.SimpleArticle;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;
import static zendesk.support.guide.ViewArticleActivity.LOG_TAG;

/**
 * This view provides voting functionality for a Help Center article. Articles can be voted up or
 * down, and this vote is persisted using {@link ArticleVoteStorage}.
 * <p>
 * The article's ID, {@link ArticleVoteStorage} and {@link HelpCenterProvider} must be bound
 * to the view using {@link #bindTo(Long, ArticleVoteStorage, HelpCenterProvider)} before
 * the View can be used. The supplied value should be the return value of either
 * {@link Article#getId()} or {@link SimpleArticle#getId()}. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
class ArticleVotingView extends RelativeLayout {

    /**
     * Represents the different states that a user's vote on an article can be in.
     */
    private enum VoteState {
        UPVOTED,
        DOWNVOTED,
        NONE;

        /**
         * {@link ArticleVote#getValue()} returns an integer, the value of which determines whether
         * it is an upvote, downvote or no vote. This method takes an {@link ArticleVote} and
         * uses its {@link ArticleVote#getValue()} to return the appropriate state of the vote.
         * <p>
         * A value greater than zero returns {@link #UPVOTED}, a value less than zero returns
         * {@link #DOWNVOTED}, and a value of zero returns {@link #NONE}.
         * <p>
         * A null {@link ArticleVote} or a null {@link ArticleVote#getValue()} returns {@link VoteState#NONE}/
         *
         * @param articleVote the vote
         * @return the state of the vote
         */
        static VoteState fromArticleVote(ArticleVote articleVote) {
            if (articleVote == null || articleVote.getValue() == null) {
                return NONE;
            }

            int voteState = articleVote.getValue();
            if (voteState > 0) {
                return UPVOTED;
            } else if (voteState < 0) {
                return DOWNVOTED;
            } else {
                return NONE;
            }
        }
    }

    private HelpCenterProvider helpCenterProvider;
    private ArticleVoteStorage articleVoteStorage;
    private ArticleVote articleVote;
    private Long articleId;

    private ViewGroup upvoteButtonFrame;
    private ImageButton upvoteButton;
    private ViewGroup downvoteButtonFrame;
    private ImageButton downvoteButton;

    /**
     * Creates an instance using and calls through to {@link View#View(Context)}
     *
     * @param context the context to use when setting up the view
     */
    public ArticleVotingView(Context context) {
        super(context);

        setupViews(context);
    }

    /**
     * Creates an instance using and calls through to {@link View#View(Context, AttributeSet)}
     *
     * @param context the context to use when setting up the view
     * @param attrs   the attribute set to use when setting up the view
     */
    public ArticleVotingView(Context context, AttributeSet attrs) {
        super(context, attrs);

        setupViews(context);
    }

    /**
     * Creates an instance using and calls through to {@link View#View(Context, AttributeSet, int)}
     *
     * @param context      the context to use when setting up the view
     * @param attrs        the attribute set to use when setting up the view
     * @param defStyleAttr the style attribute to use when setting up the view
     */
    public ArticleVotingView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        setupViews(context);
    }

    /**
     * Binds the given article ID and article vote storage to this voting view, so that all votes
     * cast through this view will be votes on that article, and the vote information will be persisted
     * in the supplied storage. If there is a vote for this article already in storage (if the user has
     * previously votes on this article, on this device), it will be loaded and the
     * appropriate button will show as "pressed".
     * <p>
     * Make sure to call this method before attempting to use the view.
     *
     * @param articleId          the ID for the article all votes should be cast on
     * @param articleVoteStorage the storage used to facilitate article voting
     * @param helpCenterProvider the provider used to fetch Help Center content
     */
    public void bindTo(Long articleId, ArticleVoteStorage articleVoteStorage, HelpCenterProvider helpCenterProvider) {
        this.articleVoteStorage = articleVoteStorage;
        this.helpCenterProvider = helpCenterProvider;
        this.articleId = articleId;

        if (articleId != null) {
            articleVote = articleVoteStorage.getStoredArticleVote(articleId);
            updateButtons(VoteState.fromArticleVote(articleVote));
        }
    }

    private void setupViews(Context context) {
        LayoutInflater.from(context).inflate(R.layout.zs_view_article_voting, this);

        upvoteButtonFrame = findViewById(R.id.upvote_button_frame);
        upvoteButton = findViewById(R.id.upvote_button);
        downvoteButtonFrame = findViewById(R.id.downvote_button_frame);
        downvoteButton = findViewById(R.id.downvote_button);

        int primaryColorOrFallback = UiUtils.themeAttributeToColor(R.attr.colorPrimary, getContext(),
                R.color.zs_fallback_text_color);

        themeVotingButton(upvoteButton, R.drawable.zs_ic_thumb_up, primaryColorOrFallback);
        themeVotingButton(downvoteButton, R.drawable.zs_ic_thumb_down, primaryColorOrFallback);

        upvoteButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                setVotingButtonsClickable(false);
                VoteState articleVoteValue;
                if (articleVote != null && articleVote.getValue() != null && articleVote.getValue().equals(1)) {
                    //Article was already upvoted, remove the vote
                    articleVoteValue = VoteState.NONE;
                    removeVote();
                } else {
                    //Article had no vote or was downvoted, upvote the article
                    articleVoteValue = VoteState.UPVOTED;
                    upvoteArticle();
                }
                updateButtons(articleVoteValue);
            }
        });

        downvoteButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                setVotingButtonsClickable(false);
                VoteState articleVoteValue;
                if (articleVote != null && articleVote.getValue() != null && articleVote.getValue().equals(-1)) {
                    //Article was already downvoted, remove the vote
                    articleVoteValue = VoteState.NONE;
                    removeVote();
                } else {
                    //Article had no vote or was upvoted, downvote the article
                    articleVoteValue = VoteState.DOWNVOTED;
                    downvoteArticle();
                }
                updateButtons(articleVoteValue);
            }
        });
    }

    private void setVotingButtonsClickable(boolean clickable) {
        upvoteButton.setClickable(clickable);
        downvoteButton.setClickable(clickable);
    }

    private void themeVotingButton(ImageButton imageButton, int imageResource, int enabledColor) {

        ViewCompat.setBackground(imageButton, getVotingButtonBackground(enabledColor));

        //noinspection ConstantConditions
        Drawable icon = DrawableCompat.wrap(ContextCompat.getDrawable(getContext(), imageResource));
        DrawableCompat.setTintList(icon, colorStateList(Color.WHITE, enabledColor));
        DrawableCompat.setTintMode(icon, PorterDuff.Mode.SRC_IN);
        imageButton.setImageDrawable(icon);
    }

    private StateListDrawable getVotingButtonBackground(int enabledColor) {
        Drawable enabled = buildButtonBackground(getContext(), enabledColor);
        Drawable disabled = buildButtonBackground(getContext(), Color.WHITE);

        StateListDrawable backgroundStateList = new StateListDrawable();
        backgroundStateList.addState(new int[]{android.R.attr.state_activated}, enabled);
        backgroundStateList.addState(new int[]{android.R.attr.state_pressed}, enabled);
        backgroundStateList.addState(new int[]{}, disabled);

        return backgroundStateList;
    }

    private ColorStateList colorStateList(int enabled, int disabled) {
        int[][] states = new int[][]{
                new int[]{android.R.attr.state_activated},
                new int[]{android.R.attr.state_pressed},
                new int[]{},
        };

        int[] colors = new int[]{
                enabled,
                enabled,
                disabled
        };

        return new ColorStateList(states, colors);
    }

    private GradientDrawable buildButtonBackground(Context v, int backgroundColor) {
        final int cornerRadius = v.getResources().getDimensionPixelSize(R.dimen
                .zs_help_voting_button_border_corner_radius);
        final int strokeColor = ContextCompat.getColor(v, R.color.zs_help_voting_button_border);
        final int strokeWidth = v.getResources().getDimensionPixelSize(R.dimen.zs_help_voting_button_border_width);

        final GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(cornerRadius);
        shape.setColor(backgroundColor);
        shape.setStroke(strokeWidth, strokeColor);
        return shape;
    }

    private void upvoteArticle() {
        if (articleId == null) {
            Logger.w(LOG_TAG, "Cannot upvote article, articleId is null. Make sure you've called bindTo()!");
            return;
        }

        helpCenterProvider.upvoteArticle(articleId, new ZendeskCallback<ArticleVote>() {
            @Override
            public void onSuccess(ArticleVote articleVote) {
                Logger.d(LOG_TAG, "Successfully upvoted article!");
                ArticleVotingView.this.articleVote = articleVote;
                announceForAccessibility(getResources().getString(R.string
                        .zs_view_article_voted_yes_accessibility_announce));
                articleVoteStorage.storeArticleVote(articleId, articleVote);
                setVotingButtonsClickable(true);
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.d(LOG_TAG, "Failed to upvote article. " + errorResponse);
                announceForAccessibility(getResources().getString(R.string
                        .zs_view_article_voted_failed_accessibility_announce));
                updateButtons(VoteState.fromArticleVote(articleVote));
                setVotingButtonsClickable(true);
            }
        });
    }

    private void downvoteArticle() {
        if (articleId == null) {
            Logger.w(LOG_TAG, "Cannot downvote article, articleId is null. Make sure you've called bindTo()!");
            return;
        }

        Logger.e(LOG_TAG, "hcp == null -> " + (helpCenterProvider == null));

        helpCenterProvider.downvoteArticle(articleId, new ZendeskCallback<ArticleVote>() {
            @Override
            public void onSuccess(ArticleVote articleVote) {
                Logger.d(LOG_TAG, "Successfully downvoted article!");
                ArticleVotingView.this.articleVote = articleVote;
                announceForAccessibility(getResources().getString(R.string
                        .zs_view_article_voted_no_accessibility_announce));
                articleVoteStorage.storeArticleVote(articleId, articleVote);
                setVotingButtonsClickable(true);
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.d(LOG_TAG, "Failed to downvote article. " + errorResponse);
                announceForAccessibility(getResources().getString(R.string
                        .zs_view_article_voted_failed_accessibility_announce));
                updateButtons(VoteState.fromArticleVote(articleVote));
                setVotingButtonsClickable(true);
            }
        });
    }

    private void removeVote() {
        if (articleId == null) {
            Logger.w(LOG_TAG, "Article vote was null, could not remove vote");
            return;
        }

        if (articleVote.getId() != null) {
            helpCenterProvider.deleteVote(articleVote.getId(), new ZendeskCallback<Void>() {
                @Override
                public void onSuccess(Void value) {
                    Logger.d(LOG_TAG, "Successfully removed vote!");
                    articleVote = null;
                    articleVoteStorage.removeStoredArticleVote(articleId);
                    setVotingButtonsClickable(true);
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    Logger.d(LOG_TAG, "Failed to remove vote. "
                            + errorResponse.getResponseBody() + "\n"
                            + errorResponse.getResponseBodyType() + "\n"
                            + errorResponse.getUrl());
                    updateButtons(VoteState.fromArticleVote(articleVote));
                    setVotingButtonsClickable(true);
                }
            });
        }

    }

    private void updateButtons(VoteState voteState) {
        if (voteState == VoteState.NONE) {
            upvoteButtonFrame.setActivated(false);
            downvoteButtonFrame.setActivated(false);
        } else if (voteState == VoteState.UPVOTED) {
            upvoteButtonFrame.setActivated(true);
            downvoteButtonFrame.setActivated(false);

        } else if (voteState == VoteState.DOWNVOTED) {
            upvoteButtonFrame.setActivated(false);
            downvoteButtonFrame.setActivated(true);
        }
        updateContentDesc(voteState);
    }

    private void updateContentDesc(VoteState voteState) {
        switch (voteState) {
            case NONE:
                upvoteButton.setContentDescription(getResources().getString(R.string
                        .zs_view_article_vote_yes_accessibility));
                downvoteButton.setContentDescription(getResources().getString(R.string
                        .zs_view_article_vote_no_accessibility));
                break;
            case UPVOTED:
                upvoteButton.setContentDescription(getResources().getString(R.string
                        .zs_view_article_vote_no_remove_accessibility));
                downvoteButton.setContentDescription(getResources().getString(R.string
                        .zs_view_article_vote_no_accessibility));
                break;
            case DOWNVOTED:
                upvoteButton.setContentDescription(getResources().getString(R.string
                        .zs_view_article_vote_yes_accessibility));
                downvoteButton.setContentDescription(getResources().getString(R.string
                        .zs_view_article_vote_yes_remove_accessibility));
                break;
            default:
                Logger.d(LOG_TAG, "Unhandled voteState case");
        }
    }
}
