package zendesk.support.guide;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import androidx.annotation.VisibleForTesting;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.zendesk.guide.sdk.R;
import com.zendesk.logger.Logger;

import java.util.List;

import zendesk.core.NetworkInfoProvider;
import zendesk.support.CategoryItem;
import zendesk.support.HelpCenterProvider;
import zendesk.support.HelpItem;
import zendesk.support.SectionItem;
import zendesk.support.SeeAllArticlesItem;

import static zendesk.support.guide.HelpCenterActivity.LOG_TAG;

/**
 * An adapter to render {@link HelpItem HelpItems} in a RecyclerView.
 */
class HelpRecyclerViewAdapter
        extends RecyclerView.Adapter<HelpRecyclerViewAdapter.HelpViewHolder>
        implements HelpMvp.View {

    private HelpMvp.Presenter presenter;

    private Context context;

    private int highlightCategoryTitleColour;
    private int defaultCategoryTitleColour;
    private final HelpCenterConfiguration helpCenterUiConfig;

    /**
     * Creates an instance of the adapter for use when started with an HelpCenterConfiguration.
     */
    HelpRecyclerViewAdapter(HelpCenterConfiguration helpCenterUiConfig, HelpCenterProvider helpCenterProvider,
                            NetworkInfoProvider networkInfoProvider) {
        presenter = new HelpAdapterPresenter(
                this,
                new HelpModel(helpCenterProvider),
                networkInfoProvider,
                helpCenterUiConfig);
        this.helpCenterUiConfig = helpCenterUiConfig;
    }

    /**
     * Sets the content update listener
     *
     * @param listener The listener to set.
     */
    void setContentUpdateListener(HelpCenterMvp.Presenter listener) {
        if (presenter != null) {
            presenter.setContentPresenter(listener);
        }
    }

    @Override
    public void showItems(List<HelpItem> items) {
        notifyDataSetChanged();
    }

    @Override
    public void addItem(int position, HelpItem item) {
        notifyItemInserted(position);
    }

    @Override
    public void removeItem(int position) {
        notifyItemRemoved(position);
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        this.context = recyclerView.getContext();

        this.highlightCategoryTitleColour = UiUtils.themeAttributeToColor(R.attr.colorPrimary, context,
                R.color.zs_fallback_text_color);
        this.defaultCategoryTitleColour = ContextCompat.getColor(context, R.color.zs_help_text_color_primary);

        presenter.onAttached();
    }

    @Override
    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);
        presenter.onDetached();
        this.context = null;
    }

    @Override
    public HelpViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view;

        switch (viewType) {
            case HelpItem.TYPE_CATEGORY:
                view = inflateView(parent, R.layout.zs_row_category);
                return new CategoryViewHolder(view);

            case HelpItem.TYPE_SECTION:
                view = inflateView(parent, R.layout.zs_row_section);
                return new SectionViewHolder(view);

            case HelpItem.TYPE_ARTICLE:
                view = inflateView(parent, R.layout.zs_row_article);
                return new ArticleViewHolder(view);

            case HelpItem.TYPE_SEE_ALL:
                view = inflateView(parent, R.layout.zs_row_action);
                return new SeeAllViewHolder(view);

            case HelpItem.TYPE_LOADING:
                view = inflateView(parent, R.layout.zs_row_loading_progress);
                return new LoadingViewHolder(view);

            case HelpItem.TYPE_NO_RESULTS:
                view = inflateView(parent, R.layout.zs_row_no_articles_found);
                return new NoResultsViewHolder(view);

            case HelpItem.TYPE_PADDING:
                view = inflateView(parent, R.layout.zs_row_padding);
                return new ExtraPaddingViewHolder(view);

            default:
                Logger.w(LOG_TAG, "Unknown item type, returning null for holder");
                return null;
        }
    }

    private View inflateView(ViewGroup parent, int layoutId) {
        return LayoutInflater.from(parent.getContext()).inflate(layoutId, parent, false);
    }

    @Override
    public int getItemCount() {
        return presenter.getItemCount();
    }

    @Override
    public void onBindViewHolder(HelpViewHolder holder, int position) {

        if (holder == null) {
            Logger.w(LOG_TAG, "Holder was null, possible unexpected item type");
            return;
        }

        holder.bindTo(presenter.getItemForBinding(position), position);
    }

    @Override
    public int getItemViewType(int position) {
        return presenter.getItemViewType(position);
    }

    class CategoryViewHolder extends HelpViewHolder {

        private static final int ROTATION_START_LEVEL = 0;
        private static final int ROTATION_END_LEVEL = 10000;
        private static final String ROTATION_PROPERTY_NAME = "level";

        private Drawable expanderDrawable;

        private boolean expanded;

        CategoryViewHolder(View itemView) {
            super(itemView);

            this.textView = (TextView) itemView;

            expanderDrawable = DrawableCompat.wrap(ContextCompat.getDrawable(
                    itemView.getContext(), R.drawable.zs_help_ic_expand_more)).mutate();
            DrawableCompat.setTint(expanderDrawable, UiUtils.themeAttributeToColor(android.R.attr.textColorSecondary,
                    context, R.color.zs_fallback_text_color));
            DrawableCompat.setTintMode(expanderDrawable, PorterDuff.Mode.SRC_IN);

            TextView textView = (TextView) itemView;

            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, expanderDrawable, null);
        }

        @Override
        public void bindTo(final HelpItem item, final int position) {

            if (item == null) {
                Logger.e(LOG_TAG, "Category item was null, cannot bind");
                return;
            }

            textView.setText(UiUtils.decodeHtmlEntities(item.getName()));

            final CategoryItem categoryItem = (CategoryItem) item;
            expanded = categoryItem.isExpanded();
            expanderDrawable.setLevel(expanded ? ROTATION_END_LEVEL : ROTATION_START_LEVEL);
            setHighlightColor(categoryItem.isExpanded());

            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    expanded = presenter.onCategoryClick(categoryItem, position);

                    ObjectAnimator.ofInt(
                            expanderDrawable,
                            ROTATION_PROPERTY_NAME,
                            (expanded) ? ROTATION_START_LEVEL : ROTATION_END_LEVEL,
                            (expanded) ? ROTATION_END_LEVEL : ROTATION_START_LEVEL)
                            .start();

                    setHighlightColor(expanded);
                }
            });
        }

        private void setHighlightColor(boolean expanded) {
            if (expanded) {
                textView.setTextColor(highlightCategoryTitleColour);
                expanderDrawable.setColorFilter(highlightCategoryTitleColour, PorterDuff.Mode.SRC_IN);
            } else {
                textView.setTextColor(defaultCategoryTitleColour);
                expanderDrawable.setColorFilter(defaultCategoryTitleColour, PorterDuff.Mode.SRC_IN);
            }
        }

        public boolean isExpanded() {
            return expanded;
        }
    }

    @VisibleForTesting
    class SectionViewHolder extends HelpViewHolder {

        SectionViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.section_title);
        }

        @Override
        public void bindTo(final HelpItem item, final int position) {

            if (item == null) {
                Logger.e(LOG_TAG, "Section item was null, cannot bind");
                return;
            }

            textView.setText(UiUtils.decodeHtmlEntities(item.getName()));
        }

    }

    @VisibleForTesting
    class ArticleViewHolder extends HelpViewHolder {

        ArticleViewHolder(View itemView) {
            super(itemView);
            textView = (TextView) itemView;
        }

        @Override
        public void bindTo(final HelpItem item, int position) {

            if (item == null || item.getId() == null) {
                Logger.e(LOG_TAG, "Article item was null, cannot bind");
                return;
            }

            textView.setText(UiUtils.decodeHtmlEntities(item.getName()));
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ViewArticleActivity.builder(item.getId())
                            .show(context, helpCenterUiConfig.getConfigurations());
                }
            });
        }
    }

    private class SeeAllViewHolder extends HelpViewHolder {

        private ProgressBar progressBar;

        SeeAllViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.help_section_action_button);
            progressBar = itemView.findViewById(R.id.help_section_loading_progress);
        }

        @Override
        public void bindTo(final HelpItem item, final int position) {

            if (!(item instanceof SeeAllArticlesItem)) {
                Logger.e(LOG_TAG, "SeeAll item was null, cannot bind");
                return;
            }

            final SeeAllArticlesItem seeAllArticlesItem = (SeeAllArticlesItem) item;

            /*
              This is to reset recycled SeeAllArticlesItems so that they don't show a
              progress spinner when they should be showing the button.
             */
            if (seeAllArticlesItem.isLoading()) {
                textView.setVisibility(View.GONE);
                progressBar.setVisibility(View.VISIBLE);
            } else {
                textView.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
            }

            SectionItem section = seeAllArticlesItem.getSection();
            String sectionLabel;

            if (section != null) {
                sectionLabel = context.getString(R.string.support_help_see_all_n_articles_label, section
                        .getTotalArticlesCount());
            } else {
                sectionLabel = context.getString(R.string.support_help_see_all_articles_label);
            }

            textView.setText(sectionLabel);

            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    textView.setVisibility(View.GONE);
                    progressBar.setVisibility(View.VISIBLE);
                    presenter.onSeeAllClick((SeeAllArticlesItem) item);
                    seeAllArticlesItem.setLoading(true);
                }
            });
        }
    }

    private class LoadingViewHolder extends HelpViewHolder {

        LoadingViewHolder(View itemView) {
            super(itemView);
        }

        @Override
        public void bindTo(HelpItem item, int position) {
            // Intentionally empty. Nothing to bind to.
        }
    }

    private class NoResultsViewHolder extends HelpViewHolder {

        NoResultsViewHolder(View itemView) {
            super(itemView);
        }

        @Override
        public void bindTo(HelpItem item, int position) {
            // Nothing to bind.
        }
    }

    private class ExtraPaddingViewHolder extends HelpViewHolder {

        ExtraPaddingViewHolder(View itemView) {
            super(itemView);
        }

        @Override
        public void bindTo(HelpItem item, int position) {
            // Nothing to bind.
        }
    }

    abstract static class HelpViewHolder extends RecyclerView.ViewHolder {

        TextView textView;

        HelpViewHolder(View itemView) {
            super(itemView);
        }

        public abstract void bindTo(HelpItem item, int position);
    }
}

