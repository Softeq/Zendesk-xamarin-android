package zendesk.support.guide;

import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

import zendesk.core.NetworkInfoProvider;
import zendesk.core.RetryAction;
import zendesk.support.ArticleItem;
import zendesk.support.CategoryItem;
import zendesk.support.HelpItem;
import zendesk.support.SectionItem;
import zendesk.support.SeeAllArticlesItem;

import static zendesk.support.guide.HelpCenterActivity.LOG_TAG;

/**
 * Reference implementation of the presenter
 */
class HelpAdapterPresenter implements HelpMvp.Presenter {

    private static final Integer RETRY_ACTION_ID = 5;

    private HelpMvp.View view;

    private HelpMvp.Model model;

    private List<HelpItem> helpItems = new ArrayList<>();

    private List<HelpItem> filteredItems = new ArrayList<>();

    private HelpCenterConfiguration helpCenterUiConfig;

    private boolean noResults;

    private boolean hasError;

    private HelpCenterMvp.Presenter contentPresenter;

    private NetworkInfoProvider networkInfoProvider;

    private RetryAction retryAction;

    /**
     * Creates a instance of the adapter
     *
     * @param view                The view interface
     * @param model               The model interface
     * @param networkInfoProvider The provider to inform the presenter of changes in network
     *                            connectivity.
     */
    public HelpAdapterPresenter(HelpMvp.View view, HelpMvp.Model model, NetworkInfoProvider networkInfoProvider,
                                HelpCenterConfiguration helpCenterUiConfig) {
        this.view = view;
        this.model = model;
        this.networkInfoProvider = networkInfoProvider;
        this.helpCenterUiConfig = helpCenterUiConfig;
    }

    @Override
    public void setContentPresenter(HelpCenterMvp.Presenter presenter) {
        this.contentPresenter = presenter;
    }

    @Override
    public void onAttached() {
        networkInfoProvider.register();

        if (CollectionUtils.isEmpty(helpItems)) {
            requestHelpContent();
        }
    }

    @Override
    public void onDetached() {
        networkInfoProvider.removeRetryAction(RETRY_ACTION_ID);
        networkInfoProvider.unregister();
    }

    @Override
    public boolean onCategoryClick(CategoryItem categoryItem, int position) {
        if (categoryItem == null) {
            return false;
        }

        boolean expanded = categoryItem.setExpanded(!categoryItem.isExpanded());

        if (expanded) {
            expandItem(categoryItem, filteredItems.indexOf(categoryItem));
        } else {
            collapseItem(filteredItems.indexOf(categoryItem));
        }

        return expanded;
    }

    @Override
    public void onSeeAllClick(SeeAllArticlesItem item) {
        loadMoreArticles(item);
    }

    @Override
    public HelpItem getItem(int position) {
        return filteredItems.get(position);
    }

    @Override
    public int getItemCount() {
        // If we've received an error, no items are shown in the list.
        if (hasError) {
            return 0;
        }

        // Return a minimum value of 1 so that we get our initial loading state and our error state,
        // and add an extra item for padding at the end of the list, if we are adding padding
        return Math.max(filteredItems.size() + getPaddingItemCount(), 1);
    }

    private int getPaddingItemCount() {
        return helpCenterUiConfig.isContactUsButtonVisible() ? 1 : 0;
    }

    @Override
    public int getItemViewType(int position) {
        if (noResults) {
            return HelpItem.TYPE_NO_RESULTS;
        } else {
            // Return TYPE_LOADING if we have no items to display, return TYPE_PADDING if the position
            // is the position beyond our last index
            return (filteredItems.size() > 0) ? (position == filteredItems.size() ? HelpItem.TYPE_PADDING
                    : filteredItems.get(position).getViewType()) : HelpItem.TYPE_LOADING;
        }
    }

    @Nullable
    @Override
    public HelpItem getItemForBinding(int position) {
        // Bit of null safety for the initial loading state case and the end padding case. 
        return (filteredItems.size() > 0)
                ? ((position < filteredItems.size()) ? filteredItems.get(position) : null)
                : null;
    }

    /**
     * Requests the content for the categories or sections specified in the constructor.
     */
    private void requestHelpContent() {
        if (!networkInfoProvider.isNetworkAvailable()) {
            retryAction = new RetryAction() {
                @Override
                public void onRetry() {
                    requestHelpContent();
                }
            };
            networkInfoProvider.addRetryAction(RETRY_ACTION_ID, retryAction);
        }

        model.getArticles(helpCenterUiConfig.getCategoryIds(), helpCenterUiConfig.getSectionIds(),
                helpCenterUiConfig.getLabelNames(), callback);
    }

    private ZendeskCallback<List<HelpItem>> callback = new ZendeskCallback<List<HelpItem>>() {
        @Override
        public void onSuccess(List<HelpItem> result) {
            hasError = false;

            helpItems = CollectionUtils.copyOf(result);

            if (helpCenterUiConfig.isCollapseCategories()) {
                filteredItems = getCollapsedCategories(helpItems);
            } else {
                filteredItems = CollectionUtils.copyOf(helpItems);
            }
            noResults = (CollectionUtils.isEmpty(filteredItems));

            view.showItems(filteredItems);
            contentPresenter.onLoad();
        }

        @Override
        public void onError(ErrorResponse error) {

            HelpCenterMvp.ErrorType errorType;

            if (CollectionUtils.isNotEmpty(helpCenterUiConfig.getCategoryIds())) {
                errorType = HelpCenterMvp.ErrorType.CATEGORY_LOAD;
            } else if (CollectionUtils.isNotEmpty(helpCenterUiConfig.getSectionIds())) {
                errorType = HelpCenterMvp.ErrorType.SECTION_LOAD;
            } else {
                errorType = HelpCenterMvp.ErrorType.ARTICLES_LOAD;
            }

            contentPresenter.onErrorWithRetry(errorType, new RetryAction() {
                @Override
                public void onRetry() {
                    hasError = false;
                    view.showItems(filteredItems);
                    requestHelpContent();
                }
            });

            hasError = true;
            view.showItems(filteredItems);
        }
    };

    private List<HelpItem> getCollapsedCategories(List<HelpItem> helpItems) {
        List<HelpItem> collapsedCategories = new ArrayList<>();

        if (helpItems == null || helpItems.size() == 0) {
            return collapsedCategories;
        }

        for (int i = 0, count = helpItems.size(); i < count; i++) {
            if (HelpItem.TYPE_CATEGORY == helpItems.get(i).getViewType()) {
                collapsedCategories.add(helpItems.get(i));
                ((CategoryItem) helpItems.get(i)).setExpanded(false);
            }
        }
        return collapsedCategories;
    }

    private void expandItem(CategoryItem categoryItem, int position) {
        int positionToAddAt = position + 1; // add after the category
        for (HelpItem categoryChildItem : categoryItem.getSections()) {
            addItem(positionToAddAt, categoryChildItem);
            positionToAddAt++;
            try {
                SectionItem sectionItem = (SectionItem) categoryChildItem;
                for (HelpItem sectionChildItem : sectionItem.getChildren()) {
                    addItem(positionToAddAt, sectionChildItem);
                    positionToAddAt++;
                }
            } catch (ClassCastException ex) {
                Logger.e(LOG_TAG, "Error expanding item", ex);
            }
        }
    }

    private void collapseItem(int position) {
        if (position >= getItemCount() - 1) {
            return;
        }

        int positionToRemoveFrom = position + 1;

        while (positionToRemoveFrom < filteredItems.size()
                && HelpItem.TYPE_CATEGORY != filteredItems.get(positionToRemoveFrom).getViewType()) {
            removeItem(positionToRemoveFrom);
        }
    }

    private void addItem(int position, HelpItem item) {
        filteredItems.add(position, item);
        view.addItem(position, item);
    }

    private void removeItem(int position) {
        filteredItems.remove(position);
        view.removeItem(position);
    }

    private void loadMoreArticles(final SeeAllArticlesItem seeAllItem) {

        final SectionItem section = seeAllItem.getSection();

        final RetryAction loadMoreRetryAction = new RetryAction() {
            @Override
            public void onRetry() {
                loadMoreArticles(seeAllItem);
            }
        };

        if (networkInfoProvider.isNetworkAvailable()) {
            model.getArticlesForSection(section, helpCenterUiConfig.getLabelNames(),
                    new ZendeskCallback<List<ArticleItem>>() {
                        @Override
                        public void onSuccess(List<ArticleItem> articleItems) {

                            int positionInFullList = helpItems.indexOf(seeAllItem);
                            int positionInFilteredList = filteredItems.indexOf(seeAllItem);

                            for (ArticleItem item : articleItems) {
                                if (!helpItems.contains(item)) {
                                    // Add to full list
                                    helpItems.add(positionInFullList++, item);
                                    // Add to SectionItem's children
                                    section.addArticle(item);

                                    if (positionInFilteredList != -1) {
                                        // Add to filtered list
                                        filteredItems.add(positionInFilteredList, item);
                                        // Update RecyclerView with inserted item
                                        view.addItem(positionInFilteredList, item);
                                        positionInFilteredList++;
                                    }
                                }
                            }

                            // Remove see all/loading view from full list
                            helpItems.remove(seeAllItem);
                            int removedItemPosition = filteredItems.indexOf(seeAllItem);
                            // Remove see all/loading view from filtered list
                            filteredItems.remove(seeAllItem);
                            // Update RecyclerView that see all/loading view has been removed
                            view.removeItem(removedItemPosition);
                        }

                        @Override
                        public void onError(ErrorResponse errorResponse) {
                            helpItems.remove(seeAllItem);
                            Logger.e(LOG_TAG, "Failed to load more articles", errorResponse);

                            contentPresenter.onErrorWithRetry(HelpCenterMvp.ErrorType.ARTICLES_LOAD,
                                    loadMoreRetryAction);
                        }
                    });
        } else {
            retryAction = loadMoreRetryAction;
            networkInfoProvider.addRetryAction(RETRY_ACTION_ID, retryAction);
        }
    }
}
