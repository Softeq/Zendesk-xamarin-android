package zendesk.support;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;

import java.util.Locale;

import javax.inject.Inject;

import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.core.AuthenticationProvider;
import zendesk.core.CoreModule;
import zendesk.core.Zendesk;

/**
 * Configuration class for Zendesk initialization. Call this first to configure Zendesk to use the
 * correct credentials and Zendesk URL.
 */
@SuppressWarnings("unused")
public enum Support {
    INSTANCE;

    private static final String LOG_TAG = "ZendeskConfiguration";

    private ApplicationScope applicationScope;
    private boolean initialised;

    @Inject
    ProviderStore providerStore;

    @Inject
    SupportModule supportModule;

    @Inject
    RequestMigrator requestMigrator;

    @Inject
    SupportBlipsProvider blipsProvider;

    @Inject
    ActionHandlerRegistry actionHandlerRegistry;

    @Inject
    RequestProvider requestProvider;

    @Inject
    AuthenticationProvider authenticationProvider;

    /**
     * Initialises the Support SDK
     *
     * <p>
     * A lazy loading strategy is applied to all Provider calls to ensure that settings
     * are always present before a call to Zendesk.
     * </p>
     *
     * @param zendesk The instance of zendesk to initialize Support with
     */
    @SuppressWarnings("SameParameterValue")
    public void init(@NonNull Zendesk zendesk) {

        if (zendesk.isInitialized()) {
            final ApplicationScope build = new ApplicationScope.Builder()
                    .build();
            initApplicationScope(zendesk.coreModule(), build);
            initialised = true;
        } else {
            Logger.e(LOG_TAG, "Cannot use SupportSDK without initializing Zendesk. Call Zendesk.INSTANCE.init(...)");
        }
    }


    /**
     * Not public intentionally. This method allows us to teardown the object and must only
     * be used for testing. If you make this public this kitten will die. Do you want that on
     * your conscience?
     * 　 ／l、
     * ﾞ（ﾟ､ ｡ ７
     * 　l、ﾞ ~ヽ
     * 　じしf_, )ノ
     */
    @VisibleForTesting
    void reset() {
        initialised = false;
    }

    /**
     * Gets whether {@link #init(Zendesk)} was called or not.
     *
     * @return true if init was successfully called, false otherwise.
     */
    public boolean isInitialized() {
        return initialised;
    }

    /**
     * Gets a {@link ProviderStore} for accessing all available
     * SDK Providers.
     *
     * @return an instance of {@link ProviderStore}
     */
    @Nullable
    public ProviderStore provider() {

        if (!isInitialized()) {
            Logger.e(LOG_TAG, "Cannot get ProviderStore before SDK has been initialized. init() must be " +
                    "called before provider().");
            return null;
        }

        if (!isAuthenticated()) {
            Logger.e(LOG_TAG, "Cannot get ProviderStore before an identity has been set. " +
                    "Zendesk.INSTANCE.setIdentity() must be called before provider().");
            return null;
        }

        return providerStore;
    }

    /**
     * Refreshes the Support SDK RequestActivity if it is currently being displayed (after
     * {@link Activity#onResume()} but before {@link Activity#onPause()}) for the given request ID,
     * or the RequestListActivity if it has not been destroyed (ie, by {@link Activity#onDestroy()}.
     * <p>
     * This is intended for use in the handling of push notifications for updates on Zendesk Support
     * requests. If not using push notifications, or using a provider-only integration (ie, not
     * using the Support SDK UI), then this method should not be used.
     * <p>
     * The method should be called from the {@link android.content.BroadcastReceiver} being used to
     * receive your push notifications. If the Support SDK UI is currently on screen, this method
     * will trigger a refresh to capture the update, and return true. If it is not on screen, this
     * method will return false. We recommend showing a notification to the user only if this method
     * returns false.
     *
     * @param requestId the ID of the request to refresh
     * @param context   the application Context
     * @return true if the conversation UI was refreshed on screen, false if not.
     */
    public boolean refreshRequest(String requestId, Context context) {

        if (!isInitialized()) {
            Logger.e(LOG_TAG, "Cannot use Support SDK without initializing Zendesk. " +
                    "Call Zendesk.INSTANCE.init(...) and Support.INSTANCE.init(Zendesk)");
            return false;
        }

        if (!isAuthenticated()) {
            Logger.e(LOG_TAG, "Cannot use Support SDK without setting an identity. " +
                    "Zendesk.INSTANCE.setIdentity(...) must be called before refreshRequest(...).");
            return false;
        }

        ActionHandler conversationRefreshHandler = actionHandlerRegistry
                .handlerByAction(Constants.ACTION_REFRESH_REQUEST_CONVERSATION + requestId);

        if (conversationRefreshHandler != null) {
            conversationRefreshHandler.handle(null, context);
            return true;
        }

        ActionHandler requestListRefreshHandler = actionHandlerRegistry
                .handlerByAction(Constants.ACTION_REFRESH_REQUEST_LIST);

        if (requestListRefreshHandler != null) {
            requestListRefreshHandler.handle(null, context);
        } else {
            requestProvider.markRequestAsUnread(requestId);
        }
        return false;
    }

    private void initApplicationScope(CoreModule coreModule, ApplicationScope applicationScope) {
        this.applicationScope = applicationScope;

        Guide.INSTANCE.init(Zendesk.INSTANCE);

        DaggerSupportSdkProvidersComponent
                .builder()
                .coreModule(coreModule)
                .providerModule(new ProviderModule())
                .storageModule(new StorageModule())
                .supportApplicationModule(new SupportApplicationModule(applicationScope))
                .guideModule(Guide.INSTANCE.guideModule())
                .build()
                .inject(this);
    }

    /**
     * Get whether an identity is available or not.
     *
     * @return {@code true} if there is an identity, {@code false} if not.
     */
    boolean isAuthenticated() {
        return authenticationProvider != null && authenticationProvider.getIdentity() != null;
    }

    /**
     * Installs a tracker. Intentionally package-private
     *
     * @param tracker The tracker to install
     */
    void installTracker(ZendeskTracker tracker) {
        ApplicationScope newScope = applicationScope.newBuilder().zendeskTracker(tracker).build();
        initApplicationScope(Zendesk.INSTANCE.coreModule(), newScope);
    }

    /**
     * Only for internal use.
     * <br />
     * <b>Here be dragons</b>
     */
    SupportModule getSupportModule() {
        return supportModule;
    }

    /**
     * Set a locale override for Help Center content. By default, Help Center content will be
     * requested in the locale of the device. Use this method to force a specific locale to be used
     * when requesting Help Center content.
     *
     * <p>
     * Note that if you set a locale that is not supported on your Help Center, you will not
     * receive any content.
     * </p>
     *
     * @param locale the locale to force in all requests to Help Center.
     */
    public void setHelpCenterLocaleOverride(Locale locale) {
        Guide.INSTANCE.setHelpCenterLocaleOverride(locale);
    }

    /**
     * Returns the override, if any, for the locale to be used in Help Center requests. If no
     * override has been set, the device locale will be used.
     *
     * @return the locale override, or null if no override has been set.
     */
    public Locale getHelpCenterLocaleOverride() {
        return Guide.INSTANCE.getHelpCenterLocaleOverride();
    }
}
