package zendesk.support;

/**
 * Defines some operations which can be used for tracking or analytics purposes.
 * <p>
 * Created by Zendesk on 21/11/2016.
 */
interface ZendeskTracker {

    /**
     * Called when a request is created
     */
    void requestCreated();

    /**
     * Called when a request is updated
     */
    void requestUpdated();

    /**
     * A default, no-op implementation of the ZendeskTracker interface. This is used by default when the Support SDK is
     * initialized. Replace (or override) the DefaultTracker using the {@link Support#installTracker(ZendeskTracker)}
     * method.
     */
    class DefaultTracker implements ZendeskTracker {

        @Override
        public void requestCreated() {
            // Intentionally empty.
        }

        @Override
        public void requestUpdated() {
            // Intentionally empty.
        }
    }

}
