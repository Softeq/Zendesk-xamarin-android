package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;
import com.zendesk.util.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
 * This is a model class for a Comment object that will be created by the
 * {@link RequestProvider} as part of {@link CommentsResponse}.
 *
 * @see <a href ="http://developer.zendesk.com/documentation/rest_api/requests.html#getting-comments">Getting
 * Comments</a>
 */
@SuppressWarnings({"unused", "FieldCanBeLocal"})
public class Comment {

    private String url;
    private Long id;
    private String requestId;
    private String body;
    private String htmlBody;
    private Long authorId;
    private Date createdAt;

    @SerializedName("public")
    private boolean isPublic = true;

    @SerializedName("uploads")
    private List<String> attachments;

    /**
     * Gets the API URL of the comment
     *
     * @return the API url of the comment
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the ID of the comment
     *
     * @return the ID of the comment
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the ID of the request that this comment belongs to
     *
     * @return the ID of the request that this comment belongs to
     */
    @Nullable
    public String getRequestId() {
        return requestId;
    }

    /**
     * Gets the body of the comment in plain text
     *
     * @return the body of the comment in plain text
     */
    @Nullable
    public String getBody() {
        return body;
    }

    /**
     * Sets the body of the comment in plain text
     *
     * @param body the body of the comment in plain text
     */
    public void setBody(String body) {
        this.body = body;
    }

    /**
     * Gets the HTML body of the comment
     *
     * @return the HTML body of the comment
     */
    @Nullable
    public String getHtmlBody() {
        return htmlBody;
    }

    /**
     * Checks if this comment is public or not
     *
     * @return true if the comment is public, false otherwise
     */
    public boolean isPublic() {
        return isPublic;
    }

    /**
     * Gets the ID of the author who created the comment.
     *
     * @return the ID of the author who created the comment.
     */
    @Nullable
    public Long getAuthorId() {
        return authorId;
    }

    /**
     * Sets the ID of the author who created the comment
     *
     * @param authorId the ID of the author to set
     */
    public void setAuthorId(Long authorId) {
        this.authorId = authorId;
    }

    /**
     * Gets the attachments of the comment
     *
     * @return the attachments of the comment
     */
    @NonNull
    public List<String> getAttachments() {
        return CollectionUtils.copyOf(attachments);
    }

    /**
     * Sets the attachments of the comment
     *
     * @param attachments the attachments to set
     */
    public void setAttachments(List<String> attachments) {
        this.attachments = attachments;
    }

    /**
     * Gets the date that the comment was created at
     *
     * @return the date that the comment was created at
     */
    @Nullable
    public Date getCreatedAt() {
        return createdAt == null ? null : new Date(createdAt.getTime());
    }

    /**
     * Sets the date that the comment that the comment was created at
     *
     * @param createdAt the date to set
     */
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
