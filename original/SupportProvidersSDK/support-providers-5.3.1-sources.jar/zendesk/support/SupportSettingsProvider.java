package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;

/**
 * This provider is used internally by the SDK and does not need to be called explicitly.
 */
public interface SupportSettingsProvider {

    /**
     * Retrieves the {@link SupportSettings} wrapped in a {@link SupportSdkSettings} object.
     *
     * @param callback A callback which will be notified of the result of the call.
     * @since 2.0.0
     */
    void getSettings(@Nullable ZendeskCallback<SupportSdkSettings> callback);
}
