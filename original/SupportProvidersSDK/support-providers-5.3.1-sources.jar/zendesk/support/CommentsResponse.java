package zendesk.support;

import androidx.annotation.NonNull;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * This is a class model for a response for requesting comments for a request. This object will be created by
 * {@link RequestProvider}
 *
 * @see <a href ="http://developer.zendesk.com/documentation/rest_api/requests.html#getting-comments">Getting
 * Comments</a>
 */
@SuppressWarnings("unused")
public class CommentsResponse extends ResponseWrapper {

    private List<CommentResponse> comments;
    private List<User> users;
    private List<Organization> organizations;

    /**
     * Gets the comments in the response
     *
     * @return the comments in the response
     */
    @NonNull
    public List<CommentResponse> getComments() {
        return CollectionUtils.copyOf(comments);
    }

    /**
     * Gets the users who made the comments in {@link #getComments()}
     *
     * @return the users who made the comments
     */
    @NonNull
    public List<User> getUsers() {
        return CollectionUtils.copyOf(users);
    }

    /**
     * Gets the organizations that the {@link #getUsers() users} belong to
     *
     * @return the organisations that the users belong to who made comments
     */
    @NonNull
    public List<Organization> getOrganizations() {
        return CollectionUtils.copyOf(organizations);
    }
}
