package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

/**
 * Storage for persisting request related data.
 */
interface RequestStorage {

    /**
     * Stores a list of requests to disk. Already stored data will be overwritten
     *
     * @param requestData the list of data to store
     */
    void storeRequestData(@Nullable List<RequestData> requestData);

    /**
     * Retrieve a list of requests from the cache
     */
    @NonNull
    List<RequestData> getRequestData();

    /**
     * @return true if the RequestData is more than one hour old
     */
    boolean isRequestDataExpired();

    /**
     * Updates the stored request list.
     */
    void updateRequestData(List<Request> request);

    /**
     * Mark a request as read.
     *
     * @param requestId    request id
     * @param commentCount number of read comments
     */
    void markRequestAsRead(String requestId, int commentCount);

    /**
     * Mark a request as unread.
     *
     * @param requestId request id
     */
    void markRequestAsUnread(String requestId);
}
