package zendesk.support;

import androidx.annotation.Nullable;

import java.util.Date;

/**
 * This is a class model for a response for an uploaded attachment. This object will be returned by
 * {@link zendesk.support.UploadProvider}
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/core/attachments#uploading-files">Show Attachments API
 * documentation</a>
 */
@SuppressWarnings("unused")
public class UploadResponse {

    private String token;
    private Date expiresAt;
    private Attachment attachment;

    /**
     * Gets the token associated with the uploaded file. Needed for attaching uploads to comments.
     *
     * @return the attachment token
     */
    @Nullable
    public String getToken() {
        return token;
    }

    /**
     * Gets the date that the token expires at
     *
     * @return the date that the token expires at
     */
    @Nullable
    public Date getExpiresAt() {
        return expiresAt == null ? null : new Date(expiresAt.getTime());
    }

    /**
     * Get a {@link Attachment} as a response of an uploaded file
     *
     * @return The attachment
     */
    @Nullable
    public Attachment getAttachment() {
        return attachment;
    }

}
