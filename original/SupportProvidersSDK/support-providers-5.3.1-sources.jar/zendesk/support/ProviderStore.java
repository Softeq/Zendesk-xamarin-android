package zendesk.support;

/**
 * Interface used to expose Providers through {@link Support}.
 */
public interface ProviderStore {

    /**
     * Returns an implementation of {@link HelpCenterProvider}
     *
     * @return an instance of {@link HelpCenterProvider}
     */
    HelpCenterProvider helpCenterProvider();

    /**
     * Returns an implementation of {@link RequestProvider}
     *
     * @return an instance {@link RequestProvider}
     */
    RequestProvider requestProvider();

    /**
     * Returns an implementation of {@link UploadProvider}
     *
     * @return an instance of {@link UploadProvider}
     */
    UploadProvider uploadProvider();

}