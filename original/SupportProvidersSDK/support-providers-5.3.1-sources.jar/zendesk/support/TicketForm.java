package zendesk.support;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * Model class for ticket forms.
 */
public class TicketForm {

    private long id;
    private String name;
    private List<TicketField> ticketFields;

    /**
     * Constructor for creating an instance of a ticket form.
     *
     * @param id           ticket form id
     * @param name         ticket form name
     * @param ticketFields a list of associated ticket fields
     */
    public TicketForm(long id, String name, List<TicketField> ticketFields) {
        this.id = id;
        this.name = name;
        this.ticketFields = CollectionUtils.copyOf(ticketFields);
    }

    /**
     * Gets the ID of the ticket form.
     *
     * @return the id of the ticket form
     */
    public long getId() {
        return id;
    }

    /**
     * Gets the name of the ticket form.
     *
     * @return the name of the ticket form
     */
    public String getName() {
        return name;
    }

    /**
     * Gets a list of associated {@link TicketField}.
     *
     * @return a list of ticket fields
     */
    public List<TicketField> getTicketFields() {
        return CollectionUtils.copyOf(ticketFields);
    }
}