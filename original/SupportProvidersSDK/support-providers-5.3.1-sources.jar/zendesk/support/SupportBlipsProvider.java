package zendesk.support;

import androidx.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * A Provider for tracking user actions.
 * <p>
 * This is used internally by the Support SDK and should not be called directly by an integrator.
 */
public interface SupportBlipsProvider {

    @IntDef({ArticleVote.ARTICLE_VOTE_UP, ArticleVote.ARTICLE_VOTE_DOWN})
    @Retention(RetentionPolicy.SOURCE)
    @interface ArticleVote {
        int ARTICLE_VOTE_UP = 1;
        int ARTICLE_VOTE_DOWN = -1;
    }

    /**
     * Tracks a Support SDK initialisation event as a UserAction blip.
     */
    void supportSdkInit();

    /**
     * Tracks creation of a Support request as a UserAction blip.
     *
     * @param requestId the ID of the created request.
     */
    void requestCreated(String requestId);

    /**
     * Tracks a user's update of a Support request as a UserAction blip.
     *
     * @param requestId the ID of the updated request.
     */
    void requestUpdated(String requestId);

    /**
     * Tracks a user's viewing of a Support request as a UserAction blip.
     *
     * @param requestId the ID of the viewed request.
     */
    void requestViewed(String requestId);

    /**
     * Tracks a user's viewing of the request list as a UserAction blip.
     */
    void requestListViewed();
}
