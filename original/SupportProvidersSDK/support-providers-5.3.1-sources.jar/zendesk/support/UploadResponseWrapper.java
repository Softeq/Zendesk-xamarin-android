package zendesk.support;

import androidx.annotation.Nullable;

/**
 * Wrapper class to encapsulate an {@link UploadResponse} received from the network.
 */
@SuppressWarnings("unused")
class UploadResponseWrapper {

    private UploadResponse upload;

    /**
     * Get a {@link UploadResponse} sent by a Zendesk instance after uploading a file
     *
     * @return The upload response
     */
    @Nullable
    UploadResponse getUpload() {
        return upload;
    }
}
