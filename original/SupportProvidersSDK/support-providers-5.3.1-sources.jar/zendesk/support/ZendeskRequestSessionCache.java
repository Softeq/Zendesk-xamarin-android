package zendesk.support;

import androidx.annotation.NonNull;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation of {@link RequestSessionCache}
 */
class ZendeskRequestSessionCache implements RequestSessionCache {

    private final Map<Long, TicketForm> cachedTicketForms;

    ZendeskRequestSessionCache() {
        cachedTicketForms = new HashMap<>();
    }

    @Override
    public void updateTicketFormCache(@NonNull List<TicketForm> ticketForms) {

        final List<TicketForm> ensuredTicketFormList = CollectionUtils.ensureEmpty(ticketForms);
        final Map<Long, TicketForm> ticketFormMap = new HashMap<>();
        for (TicketForm ticketForm : ensuredTicketFormList) {
            ticketFormMap.put(ticketForm.getId(), ticketForm);
        }

        synchronized (cachedTicketForms) {
            cachedTicketForms.putAll(ticketFormMap);
        }
    }

    @NonNull
    @Override
    public synchronized List<TicketForm> getTicketFormsById(@NonNull List<Long> ticketFormIds) {

        List<TicketForm> ticketForms = new ArrayList<>();
        List<Long> ensuredTicketFormIdList = CollectionUtils.ensureEmpty(ticketFormIds);

        synchronized (cachedTicketForms) {
            for (Long id : ensuredTicketFormIdList) {
                ticketForms.add(cachedTicketForms.get(id));
            }
        }

        return ticketForms;
    }

    @Override
    public boolean containsAllTicketForms(@NonNull List<Long> ticketFormIds) {

        List<Long> ensuredTicketFormIdList = CollectionUtils.ensureEmpty(ticketFormIds);
        boolean contains = true;

        synchronized (cachedTicketForms) {
            for (Long id : ensuredTicketFormIdList) {
                if (!cachedTicketForms.containsKey(id)) {
                    contains = false;
                    break;
                }
            }
        }

        return contains;
    }
}