package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.zendesk.util.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
 * This is a model class for a Request object that will be created by the
 * {@link RequestProvider}.
 *
 * @see <a href="http://developer.zendesk.com/documentation/rest_api/requests.html">Requests</a>
 */
@SuppressWarnings({"unused", "FieldCanBeLocal"})
public class Request {

    private String id;
    private String url;
    private String subject;
    private String description;
    private RequestStatus status;
    private String priority;
    private String type;
    private Long organizationId;
    private Long requesterId;
    private List<Long> collaboratorIds;
    private EndUserComment comment;
    private Date dueAt;
    private Date createdAt;
    private Date updatedAt;
    private Date publicUpdatedAt;
    private Integer commentCount;
    private Comment lastComment;
    private Comment firstComment;
    private List<Long> lastCommentingAgentsIds;
    private List<User> lastCommentingAgents;
    private List<CustomField> customFields;

    /**
     * Empty constructor for gson
     */
    public Request() {
        // Intentionally empty
    }

    @VisibleForTesting
    Request(String id, RequestStatus status) {
        this.id = id;
        this.status = status;
    }

    /**
     * Gets the ID of the Request
     *
     * @return the ID of the Request
     */
    @Nullable
    public String getId() {
        return id;
    }

    /**
     * Gets the API URL of the Request
     *
     * @return the API url of the Request
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the subject of the Request
     *
     * @return the subject of the Request
     */
    @Nullable
    public String getSubject() {
        return subject;
    }

    /**
     * Gets the description of the Request
     *
     * @return the description of the Request
     */
    @Nullable
    public String getDescription() {
        return description;
    }

    /**
     * Gets the status of the Request
     *
     * @return the status of the Request
     */
    @Nullable
    public RequestStatus getStatus() {
        return status;
    }

    /**
     * Gets the priority of the Request
     *
     * @return the priority of the Request
     */
    @Nullable
    public String getPriority() {
        return priority;
    }

    /**
     * Gets the type of the Request
     *
     * @return the type of the Request
     */
    @Nullable
    public String getType() {
        return type;
    }

    /**
     * Gets the ID of the Organization that the Request is associated with
     *
     * @return the ID of the Organization that the Request is associated with
     */
    @Nullable
    public Long getOrganizationId() {
        return organizationId;
    }

    /**
     * Gets the ID of the user who requested the Request
     *
     * @return the ID of the user who requested the Request
     */
    @Nullable
    public Long getRequesterId() {
        return requesterId;
    }

    /**
     * Gets the IDs of all of the users who are collaborators on the Request
     *
     * @return the IDs of all of the users who are collaborators on the Request
     */
    @NonNull
    public List<Long> getCollaboratorIds() {
        return CollectionUtils.copyOf(collaboratorIds);
    }

    /**
     * Gets the date that the Request is due at
     *
     * @return the date that the Request was created at
     */
    @Nullable
    public Date getDueAt() {
        return dueAt == null ? null : new Date(dueAt.getTime());
    }

    /**
     * Gets the date that the Request was created at
     *
     * @return the date that the Request was created at
     */
    @Nullable
    public Date getCreatedAt() {
        return createdAt == null ? null : new Date(createdAt.getTime());
    }

    /**
     * Gets the date that the Request was updated at
     *
     * @return the date that the Request was updated at
     */
    @Nullable
    public Date getUpdatedAt() {
        return updatedAt == null ? null : new Date(updatedAt.getTime());
    }

    /**
     * Gets the date that the Request was publicly updated at
     *
     * @return the date that the Request was publicly updated at
     */
    @Nullable
    public Date getPublicUpdatedAt() {
        // client-side fix for MSDK-2751
        if (publicUpdatedAt == null) {
            return getUpdatedAt();
        }
        return new Date(publicUpdatedAt.getTime());
    }

    /**
     * Sets the comment for the Request. Used when updating the request.
     *
     * @param comment the comment to set
     */
    public void setComment(EndUserComment comment) {
        this.comment = comment;
    }

    /**
     * Gets the number of comments on the Request
     *
     * @return the number of comments on the Request
     */
    @Nullable
    public Integer getCommentCount() {
        return commentCount;
    }

    /**
     * Gets the last comment from the Request.
     *
     * @return the last comment from the Request
     */
    @Nullable
    public Comment getLastComment() {
        return lastComment;
    }

    /**
     * Gets the first comment from the Request.
     *
     * @return the first comment from the Request
     */
    @Nullable
    public Comment getFirstComment() {
        return firstComment;
    }

    /**
     * Gets the last 5 commenting agents.
     *
     * @return the list of the last 5 commenting agents.
     */
    public List<User> getLastCommentingAgents() {
        return CollectionUtils.copyOf(lastCommentingAgents);
    }

    /**
     * Gets the ids of the last 5 commenting agents.
     *
     * @return the list of ids for the last 5 commenting agents.
     */
    List<Long> getLastCommentingAgentsIds() {
        return CollectionUtils.copyOf(lastCommentingAgentsIds);
    }

    /**
     * Sets the last 5 commenting agents
     *
     * @param lastCommentingAgents list of commenting agents
     */
    void setLastCommentingAgents(List<User> lastCommentingAgents) {
        this.lastCommentingAgents = lastCommentingAgents;
    }

    /**
     * Gets the custom fields on the Request
     *
     * @return the custom fields on the Request
     */
    @Nullable
    public List<CustomField> getCustomFields() {
        return customFields;
    }
}