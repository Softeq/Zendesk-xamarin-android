package zendesk.support;

/**
 * Used to store information about a request. More fields can be added if needed here in future.
 */
final class RequestData {

    static RequestData create(Request request) {
        return new RequestData(request.getId(), request.getCommentCount(), 0);
    }

    static RequestData create(String requestId, int commentCount, int readCommentCount) {
        return new RequestData(requestId, commentCount, readCommentCount);
    }

    private final String id;
    private final int commentCount;
    private int readCommentCount;

    private RequestData(String id, int commentCount, int readCommentCount) {
        this.commentCount = commentCount;
        this.id = id;
        this.readCommentCount = readCommentCount;
    }

    String getId() {
        return id;
    }

    int getCommentCount() {
        return commentCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RequestData that = (RequestData) o;
        return id != null ? id.equals(that.id) : that.id == null;
    }

    @Override
    public int hashCode() {
        return (id != null ? id.hashCode() : 0);
    }

    @Override
    public String toString() {
        return "RequestData{" +
                "commentCount=" + commentCount +
                "readCommentCount=" + readCommentCount +
                ", id='" + id + '\'' +
                '}';
    }

    int getReadCommentCount() {
        return readCommentCount;
    }

    int unreadComments() {
        return this.commentCount - readCommentCount;
    }
}
