package zendesk.support;

import androidx.annotation.NonNull;

import java.util.Locale;

/**
 * Representation of one configured SDK instance. Holding all the
 * state and configurations.
 */
class ApplicationScope {

    private final Locale locale;
    private final ZendeskTracker zendeskTracker;

    private ApplicationScope(Builder builder) {
        this.locale = builder.locale;
        this.zendeskTracker = builder.zendeskTracker;
    }

    /**
     * Get the configured {@link Locale} of
     * the recent SDK configuration.
     * <br>
     * If no value was set {@code Locale.getDefault()} will be used.
     *
     * @return the used {@link Locale}
     */
    @NonNull
    public Locale getLocale() {
        return locale;
    }

    public ZendeskTracker getZendeskTracker() {
        return zendeskTracker;
    }

    /**
     * Returns newly created {@code Builder} with the
     * already configured options.
     *
     * @return a new {@code Builder}
     */
    @NonNull
    public Builder newBuilder() {
        return new Builder(this);
    }

    static class Builder {

        private Locale locale;
        private ZendeskTracker zendeskTracker;

        Builder() {
            this.locale = Locale.getDefault();
            this.zendeskTracker = new ZendeskTracker.DefaultTracker();
        }

        Builder(ApplicationScope applicationScope) {
            this.locale = applicationScope.getLocale();
        }

        /**
         * Configure a specific {@link Locale}. The {@link Locale} will
         * be used e.g. to to load the matching HelpCenter articles.
         *
         * @param locale a {@link Locale}
         * @return the updated {@link Builder}
         */
        @NonNull
        Builder locale(@NonNull Locale locale) {
            this.locale = locale;
            return this;
        }

        @NonNull
        Builder zendeskTracker(ZendeskTracker zendeskTracker) {
            this.zendeskTracker = zendeskTracker;
            return this;
        }

        /**
         * Create an {@link ApplicationScope} with the configured
         * options.
         *
         * @return an {@link ApplicationScope}
         */
        @NonNull
        ApplicationScope build() {
            return new ApplicationScope(this);
        }
    }
}
