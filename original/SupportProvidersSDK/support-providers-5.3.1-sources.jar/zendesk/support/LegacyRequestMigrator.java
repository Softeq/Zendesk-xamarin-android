package zendesk.support;

import android.content.SharedPreferences;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Implementation of {@link RequestMigrator}, used for migrating request IDs and stored comment
 * counts from legacy (1.x) versions of the Support SDK to 2.0 storage (built on Core).
 * <p>
 * {@link LegacyRequestMigrator#checkAndMigrateRequests()} should be called at SDK initialisation time.
 * However, Support SDK is unable to guarantee that any migrated data applies to the same Zendesk
 * instance or identity as has been used for Core SDK initialisation.
 * <p>
 * This implementation checks in the legacy storage location for any stored request IDs. If none are
 * found, the method returns early. If any IDs are found, they are migrated to
 * {@link ZendeskRequestStorage} using {@link ZendeskRequestStorage#storeRequestData(List)}. Any legacy comment
 * counts for those requests are migrated using {@link ZendeskRequestStorage#storeRequestData(List)}.
 * <p>
 * Following the migration of each comment count, it is removed from legacy storage. When all the
 * request IDs have been migrated, they are removed en masse from legacy storage.
 */
class LegacyRequestMigrator implements RequestMigrator {

    private static final String LOG_TAG = "LegacyRequestMigrator";

    private static final String REQUEST_KEY = "stored_requests";
    private static final String PREFS_COMMENT_COUNT_KEY_PREFIX = "request-id-cc";

    private SharedPreferences legacyRequestStorage;

    LegacyRequestMigrator(SharedPreferences legacyRequestStorage) {
        this.legacyRequestStorage = legacyRequestStorage;
    }

    @Override
    public void clearLegacyRequestStorage() {
        legacyRequestStorage.edit().clear().apply();
    }

    @Override
    public List<RequestData> getLegacyRequests() {
        String legacyRequestIds = legacyRequestStorage.getString(REQUEST_KEY, null);

        if (StringUtils.isEmpty(legacyRequestIds)) {
            return Collections.emptyList();
        }

        Logger.d(LOG_TAG, "Migrating legacy request IDs.");
        List<String> legacyRequestIdList = StringUtils.fromCsv(legacyRequestIds);

        List<RequestData> requestDataList = new ArrayList<>(legacyRequestIdList.size());
        for (String legacyRequestId : legacyRequestIdList) {

            String commentCountKey = getCommentCountKey(legacyRequestId);
            int commentCount = legacyRequestStorage.getInt(commentCountKey, -1);
            if (commentCount > -1) {
                //count found for request add to request data
                requestDataList.add(RequestData.create(legacyRequestId, commentCount, 0));
            } else {
                requestDataList.add(RequestData.create(legacyRequestId, 0, 0));
            }
        }

        return requestDataList;
    }

    private String getCommentCountKey(String requestId) {
        return String.format(Locale.US, "%s-%s", PREFS_COMMENT_COUNT_KEY_PREFIX, requestId);
    }
}
