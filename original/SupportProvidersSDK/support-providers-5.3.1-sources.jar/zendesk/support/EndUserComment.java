package zendesk.support;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;
import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * EndUserComment object is used to model the difference the API for updating a Request has with
 * fetching a list of Comments for a given request.
 * <p>
 * Note: This should only be used for the creation of comments.
 */
@SuppressWarnings({"FieldCanBeLocal", "unused"})
public class EndUserComment {

    private String value;

    @SerializedName("uploads")
    private List<String> attachments;

    /**
     * Sets the value of this comment, e.g. "My printer is on fire"
     *
     * @param value the value of the comment to set
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the attachments for this comment.
     * <p>
     * This returns a copy of the attachments. If you want to set them then use
     * {@link #setAttachments(List)}
     * </p>
     *
     * @return The attachments for this comment
     */
    @NonNull
    public List<String> getAttachments() {
        return CollectionUtils.copyOf(attachments);
    }

    /**
     * Sets the attachments for this comment
     *
     * @param attachments the attachments to set
     */
    public void setAttachments(List<String> attachments) {
        this.attachments = attachments;
    }
}




