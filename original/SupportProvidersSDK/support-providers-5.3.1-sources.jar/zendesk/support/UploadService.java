package zendesk.support;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Defines the operations that can be carried out on Uploads.
 * <p>
 * For more information on the APIs available see:
 * <a href="https://developer.zendesk.com/rest_api/docs/core/attachments">HelpCenterAttachment REST API
 * Documentation</a>
 * </p>
 * <p>
 * Currently this is defined using retrofit annotations but this could be changed in the
 * future as long as these signatures remain.
 * </p>
 */
interface UploadService {

    @POST("/api/mobile/uploads.json")
    Call<UploadResponseWrapper> uploadAttachment(
            @Query("filename") String filename,
            @Body RequestBody typedFile
    );

    @DELETE("/api/mobile/uploads/{token}.json")
    Call<Void> deleteAttachment(
            @Path("token") String token
    );
}
