package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is a model class for a user that will be created by the
 * {@link RequestProvider} as part of {@link CommentsResponse}.
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/core/users">Users API documentation</a>
 */
public class User implements Serializable {

    private Long id;
    private String name;
    private Attachment photo;
    private boolean agent;
    private Long organizationId;
    private List<String> tags;
    private Map<String, String> userFields;

    /**
     * Initialises a user with given values.
     */
    public User(Long id,
                String name,
                Attachment photo,
                boolean agent,
                Long organizationId,
                List<String> tags,
                Map<String, String> userFields) {
        this.id = id;
        this.name = name;
        this.photo = photo;
        this.agent = agent;
        this.organizationId = organizationId;
        this.tags = tags;
        this.userFields = userFields;
    }

    /**
     * Initialises a user with default values.
     */
    public User() {
        this.id = -1L;
        this.name = "";
        this.photo = null;
        this.agent = false;
        this.organizationId = -1L;
        this.tags = new ArrayList<>();
        this.userFields = new HashMap<>();
    }

    /**
     * Get the id of the user.
     *
     * @return the user's Id
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Get the name of the user.
     *
     * @return the user's name
     */
    @Nullable
    public String getName() {
        return name;
    }

    /**
     * Get avatar of the user.
     *
     * @return the user's avatar
     */
    @Nullable
    public Attachment getPhoto() {
        return photo;
    }

    /**
     * Is the user an agent.
     *
     * @return true if the user is an agent
     */
    public boolean isAgent() {
        return agent;
    }

    /**
     * Get the organization id of the user.
     *
     * @return the organization id of the user
     */
    @Nullable
    public Long getOrganizationId() {
        return organizationId;
    }

    /**
     * Gets the list of tags associated with the user
     *
     * @return the list of tags associated with the user
     */
    @NonNull
    public List<String> getTags() {
        return CollectionUtils.copyOf(tags);
    }

    /**
     * Get a map of user fields, associated with the user.
     *
     * @return A map containing user fields.
     */
    @NonNull
    public Map<String, String> getUserFields() {
        return CollectionUtils.copyOf(userFields);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        User user = (User) o;

        if (agent != user.agent) {
            return false;
        }
        if (id != null ? !id.equals(user.id) : user.id != null) {
            return false;
        }
        if (photo != null ? !photo.equals(user.photo) : user.photo != null) {
            return false;
        }
        if (organizationId != null ? !organizationId.equals(user.organizationId) : user.organizationId != null) {
            return false;
        }
        if (tags != null ? !tags.equals(user.tags) : user.tags != null) {
            return false;
        }
        return userFields != null ? userFields.equals(user.userFields) : user.userFields == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (photo != null ? photo.hashCode() : 0);
        result = 31 * result + (agent ? 1 : 0);
        result = 31 * result + (organizationId != null ? organizationId.hashCode() : 0);
        result = 31 * result + (tags != null ? tags.hashCode() : 0);
        result = 31 * result + (userFields != null ? userFields.hashCode() : 0);
        return result;
    }
}