package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

import zendesk.core.AuthenticationType;

/**
 * Wraps {@link SupportSettings} and makes settings call null-safe.
 * <p>
 * This class will generally default to false or 0 for return values if they don't exist.
 * </p>
 * <p>
 * Created by Zendesk on 28/07/15.
 */
@SuppressWarnings("unused")
public class SupportSdkSettings {

    private final SupportSettings mobileSettings;
    private final HelpCenterSettings helpCenterSettings;
    private final AuthenticationType authenticationType;

    /**
     * Creates an instance of SafeMobileSettings
     *
     * @param supportSettings    The Support SDK settings
     * @param helpCenterSettings The Help Center SDK settings
     * @param authenticationType The authentication type
     */
    public SupportSdkSettings(SupportSettings supportSettings,  HelpCenterSettings helpCenterSettings,
                              AuthenticationType authenticationType) {
        this.mobileSettings = supportSettings;
        this.helpCenterSettings = helpCenterSettings;
        this.authenticationType = authenticationType;
    }

    /**
     * Checks if conversations are enabled or not
     *
     * @return true only if conversations are enabled, false if they are not or the settings are
     * missing
     */
    public boolean isConversationsEnabled() {
        ConversationsSettings settings = getConversationsSettings();
        return settings != null && settings.isEnabled();
    }

    /**
     * Checks if attachments are enabled or not
     *
     * @return true only if they are enabled, false if they are not or the settings are missing
     */
    public boolean isAttachmentsEnabled() {
        AttachmentSettings settings = getAttachmentSettings();
        return settings != null && settings.isEnabled();
    }

    /**
     * Gets the maximum attachment size allowed in bytes
     *
     * @return The maximum attachment size allowed in bytes, or 0 if the settings are missing
     */
    public long getMaxAttachmentSize() {
        AttachmentSettings settings = getAttachmentSettings();
        return settings != null ? settings.getMaxAttachmentSize() : 0L;
    }

    /**
     * Checks if we have Help Center settings or not.
     *
     * @return true if we have a non-null {@link HelpCenterSettings}, false if not.
     */
    public boolean hasHelpCenterSettings() {
        return helpCenterSettings != null;
    }

    /**
     * Checks if help center is enabled or not.
     *
     * @return true only if help center is enabled, false if it is not or if the settings are
     * missing
     */
    public boolean isHelpCenterEnabled() {
        return helpCenterSettings != null && helpCenterSettings.isEnabled();
    }

    /**
     * Checks if help center voting is enabled or not.
     *
     * @return true only if help center voting is enabled, false if it is not or if the settings are
     * missing
     */
    public boolean isHelpCenterArticleVotingEnabled() {
        return hasHelpCenterSettings() && helpCenterSettings.isArticleVotingEnabled();
    }

    /**
     * Gets the default locale of the help center
     *
     * @return the default locale of the help center, or the empty string if the settings are missing
     */
    @NonNull
    public String getHelpCenterLocale() {
        final boolean isLocaleAvailable = helpCenterSettings != null && helpCenterSettings.getLocale() != null;
        return isLocaleAvailable ? helpCenterSettings.getLocale() : StringUtils.EMPTY_STRING;
    }

    /**
     * Gets the attachment settings
     * <p>
     * <code>mobileSettings.getAccountSettings()</code> is NonNull but let's check it anyway, in case
     * that is changed.
     * </p>
     *
     * @return the AttachmentSettings if we have them, null otherwise
     */
    @Nullable
    @SuppressWarnings("ConstantConditions")
    private AttachmentSettings getAttachmentSettings() {

        boolean hasAttachmentSettings = mobileSettings != null
                && mobileSettings.getAttachments() != null;

        return hasAttachmentSettings
                ? this.mobileSettings.getAttachments()
                : null;
    }

    /**
     * Gets the conversations settings
     * <p>
     * <code>mobileSettings.getSdkSettings()</code> is NonNull but let's check it anyway, in case
     * that is changed.
     * </p>
     *
     * @return the ConversationsSettings if we have them, null otherwise
     */
    @Nullable
    @SuppressWarnings("ConstantConditions")
    private ConversationsSettings getConversationsSettings() {

        boolean hasConversationSettings = mobileSettings != null
                && mobileSettings.getConversations() != null;

        return hasConversationSettings
                ? this.mobileSettings.getConversations()
                : null;
    }

    /**
     * Gets the tags to use for the {@code ContactZendesk} components.
     */
    @SuppressWarnings("ConstantConditions")
    @NonNull
    public List<String> getContactZendeskTags() {

        boolean hasContactUsSettings = mobileSettings != null
                && mobileSettings.getContactUs() != null
                && CollectionUtils.isNotEmpty(mobileSettings.getContactUs().getTags());

        return hasContactUsSettings
                ? mobileSettings.getContactUs().getTags()
                : new ArrayList<String>();
    }


    public AuthenticationType getAuthenticationType() {
        return authenticationType;
    }

    /**
     * Gets if TicketForm support is available, or not.
     *
     * @return {@code true} if TicketForm support is available, {@code false} if not.
     */
    @SuppressWarnings("ConstantConditions")
    public boolean isTicketFormSupportAvailable() {
        final boolean settingsValid = mobileSettings != null
                && mobileSettings.getTicketForms() != null;


        return settingsValid
                && mobileSettings.getTicketForms().isAvailable();
    }

    /**
     * Checks if the SDK is allowed to ask the end-user for an email address if needed
     *
     * @return {@code true} if the SDK is <b>not</b> allowed to ask for an email address.
     */
    public boolean isNeverAskForEmailEnabled() {
        return mobileSettings == null || mobileSettings.isNeverRequestEmailOn();
    }

    /**
     * Checks if the SDK is allowed to show closed requests in the {@code RequestListView}.
     *
     * @return {@code true} if the SDK should <b>should</b> display closed requests.
     */
    public boolean isShowClosedRequests() {
        return mobileSettings == null || mobileSettings.isShowClosedRequests();
    }

    /**
     * Checks if the SDK is allowed to display a referrer logo inside the {@code RequestListView}
     * and {@code RequestViewConversationsDisabled}.
     *
     * @return {@code true} if the SDK <b>should</b> display a referrer logo.
     */
    public boolean isShowReferrerLogoEnabled() {
        return mobileSettings != null && mobileSettings.isShowReferrerLogo();
    }

    /**
     * Gets the url that will be opened when referrer logo is clicked.
     *
     * @return the referrer url if we have it, empty {@code String} otherwise.
     */
    public String getReferrerUrl() {
        return mobileSettings != null && StringUtils.hasLength(mobileSettings.getReferrerUrl())
                ? mobileSettings.getReferrerUrl()
                : "https://www.zendesk.com/embeddables";
    }

    /**
     * Gets the system message that will be shown after the first message was successfully sent.
     *
     * @return the system message as a string
     */
    public String getRequestSystemMessage() {
        return mobileSettings != null && StringUtils.hasLength(mobileSettings.getSystemMessage())
                ? mobileSettings.getSystemMessage()
                : StringUtils.EMPTY_STRING;
    }

}
