package zendesk.support;

import androidx.annotation.VisibleForTesting;

/**
 * These settings describe how attachments are handled in your Zendesk instance.
 */
@SuppressWarnings("unused")
class AttachmentSettings {

    private boolean enabled;
    private long maxAttachmentSize;

    private static AttachmentSettings DEFAULT = new AttachmentSettings(false, 0L);

    static AttachmentSettings defaultSettings() {
        return DEFAULT;
    }

    @VisibleForTesting
    AttachmentSettings(boolean enabled, long maxAttachmentSize) {
        this.enabled = enabled;
        this.maxAttachmentSize = maxAttachmentSize;
    }

    @VisibleForTesting
    AttachmentSettings() {
        // intentionally empty
    }


    /**
     * This setting corresponds to the "Customers can attach files" setting in the Zendesk admin
     * interface.
     *
     * @return true if customers can attach files, false otherwise.
     */
    boolean isEnabled() {
        return enabled;
    }

    /**
     * This setting controls the maximum attachment size that can be uploaded to your Zendesk.
     *
     * @return The maximum attachment size allowed in bytes
     */
    long getMaxAttachmentSize() {
        return maxAttachmentSize;
    }
}
