package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

import java.util.Locale;

import zendesk.core.AuthenticationType;
import zendesk.core.SettingsPack;
import zendesk.core.SettingsProvider;
import zendesk.core.Zendesk;
import zendesk.core.ZendeskLocaleConverter;

/**
 * This provider will allow you to download {@link SupportSdkSettings}
 * from your Zendesk.
 * <p>
 * This provider requires that you have
 * {@link Support#init(Zendesk)}  correctly initialised Support}.
 * </p>
 */
class ZendeskSupportSettingsProvider implements SupportSettingsProvider {

    private static final String LOG_TAG = "ZendeskSettingsProvider";

    static final String SUPPORT_KEY = "support";
    private static final String HELP_CENTER_KEY = "help_center";

    private final SettingsProvider sdkSettingsProvider;
    private final ZendeskLocaleConverter localeConverter;
    private final Locale deviceLocale;

    ZendeskSupportSettingsProvider(SettingsProvider sdkSettingsProvider,
                                   ZendeskLocaleConverter localeConverter, Locale deviceLocale) {
        this.sdkSettingsProvider = sdkSettingsProvider;
        this.localeConverter = localeConverter;
        this.deviceLocale = deviceLocale;
    }

    @Override
    public void getSettings(@Nullable final ZendeskCallback<SupportSdkSettings> callback) {
        sdkSettingsProvider.getSettingsForSdk(SUPPORT_KEY, SupportSettings.class, new LoadSupportSettings(callback));
    }

    class LoadSupportSettings extends ZendeskCallback<SettingsPack<SupportSettings>> {

        private final ZendeskCallback<SupportSdkSettings> callback;

        LoadSupportSettings(ZendeskCallback<SupportSdkSettings> callback) {
            this.callback = callback;
        }

        @Override
        public void onSuccess(SettingsPack<SupportSettings> supportSettingsSettingsPack) {
            final LoadHelpCenterSettings loadHelpCenterSettingsCallback =
                    new LoadHelpCenterSettings(callback, supportSettingsSettingsPack);
            sdkSettingsProvider
                    .getSettingsForSdk(HELP_CENTER_KEY, HelpCenterSettings.class, loadHelpCenterSettingsCallback);
        }

        @Override
        public void onError(ErrorResponse errorResponse) {
            if (callback != null) {
                Logger.d(LOG_TAG, "Returning default Support Settings.");
                final SupportSdkSettings defaultSettings = new SupportSdkSettings(
                        SupportSettings.defaultSettings(),
                        HelpCenterSettings.defaultSettings(),
                        null);
                callback.onSuccess(defaultSettings);
            }
        }


        class LoadHelpCenterSettings extends ZendeskCallback<SettingsPack<HelpCenterSettings>> {

            private final ZendeskCallback<SupportSdkSettings> callback;
            private final SettingsPack<SupportSettings> supportSettingsPack;

            LoadHelpCenterSettings(ZendeskCallback<SupportSdkSettings> callback,
                                   SettingsPack<SupportSettings> supportSettingsPack) {
                this.callback = callback;
                this.supportSettingsPack = supportSettingsPack;
            }

            @Override
            public void onSuccess(SettingsPack<HelpCenterSettings> supportSettingsSettingsPack) {
                final HelpCenterSettings settings = supportSettingsSettingsPack.getSettings();
                final AuthenticationType authenticationType =
                        supportSettingsSettingsPack.getCoreSettings().getAuthentication();
                logIfLocaleNotAvailable(settings);

                Logger.d(LOG_TAG, "Successfully retrieved Settings");
                if (callback != null) {
                    callback.onSuccess(new SupportSdkSettings(supportSettingsPack.getSettings(),
                            settings,
                            authenticationType));
                }
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                if (callback != null) {
                    Logger.d(LOG_TAG, "Returning default Help Center Settings.");
                    final HelpCenterSettings defaultHelpCenterSettings = HelpCenterSettings.defaultSettings();
                    final AuthenticationType authenticationType =
                            supportSettingsPack.getCoreSettings().getAuthentication();

                    callback.onSuccess(new SupportSdkSettings(supportSettingsPack.getSettings(),
                            defaultHelpCenterSettings,
                            authenticationType));
                }
            }
        }

        private void logIfLocaleNotAvailable(HelpCenterSettings helpCenterSettings) {
            if (helpCenterSettings != null && helpCenterSettings.getLocale() != null) {
                // If we're still getting an NPE on this method call, WTF is going on?!
                // This incredibly redundant variable is a stab-in-the-dark attempt to avoid the very
                // strange NPE we intermittently get on Jenkins.
                String settingsLocale = helpCenterSettings.getLocale();

                final String locale = localeConverter.toHelpCenterLocaleString(deviceLocale);
                boolean requestedLocaleIsNotAvailable = !locale.equals(settingsLocale);

                if (requestedLocaleIsNotAvailable) {
                    Logger.w(LOG_TAG,
                            "No support for %s, Help Center is %s in your application settings",
                            locale, helpCenterSettings.isEnabled());
                }
            }
        }


    }
}