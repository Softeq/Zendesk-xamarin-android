package zendesk.support;

import com.zendesk.service.RetrofitZendeskCallbackAdapter;
import com.zendesk.service.ZendeskCallback;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.RequestBody;

/**
 * Service to provide POST operations for uploading/deleting files
 * {@link UploadService UploadService}
 */
@SuppressWarnings("unused")
class ZendeskUploadService {

    private static final String LOG_TAG = "ZendeskUploadService";

    private final UploadService uploadService;

    public ZendeskUploadService(UploadService uploadService) {
        this.uploadService = uploadService;
    }

    /**
     * Upload an attachment
     *
     * @param fileName Name of the file
     * @param file     The actual file which should be uploaded
     * @param mimeType The MIME type of the file (e.g. "image/png")
     * @param callback Callback that will deliver a newly uploaded file of type
     *                 {@link UploadResponseWrapper} or {@link com.zendesk.service.ErrorResponse}
     */
    void uploadAttachment(String fileName,
                          File file,
                          String mimeType,
                          final ZendeskCallback<UploadResponseWrapper> callback) {
        uploadService
                .uploadAttachment(fileName, RequestBody.create(MediaType.parse(mimeType), file))
                .enqueue(new RetrofitZendeskCallbackAdapter<UploadResponseWrapper, UploadResponseWrapper>(callback));
    }

    /**
     * Deletes an attachment
     *
     * @param token    Token of an attachment ({@link UploadResponse#getToken()})
     * @param callback Callback that will deliver a `Void` in onSuccess or onError with a
     * {@link com.zendesk.service.ErrorResponse}
     */
    void deleteAttachment(String token, final ZendeskCallback<Void> callback) {
        uploadService
                .deleteAttachment(token)
                .enqueue(new RetrofitZendeskCallbackAdapter<Void, Void>(callback));
    }
}
