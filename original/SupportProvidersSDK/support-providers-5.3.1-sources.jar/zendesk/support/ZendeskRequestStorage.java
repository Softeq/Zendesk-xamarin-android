package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.zendesk.util.CollectionUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import zendesk.core.BaseStorage;
import zendesk.core.MemoryCache;

class ZendeskRequestStorage implements RequestStorage {

    private final Object lock = new Object();

    private static final long HOUR_IN_MILLIS = TimeUnit.HOURS.toMillis(1);
    private static final String LOG_TAG = "ZendeskRequestStorage";

    private static final String TIMESTAMP_KEY = "zendesk_request_storage_requests_data_cache_time";
    private static final String REQUESTS_DATA_KEY = "zendesk_request_storage_request_data_list";
    private static final String MEMORY_CACHE_MIGRATED_KEY = "zendesk_request_storage_memory_cache_migrated_flag";

    private final BaseStorage storage;
    private final RequestMigrator requestMigrator;
    private final MemoryCache memoryCache;

    ZendeskRequestStorage(BaseStorage storage, RequestMigrator requestMigrator, MemoryCache memoryCache) {
        this.storage = storage;
        this.requestMigrator = requestMigrator;
        this.memoryCache = memoryCache;
    }

    @Override
    public void storeRequestData(@Nullable List<RequestData> requestData) {
        if (requestData == null) {
            return;
        }
        synchronized (lock) {
            storage.put(REQUESTS_DATA_KEY, new RequestDataList(requestData));
            storage.put(TIMESTAMP_KEY, Long.toString(System.currentTimeMillis()));
        }
    }

    @Override
    public boolean isRequestDataExpired() {
        String timestamp;
        synchronized (lock) {
            timestamp = storage.get(TIMESTAMP_KEY);
        }

        long millsTimeStamp = timestamp == null ? 0 : Long.parseLong(timestamp);
        return Math.abs(System.currentTimeMillis() - millsTimeStamp) > HOUR_IN_MILLIS;
    }

    @Override
    public void updateRequestData(List<Request> request) {
        synchronized (lock) {
            final List<RequestData> storedRequests = getRequestData();
            final List<RequestData> updatedList = updateRequests(storedRequests, request);
            storeRequestData(updatedList);
        }
    }

    @Override
    public void markRequestAsRead(String requestId, int commentCount) {
        synchronized (lock) {
            final List<RequestData> readRequestList = getRequestData();
            final List<RequestData> newList = new ArrayList<>(readRequestList.size());

            for (RequestData requestData : readRequestList) {
                if (requestId.equals(requestData.getId())) {
                    newList.add(RequestData.create(requestData.getId(), commentCount, commentCount));
                } else {
                    newList.add(requestData);
                }
            }

            storeRequestData(newList);
        }
    }

    @Override
    public void markRequestAsUnread(String requestId) {
        synchronized (lock) {
            final List<RequestData> readRequestList = getRequestData();
            final List<RequestData> newList = new ArrayList<>(readRequestList.size());

            for (RequestData requestData : readRequestList) {
                if (requestId.equals(requestData.getId())) {
                    final int newCommentCount = requestData.getCommentCount() + 1;
                    newList.add(RequestData.create(requestId, newCommentCount, requestData.getReadCommentCount()));
                } else {
                    newList.add(requestData);
                }
            }

            storeRequestData(newList);
        }
    }

    @Override
    @NonNull
    public List<RequestData> getRequestData() {
        checkForAndMigrateLegacyRequestData();

        final RequestDataList requestData;
        synchronized (lock) {
            requestData = storage.get(REQUESTS_DATA_KEY, RequestDataList.class);
        }
        return requestData != null ? requestData.requestDataList : new ArrayList<RequestData>(0);
    }

    private void checkForAndMigrateLegacyRequestData() {
        if (!memoryCache.getOrDefault(MEMORY_CACHE_MIGRATED_KEY, false)) {
            List<RequestData> legacyRequests = requestMigrator.getLegacyRequests();
            if (CollectionUtils.isNotEmpty(legacyRequests)) {

                storeRequestData(legacyRequests);

                requestMigrator.clearLegacyRequestStorage();

                memoryCache.put(MEMORY_CACHE_MIGRATED_KEY, true);
            }
        }
    }

    private static List<RequestData> updateRequests(List<RequestData> storedRequests, List<Request> newRequests) {

        final Map<String, RequestData> requestDataMap = new HashMap<>(storedRequests.size() + newRequests.size());

        for (RequestData data : storedRequests) {
            requestDataMap.put(data.getId(), data);
        }

        for (Request request : newRequests) {
            if (requestDataMap.containsKey(request.getId())) {
                RequestData storedRequest = requestDataMap.get(request.getId());
                requestDataMap.put(storedRequest.getId(),
                        RequestData.create(storedRequest.getId(),
                                request.getCommentCount(),
                                storedRequest.getReadCommentCount()));
            } else {
                requestDataMap.put(request.getId(), RequestData.create(request));
            }
        }

        return new ArrayList<>(requestDataMap.values());
    }
}
