package zendesk.support;

import com.google.gson.annotations.SerializedName;

public enum RequestStatus {

    @SerializedName("new")
    New,

    @SerializedName("open")
    Open,

    @SerializedName("pending")
    Pending,

    @SerializedName("hold")
    Hold,

    @SerializedName("solved")
    Solved,

    @SerializedName("closed")
    Closed,

}
