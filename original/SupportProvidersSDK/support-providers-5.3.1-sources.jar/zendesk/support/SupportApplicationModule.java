package zendesk.support;

import android.content.Context;

import java.util.Locale;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
class SupportApplicationModule {

    private ApplicationScope applicationScope;

    SupportApplicationModule(ApplicationScope applicationScope) {
        this.applicationScope = applicationScope;
    }

    @Provides
    @Singleton
    Locale provideLocale() {
        return applicationScope.getLocale();
    }

    @Provides
    @Singleton
    ZendeskTracker providesZendeskTracker() {
        return applicationScope.getZendeskTracker();
    }

    @Provides
    @Singleton
    SupportSdkMetadata provideMetadata(Context context) {
        return new SupportSdkMetadata(context);
    }
}
