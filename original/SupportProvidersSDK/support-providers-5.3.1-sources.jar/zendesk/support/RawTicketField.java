package zendesk.support;

import com.google.gson.annotations.SerializedName;
import com.zendesk.util.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
 * Json model class for TicketFields.
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/core/ticket_fields">Ticket fields</a>
 */
class RawTicketField {

    private long accountId;
    private Date createdAt;
    private String defaultContentKey;
    private String description;
    private long id;

    @SerializedName("isActive")
    private boolean active;

    @SerializedName("isCollapsedForAgents")
    private boolean collapsedForAgents;

    @SerializedName("isEditableInPortal")
    private boolean editableInPortal;

    @SerializedName("isExportable")
    private boolean exportable;

    @SerializedName("isRequired")
    private boolean required;

    @SerializedName("isRequiredInPortal")
    private boolean requiredInPortal;

    @SerializedName("isVisibleInPortal")
    private boolean visibleInPortal;

    private int position;
    private String regexpForValidation;
    private long subTypeId;
    private String tag;
    private String title;
    private String titleInPortal;
    private TicketFieldType type;
    private Date updatedAt;

    private List<RawTicketFieldOption> customFieldOptions;
    private List<RawTicketFieldSystemOption> systemFieldOptions;

    /**
     * Gets the ID of the ticket field.
     *
     * @return the id of the field
     */
    long getId() {
        return id;
    }

    /**
     * Gets the title of the ticket field.
     *
     * @return the title of the field
     */
    String getTitle() {
        return title;
    }


    /**
     * Gets title of the ticket field for end user
     *
     * @return title the ticket field title for end users
     */
    String getTitleInPortal() {
        return titleInPortal;
    }

    /**
     * Gets the type of the ticket field.
     *
     * @return the type of the ticket field
     */
    TicketFieldType getType() {
        return type;
    }

    /**
     * Gets the description of the ticket field.
     *
     * @return the description of the ticket field
     */
    String getDescription() {
        return description;
    }

    /**
     * Gets the regular expression to validate the ticket field.
     *
     * @return the regular expression to validate the ticket field
     */
    String getRegexpForValidation() {
        return regexpForValidation;
    }

    /**
     * Ticket field options, this field will only be populated for {@code TicketFieldType.Tagger} field types
     *
     * @return a list of ticket field options
     */
    List<RawTicketFieldOption> getCustomFieldOptions() {
        return CollectionUtils.copyOf(customFieldOptions);
    }

    /**
     * Ticket field system options, this field will only be populated for {@code TicketFieldType.Priority} field types
     *
     * @return a list of ticket field system options
     */
    List<RawTicketFieldSystemOption> getSystemFieldOptions() {
        return CollectionUtils.copyOf(systemFieldOptions);
    }
}