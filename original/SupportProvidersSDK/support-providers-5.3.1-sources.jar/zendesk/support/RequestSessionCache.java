package zendesk.support;

import androidx.annotation.NonNull;

import java.util.List;

/**
 * Cache for storing network results like ticket forms in memory.
 */
interface RequestSessionCache {

    /**
     * Add a list of {@link TicketForm} to the cache.
     *
     * @param ticketForms a list of {@link TicketForm}
     */
    void updateTicketFormCache(@NonNull List<TicketForm> ticketForms);

    /**
     * Retrieve a list of cached {@link TicketForm}.
     *
     * @return a list of {@link TicketForm} or {@code null}
     * if  the cache is empty.
     */
    @NonNull
    List<TicketForm> getTicketFormsById(@NonNull List<Long> ticketFormIds);

    /**
     * Query the cache if stored ids are available.
     *
     * @param ticketFormIds list of ticket form ids ({@link TicketForm#getId()})
     * @return {@code true} if the ticket form ids are available in cache,
     * {@code false} if not
     */
    boolean containsAllTicketForms(@NonNull List<Long> ticketFormIds);

}