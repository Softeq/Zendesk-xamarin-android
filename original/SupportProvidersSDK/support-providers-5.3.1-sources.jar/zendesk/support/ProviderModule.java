package zendesk.support;

import java.util.Locale;

import javax.inject.Singleton;

import zendesk.core.AuthenticationProvider;
import zendesk.core.BlipsProvider;
import zendesk.core.RestServiceProvider;
import zendesk.core.SettingsProvider;
import zendesk.core.ZendeskLocaleConverter;

import dagger.Module;
import dagger.Provides;

@Module
class ProviderModule {

    @Provides
    @Singleton
    SupportSettingsProvider provideSdkSettingsProvider(SettingsProvider sdkSettingsProvider,
                                                       Locale locale,
                                                       ZendeskLocaleConverter helpCenterLocaleConverter) {
        return new ZendeskSupportSettingsProvider(sdkSettingsProvider, helpCenterLocaleConverter, locale);
    }

    @Provides
    @Singleton
    ZendeskLocaleConverter provideZendeskLocaleConverter() {
        return new ZendeskLocaleConverter();
    }

    @Provides
    @Singleton
    UploadProvider provideUploadProvider(ZendeskUploadService uploadService) {
        return new ZendeskUploadProvider(uploadService);
    }

    @Provides
    @Singleton
    RequestProvider provideRequestProvider(SupportSettingsProvider settingsProvider,
                                           AuthenticationProvider authenticationProvider,
                                           ZendeskRequestService requestService,
                                           RequestStorage requestStorage,
                                           RequestSessionCache requestSessionCache,
                                           ZendeskTracker zendeskTracker,
                                           SupportSdkMetadata supportSdkMetadata,
                                           SupportBlipsProvider blipsProvider) {

        return new ZendeskRequestProvider(settingsProvider, requestService, authenticationProvider,
                requestStorage, requestSessionCache, zendeskTracker, supportSdkMetadata, blipsProvider);
    }

    @Provides
    @Singleton
    SupportBlipsProvider provideSupportBlipsProvider(BlipsProvider blipsProvider) {
        return new ZendeskSupportBlipsProvider(blipsProvider);
    }

    @Provides
    @Singleton
    ProviderStore provideProviderStore(HelpCenterProvider helpCenterProvider,
                                       RequestProvider requestProvider, UploadProvider uploadProvider) {
        return new ZendeskProviderStore(helpCenterProvider, requestProvider, uploadProvider);
    }

    @Provides
    @Singleton
    SupportModule provideSupportModule(RequestProvider requestProvider, UploadProvider uploadProvider,
                                       HelpCenterProvider helpCenterProvider, SupportSettingsProvider settingsProvider,
                                       RestServiceProvider restServiceProvider, SupportBlipsProvider blipsProvider,
                                       ZendeskTracker zendeskTracker, ArticleVoteStorage articleVoteStorage) {
        return new SupportModule(requestProvider, uploadProvider,
                helpCenterProvider, settingsProvider, blipsProvider,
                restServiceProvider.getMediaOkHttpClient(),
                zendeskTracker,
                articleVoteStorage);
    }
}
