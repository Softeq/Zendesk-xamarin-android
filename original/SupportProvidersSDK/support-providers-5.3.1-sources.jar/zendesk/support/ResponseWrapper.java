package zendesk.support;

/**
 * Wrapper class to encapsulate a generic response received from Zendesk service.
 */
@SuppressWarnings("unused")
public abstract class ResponseWrapper {
    private Integer count;
    private String nextPage;
    private String previousPage;

    /**
     * Gets the count of the resources in this response
     *
     * @return the count of the resources in this response
     */
    public Integer getCount() {
        return count;
    }

    /**
     * Gets the API URL of the next page
     *
     * @return the API URL of the next page
     */
    public String getNextPage() {
        return nextPage;
    }

    /**
     * Gets the API URL of the previous page
     *
     * @return the API URL of the previous page
     */
    public String getPreviousPage() {
        return previousPage;
    }

}
