package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Wrapper class so that a List<RequestData> can be stored easily in base storage
 */
final class RequestDataList {

    @NonNull
    final List<RequestData> requestDataList = new ArrayList<>(0);

    RequestDataList(@Nullable List<RequestData> requestDataList) {
        if (CollectionUtils.isNotEmpty(requestDataList)) {
            this.requestDataList.addAll(requestDataList);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RequestDataList dataList = (RequestDataList) o;

        return requestDataList.equals(dataList.requestDataList);
    }

    @Override
    public int hashCode() {
        return requestDataList.hashCode();
    }

}
