package zendesk.support;

import java.util.List;

/**
 * Models behaviour for checking for and migrating requests from legacy versions of Support SDK
 * (1.x) to 2.0 or above.
 * <p>
 * This is used internally by the SDK and should not be called directly by an integrator.
 */
interface RequestMigrator {

    /**
     * Returns a list of any request IDs with stored comment counts from legacy (1.x) versions of
     * the Support SDK, or an empty list if none are found. The returned data should be immediately
     * put into {@link RequestStorage#storeRequestData(List)}.
     * <p>
     * If any are found, they will be migrated to the 2.0 storage so
     * that the requests are not lost in the upgrade. Following the migration, the data will be
     * removed from the legacy storage location.
     */
    List<RequestData> getLegacyRequests();

    /**
     * Deletes all data from the legacy request storage file.
     * <p>
     * This should only be invoked following a successful migration of request data from a legacy
     * (1.x) version of the Support SDK, immediately after the migration completes. Failing to call
     * this method could result in re-migrating the same data multiple times. Calling this method
     * too soon could result in deleting the data before it has been migrated, losing it forever.
     */
    void clearLegacyRequestStorage();
}
