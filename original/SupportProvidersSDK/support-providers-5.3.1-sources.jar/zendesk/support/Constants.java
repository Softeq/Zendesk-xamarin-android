package zendesk.support;

/**
 * Constants required for network operations
 */
public interface Constants {

    /**
     * Mobile-Sdk-Identity header name, used to convey identity information.
     */
    String SDK_GUID_HEADER = "Mobile-Sdk-Identity";

    /**
     * Date format for displaying hours and minutes.
     */
    String HOURS_MINUTES_FORMAT = "mm:ss";

    /**
     * Header name for the standard cache control header.
     */
    String USER_AGENT_VARIANT = "Support";

    /**
     * Action string for refreshing the Request List UI.
     */
    String ACTION_REFRESH_REQUEST_LIST = "request_list_refresh";

    /**
     * Action string for refreshing the Request Conversation UI.
     */
    String ACTION_REFRESH_REQUEST_CONVERSATION = "request_conversation_refresh";

    /**
     * Action string for Action Handlers which allow the user to contact
     */
    String ACTION_CONTACT_OPTION = "action_contact_option";

    /**
     * Action string for opening a conversation list UI (such as Support SDK's RequestListActivity).
     */
    String ACTION_CONVERSATION_LIST = "action_conversation_list";

    /**
     * Map key for a Help Center article URL when using an ActionHandler to open the article UI.
     */
    String KEY_HELP_CENTER_ARTICLE_URL = "help_center_view_article";
}
