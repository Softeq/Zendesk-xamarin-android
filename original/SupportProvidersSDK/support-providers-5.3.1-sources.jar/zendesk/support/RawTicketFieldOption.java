package zendesk.support;

import com.google.gson.annotations.SerializedName;

/**
 * Json model class for TicketFieldOption.
 */
class RawTicketFieldOption {

    private long id;
    private String name;
    private String rawName;
    private String value;

    /**
     * Convert a {@link RawTicketFieldOption} into a {@link TicketFieldOption}
     *
     * @param rawTicketFieldOption a raw ticket field option
     * @return the new ticket field option
     */
    public static TicketFieldOption create(RawTicketFieldOption rawTicketFieldOption) {
        return new TicketFieldOption(rawTicketFieldOption.getId(),
                rawTicketFieldOption.getName(),
                rawTicketFieldOption.getValue(),
                rawTicketFieldOption.isDefault());
    }

    @SerializedName("default")
    private boolean isDefault;

    /**
     * Gets the ID of the ticket field option.
     *
     * @return the id of the ticket field option
     */
    long getId() {
        return id;
    }

    /**
     * Gets the name of the ticket field option.
     *
     * @return the name of the ticket field option.
     */
    String getName() {
        return name;
    }

    /**
     * Gets the value of the ticket field option.
     *
     * @return the value of the ticket field option.
     */
    String getValue() {
        return value;
    }

    /**
     * Gets if the field is the default value.
     *
     * @return {@code true} if it is the default value, {@code false} if not
     */
    boolean isDefault() {
        return isDefault;
    }
}
