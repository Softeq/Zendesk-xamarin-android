package zendesk.support;

import javax.inject.Singleton;

import zendesk.core.CoreModule;

import dagger.Component;

@Component(modules = {
        SupportApplicationModule.class,
        CoreModule.class,
        ServiceModule.class,
        ProviderModule.class,
        GuideModule.class,
        StorageModule.class
})
@Singleton
interface SupportSdkProvidersComponent {

    Support inject(Support config);
}
