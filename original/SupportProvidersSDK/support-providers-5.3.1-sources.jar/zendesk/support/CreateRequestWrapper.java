package zendesk.support;


/**
 * Models the api request which is formed when creating a request in Zendesk
 */
@SuppressWarnings({"FieldCanBeLocal", "unused"})
class CreateRequestWrapper {

    private CreateRequest request;

    CreateRequestWrapper(CreateRequest request) {
        this.request = request;
    }
}
