package zendesk.support;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * Json model class for TicketFormResponses.
 */
class RawTicketFormResponse {

    private List<RawTicketForm> ticketForms;
    private List<RawTicketField> ticketFields;

    /**
     * Gets a list of {@link RawTicketForm}.
     *
     * @return a list of ticket forms
     */
    List<RawTicketForm> getTicketForms() {
        return CollectionUtils.copyOf(ticketForms);
    }

    /**
     * Gets a list of {@link RawTicketField}.
     *
     * @return a list of ticket fields
     */
    List<RawTicketField> getTicketFields() {
        return CollectionUtils.copyOf(ticketFields);
    }
}
