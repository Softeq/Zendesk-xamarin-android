package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.sdk.providers.BuildConfig;
import com.zendesk.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

import zendesk.core.BlipsGroup;
import zendesk.core.BlipsProvider;
import zendesk.core.UserAction;

class ZendeskSupportBlipsProvider implements SupportBlipsProvider {

    private static final String BLIPS_SUPPORT_VERSION = BuildConfig.VERSION_NAME;
    private static final String BLIPS_SUPPORT_CHANNEL = "support_sdk";

    private static final String BLIPS_SUPPORT_CATEGORY = "SupportSDK";

    private static final String BLIPS_SUPPORT_ACTION_INIT = "init";
    private static final String BLIPS_SUPPORT_ACTION_REQUEST_CREATED = "requestCreated";
    private static final String BLIPS_SUPPORT_ACTION_REQUEST_UPDATED = "requestUpdated";
    private static final String BLIPS_SUPPORT_ACTION_REQUEST_VIEWED = "requestViewed";
    private static final String BLIPS_SUPPORT_ACTION_REQUEST_LIST_VIEWED = "requestListViewed";

    private static final String BLIPS_FIELD_NAME_REQUEST_ID = "requestId";

    private BlipsProvider blipsProvider;

    ZendeskSupportBlipsProvider(BlipsProvider blipsProvider) {
        this.blipsProvider = blipsProvider;
    }

    @Override
    public void supportSdkInit() {
        sendUserAction(BlipsGroup.REQUIRED, BLIPS_SUPPORT_ACTION_INIT, null);
    }

    @Override
    public void requestCreated(String requestId) {
        if (StringUtils.isEmpty(requestId)) {
            return;
        }

        Map<String, Object> value = new HashMap<>();
        value.put(BLIPS_FIELD_NAME_REQUEST_ID, requestId);

        sendUserAction(BlipsGroup.BEHAVIOURAL, BLIPS_SUPPORT_ACTION_REQUEST_CREATED, value);
    }

    @Override
    public void requestUpdated(String requestId) {
        if (StringUtils.isEmpty(requestId)) {
            return;
        }

        Map<String, Object> value = new HashMap<>();
        value.put(BLIPS_FIELD_NAME_REQUEST_ID, requestId);

        sendUserAction(BlipsGroup.BEHAVIOURAL, BLIPS_SUPPORT_ACTION_REQUEST_UPDATED, value);
    }

    @Override
    public void requestViewed(String requestId) {
        if (StringUtils.isEmpty(requestId)) {
            return;
        }

        Map<String, Object> value = new HashMap<>();
        value.put(BLIPS_FIELD_NAME_REQUEST_ID, requestId);

        sendUserAction(BlipsGroup.BEHAVIOURAL, BLIPS_SUPPORT_ACTION_REQUEST_VIEWED, value);
    }

    @Override
    public void requestListViewed() {
        sendUserAction(BlipsGroup.BEHAVIOURAL, BLIPS_SUPPORT_ACTION_REQUEST_LIST_VIEWED, null);
    }

    private void sendUserAction(@NonNull BlipsGroup group, @NonNull String action,
                                @Nullable Map<String, Object> value) {
        blipsProvider.sendBlip(new UserAction(
                BLIPS_SUPPORT_VERSION,
                BLIPS_SUPPORT_CHANNEL,
                BLIPS_SUPPORT_CATEGORY,
                action,
                null,
                value
        ), group);
    }
}
