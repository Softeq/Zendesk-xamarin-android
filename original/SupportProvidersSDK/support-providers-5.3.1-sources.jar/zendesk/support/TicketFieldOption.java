package zendesk.support;

/**
 * Model class for ticket field option.
 */
public class TicketFieldOption {

    /**
     * Convert a {@link RawTicketFieldOption} into a {@link TicketFieldOption}
     *
     * @param rawTicketFieldOption a raw ticket field option
     * @return the new ticket field option
     */
    static TicketFieldOption create(RawTicketFieldOption rawTicketFieldOption) {
        return new TicketFieldOption(rawTicketFieldOption.getId(),
                rawTicketFieldOption.getName(),
                rawTicketFieldOption.getValue(),
                rawTicketFieldOption.isDefault());
    }

    private long id;
    private String name;
    private String value;
    private boolean isDefault;

    /**
     * Constructor for creating an instance of a ticket field option.
     *
     * @param id    ticket field option name
     * @param name  ticket field option name
     * @param value ticket field option value
     */
    TicketFieldOption(long id, String name, String value, boolean isDefault) {
        this.id = id;
        this.name = name;
        this.value = value;
        this.isDefault = isDefault;
    }

    /**
     * Gets the ID of the ticket field option.
     *
     * @return the id of the ticket field option
     */
    public long getId() {
        return id;
    }

    /**
     * Gets the name of the ticket field option.
     *
     * @return the name of the ticket field option.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the value of the ticket field option.
     *
     * @return the value of the ticket field option.
     */
    public String getValue() {
        return value;
    }

    /**
     * Gets if the field is the default value.
     *
     * @return {@code true} if it is the default value, {@code false} if not
     */
    public boolean isDefault() {
        return isDefault;
    }
}