package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

import java.io.File;

/**
 * Provider used to upload files to a Zendesk instance and retrieve {@link UploadResponse}
 */
class ZendeskUploadProvider implements UploadProvider {

    private final ZendeskUploadService uploadService;

    /**
     * Default constructor for instantiating an implementation of {@link UploadProvider}
     */
    ZendeskUploadProvider(ZendeskUploadService uploadService) {
        this.uploadService = uploadService;
    }

    /**
     * Calls a upload service to upload a file on behalf of the end-user.
     *
     * @param fileName Name of the file
     * @param file     The actual file which should be uploaded
     * @param mimeType The MIME type of the file (e.g. "image/png")
     * @param callback Callback that will deliver a newly uploaded file of type
     */
    @Override
    public void uploadAttachment(@NonNull final String fileName,
                                 @NonNull final File file,
                                 @NonNull final String mimeType,
                                 @Nullable final ZendeskCallback<UploadResponse> callback) {
        uploadService.uploadAttachment(fileName, file, mimeType,
                new ZendeskCallbackSuccess<UploadResponseWrapper>(callback) {
                    @Override
                    public void onSuccess(UploadResponseWrapper result) {
                        if (callback != null) {
                            callback.onSuccess(result.getUpload());
                        }
                    }
                });
    }


    /**
     * Calls a upload service to delete an upload on behalf of the end-user.
     *
     * @param token    Token of an attachment ({@link UploadResponse#getToken()})
     * @param callback Callback that will deliver a newly uploaded file of type
     *                 {@link UploadResponse} or {@link ErrorResponse}
     */
    @Override
    public void deleteAttachment(@NonNull final String token, @Nullable final ZendeskCallback<Void> callback) {
        uploadService.deleteAttachment(token, callback);
    }
}
