package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

abstract class ZendeskCallbackSuccess<E> extends ZendeskCallback<E> {

    private final ZendeskCallback callback;

    ZendeskCallbackSuccess(@Nullable ZendeskCallback callback) {
        this.callback = callback;
    }

    @Override
    public abstract void onSuccess(final E e);

    @Override
    public void onError(final ErrorResponse errorResponse) {
        if (callback != null) {
            callback.onError(errorResponse);
        }
    }
}
