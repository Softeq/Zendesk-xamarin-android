package zendesk.support;

import com.zendesk.sdk.providers.BuildConfig;

import javax.inject.Singleton;

import zendesk.core.RestServiceProvider;

import dagger.Module;
import dagger.Provides;

@Module
class ServiceModule {

    @Provides
    @Singleton
    static ZendeskRequestService provideZendeskRequestService(RequestService requestService) {
        return new ZendeskRequestService(requestService);
    }

    @Provides
    @Singleton
    static ZendeskUploadService provideZendeskUploadService(UploadService uploadService) {
        return new ZendeskUploadService(uploadService);
    }

    @Provides
    @Singleton
    static RequestService providesRequestService(RestServiceProvider restServiceProvider) {
        return restServiceProvider.createRestService(RequestService.class, BuildConfig.VERSION_NAME,
                Constants.USER_AGENT_VARIANT);
    }

    @Provides
    @Singleton
    static UploadService providesUploadService(RestServiceProvider restServiceProvider) {
        return restServiceProvider.createRestService(UploadService.class, BuildConfig.VERSION_NAME,
                Constants.USER_AGENT_VARIANT);
    }

}
