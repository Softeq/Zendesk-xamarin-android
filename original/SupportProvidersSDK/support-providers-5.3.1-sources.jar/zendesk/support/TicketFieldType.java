package zendesk.support;

import com.google.gson.annotations.SerializedName;

/**
 * All supported ticket field types.
 */
public enum TicketFieldType {

    @SerializedName("checkbox")
    Checkbox,

    @SerializedName("date")
    Date,

    @SerializedName("decimal")
    Decimal,

    @SerializedName("description")
    Description,

    @SerializedName("integer")
    Integer,

    @SerializedName("partial_credit_card")
    PartialCreditCard,

    @SerializedName("priority")
    Priority,

    @SerializedName("status")
    Status,

    @SerializedName("tickettype")
    TicketType,

    @SerializedName("regexp")
    Regexp,

    @SerializedName("subject")
    Subject,

    @SerializedName("tagger")
    Tagger,

    @SerializedName("text")
    Text,

    @SerializedName("textarea")
    TextArea,

    @SerializedName("multiselect")
    MultiSelect,

    Unknown
}