package zendesk.support;

import androidx.annotation.Nullable;

/**
 * UpdateRequestWrapper object is used to model the payload required when posting an update to a request.
 */
class UpdateRequestWrapper {

    private Request request;

    /**
     * Set the request to be sent for updating
     *
     * @param request Request to be sent for updating
     */
    void setRequest(Request request) {
        this.request = request;
    }

    /**
     * Get the request that was updated
     *
     * @return The request that was updated
     */
    @Nullable
    Request getRequest() {
        return request;
    }
}
