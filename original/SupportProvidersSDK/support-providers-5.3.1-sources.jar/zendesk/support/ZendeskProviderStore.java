package zendesk.support;

/**
 * Default implementation of {@link ProviderStore}. Used in {@link Support} to
 * hold instances of all available provider classes.
 */
class ZendeskProviderStore implements ProviderStore {

    private final HelpCenterProvider helpCenterProvider;
    private final RequestProvider requestProvider;
    private final UploadProvider uploadProvider;

    ZendeskProviderStore(HelpCenterProvider helpCenterProvider,
                         RequestProvider requestProvider,
                         UploadProvider uploadProvider) {
        this.helpCenterProvider = helpCenterProvider;
        this.requestProvider = requestProvider;
        this.uploadProvider = uploadProvider;
    }

    @Override
    public HelpCenterProvider helpCenterProvider() {
        return helpCenterProvider;
    }

    @Override
    public RequestProvider requestProvider() {
        return requestProvider;
    }

    @Override
    public UploadProvider uploadProvider() {
        return uploadProvider;
    }

}
