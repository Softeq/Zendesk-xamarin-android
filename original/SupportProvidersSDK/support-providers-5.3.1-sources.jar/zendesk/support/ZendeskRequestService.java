package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.RetrofitZendeskCallbackAdapter;
import com.zendesk.service.ZendeskCallback;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/**
 * <p>
 * Service to provide CRUD operations for Requests by wrapping the
 * {@link RequestService RequestService}
 * </p>
 */
@SuppressWarnings("unused")
class ZendeskRequestService {

    private static final String LOG_TAG = "ZendeskRequestService";
    private static final String TICKET_FIELDS_INCLUDE = "ticket_fields";
    private static final String ROLE_USER = "end_user";
    private static final String ROLE_AGENT = "agent";

    private final RequestService requestService;
    private final DateFormat iso8601 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);

    ZendeskRequestService(RequestService requestService) {
        this.requestService = requestService;
        iso8601.setTimeZone(TimeZone.getTimeZone("UTC"));
    }

    /**
     * Creates a request.
     * <p>
     * For anonymous requests we must pass the SDK GUID but this is not required for requests
     * made when using a JWT identity.
     * </p>
     *
     * @param sdkGuid  Sdk guid associated with anonymous identity. Pass null if using JWT
     *                 identity.
     * @param request  Request object
     * @param callback Callback that will deliver a {@link Request} or {@link ErrorResponse}
     */
    public void createRequest(@Nullable String sdkGuid,
                              CreateRequest request,
                              final ZendeskCallback<Request> callback) {
        final CreateRequestWrapper wrapper = new CreateRequestWrapper(request);

        requestService
                .createRequest(sdkGuid, wrapper)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback,
                        new RetrofitZendeskCallbackAdapter.RequestExtractor<RequestResponse, Request>() {
                            @Override
                            public Request extract(final RequestResponse data) {
                                return data.getRequest();
                            }
                        }));
    }

    /**
     * Gets all end user requests
     *
     * @param status   A comma separated list of status which will filter the requests that are returned. Can be null
     *                 if all requests are to be retrieved.
     * @param include  A comma separated list of side loads to be included with the request, Can be null
     * @param callback Callback that will deliver the list of {@link Request} or {@link Throwable}
     */
    void getAllRequests(String status, String include, final ZendeskCallback<List<Request>> callback) {
        requestService
                .getAllRequests(status, include)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback, requestsExtractor));
    }

    /**
     * Gets all end user requests for a comma-separated list of request IDs
     *
     * @param requestId A comma separated list of request ids which is based on requests created by the device
     * @param status    A comma separated list of status which will filter the requests that are returned. Can be null
     * @param include   A comma separated list of side loads to be included with the request, Can be null
     * @param callback  Callback that will deliver the list of {@link Request} or {@link Throwable}
     */
    void getAllRequests(String requestId,
                        String status,
                        String include,
                        final ZendeskCallback<List<Request>> callback) {
        requestService
                .getManyRequests(requestId, status, include)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback, requestsExtractor));
    }

    /**
     * Gets comments for a specified Request
     *
     * @param requestId The id of the {@link Request} to get the comments for
     * @param callback  Callback that will deliver the {@link CommentsResponse} or {@link Throwable}
     */
    void getComments(String requestId, final ZendeskCallback<CommentsResponse> callback) {
        requestService
                .getComments(requestId)
                .enqueue(new RetrofitZendeskCallbackAdapter<CommentsResponse, CommentsResponse>(callback));
    }

    /**
     * Gets comments for a request since a specified point in time.
     *
     * @param requestId The id of the {@link Request} to get the comments for
     * @param since     The date
     * @param onlyAgent {@code true} to fetch only agent comments, {@code false} to all comments.
     * @param callback  Callback that will deliver the {@link CommentsResponse} or {@link Throwable}
     */
    void getCommentsSince(String requestId, Date since, boolean onlyAgent, ZendeskCallback<CommentsResponse> callback) {
        final String sSince = iso8601.format(since);
        final String role = onlyAgent ? ROLE_AGENT : null;
        requestService
                .getCommentsSince(requestId, sSince, role)
                .enqueue(new RetrofitZendeskCallbackAdapter<CommentsResponse, CommentsResponse>(callback));
    }

    /**
     * Add a comment on a request created by end user.
     *
     * @param requestId The id of the {@link Request} to add a comment to
     * @param comment   Comment object
     * @param callback  Callback that will deliver a {@link Request} or {@link ErrorResponse}
     */
    void addComment(String requestId, EndUserComment comment, final ZendeskCallback<Request> callback) {
        final UpdateRequestWrapper updateRequestWrapper = new UpdateRequestWrapper();
        final Request request = new Request();
        request.setComment(comment);
        updateRequestWrapper.setRequest(request);
        requestService
                .addComment(requestId, updateRequestWrapper)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback,
                        new RetrofitZendeskCallbackAdapter.RequestExtractor<RequestResponse, Request>() {
                            @Override
                            public Request extract(final RequestResponse requestResponse) {
                                return requestResponse.getRequest();
                            }
                        }));
    }

    /**
     * Get a request for the given id.
     *
     * @param requestId Id of a request
     * @param include   A comma separated list of side loads to be included with the request, Can be null
     * @param callback  Callback that will deliver a {@link RequestResponse}
     *                  or {@link ErrorResponse}
     */
    void getRequest(String requestId, String include, final ZendeskCallback<Request> callback) {
        requestService
                .getRequest(requestId, include)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback, requestExtractor));
    }

    /**
     * Get a all available ticket forms.
     *
     * @param callback Callback that will deliver a {@link RawTicketFormResponse]}
     *                 or {@link ErrorResponse}
     */
    void getTicketFormsById(String ticketFormIds,
                            ZendeskCallback<RawTicketFormResponse> callback) {
        requestService
                .getTicketFormsById(ticketFormIds, TICKET_FIELDS_INCLUDE)
                .enqueue(new RetrofitZendeskCallbackAdapter<RawTicketFormResponse, RawTicketFormResponse>(callback));
    }

    private final RetrofitZendeskCallbackAdapter.RequestExtractor<RequestsResponse, List<Request>> requestsExtractor =
            new RetrofitZendeskCallbackAdapter.RequestExtractor<RequestsResponse, List<Request>>() {
                @Override
                public List<Request> extract(RequestsResponse requestsResponse) {
                    final Map<Long, User> users = getAgentMap(requestsResponse.getLastCommentingAgents());

                    final List<Request> requests = new ArrayList<>();
                    for (Request request : requestsResponse.getRequests()) {
                        requests.add(updateLastCommentingAgents(request, users));
                    }

                    return requests;
                }
            };

    private final RetrofitZendeskCallbackAdapter.RequestExtractor<RequestResponse, Request> requestExtractor =
            new RetrofitZendeskCallbackAdapter.RequestExtractor<RequestResponse, Request>() {

                @Override
                public Request extract(RequestResponse requestResponse) {
                    final Map<Long, User> users = getAgentMap(requestResponse.getLastCommentingAgents());
                    return updateLastCommentingAgents(requestResponse.getRequest(), users);
                }
            };

    private static Map<Long, User> getAgentMap(List<User> agents) {
        final Map<Long, User> users = new HashMap<>(agents.size());
        for (User user : agents) {
            final User agent = new User(user.getId(), user.getName(), user.getPhoto(), true, -1L, null, null);
            users.put(user.getId(), agent);
        }
        return users;
    }

    private static Request updateLastCommentingAgents(Request request, Map<Long, User> agentMap) {
        final List<User> requestUser = new ArrayList<>(request.getLastCommentingAgentsIds().size());
        for (Long id : request.getLastCommentingAgentsIds()) {
            requestUser.add(agentMap.get(id));
        }
        request.setLastCommentingAgents(requestUser);
        return request;
    }

}
