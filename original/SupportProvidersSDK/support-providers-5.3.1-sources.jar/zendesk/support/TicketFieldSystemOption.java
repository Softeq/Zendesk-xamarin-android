package zendesk.support;

/**
 * Model class for ticket field system option.
 */
public class TicketFieldSystemOption {

    /**
     * Convert a {@link RawTicketFieldSystemOption} into a {@link TicketFieldSystemOption}
     *
     * @param rawTicketFieldSystemOption a raw ticket field system option
     * @return the new system field system option
     */
    static TicketFieldSystemOption create(RawTicketFieldSystemOption rawTicketFieldSystemOption) {
        return new TicketFieldSystemOption(
                rawTicketFieldSystemOption.getName(),
                rawTicketFieldSystemOption.getValue());
    }

    private String name;
    private String value;

    /**
     * Constructor for creating an instance of a ticket field system option.
     *
     * @param name  ticket field system option name
     * @param value ticket field system option value
     */
    TicketFieldSystemOption(String name, String value) {
        this.name = name;
        this.value = value;
    }

    /**
     * Gets the name of the ticket field system option.
     *
     * @return the name of the ticket field system option.
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the value of the ticket field system option.
     *
     * @return the value of the ticket field system option.
     */
    public String getValue() {
        return value;
    }
}