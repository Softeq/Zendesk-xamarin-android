package zendesk.support;

import android.content.Context;
import android.content.SharedPreferences;

import javax.inject.Singleton;

import zendesk.core.MemoryCache;
import zendesk.core.SessionStorage;

import dagger.Module;
import dagger.Provides;

@Module
class StorageModule {

    /**
     * SharedPreferences file name for legacy (1.x) request storage. Necessary for migration.
     */
    private static final String LEGACY_REQUEST_STORAGE_PREFS_NAME = "zendesk-authorization";

    @Provides
    @Singleton
    RequestStorage provideRequestStorage(SessionStorage baseStorage, RequestMigrator requestMigrator,
                                         MemoryCache memoryCache) {
        return new ZendeskRequestStorage(baseStorage.getAdditionalSdkStorage(), requestMigrator,
                memoryCache);
    }

    @Provides
    @Singleton
    RequestSessionCache provideRequestSessionCache() {
        return new ZendeskRequestSessionCache();
    }

    @Provides
    @Singleton
    RequestMigrator provideRequestMigrator(Context context) {
        SharedPreferences sharedPrefs =
                context.getSharedPreferences(LEGACY_REQUEST_STORAGE_PREFS_NAME, Context.MODE_PRIVATE);

        return new LegacyRequestMigrator(sharedPrefs);
    }
}
