package zendesk.support;

import java.util.UUID;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;

/**
 * Module holding references to internal dependencies.
 */
@Module
public class SupportModule {

    private final RequestProvider requestProvider;
    private final UploadProvider uploadProvider;
    private final HelpCenterProvider helpCenterProvider;
    private final SupportBlipsProvider blipsProvider;

    private final SupportSettingsProvider settingsProvider;
    private final OkHttpClient okHttpClient;
    private final ZendeskTracker zendeskTracker;
    private final ArticleVoteStorage articleVoteStorage;
    private final UUID id;

    public SupportModule(RequestProvider requestProvider, UploadProvider uploadProvider,
                         HelpCenterProvider helpCenterProvider, SupportSettingsProvider settingsProvider,
                         SupportBlipsProvider blipsProvider, OkHttpClient okHttpClient,
                         ZendeskTracker zendeskTracker, ArticleVoteStorage articleVoteStorage) {
        this.id = UUID.randomUUID();
        this.requestProvider = requestProvider;
        this.uploadProvider = uploadProvider;
        this.helpCenterProvider = helpCenterProvider;
        this.settingsProvider = settingsProvider;
        this.blipsProvider = blipsProvider;
        this.okHttpClient = okHttpClient;
        this.zendeskTracker = zendeskTracker;
        this.articleVoteStorage = articleVoteStorage;
    }

    @Provides
    RequestProvider providesRequestProvider() {
        return requestProvider;
    }

    @Provides
    UploadProvider providesUploadProvider() {
        return uploadProvider;
    }

    @Provides
    HelpCenterProvider providesHelpCenterProvider() {
        return helpCenterProvider;
    }

    @Provides
    SupportSettingsProvider providesSettingsProvider() {
        return settingsProvider;
    }

    @Provides
    OkHttpClient providesOkHttpClient() {
        return okHttpClient;
    }

    @Provides
    ZendeskTracker providesZendeskTracker() {
        return zendeskTracker;
    }

    @Provides
    SupportBlipsProvider providesBlipsProvider() {
        return blipsProvider;
    }

    @Provides
    ArticleVoteStorage providesArticleVoteStorage() {
        return articleVoteStorage;
    }

    public UUID getId() {
        return id;
    }
}
