package zendesk.support;

import androidx.annotation.VisibleForTesting;

/**
 * Models the TicketForm settings.
 */
public class TicketFormSettings {

    private boolean available;

    private static TicketFormSettings DEFAULT = new TicketFormSettings(false);

    static TicketFormSettings defaultSettings() {
        return DEFAULT;
    }

    @VisibleForTesting
    TicketFormSettings(boolean available) {
        this.available = available;
    }

    /**
     * Determines whether TicketForms are available or not.
     *
     * @return {@code true} if TicketForm support is available, {@code false} otherwise.
     */
    public boolean isAvailable() {
        return available;
    }
}