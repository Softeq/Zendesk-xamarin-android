package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.Collections;
import java.util.Map;

public final class RequestUpdates {

    @NonNull
    private final Map<String, Integer> requestIds;

    public RequestUpdates(@Nullable Map<String, Integer> requestIds) {
        if (requestIds == null) {
            this.requestIds = Collections.emptyMap();
        } else {
            this.requestIds = requestIds;
        }
    }

    @NonNull
    public Map<String, Integer> getRequestUpdates() {
        return CollectionUtils.copyOf(requestIds);
    }

    public boolean isRequestUnread(String requestId) {
        return requestIds.containsKey(requestId) && requestIds.get(requestId) > 0;
    }

    /**
     * @return a map of request IDs to update counts
     */
    public boolean hasUpdatedRequests() {
        return !requestIds.isEmpty();
    }

    /**
     * @return the sum of all updates for all requests
     */
    public int totalUpdates() {
        int count = 0;
        for (Integer requestUpdates : requestIds.values()) {
            count += requestUpdates;
        }
        return count;
    }
}