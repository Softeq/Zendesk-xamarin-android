package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Model class for ticket field.
 */
public class TicketField {

    /**
     * Convert a {@link RawTicketField} into a {@link TicketField}
     *
     * @param rawTicketField a raw ticket field
     * @return the new {@link TicketField}
     */
    static TicketField create(RawTicketField rawTicketField) {

        List<TicketFieldOption> ticketFieldOptions = new ArrayList<>();
        final List<RawTicketFieldOption> rawTicketFieldOptions = rawTicketField.getCustomFieldOptions();
        for (RawTicketFieldOption rtfo : rawTicketFieldOptions) {
            ticketFieldOptions.add(TicketFieldOption.create(rtfo));
        }

        List<TicketFieldSystemOption> ticketFieldSystemOptions = new ArrayList<>();
        final List<RawTicketFieldSystemOption> rawTicketFieldSystemOptions = rawTicketField.getSystemFieldOptions();
        for (RawTicketFieldSystemOption rtfso : rawTicketFieldSystemOptions) {
            ticketFieldSystemOptions.add(TicketFieldSystemOption.create(rtfso));
        }

        final TicketFieldType type;
        if (rawTicketField.getType() != null) {
            type = rawTicketField.getType();
        } else {
            type = TicketFieldType.Unknown;
        }

        return new TicketField(
                rawTicketField.getId(),
                type,
                rawTicketField.getTitle(),
                rawTicketField.getTitleInPortal(),
                rawTicketField.getDescription(),
                rawTicketField.getRegexpForValidation(),
                ticketFieldOptions,
                ticketFieldSystemOptions
        );
    }

    private long id;
    private TicketFieldType type;
    private String title;
    private String titleInPortal;
    private String description;
    private String regexpForValidation;
    private List<TicketFieldOption> ticketFieldOptions;
    private List<TicketFieldSystemOption> ticketFieldSystemOptions;


    /**
     * Constructor for creating an instance of a ticket field.
     *
     * @param id                  ticket field id
     * @param type                ticket field type
     * @param title               ticket field title
     * @param description         ticket field description
     * @param regexpForValidation regular expression for validation
     */
    TicketField(long id, @NonNull TicketFieldType type, @NonNull String title,
                @NonNull String titleInPortal, @NonNull String description,
                @Nullable String regexpForValidation,
                @NonNull List<TicketFieldOption> ticketFieldOptions,
                @NonNull List<TicketFieldSystemOption> ticketFieldSystemOptions) {
        this.id = id;
        this.type = type;
        this.title = title;
        this.titleInPortal = titleInPortal;
        this.description = description;
        this.regexpForValidation = regexpForValidation;
        this.ticketFieldOptions = ticketFieldOptions;
        this.ticketFieldSystemOptions = ticketFieldSystemOptions;
    }

    /**
     * Gets the ID of the ticket field.
     *
     * @return the ID of the ticket field
     */
    public long getId() {
        return id;
    }

    /**
     * Gets the type of the ticket field.
     *
     * @return the type of the ticket field.
     */
    @NonNull
    public TicketFieldType getType() {
        return type;
    }

    /**
     * Gets the title of the ticket field.
     *
     * @return the title of the ticket field.
     */
    @NonNull
    public String getTitle() {
        return title;
    }

    /**
     * Gets title of the ticket field for end user
     *
     * @return title the ticket field title for end users
     */
    @NonNull
    public String getTitleInPortal() {
        return titleInPortal;
    }

    /**
     * Gets the description of the ticket field.
     *
     * @return the description of the ticket field.
     */
    @NonNull
    public String getDescription() {
        return description;
    }

    /**
     * Gets a regular expression for validation.
     *
     * @return a regular expression for validation
     */
    @Nullable
    public String getRegexpForValidation() {
        return regexpForValidation;
    }

    /**
     * Ticket field options, this field will only be populated for {@link TicketFieldType#Tagger} field types
     *
     * @return a list of ticket field options
     */
    @NonNull
    public List<TicketFieldOption> getTicketFieldOptions() {
        return CollectionUtils.copyOf(ticketFieldOptions);
    }

    /**
     * Ticket field system options, this field will only be populated for {@link TicketFieldType#Priority} field types
     *
     * @return a list of ticket field system options
     */
    @NonNull
    public List<TicketFieldSystemOption> getTicketFieldSystemOptions() {
        return CollectionUtils.copyOf(ticketFieldSystemOptions);
    }
}