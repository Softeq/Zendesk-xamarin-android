package zendesk.support;

import com.google.gson.annotations.SerializedName;
import com.zendesk.util.CollectionUtils;

import java.util.Date;
import java.util.List;

/**
 * Json model class for TicketForms.
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/core/ticket_forms">Ticket forms</a>
 */
class RawTicketForm {

    private String url;
    private long id;
    private String name;
    private String rawName;
    private String rawDisplayName;
    private boolean endUserVisible;
    private int position;
    private List<Long> ticketFieldIds;

    @SerializedName("active")
    private boolean isActive;

    @SerializedName("default")
    private boolean isDefault;

    private Date createdAt;
    private Date updatedAt;
    private boolean inAllBrands;
    private List<Long> restrictedBrandIds;
    private boolean inAllOrganizations;
    private List<Long> restrictedOrganizationIds;

    /**
     * Convert a {@link RawTicketForm} into a {@link TicketForm}
     *
     * @param rawTicketForm a raw ticket form from the endpoint
     * @param ticketFields  a list of {@link TicketField} that are associated with this
     *                      ticket form
     * @return the new {@link TicketForm}
     */
    public static TicketForm create(RawTicketForm rawTicketForm, List<TicketField> ticketFields) {
        return new TicketForm(rawTicketForm.getId(), rawTicketForm.getName(), ticketFields);
    }

    /**
     * Gets the ID of the ticket form.
     *
     * @return the id of the ticket form
     */
    long getId() {
        return id;
    }


    /**
     * Gets the name of the ticket form.
     *
     * @return the name of the ticket form
     */
    String getName() {
        return name;
    }

    /**
     * Gets the list of {@link RawTicketField#getId()} that are
     * associated with this ticket field.
     *
     * @return a list of ticket field ids
     */
    List<Long> getTicketFieldIds() {
        return CollectionUtils.copyOf(ticketFieldIds);
    }
}