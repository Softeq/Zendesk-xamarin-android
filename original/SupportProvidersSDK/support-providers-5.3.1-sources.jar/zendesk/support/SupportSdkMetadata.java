package zendesk.support;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;

import com.zendesk.logger.Logger;
import com.zendesk.util.LocaleUtil;
import com.zendesk.util.StringUtils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;

/**
 * Provides metadata information about the device for the Support SDK Metadata App in Lotus.
 */
class SupportSdkMetadata {
    private static final String LOG_TAG = "SupportSdkMetadata";

    private static final int EXPECTED_TOKEN_COUNT = 3;
    private static final long BYTES_MULTIPLIER = 1024L;
    private static final int BAD_VALUE = -1;

    private static final String DEVICE_INFO_OS_VERSION = "device_os";
    private static final String DEVICE_INFO_API_VERSION = "device_api";
    private static final String DEVICE_INFO_MODEL_TYPE = "device_model";
    private static final String DEVICE_INFO_DEVICE_NAME = "device_name";
    private static final String DEVICE_INFO_USED_MEMORY = "device_used_memory";
    private static final String DEVICE_INFO_TOTAL_MEMORY = "device_total_memory";
    private static final String DEVICE_INFO_LOW_MEMORY = "device_low_memory";
    private static final String DEVICE_INFO_MANUFACTURER = "device_manufacturer";
    private static final String DEVICE_INFO_BATTERY = "device_battery";

    private final Context context;
    private final ActivityManager activityManager;

    SupportSdkMetadata(Context context) {
        this.context = context;
        this.activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
    }

    Map<String, String> getDeviceInfoAsMapForMetaData() {

        HashMap<String, String> map = new HashMap<>();

        map.put(DEVICE_INFO_OS_VERSION, getVersionName());
        map.put(DEVICE_INFO_API_VERSION, String.valueOf(getVersionCode()));
        map.put(DEVICE_INFO_MODEL_TYPE, getModel());
        map.put(DEVICE_INFO_DEVICE_NAME, getModelDeviceName());
        map.put(DEVICE_INFO_MANUFACTURER, getManufacturer());

        map.put(DEVICE_INFO_TOTAL_MEMORY, getBytesInMb(getTotalMemory()));
        map.put(DEVICE_INFO_USED_MEMORY, getBytesInMb(getUsedMemory()));
        map.put(DEVICE_INFO_LOW_MEMORY, String.valueOf(isLowMemory()));

        map.put(DEVICE_INFO_BATTERY, String.valueOf(getBatteryLevel()));

        return map;
    }

    private String getBytesInMb(long bytes) {
        return String.valueOf(bytes / (BYTES_MULTIPLIER * BYTES_MULTIPLIER));
    }

    /**
     * Returns locale of the device. This will always be just the device locale and not the SDK locale.
     *
     * @return device's locale
     * @see Locale#getDefault()
     */
    String getLocale() {
        return LocaleUtil.toLanguageTag(Locale.getDefault());
    }

    /**
     * Gets the OS version name of the device.
     *
     * @return the OS version of the device, like 4.4.2
     */
    private String getVersionName() {
        return Build.VERSION.RELEASE;
    }

    /**
     * Gets the API level of the OS
     *
     * @return the api level of the OS
     */
    private int getVersionCode() {
        return Build.VERSION.SDK_INT;
    }

    /**
     * Returns model and device name concatenated together
     * <p>
     * If the values are unknown an empty string is returned
     * </p>
     *
     * @return concatenated model and device name
     * @see Build#MODEL
     * @see Build#DEVICE
     */
    private String getModel() {
        boolean noModelInfo = Build.UNKNOWN.equals(Build.MODEL) || StringUtils.isEmpty(Build.MODEL);
        boolean noDeviceInfo = Build.UNKNOWN.equals(Build.DEVICE) || StringUtils.isEmpty(Build.DEVICE);
        if (noModelInfo && noDeviceInfo) {
            return StringUtils.EMPTY_STRING;
        }
        if (Build.MODEL.equals(Build.DEVICE)) {
            return Build.MODEL;
        } else {
            return String.format(Locale.US, "%s/%s", Build.MODEL, Build.DEVICE);
        }
    }

    /**
     * Returns the manufacturer of the device
     * <p>
     * If the values are unknown an empty string is returned
     * </p>
     *
     * @return device manufacturer
     * @see Build#MANUFACTURER
     */
    private String getManufacturer() {
        boolean noManufacturerInfo =
                Build.UNKNOWN.equals(Build.MANUFACTURER) || StringUtils.isEmpty(Build.MANUFACTURER);
        if (noManufacturerInfo) {
            return StringUtils.EMPTY_STRING;
        }

        return Build.MANUFACTURER;
    }

    /**
     * Gets the device name. This is usually a code-name like m7 for the HTC One
     *
     * @return The device name
     */
    private String getModelDeviceName() {
        return Build.DEVICE;
    }

    /**
     * Returns current battery level
     *
     * @return percentage of battery charge remaining
     */
    private int getBatteryLevel() {
        IntentFilter batteryChangedFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.getApplicationContext().registerReceiver(null, batteryChangedFilter);

        return (batteryStatus != null)
                ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, BAD_VALUE)
                : BAD_VALUE;
    }

    /**
     * Returns the used memory in bytes
     *
     * @return the used memory in bytes
     */
    private long getUsedMemory() {
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);

        return getTotalMemory() - memoryInfo.availMem;
    }

    /**
     * Gets the total memory in megabytes that this device has.
     * <p>
     * This version will automatically pick the best way of determining the total amount of
     * memory depending on what Android API level the device is running on. If the API level
     * is 17 or later the memory is read directly from the
     * {@link android.app.ActivityManager.MemoryInfo MemoryInfo API}.
     * </p>
     * <p>
     * If the API level is lower than 17 then the memory will be determined by examining the
     * /proc/meminfo file.
     * </p>
     *
     * @return The total memory in bytes
     */
    private long getTotalMemory() {

        long totalMemoryMegabytes;

        Logger.d(LOG_TAG, "Using getTotalMemoryApi() to determine memory");
        totalMemoryMegabytes = getTotalMemoryApi();

        return totalMemoryMegabytes;
    }

    /**
     * Determines whether the device is currently experiencing a low memory warning.
     *
     * @return true if this device is experiencing a low memory warning at this instant, false otherwise.
     */
    private boolean isLowMemory() {
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();

        activityManager.getMemoryInfo(memoryInfo);

        return memoryInfo.lowMemory;
    }

    /**
     * Gets the total memory that this device has by reading /proc/meminfo
     * <p>
     * Prefer the use of {@link #getTotalMemory() getTotalMemory()} because this will select
     * the best method of determining the total amount of memory.
     * </p>
     *
     * @return the total memory in bytes
     */
    private long getTotalMemoryCompat() {

        long totalMemoryBytes = BAD_VALUE;

        BufferedReader memoryInfoReader = null;
        String totalMemory = StringUtils.EMPTY_STRING;

        try {
            memoryInfoReader = new BufferedReader(new FileReader("/proc/meminfo"));
            totalMemory = memoryInfoReader.readLine();
        } catch (IOException e) {
            Logger.e(LOG_TAG, "Failed to determine total memory from /proc/meminfo: " + e.getMessage(), e);
        } finally {
            if (memoryInfoReader != null) {
                try {
                    memoryInfoReader.close();
                } catch (IOException e) {
                    Logger.w(LOG_TAG, "Failed to close /proc/meminfo file stream: " + e.getMessage(), e);
                }
            }
        }

        StringTokenizer st = new StringTokenizer(totalMemory);

        /*
          We expect a line in /proc/meminfo to be like
          "Label    123456 kB"
         */
        try {
            if (st.countTokens() == EXPECTED_TOKEN_COUNT) {
                st.nextToken();
                totalMemoryBytes = Long.valueOf(st.nextToken()) * BYTES_MULTIPLIER;
            }
        } catch (NoSuchElementException nse) {
            Logger.e(LOG_TAG, "Error reading tokens from the /proc/meminfo", nse);
        } catch (NumberFormatException nfe) {
            Logger.e(LOG_TAG, "Error reading memory size from proc/meminfo", nfe);
        }

        return totalMemoryBytes;
    }

    /**
     * Gets the total memory that this device has from the Android APIs directly.
     * <p>
     * Prefer the use of {@link #getTotalMemory() getTotalMemory()} because this will select
     * the best method of determining the total amount of memory.
     * </p>
     *
     * @return the total memory in bytes
     */
    private long getTotalMemoryApi() {

        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);

        return memoryInfo.totalMem;
    }
}
