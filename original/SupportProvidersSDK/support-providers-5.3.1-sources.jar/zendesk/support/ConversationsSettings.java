package zendesk.support;

import androidx.annotation.VisibleForTesting;

/**
 * Models the Conversations settings which will be used by the {@code RequestActivity}
 * or the {@code RequestListActivity}.
 */
@SuppressWarnings("unused")
class ConversationsSettings {

    private boolean enabled;

    private static ConversationsSettings DEFAULT = new ConversationsSettings(false);

    static ConversationsSettings defaultSettings() {
        return DEFAULT;
    }

    @VisibleForTesting
    ConversationsSettings(boolean enabled) {
        this.enabled = enabled;
    }

    @VisibleForTesting
    ConversationsSettings() {
        // intentionally empty
    }

    /**
     * Determines whether the Conversations feature should be enabled or not.
     *
     * @return true if conversations is enabled, false otherwise.
     */
    boolean isEnabled() {
        return enabled;
    }
}
