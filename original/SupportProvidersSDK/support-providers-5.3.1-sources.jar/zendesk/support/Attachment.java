package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.io.Serializable;
import java.util.List;

/**
 * This is a model class for an Attachment object.
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/core/attachments">Attachments</a>
 */
@SuppressWarnings({"unused"})
public class Attachment implements Serializable {

    private Long id;
    private String url;
    private String fileName;
    private String contentUrl;
    private String mappedContentUrl;
    private String contentType;
    private Long size;
    private Long width;
    private Long height;
    private List<Attachment> thumbnails;

    /**
     * Gets the API URL of the attachment
     *
     * @return the API URL of the attachment
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the ID of the attachment
     *
     * @return the ID of the attachment
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the file name of the attachment
     *
     * @return the file name of the attachment
     */
    @Nullable
    public String getFileName() {
        return fileName;
    }

    /**
     * Gets the URL at which the attachment can be downloaded
     *
     * @return the URL at which the attachment can be downloaded
     */
    @Nullable
    public String getContentUrl() {
        return contentUrl;
    }

    /**
     * Gets the content type of the attachment, e.g. image/png
     *
     * @return the content type of the attachment, e.g. image/png
     */
    @Nullable
    public String getContentType() {
        return contentType;
    }

    /**
     * Gets the size of the attachment in bytes
     *
     * @return the size of the attachment in bytes
     */
    @Nullable
    public Long getSize() {
        return size;
    }

    /**
     * Gets the width of the attachment in pixels
     *
     * @return the size of the attachment in pixels
     */
    @Nullable
    public Long getWidth() {
        return width;
    }

    /**
     * Gets the height of the attachment in pixels
     *
     * @return the height of the attachment in pixels
     */
    @Nullable
    public Long getHeight() {
        return height;
    }

    /**
     * Gets the thumbnails of the attachment
     *
     * @return the thumbnails of the attachment
     */
    @NonNull
    public List<Attachment> getThumbnails() {
        return CollectionUtils.copyOf(thumbnails);
    }
}