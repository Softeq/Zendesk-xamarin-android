package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * Models the api response from the api call to create a {@link Request} in Zendesk
 */
@SuppressWarnings("unused")
class RequestResponse {

    private Request request;
    private List<User> lastCommentingAgents;

    /**
     * Gets the request that was created
     *
     * @return The request that was created
     */
    @Nullable
    Request getRequest() {
        return request;
    }

    /**
     * Gets a list of commenting agents
     *
     * @return a list of commenting agents
     */
    @NonNull
    List<User> getLastCommentingAgents() {
        return CollectionUtils.copyOf(lastCommentingAgents);
    }
}
