package zendesk.support;

import androidx.annotation.NonNull;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * Represents a response that is received from Zendesk server when getting requests.
 *
 * @see <a href ="http://developer.zendesk.com/documentation/rest_api/requests.html#getting-requests">Getting
 * Requests</a>
 */
@SuppressWarnings("unused")
class RequestsResponse extends ResponseWrapper {

    private List<Request> requests;
    private List<User> lastCommentingAgents;

    /**
     * Gets the requests contained in this response
     *
     * @return the requests contained in this response
     */
    @NonNull
    List<Request> getRequests() {
        return CollectionUtils.copyOf(requests);
    }

    /**
     * Gets a list of commenting agents
     *
     * @return a list of commenting agents
     */
    @NonNull
    List<User> getLastCommentingAgents() {
        return CollectionUtils.copyOf(lastCommentingAgents);
    }
}
