package zendesk.support;

/**
 * Json model class for {@link TicketFieldSystemOption}.
 */
class RawTicketFieldSystemOption {

    private String name;
    private String value;

    /**
     * Gets the name of the ticket field system option.
     *
     * @return the name of the ticket field system option.
     */
    String getName() {
        return name;
    }

    /**
     * Gets the value of the ticket field system option.
     *
     * @return the value of the ticket field system option.
     */
    String getValue() {
        return value;
    }
}
