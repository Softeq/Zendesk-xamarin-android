package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import com.zendesk.util.CollectionUtils;

import java.util.Collections;
import java.util.List;

/**
 * Models the Request settings which will be used by the {@code ContactZendeskActivity}
 * or the {@code ContactZendeskFragment}.
 */
@SuppressWarnings("unused")
class ContactUsSettings {

    private List<String> tags;

    private static ContactUsSettings DEFAULT = new ContactUsSettings(Collections.<String>emptyList());

    static ContactUsSettings defaultSettings() {
        return DEFAULT;
    }

    @VisibleForTesting
    ContactUsSettings(List<String> tags) {
        this.tags = tags;
    }

    @VisibleForTesting
    ContactUsSettings() {
        // intentionally empty
    }

    /**
     * Gets a list of tags that will be appended to the ticket that is created by the contact Zendesk
     * component.
     * <p>
     * These server-supplied tags will be appended to any locally specified tags and will not
     * overwrite them.
     * </p>
     *
     * @return The list of tags to append to the ticket.  This is unmodifiable.
     */
    @NonNull
    public List<String> getTags() {
        return CollectionUtils.copyOf(tags);
    }

}