package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * CustomFields model which allows for custom data to be set on a request
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/core/requests">Zendesk Rest API on Requests</a>
 */
@SuppressWarnings({"unused", "FieldCanBeLocal"})
public class CustomField implements Serializable {

    private static final String LOG_TAG = "CustomField";

    private Long id;
    private Object value;

    /**
     * Constructor for a custom field model to be included with a ticket
     *
     * @param id    The id of the custom field
     * @param value The value of the custom field
     */
    public CustomField(Long id, Object value) {
        this.id = id;
        this.value = value;
    }

    /**
     * @return the id of the custom ticket field
     */
    public Long getId() {
        return id;
    }

    /**
     * @return the value as {@link String} of the custom ticket field
     * @deprecated use #getValueString()
     * <p>
     * As of 2.2.2 #value is of type Object, and may be a String, a Boolean, or a List<String>
     * This is to support multi-select custom fields. Use type specific getters for value,
     * or use #getValueObject() to get the value as an object.
     */
    @Deprecated
    @Nullable
    public String getValue() {
        if (value instanceof String) {
            return (String) value;
        } else if (value instanceof Boolean) {
            return String.valueOf(value);
        } else {
            Logger.w(LOG_TAG,
                    "Custom Field Value is of a type other than String or Boolean. Is this a multi-select field?");
            return null;
        }
    }

    /**
     * @return the value as {@link Object} of the custom ticket field
     */
    @Nullable
    public Object getValueObject() {
        return value;
    }

    /**
     * @return the value as {@link String} of the custom ticket field. Returns null if value is not a String
     */
    @Nullable
    public String getValueString() {
        if (value == null) {
            return null;
        }
        if (value instanceof String) {
            return (String) value;
        } else {
            Logger.w(LOG_TAG, "Custom field value is not a string");
            return null;
        }
    }

    /**
     * @return the value as {@link Boolean} of the custom ticket field. Returns null if value is not a Boolean
     */
    @Nullable
    public Boolean getValueBoolean() {
        if (value == null) {
            return null;
        }
        if (value instanceof Boolean) {
            return (Boolean) value;
        } else {
            Logger.w(LOG_TAG, "Custom field value is not a boolean");
            return null;
        }
    }

    /**
     * @return the value of the custom ticket field as a {@link List} of {@link String}. Returns null if value is not
     * a List
     */
    @Nullable
    public List<String> getValueList() {
        if (value == null) {
            return null;
        }
        if (value instanceof List) {
            List valueList = (List) value;
            if (CollectionUtils.isNotEmpty(valueList)) {
                List<String> stringValues = new ArrayList<>(valueList.size());
                for (Object object : valueList) {
                    stringValues.add(String.valueOf(object));
                }
                return stringValues;
            }
        }
        Logger.w(LOG_TAG, "Custom field value is not a list.");
        return null;
    }
}
