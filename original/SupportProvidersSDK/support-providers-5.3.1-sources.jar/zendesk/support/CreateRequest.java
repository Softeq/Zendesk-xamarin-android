package zendesk.support;

import androidx.annotation.Nullable;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is a model class for a request which will be created by the {@link RequestProvider}
 */
@SuppressWarnings({"unused", "FieldCanBeLocal", "MismatchedQueryAndUpdateOfCollection"})
public class CreateRequest {

    private static final transient String METADATA_SDK_KEY = "sdk";

    private String id;

    private List<String> tags;

    private String subject;

    private Comment comment;

    private Long ticketFormId;

    private Map<String, Map<String, String>> metadata;

    private List<CustomField> customFields;

    /**
     * Gets the ID for this request
     *
     * @return the ID for this request
     */
    @Nullable
    public String getId() {
        return id;
    }

    /**
     * Sets the ID for this request
     *
     * @param id the ID to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the tags for this request
     *
     * @return the tags for this request, or null if there are none
     */
    @Nullable
    public List<String> getTags() {
        return tags;
    }

    /**
     * Sets the tags for this request
     *
     * @param tags the tags to set for this request
     */
    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    /**
     * Gets the description of this request
     *
     * @return the description of this request, or null if there is none
     */
    @Nullable
    public String getDescription() {
        return comment == null ? null : comment.getBody();
    }

    /**
     * Sets the description of this request
     *
     * @param description the description to set
     */
    public void setDescription(String description) {
        if (comment == null) {
            comment = new Comment();
        }
        comment.setBody(description);
    }

    /**
     * Sets a {@link List} of attachment {@code UploadResponse#token} to this Request.
     *
     * @param attachments The list of tokens to set
     * @see <a href="https://developer.zendesk.com/rest_api/docs/core/attachments#example-response">Uploading
     * attachments</a>
     */
    public void setAttachments(List<String> attachments) {
        if (comment == null) {
            comment = new Comment();
        }
        comment.setAttachments(attachments);
    }

    /**
     * Returns a {@link List} of attachment {@code UploadResponse#token}s attached to the Request.
     *
     * If no attachments have been added, the list will be empty.
     *
     * @return
     */
    public List<String> getAttachments() {
        if (comment == null) {
            return Collections.emptyList();
        }

        return comment.getAttachments();
    }

    /**
     * Gets the subject of this request
     *
     * @return the subject of this request
     */
    @Nullable
    public String getSubject() {
        return subject;
    }

    /**
     * Sets the subject of this request
     *
     * @param subject the subject to set
     */
    public void setSubject(String subject) {
        this.subject = subject;
    }

    /**
     * Sets the custom fields for this Request.
     *
     * @param customFields The list of custom fields to set
     * @see
     * <a href="https://developer.zendesk.com/embeddables/docs/android/providers#using-custom-fields-and-custom-forms">Custom fields and forms documentation</a>
     */
    public void setCustomFields(List<CustomField> customFields) {
        this.customFields = customFields;
    }

    /**
     * Sets the metadata for this Request.
     *
     * @param metadata The metadata to set.
     * @see <a href="https://developer.zendesk.com/embeddables/docs/android/providers#using-metadata">Metadata
     * documentation</a>
     */
    public void setMetadata(Map<String, String> metadata) {
        this.metadata = new HashMap<>();
        this.metadata.put(METADATA_SDK_KEY, metadata);
    }

    /**
     * Sets the ticket form id for this Request.
     * <p>
     * The ticket form id will be ignored if your Zendesk doesn't support it.  Currently
     * Enterprise and higher plans support this.
     * </p>
     *
     * @param ticketFormId The ticket form id to set
     * @see
     * <a href="https://developer.zendesk.com/embeddables/docs/android/providers#using-custom-fields-and-custom-forms">Custom fields and forms documentation</a>
     */
    public void setTicketFormId(Long ticketFormId) {
        this.ticketFormId = ticketFormId;
    }

    public Long getTicketFormId() {
        return ticketFormId;
    }

    public List<CustomField> getCustomFields() {
        return customFields;
    }
}
