package zendesk.support;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * A provider which will offer a higher level of abstraction compared to the {@link RequestService}
 * <br>
 * You can create an instance of RequestProvider like this:
 *
 * <pre>
 *      import zendesk.support.RequestProvider;
 *      import zendesk.support.Support;
 *      ...
 *      RequestProvider provider = Support.INSTANCE.provider().requestProvider();
 *      ...
 * </pre>
 *
 * <p>
 * Once you have an instance of the provider you can call methods on it and handle the results
 * in callbacks. A success callback will give you the resource(s) that you are requesting, like
 * requests, comments, and so on. The error callback will be called if there was some
 * issue with the method call and it will define details about the error in an
 * {@link ErrorResponse}
 * </p>
 * <p>
 * For example you can list all your requests like this:
 *
 * <pre>
 *   provider.getAllRequests(new ZendeskCallback{@literal <List&lt;Request>>}() {
 *       {@literal @Override}
 *       public void onSuccess(List&lt;Request&gt; requests) {
 *           // Handle success
 *       }
 *
 *       {@literal @Override}
 *       public void onError(ErrorResponse errorResponse) {
 *           // Handle error
 *       }
 *  });
 * </pre>
 */
@SuppressWarnings("unused")
public interface RequestProvider {

    /**
     * Calls a request service to create a request on behalf of the end-user.
     *
     * @param request  The request to create
     * @param callback Callback that will deliver a newly created request of type
     *                 {@link Request} or {@link ErrorResponse}
     * @since 2.0.0.1
     */
    void createRequest(@NonNull final CreateRequest request, @Nullable final ZendeskCallback<Request> callback);

    /**
     * Gets all requests that user has opened.
     *
     * @param callback The callback to invoke which will return a list of {@link Request} or an
     *                 {@link ErrorResponse}
     * @since 1.0.0.1
     */
    void getAllRequests(@Nullable ZendeskCallback<List<Request>> callback);

    /**
     * Filters requests that user has opened by a status.
     *
     * @param status   A comma separated list of status to filter the results by status.
     *                 <ul>
     *                 <li>new</li>
     *                 <li>open</li>
     *                 <li>pending</li>
     *                 <li>hold</li>
     *                 <li>solved</li>
     *                 <li>closed</li>
     *                 </ul>
     * @param callback The callback to invoke which will return a list of
     *                 {@link Request} or an {@link ErrorResponse}
     * @since 1.0.0.1
     */
    void getRequests(@NonNull String status, @Nullable ZendeskCallback<List<Request>> callback);

    /**
     * Gets all comments for a request.
     *
     * @param requestId Id of a request. This is a String Id that will have been returned
     *                  by {@link #getAllRequests(ZendeskCallback)} or
     *                  {@link #getRequests(String, ZendeskCallback)}
     * @param callback  Callback that will deliver a {@link CommentsResponse} or
     *                  {@link ErrorResponse}
     * @since 1.0.0.1
     */
    void getComments(@NonNull String requestId, @Nullable ZendeskCallback<CommentsResponse> callback);

    /**
     * Gets comments for a request since a specified point in time.
     *
     * @param requestId Id of a request. This is a String Id that will have been returned
     *                  by {@link #getAllRequests(ZendeskCallback)} or
     *                  {@link #getRequests(String, ZendeskCallback)}
     * @param since     Date used to filter the comments. Only comments submitted after this date will be returned.
     * @param onlyAgent {@code true} to fetch only agent comments, {@code false} to all comments.
     * @param callback  Callback that will deliver a {@link CommentsResponse} or
     *                  {@link ErrorResponse}
     * @since 2.0.0.1
     */
    void getCommentsSince(@NonNull String requestId,
                          @NonNull Date since,
                          boolean onlyAgent,
                          @Nullable ZendeskCallback<CommentsResponse> callback);

    /**
     * Add a {@link EndUserComment} to a request.
     *
     * @param requestId      Id of a request to post this comment to
     * @param endUserComment A {@link EndUserComment} containing text and attachment tokens
     * @param callback       Callback that will deliver a {@link Comment} or {@link ErrorResponse}
     * @since 1.1.0.1
     */
    void addComment(@NonNull String requestId,
                    @NonNull EndUserComment endUserComment,
                    @Nullable final ZendeskCallback<Comment> callback);

    /**
     * Calls a request service to get a request for the given request id.
     *
     * @param requestId Id of a request
     * @param callback  Callback that will deliver a {@link Request} or
     *                  {@link ErrorResponse}
     * @since 1.2.0.1
     */
    void getRequest(@NonNull String requestId, @Nullable final ZendeskCallback<Request> callback);


    /**
     * Get all available ticket forms.
     *
     * @param ids      List of ticket form ids to fetch
     * @param callback Callback that will deliver a list of {@link TicketForm} or
     *                 {@link ErrorResponse}
     */
    void getTicketFormsById(@NonNull List<Long> ids,
                            @Nullable final ZendeskCallback<List<TicketForm>> callback);

    /**
     * Gets the details of any updates to requests for this device.
     * <p>
     * {@link RequestUpdates} are cached for up to one hour. Subsequent calls to this method within
     * the hour will return the same object without querying the network. Calling this method once
     * the hour has expired will query the network again, and cache the new results for the next
     * hour.
     * <p>
     * If using the Zendesk UI, viewing a request will update the stored {@link RequestUpdates}
     * to remove the viewed request. If using the API providers only, a request can be removed from
     * the stored {@link RequestUpdates} by calling
     * {@link #markRequestAsRead(String, int)} with the request ID.
     * <p>
     * It is important to note the difference in behaviour of this method users using
     * {@link zendesk.core.AnonymousIdentity} versus users using {@link zendesk.core.JwtIdentity}.
     * For an {@link zendesk.core.AnonymousIdentity}, this method will only fetch updates for
     * requests which were created from this device (since those are all an Anonymous user has
     * access to). However, a {@link zendesk.core.JwtIdentity} will fetch all of the users open
     * requests, regardless of where they were created. Any request created on another channel is
     * unknown to this instance of the Support SDK, and as such it will show in the resulting
     * {@link RequestUpdates} with all of its comments counting as updates.
     *
     * @param callback Callback that will deliver the number of request updates or
     *                 {@link ErrorResponse}
     */
    void getUpdatesForDevice(@NonNull ZendeskCallback<RequestUpdates> callback);

    /**
     * Marks a request as read on this device.
     *
     * @param requestId    the ID of the request to mark as read
     * @param commentCount the number of comments on this request that have been read
     * @see #getUpdatesForDevice(ZendeskCallback) for more information
     */
    void markRequestAsRead(@NonNull String requestId, int commentCount);

    /**
     * Marks a request as unread on this device, by incrementing its total number of comments.
     * <p>
     * This should be used to update a request as being "unread" after receiving a push notification
     * for an update on that ticket, when using an SDK providers-only integration.
     * <p>
     * If you are using the SDK UI module and {@link Support#refreshRequest(String, Context)} then
     * you should not call this method. It is already being called for you, and calling it again
     * will lead to inaccurate {@link RequestUpdates}.
     *
     * @param requestId the ID of the request to mark as unread
     */
    void markRequestAsUnread(@NonNull String requestId);
}
