package zendesk.support;

import androidx.annotation.VisibleForTesting;

import com.zendesk.util.StringUtils;

import zendesk.core.Settings;

/**
 * This model contains the server-driven configurations that can affect how the SDK behaves.
 */
@SuppressWarnings("unused")
class SupportSettings implements Settings {

    private final ConversationsSettings conversations;
    private final ContactUsSettings contactUs;
    private final AttachmentSettings attachments;
    private final TicketFormSettings ticketForms;
    private final boolean neverRequestEmail;
    private final boolean showClosedRequests;
    private final boolean showReferrerLogo;
    private final String referrerUrl;
    private final String systemMessage;

    private static SupportSettings DEFAULT = new SupportSettings(
            ConversationsSettings.defaultSettings(),
            ContactUsSettings.defaultSettings(),
            AttachmentSettings.defaultSettings(),
            TicketFormSettings.defaultSettings(),
            true,
            true,
            false,
            StringUtils.EMPTY_STRING,
            StringUtils.EMPTY_STRING
    );

    static SupportSettings defaultSettings() {
        return DEFAULT;
    }

    @VisibleForTesting
    SupportSettings(ConversationsSettings conversations,
                    ContactUsSettings contactUs,
                    AttachmentSettings attachments,
                    TicketFormSettings ticketForms,
                    boolean neverRequestEmail,
                    boolean showClosedRequests,
                    boolean showReferrerLogo,
                    String referrerUrl,
                    String systemMessage) {
        this.conversations = conversations;
        this.contactUs = contactUs;
        this.attachments = attachments;
        this.ticketForms = ticketForms;
        this.neverRequestEmail = neverRequestEmail;
        this.showClosedRequests = showClosedRequests;
        this.showReferrerLogo = showReferrerLogo;
        this.referrerUrl = referrerUrl;
        this.systemMessage = systemMessage;
    }

    ConversationsSettings getConversations() {
        return conversations;
    }

    ContactUsSettings getContactUs() {
        return contactUs;
    }

    AttachmentSettings getAttachments() {
        return attachments;
    }

    TicketFormSettings getTicketForms() {
        return ticketForms;
    }

    boolean isNeverRequestEmailOn() {
        return neverRequestEmail;
    }

    boolean isShowClosedRequests() {
        return showClosedRequests;
    }

    boolean isShowReferrerLogo() {
        return showReferrerLogo;
    }

    String getReferrerUrl() {
        return referrerUrl;
    }

    String getSystemMessage() {
        return systemMessage;
    }
}