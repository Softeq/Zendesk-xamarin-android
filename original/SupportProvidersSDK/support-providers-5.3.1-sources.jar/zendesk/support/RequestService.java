package zendesk.support;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Defines the operations that can be carried out on Requests.
 * <p>
 * Currently this is defined using retrofit annotations but this could be changed in the
 * future as long as these signatures remain.
 * </p>
 */
interface RequestService {

    @POST("/api/mobile/requests.json?include=last_comment")
    Call<RequestResponse> createRequest(
            @Header(Constants.SDK_GUID_HEADER) String sdkGuid,
            @Body CreateRequestWrapper wrapper);

    @GET("/api/mobile/requests.json?sort_by=updated_at&sort_order=desc")
    Call<RequestsResponse> getAllRequests(
            @Query("status") String status,
            @Query("include") String include);

    @GET("/api/mobile/requests/show_many.json?sort_order=desc")
    Call<RequestsResponse> getManyRequests(
            @Query("tokens") String requestTokens,
            @Query("status") String status,
            @Query("include") String include);

    @GET("/api/mobile/requests/{id}/comments.json?sort_order=desc")
    Call<CommentsResponse> getComments(
            @Path("id") String id);

    @GET("/api/mobile/requests/{id}/comments.json?sort_order=desc")
    Call<CommentsResponse> getCommentsSince(
            @Path("id") String id,
            @Query("since") String since,
            @Query("role") String role);

    @PUT("/api/mobile/requests/{id}.json?include=last_comment")
    Call<RequestResponse> addComment(
            @Path("id") String id,
            @Body UpdateRequestWrapper updateRequestWrapper);

    @GET("/api/mobile/requests/{id}.json")
    Call<RequestResponse> getRequest(
            @Path("id") String id,
            @Query("include") String include);

    @GET("/api/v2/ticket_forms/show_many.json?active=true")
    Call<RawTicketFormResponse> getTicketFormsById(
            @Query("ids") String ticketFormIds,
            @Query("include") String include);
}
