package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

import java.io.File;

import retrofit2.Response;

/**
 * <p>
 * A provider which will offer a higher level of abstraction compared to the {@link UploadService}
 * <br>
 * You can create an instance of UploadProvider like this:
 *
 * <pre>
 *      import zendesk.support.UploadProvider;
 *      import zendesk.support.Support;
 *      ...
 *      UploadProvider provider = Support.INSTANCE.provider().uploadProvider();
 *      ...
 * </pre>
 *
 * <p>
 * Once you have an instance of the provider you can call methods on it and handle the results
 * in callbacks. A success callback will give you the resource(s) that you are requesting. The error
 * callback will be called if there was some issue with the method call and it will define details
 * about the error in an {@link ErrorResponse}
 * </p>
 * <p>
 * For example you can upload a file like this:
 * <pre>
 *   File fileToUpload = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "picture.png");
 *
 *   provider.uploadAttachment("screenshot.png", fileToUpload, "image/png", {@literal new
 *   ZendeskCallback<UploadResponse>()} {
 *       {@literal @Override}
 *       public void onSuccess(UploadResponse uploadResponse) {
 *           // Handle success
 *       }
 *
 *       {@literal @Override}
 *       public void onError(ErrorResponse errorResponse) {
 *           // Handle error
 *       }
 *   });
 * </pre>
 */
@SuppressWarnings("unused")
public interface UploadProvider {

    /**
     * Calls a upload service to upload a file on behalf of the end-user.
     *
     * @param fileName Name of the file
     * @param file     The actual file which should be uploaded
     * @param mimeType The MIME type of the file (e.g. "image/png")
     * @param callback Callback that will deliver a newly uploaded file of type
     *                 {@link UploadResponse} or {@link ErrorResponse}
     * @since 1.1.0.1
     */
    void uploadAttachment(@NonNull String fileName,
                          @NonNull File file,
                          @NonNull String mimeType,
                          @Nullable ZendeskCallback<UploadResponse> callback);


    /**
     * Calls a upload service to delete an upload on behalf of the end-user.
     *
     * @param token    Token of an attachment ({@link UploadResponse#getToken()})
     * @param callback Callback that will deliver a newly uploaded file of type
     *                 {@link Response} or {@link ErrorResponse}
     * @since 1.1.0.1
     */
    void deleteAttachment(@NonNull String token, @Nullable ZendeskCallback<Void> callback);
}
