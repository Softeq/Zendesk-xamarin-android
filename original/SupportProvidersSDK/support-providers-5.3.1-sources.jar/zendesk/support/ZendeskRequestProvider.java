package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ErrorResponseAdapter;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zendesk.core.AnonymousIdentity;
import zendesk.core.AuthenticationProvider;
import zendesk.core.AuthenticationType;
import zendesk.core.Identity;

final class ZendeskRequestProvider implements RequestProvider {

    private static final String LOG_TAG = "ZendeskRequestProvider";

    private static final String GET_REQUESTS_SIDE_LOAD =
            "public_updated_at,last_commenting_agents,last_comment,first_comment";
    private static final String ALL_REQUEST_STATUSES = "new,open,pending,hold,solved,closed";

    private static final int MAX_TICKET_FIELDS = 5;

    private final SupportSettingsProvider settingsProvider;
    private final ZendeskRequestService requestService;
    private final AuthenticationProvider authenticationProvider;
    private final RequestStorage requestStorage;
    private final RequestSessionCache requestSessionCache;
    private final ZendeskTracker zendeskTracker;
    private final SupportSdkMetadata metadata;
    private final SupportBlipsProvider blipsProvider;

    /**
     * Default constructor for instantiating an implementation of {@link RequestProvider}
     */
    ZendeskRequestProvider(SupportSettingsProvider settingsProvider, ZendeskRequestService requestService,
                           AuthenticationProvider authenticationProvider, RequestStorage requestStorage,
                           RequestSessionCache requestSessionCache, ZendeskTracker zendeskTracker,
                           SupportSdkMetadata metadata, SupportBlipsProvider blipsProvider) {
        this.settingsProvider = settingsProvider;
        this.requestService = requestService;
        this.authenticationProvider = authenticationProvider;
        this.requestStorage = requestStorage;
        this.requestSessionCache = requestSessionCache;
        this.zendeskTracker = zendeskTracker;
        this.metadata = metadata;
        this.blipsProvider = blipsProvider;
    }

    /**
     * Calls a request service to create a request on behalf of the end-user.
     * It will also do a sanity check on request validity.
     *
     * @param request  the {@link CreateRequest} object signifying the user's request
     * @param callback Callback that will deliver a newly created request of type {@link Request} or
     * {@link ErrorResponse}
     */
    @SuppressWarnings("ConstantConditions")
    @Override
    public void createRequest(@NonNull final CreateRequest request, @Nullable final ZendeskCallback<Request> callback) {
        boolean isValid = true;

        if (request == null) {
            isValid = false;
        }

        if (!isValid) {
            final String error = "configuration is invalid: request null";
            Logger.e(LOG_TAG, error);

            if (callback != null) {
                callback.onError(new ErrorResponseAdapter(error));
            }
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<SupportSdkSettings>(callback) {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                request.setMetadata(metadata.getDeviceInfoAsMapForMetaData());

                addServerTags(request, supportSdkSettings);

                internalCreateRequest(request,
                        supportSdkSettings.getAuthenticationType(),
                        authenticationProvider.getIdentity(),
                        callback);
            }
        });
    }

    private void addServerTags(
            @NonNull CreateRequest request,
            @NonNull SupportSdkSettings settings) {

        List<String> combinedTags = CollectionUtils.combineLists(
                request.getTags(),
                settings.getContactZendeskTags()
        );

        if (CollectionUtils.isNotEmpty(combinedTags)) {
            Logger.d(LOG_TAG, "Adding tags to feedback...");
            request.setTags(combinedTags);
        }
    }

    private void internalCreateRequest(@NonNull final CreateRequest request, final AuthenticationType authentication,
                                       final Identity identity, @Nullable final ZendeskCallback<Request> callback) {
        final ZendeskCallback<Request> zendeskCallback = new ZendeskCallbackSuccess<Request>(callback) {
            @Override
            public void onSuccess(Request result) {

                if (result == null || result.getId() == null) {
                    onError(new ErrorResponseAdapter("The request was created, but the ID is unknown."));
                } else {

                    zendeskTracker.requestCreated();
                    blipsProvider.requestCreated(result.getId());
                    requestStorage.updateRequestData(Collections.singletonList(result));

                    if (callback != null) {
                        callback.onSuccess(result);
                    }
                }
            }
        };

        if (authentication == AuthenticationType.ANONYMOUS && identity != null
                && identity instanceof AnonymousIdentity) {
            final AnonymousIdentity anonymousIdentity = (AnonymousIdentity) identity;
            final String sdkGuid = anonymousIdentity.getSdkGuid();
            requestService.createRequest(sdkGuid, request, zendeskCallback);
        } else {
            // JWT, we do not need sdkGuid
            requestService.createRequest(null, request, zendeskCallback);
        }

    }

    /**
     * Calls a request service to get all requests created by current user identified by {@link Support}.
     * <p/>
     * This request additionally makes a side load for public_updated_at in order to determine the date the last
     * public update was made
     * <p/>
     * If you are using anonymous identities we will check to see if you have any stored request IDs.
     * This is how requests work when dealing with anonymous identities. If you do have stored request
     * IDs we will fetch these requests from your Zendesk instance. If you do not have any stored request
     * IDs we will skip the network call and return an empty list of Requests.
     *
     * @param status   A comma separated list of status to filter the results by
     * @param callback Callback that will deliver a list of {@link Request} or {@link ErrorResponse}
     */
    private void getAllRequestsInternal(@Nullable String status,
                                        final AuthenticationType authentication,
                                        @Nullable final ZendeskCallback<List<Request>> callback) {

        if (StringUtils.isEmpty(status)) {
            status = ALL_REQUEST_STATUSES;
        }

        final ZendeskCallback<List<Request>> cachingCallback = new ZendeskCallbackSuccess<List<Request>>(callback) {
            @Override
            public void onSuccess(List<Request> requests) {
                requestStorage.updateRequestData(requests);

                if (callback != null) {
                    callback.onSuccess(requests);
                }
            }
        };

        final String include = GET_REQUESTS_SIDE_LOAD;
        if (authentication == AuthenticationType.ANONYMOUS) {
            final List<RequestData> requestDataList = requestStorage.getRequestData();
            final List<String> listOfRequestIds = new ArrayList<>(requestDataList.size());
            for (RequestData requestData : requestDataList) {
                listOfRequestIds.add(requestData.getId());
            }

            if (CollectionUtils.isEmpty(listOfRequestIds)) {

                Logger.w(LOG_TAG, "getAllRequestsInternal: There are no requests to fetch");

                if (callback != null) {
                    callback.onSuccess(new ArrayList<Request>());
                }

            } else {
                requestService
                        .getAllRequests(StringUtils.toCsvString(listOfRequestIds), status, include, cachingCallback);
            }

        } else {
            requestService.getAllRequests(status, include, cachingCallback);
        }
    }

    @Override
    public void getAllRequests(@Nullable final ZendeskCallback<List<Request>> callback) {
        this.getRequests(null, callback);
    }

    @Override
    public void getRequests(@Nullable final String status, @Nullable final ZendeskCallback<List<Request>> callback) {

        settingsProvider.getSettings(new ZendeskCallbackSuccess<SupportSdkSettings>(callback) {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                if (areConversationsEnabled(supportSdkSettings)) {
                    getAllRequestsInternal(status, supportSdkSettings.getAuthenticationType(), callback);
                } else {
                    answerCallbackOnConversationsDisabled(callback);
                }
            }
        });
    }

    @Override
    public void getComments(@NonNull final String requestId,
                            @Nullable final ZendeskCallback<CommentsResponse> callback) {
        settingsProvider.getSettings(new ZendeskCallbackSuccess<SupportSdkSettings>(callback) {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                if (areConversationsEnabled(supportSdkSettings)) {
                    requestService.getComments(requestId, callback);
                } else {
                    answerCallbackOnConversationsDisabled(callback);
                }
            }
        });
    }

    @Override
    public void getCommentsSince(@NonNull final String requestId,
                                 @NonNull final Date since,
                                 final boolean onlyAgent,
                                 @Nullable final ZendeskCallback<CommentsResponse> callback) {
        settingsProvider.getSettings(new ZendeskCallbackSuccess<SupportSdkSettings>(callback) {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                if (areConversationsEnabled(supportSdkSettings)) {
                    requestService.getCommentsSince(requestId, since, onlyAgent, callback);
                } else {
                    answerCallbackOnConversationsDisabled(callback);
                }
            }
        });
    }

    /**
     * Calls a request service to upload a comment to a request with a given id.
     *
     * @param requestId      Id of a request to post this comment to
     * @param endUserComment A {@link EndUserComment} containing text and attachment tokens
     * @param callback       Callback that will deliver a {@link Comment} or {@link ErrorResponse}
     */
    private void addCommentInternal(@NonNull final String requestId,
                                    @NonNull EndUserComment endUserComment,
                                    @Nullable final ZendeskCallback<Comment> callback) {
        requestService.addComment(requestId, endUserComment, new ZendeskCallbackSuccess<Request>(callback) {
            @Override
            public void onSuccess(Request result) {
                zendeskTracker.requestUpdated();
                blipsProvider.requestUpdated(requestId);

                // Update comment count in storage
                if (result.getId() != null && result.getCommentCount() != null) {
                    requestStorage.updateRequestData(Collections.singletonList(result));
                } else {
                    Logger.w(LOG_TAG, "The ID and / or comment count was missing. Cannot store comment totalUpdates.");
                }

                if (callback != null) {
                    callback.onSuccess(result.getLastComment());
                }
            }
        });
    }

    /**
     * Calls a request service to upload a {@link EndUserComment} to a request with a given id.
     *
     * @param requestId      Id of a request to post this comment to
     * @param endUserComment A {@link EndUserComment} containing text and attachment tokens
     * @param callback       Callback that will deliver a {@link Comment} or {@link ErrorResponse}
     */
    @Override
    public void addComment(@NonNull final String requestId,
                           @NonNull final EndUserComment endUserComment,
                           @Nullable final ZendeskCallback<Comment> callback) {
        settingsProvider.getSettings(new ZendeskCallbackSuccess<SupportSdkSettings>(callback) {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                if (areConversationsEnabled(supportSdkSettings)) {
                    addCommentInternal(requestId, endUserComment, callback);
                } else {
                    answerCallbackOnConversationsDisabled(callback);
                }
            }
        });
    }

    /**
     * Calls a request service to get a request for the given request id.
     *
     * @param requestId Id of a request
     * @param callback  Callback that will deliver a {@link Request} or
     *                  {@link ErrorResponse}
     */
    @Override
    public void getRequest(@NonNull final String requestId, @Nullable final ZendeskCallback<Request> callback) {
        settingsProvider.getSettings(new ZendeskCallbackSuccess<SupportSdkSettings>(callback) {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                if (areConversationsEnabled(supportSdkSettings)) {
                    requestService.getRequest(requestId, GET_REQUESTS_SIDE_LOAD, callback);
                } else {
                    answerCallbackOnConversationsDisabled(callback);
                }
            }
        });
    }


    @Override
    public void getTicketFormsById(@NonNull final List<Long> ids,
                                   @Nullable final ZendeskCallback<List<TicketForm>> callback) {

        if (CollectionUtils.isEmpty(ids)) {
            if (callback != null) {
                callback.onError(new ErrorResponseAdapter("Ticket forms must at least contain 1 Id"));
            }
            return;
        }

        final List<Long> ticketFieldIds = new ArrayList<>();

        if (ids.size() > MAX_TICKET_FIELDS) {
            ticketFieldIds.addAll(ids.subList(0, MAX_TICKET_FIELDS));
            Logger.d(LOG_TAG, "Maximum number of allowed ticket fields: %d.", MAX_TICKET_FIELDS);
        } else {
            ticketFieldIds.addAll(ids);
        }

        if (requestSessionCache.containsAllTicketForms(ticketFieldIds)) {
            if (callback != null) {
                callback.onSuccess(requestSessionCache.getTicketFormsById(ticketFieldIds));
            }

        } else {

            settingsProvider.getSettings(new ZendeskCallbackSuccess<SupportSdkSettings>(callback) {
                @Override
                public void onSuccess(SupportSdkSettings supportSdkSettings) {
                    if (supportSdkSettings.isTicketFormSupportAvailable()) {

                        String idsToFilter = StringUtils.toCsvStringNumber(ticketFieldIds);

                        requestService.getTicketFormsById(
                                idsToFilter,
                                new ZendeskCallbackSuccess<RawTicketFormResponse>(callback) {
                                    @Override
                                    public void onSuccess(RawTicketFormResponse ticketFormResponse) {
                                        List<TicketForm> ticketForms = convertTicketFormResponse(
                                                ticketFormResponse.getTicketForms(),
                                                ticketFormResponse.getTicketFields());
                                        requestSessionCache.updateTicketFormCache(ticketForms);

                                        if (callback != null) {
                                            callback.onSuccess(ticketForms);
                                        }
                                    }
                                });

                    } else if (callback != null) {
                        callback.onError(new ErrorResponseAdapter("Ticket form support disabled."));
                    }
                }
            });
        }
    }

    @Override
    public void getUpdatesForDevice(@NonNull final ZendeskCallback<RequestUpdates> callback) {
        if (!requestStorage.isRequestDataExpired()) {
            //if we have a valid disk cached ReadRequestList calc the request updates
            final List<RequestData> requestData = requestStorage.getRequestData();
            final RequestUpdates requestUpdates = calcRequestUpdates(requestData);
            callback.onSuccess(requestUpdates);
        } else {
            //if we dont have a valid disk cached ReadRequestList, get the updated requests
            //and calc from it
            settingsProvider.getSettings(new ZendeskCallback<SupportSdkSettings>() {
                @Override
                public void onSuccess(SupportSdkSettings supportSdkSettings) {

                    if (!supportSdkSettings.isConversationsEnabled()) {
                        answerCallbackOnConversationsDisabled(callback);

                    } else {
                        getAllRequestsInternal(null, supportSdkSettings.getAuthenticationType(),
                                new ZendeskCallbackSuccess<List<Request>>(callback) {
                                    @Override
                                    public void onSuccess(List<Request> requests) {
                                        final RequestUpdates requestUpdates =
                                                calcRequestUpdates(requestStorage.getRequestData());
                                        callback.onSuccess(requestUpdates);
                                    }
                                });
                    }
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    callback.onError(errorResponse);
                }
            });
        }
    }

    @Override
    public void markRequestAsRead(@NonNull String requestId, int commentCount) {
        requestStorage.markRequestAsRead(requestId, commentCount);
    }

    @Override
    public void markRequestAsUnread(@NonNull String requestId) {
        requestStorage.markRequestAsUnread(requestId);
    }

    private static RequestUpdates calcRequestUpdates(@NonNull List<RequestData> requests) {

        Map<String, Integer> requestUpdatesMap = new HashMap<>(requests.size());

        for (RequestData request : requests) {

            int unreadComments = request.unreadComments();
            if (unreadComments != 0) {
                //has read comments, calc diff and add to updates
                requestUpdatesMap.put(request.getId(), unreadComments);
            }
        }

        return new RequestUpdates(requestUpdatesMap);
    }

    private static List<TicketForm> convertTicketFormResponse(List<RawTicketForm> rawTicketForms,
                                                              List<RawTicketField> rawTicketFields) {

        final List<TicketForm> ticketForms = new ArrayList<>();
        final Map<Long, TicketField> ticketFieldMap = createTicketFieldMap(rawTicketFields);

        for (RawTicketForm rawTicketForm : rawTicketForms) {
            ticketForms.add(createTicketFormFromResponse(rawTicketForm, ticketFieldMap));
        }

        return ticketForms;
    }

    private static TicketForm createTicketFormFromResponse(RawTicketForm rawTicketForm,
                                                           Map<Long, TicketField> ticketFieldMap) {
        final List<TicketField> ticketFields = new ArrayList<>();
        for (Long id : rawTicketForm.getTicketFieldIds()) {
            if (id != null && ticketFieldMap.get(id) != null) {
                ticketFields.add(ticketFieldMap.get(id));
            }
        }
        return RawTicketForm.create(rawTicketForm, ticketFields);
    }

    private static Map<Long, TicketField> createTicketFieldMap(List<RawTicketField> rawTicketFields) {
        final Map<Long, TicketField> ticketFieldMap = new HashMap<>(rawTicketFields.size());

        for (RawTicketField rawTicketField : rawTicketFields) {
            ticketFieldMap.put(rawTicketField.getId(), TicketField.create(rawTicketField));
        }

        return ticketFieldMap;
    }

    /**
     * Check if conversations are enabled by the server.
     *
     * @param mobileSettings of the current account
     * @return {@code true} if conversations are enabled, {@code false} if not or if the flag could
     * not be determined due to null problems with the MobileSettings model
     */
    @SuppressWarnings("SimplifiableConditionalExpression")
    private static boolean areConversationsEnabled(@Nullable SupportSdkSettings mobileSettings) {
        return mobileSettings == null ? false : mobileSettings.isConversationsEnabled();
    }

    /**
     * Answer the provided callback and log in case conversations are disabled and someone
     * tries to retrieve requests through this provider.
     *
     * @param callback the {@link ZendeskCallback} that should be answered. Can be {@code null}
     */
    private static void answerCallbackOnConversationsDisabled(@Nullable ZendeskCallback callback) {
        Logger.d(LOG_TAG, "Conversations disabled, this feature is not available on your plan or was disabled.");
        if (callback != null) {
            callback.onError(new ErrorResponseAdapter("Access Denied"));
        }
    }
}