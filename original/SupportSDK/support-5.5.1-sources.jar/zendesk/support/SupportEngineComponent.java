package zendesk.support;

import androidx.annotation.RestrictTo;

import javax.inject.Singleton;

import dagger.Component;
import zendesk.core.CoreModule;

@Singleton
@Component(modules = {
        CoreModule.class,
        SupportModule.class,
        SupportEngineModule.class
})
@RestrictTo(RestrictTo.Scope.LIBRARY)
interface SupportEngineComponent {

    SupportEngine supportEngine();
}