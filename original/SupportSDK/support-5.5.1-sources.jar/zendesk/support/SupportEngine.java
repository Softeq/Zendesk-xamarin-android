package zendesk.support;

import android.content.Context;
import androidx.annotation.NonNull;

import zendesk.core.Zendesk;
import zendesk.classic.messaging.AgentDetails;
import zendesk.classic.messaging.Engine;
import zendesk.classic.messaging.Event;
import zendesk.classic.messaging.MessagingApi;
import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.ObservableEngine;
import zendesk.classic.messaging.Update;
import zendesk.classic.messaging.components.ActionListener;
import zendesk.classic.messaging.components.CompositeActionListener;
import zendesk.classic.messaging.components.bot.BotMessageDispatcher;

public class SupportEngine extends ObservableEngine {

    private static final String SUPPORT_ENGINE_ID = "SUPPORT";

    private final Context context;
    private final SupportEngineModel supportModel;
    private final CompositeActionListener<BotMessageDispatcher.ConversationState<MessagingItem>> stateViewObserver;
    private final CompositeActionListener<Update> updateViewObserver;

    private final TransferOptionDescription description;

    public static Engine engine() {
        final SupportModule supportModule = Support.INSTANCE.supportModule;
        final SupportEngineModule supportEngineModule = new SupportEngineModule();

        return DaggerSupportEngineComponent.builder()
                .coreModule(Zendesk.INSTANCE.coreModule())
                .supportModule(supportModule)
                .supportEngineModule(supportEngineModule)
                .build()
                .supportEngine();
    }

    SupportEngine(Context context,
                  SupportEngineModel supportEngineModel,
                  CompositeActionListener<BotMessageDispatcher.ConversationState<MessagingItem>> stateViewObserver,
                  CompositeActionListener<Update> updateViewObserver) {
        this.context = context;
        this.supportModel = supportEngineModel;
        this.stateViewObserver = stateViewObserver;
        this.updateViewObserver = updateViewObserver;
        this.description = new TransferOptionDescription(
                SUPPORT_ENGINE_ID,
                context.getString(R.string.zs_request_contact_option_leave_a_message)
        );
    }

    @Override
    public void start(@NonNull MessagingApi messagingApi) {
        setupViewObserver(messagingApi.getBotAgentDetails());
        supportModel.start(context, messagingApi);
    }

    private void setupViewObserver(final AgentDetails agentDetails) {
        stateViewObserver.addListener(new ActionListener<BotMessageDispatcher.ConversationState<MessagingItem>>() {
            @Override
            public void onAction(BotMessageDispatcher.ConversationState<MessagingItem> data) {
                if (data.shouldShowTypingIndicator()) {
                    notifyObservers(new Update.State.ShowTyping(agentDetails));
                } else {
                    notifyObservers(new Update.State.HideTyping());
                }
                notifyObservers(new Update.State.ApplyMessagingItems(data.getMessages()));
            }
        });

        updateViewObserver.addListener(new ActionListener<Update>() {
            @Override
            public void onAction(Update data) {
                notifyObservers(data);
            }
        });
    }

    @Override
    public void stop() {
        stateViewObserver.clearListeners();
        updateViewObserver.clearListeners();
    }

    @NonNull
    @Override
    public String getId() {
        return SUPPORT_ENGINE_ID;
    }

    @NonNull
    @Override
    public TransferOptionDescription getTransferOptionDescription() {
        return description;
    }

    @Override
    public void onEvent(@NonNull Event event) {
        switch (event.getType()) {
            case Event.ACTION_OPTION_CLICKED:
                supportModel.actionItemClicked();

                break;
            case Event.MESSAGE_SUBMITTED:
                Event.MessageSubmitted messageSubmitted = (Event.MessageSubmitted) event;

                supportModel.textEntered(messageSubmitted.getTextInput());
                break;
            case Event.RESPONSE_OPTION_CLICKED:
                supportModel.retryClicked();

                break;
        }
    }
}
