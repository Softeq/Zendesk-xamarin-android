package zendesk.support.request;

import com.zendesk.util.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import zendesk.support.suas.State;

/**
 * Root state data. Holding information about the configuration of the RequestActivity.
 */
class StateConfig implements Serializable {

    static final long MAX_ATTACHMENTS_SIZE_UNAVAILABLE = -1L;

    static StateConfig fromState(State state) {
        final StateConfig config = state.getState(StateConfig.class);

        if (config != null) {
            return config;
        } else {
            return new StateConfig();
        }
    }

    private final StateSettings settings;

    private final String subject;
    private final StateRequestTicketForm ticketForm;
    private final List<String> tags;

    private StateConfig(StateSettings settings, List<String> tags, String subject, StateRequestTicketForm ticketForm) {
        this.settings = settings;
        this.tags = tags;
        this.subject = subject;
        this.ticketForm = ticketForm;
    }

    StateConfig() {
        this.settings = new StateSettings();
        this.tags = new ArrayList<>();
        this.subject = StringUtils.EMPTY_STRING;
        this.ticketForm = null;
    }

    StateSettings getSettings() {
        return settings;
    }

    List<String> getTags() {
        return tags;
    }

    String getSubject() {
        return subject;
    }

    StateRequestTicketForm getTicketForm() {
        return ticketForm;
    }

    Builder newBuilder() {
        return new Builder(settings, tags, subject, ticketForm);
    }

    @Override
    public String toString() {
        return "Config{" +
                "settings=" + settings +
                ", subject='" + subject + '\'' +
                ", ticketForm=" + ticketForm +
                ", tags=" + tags +
                '}';
    }

    static class Builder {

        private StateSettings settings;
        private List<String> tags;
        private String subject;
        private StateRequestTicketForm ticketForm;

        private Builder(StateSettings settings, List<String> tags, String subject, StateRequestTicketForm ticketForm) {
            this.settings = settings;
            this.tags = tags;
            this.subject = subject;
            this.ticketForm = ticketForm;
        }

        Builder setSettings(StateSettings settings) {
            this.settings = settings;
            return this;
        }

        Builder setTags(List<String> tags) {
            this.tags = tags;
            return this;
        }

        Builder setSubject(String subject) {
            this.subject = subject;
            return this;
        }

        Builder setTicketForm(StateRequestTicketForm ticketForm) {
            this.ticketForm = ticketForm;
            return this;
        }

        StateConfig build() {
            return new StateConfig(settings, tags, subject, ticketForm);
        }
    }
}