package zendesk.support.request;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;

import com.zendesk.util.CollectionUtils;
import com.zendesk.util.FileUtils;
import com.zendesk.util.MimeUtils;
import com.zendesk.util.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationUtil;
import zendesk.support.AttachmentFile;
import zendesk.support.CustomField;
import zendesk.support.DeepLinkingBroadcastReceiver;
import zendesk.support.Request;
import zendesk.support.RequestStatus;
import zendesk.support.requestlist.RequestInfo;

import static zendesk.support.DeepLinkingBroadcastReceiver.EXTRA_BACK_STACK_ACTIVITIES;
import static zendesk.support.DeepLinkingBroadcastReceiver.EXTRA_REQUEST_INTENT;

/**
 * Data class, that represents the initial configuration of {@link RequestActivity}. Use the
 * {@link Builder} to create an instance.
 */
public class RequestConfiguration implements Configuration {

    /**
     * Sentinel value to represent the absence of a valid Ticket Form ID.
     */
    public static final long NO_TICKET_FORM_ID = -1L;

    private final String requestSubject;
    private final List<String> tags;
    private final List<CustomField> customFields;
    private final long ticketFormId;
    private final List<AttachmentFile> files;

    private final String requestId;
    private final String localRequestId;
    private final RequestStatus requestStatus;
    private final boolean hasAgentReplies;

    private final List<Configuration> configurations;

    RequestConfiguration(
            String requestSubject,
            List<String> tags,
            String requestId,
            String localRequestId,
            RequestStatus requestStatus,
            List<CustomField> customFields,
            long ticketFormId,
            List<AttachmentFile> files,
            boolean hasAgentReplies,
            List<Configuration> configurations) {
        this.requestSubject = requestSubject;
        this.tags = CollectionUtils.ensureEmpty(tags);
        this.requestId = requestId;
        this.localRequestId = localRequestId;
        this.requestStatus = requestStatus;
        this.hasAgentReplies = hasAgentReplies;
        this.customFields = customFields;
        this.ticketFormId = ticketFormId;
        this.files = files;
        this.configurations = configurations;
    }

    public String getRequestSubject() {
        return requestSubject;
    }

    public List<String> getTags() {
        return tags;
    }

    public String getRequestId() {
        return requestId;
    }

    public String getLocalRequestId() {
        return localRequestId;
    }

    public RequestStatus getRequestStatus() {
        return requestStatus;
    }

    public List<StateRequestAttachment> getFiles() {
        List<StateRequestAttachment> attachments = new ArrayList<>(files.size());
        for (AttachmentFile file : files) {
            attachments.add(StateRequestAttachment.convert(file));
        }

        return attachments;
    }

    public List<AttachmentFile> getFilesAsAttachments() {
        return files;
    }

    public StateRequestTicketForm getTicketForm() {
        return new StateRequestTicketForm(ticketFormId, customFields);
    }

    public List<CustomField> getCustomFields() {
        return customFields;
    }

    public long getTicketFormId() {
        return ticketFormId;
    }

    boolean hasAgentReplies() {
        return hasAgentReplies;
    }

    @SuppressLint("RestrictedApi")
    @Override
    public List<Configuration> getConfigurations() {
        return ConfigurationUtil.addSelfIfNotInList(configurations, this);
    }

    public static class Builder {

        private String requestSubject = StringUtils.EMPTY_STRING;
        private List<String> tags = new ArrayList<>(0);
        private String requestId = StringUtils.EMPTY_STRING;
        private String localRequestId = StringUtils.EMPTY_STRING;
        private RequestStatus requestStatus = null;
        private boolean hasAgentReplies = false;
        private List<CustomField> customFields = new ArrayList<>(0);
        private long ticketFormId = NO_TICKET_FORM_ID;
        private List<AttachmentFile> files = new ArrayList<>(0);
        private List<Configuration> configurations = new ArrayList<>();

        public Builder() {
            // intentionally empty
        }

        /**
         * Attach request subject to the created request
         *
         * <p>
         * This information is only used for new requests.
         * </p>
         */
        public Builder withRequestSubject(@NonNull String requestSubject) {
            this.requestSubject = requestSubject;
            return this;
        }

        /**
         * Attach tags to the created request.
         *
         * <p>
         * This information is only used for new requests.
         * </p>
         */
        @SuppressWarnings("unused")
        public Builder withTags(@NonNull String... tags) {
            this.tags = CollectionUtils.copyOf(Arrays.asList(tags));
            return this;
        }

        /**
         * Attach tags to the created request.
         *
         * <p>
         * This information is only used for new requests.
         * </p>
         */
        public Builder withTags(@NonNull List<String> tags) {
            this.tags = CollectionUtils.copyOf(tags);
            return this;
        }

        /**
         * Show an existing request.
         */
        public Builder withRequestId(@NonNull String id) {
            this.requestId = id;
            return this;
        }

        /**
         * Attach a ticket form to the request.
         *
         * <p>
         * This information is only used for new requests.
         * </p>
         */
        @SuppressWarnings("unused")
        public Builder withTicketForm(long ticketFormId, @NonNull List<CustomField> customFields) {
            this.ticketFormId = ticketFormId;
            this.customFields = customFields;
            return this;
        }

        /**
         * Specify a list of {@link File} objects to be selected as attachments to any requests
         * created using this {@link RequestConfiguration}.
         * <p>
         * Note that this will use the {@link zendesk.support.UploadProvider} to attach any files,
         * effectively treating them the same way as any files selected by the user. This means
         * that they will show as selected files when the user opens the attachments view before
         * creating the request (and therefore the user can de-select them), and also they will
         * show as attachments on the request after it has been created, fully visible to the user.
         *
         * @param files the files to attach to any new requests
         * @return the builder
         */
        public Builder withFiles(List<File> files) {
            List<AttachmentFile> attachmentFiles = new ArrayList<>(files.size());
            for (File file: files) {
                String mimeType = MimeUtils.guessMimeTypeFromExtension(
                        FileUtils.getFileExtension(file.getName()));
                attachmentFiles.add(new AttachmentFile(file.getName(), mimeType, file));
            }

            this.files = attachmentFiles;

            return this;
        }

        /**
         * Specify {@link File} objects to be selected as an attachment to any requests
         * created using this {@link RequestConfiguration}.
         * <p>
         * Note that this will use the {@link zendesk.support.UploadProvider} to attach any files,
         * effectively treating them the same way as any files selected by the user. This means
         * that they will show as selected files when the user opens the attachments view before
         * creating the request (and therefore the user can de-select them), and also they will
         * show as attachments on the request after it has been created, fully visible to the user.
         *
         * @param files the files to attach to any new requests
         * @return the builder
         */
        @SuppressWarnings("unused")
        public Builder withFiles(File... files) {
            return withFiles(Arrays.asList(files));
        }

        /**
         * Attach a custom field form to the request.
         *
         * <p>
         * This information is only used for new requests.
         * </p>
         */
        @SuppressWarnings("unused")
        public Builder withCustomFields(@NonNull List<CustomField> customFields) {
            this.customFields = customFields;
            return this;
        }

        /**
         * Show an existing request.
         */
        public Builder withRequest(@NonNull Request request) {
            this.requestId = request.getId();
            this.requestStatus = request.getStatus();
            this.hasAgentReplies = CollectionUtils.isNotEmpty(request.getLastCommentingAgents());
            return this;
        }

        public Builder withRequestInfo(@NonNull RequestInfo requestInfo) {
            String localId = requestInfo.getLocalId();
            if (StringUtils.hasLength(localId)) {
                this.localRequestId = localId;
            }
            String remoteId = requestInfo.getRemoteId();
            if (StringUtils.hasLength(remoteId)) {
                this.requestId = remoteId;
            }
            this.requestStatus = requestInfo.getRequestStatus();
            this.hasAgentReplies = CollectionUtils.isNotEmpty(requestInfo.getAgentInfos());
            return this;
        }

        /**
         * Configurations for screen that can be started from RequestActivity.
         */
        private void setConfigurations(@NonNull List<Configuration> configurations) {
            this.configurations = configurations;

            @SuppressLint("RestrictedApi")
            RequestConfiguration config =
                    ConfigurationUtil.findConfigForType(configurations, RequestConfiguration.class);

            if (config != null) {
                this.requestSubject = config.getRequestSubject();
                this.tags = config.getTags();
                this.ticketFormId = config.ticketFormId;
                this.customFields = config.customFields;
                this.files = config.getFilesAsAttachments();
            }
        }

        /**
         * Display {@link RequestActivity} to the user.
         *
         * @param context        a valid {@link Context}
         * @param configurations Configurations for screen that can be started from RequestActivity.
         */
        public void show(@NonNull Context context, Configuration... configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Display {@link RequestActivity} to the user.
         *
         * @param context        a valid {@link Context}
         * @param configurations Configurations for screen that can be started from RequestActivity.
         */
        public void show(@NonNull Context context, List<Configuration> configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Create a {@link Configuration} for the passed in configuration options.
         */
        @NonNull
        public Configuration config() {
            return new RequestConfiguration(requestSubject, tags, requestId, localRequestId,
                    requestStatus, customFields, ticketFormId, files, hasAgentReplies, configurations);
        }

        /**
         * Create an {@link Intent} to start the {@link RequestActivity} with the specified
         * configuration options.
         *
         * @param context        The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for screen that can be started from RequestActivity.
         * @return An {@link Intent} for {@link RequestActivity} with the specified configuration
         * options
         */
        public Intent intent(Context context, Configuration... configurations) {
            return intent(context, Arrays.asList(configurations));
        }

        /**
         * Create an {@link Intent} to start the {@link RequestActivity} with the specified
         * configuration options.
         *
         * @param context        The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for screen that can be started from RequestActivity.
         * @return An {@link Intent} for {@link RequestActivity} with the specified configuration
         * options
         */
        @SuppressLint("RestrictedApi")
        public Intent intent(Context context, List<Configuration> configurations) {
            setConfigurations(configurations);

            final Configuration createRequestConfiguration = config();
            final Intent intent = new Intent(context, RequestActivity.class);
            ConfigurationUtil.addToIntent(intent, createRequestConfiguration);

            return intent;
        }

        /**
         * Creates and returns an {@link Intent} for starting a {@link DeepLinkingBroadcastReceiver},
         * for deep-linking to a {@link zendesk.support.request.RequestActivity}.
         * <p>
         * The returned Intent is intended to be wrapped in a {@link android.app.PendingIntent} and set
         * on a Notification (using
         * {@link androidx.core.app.NotificationCompat.Builder#setContentIntent(PendingIntent)}).
         *
         * @param context             the application context
         * @param backStackActivities an optional list of {@link Intent}s for a backstack of Activities to start
         * @return an Intent for this BroadcastReceiver
         */
        public Intent deepLinkIntent(Context context, Intent... backStackActivities) {
            final ArrayList<Intent> backStackItems = new ArrayList<>(Arrays.asList(backStackActivities));
            final Intent intent = new Intent(context, DeepLinkingBroadcastReceiver.class);

            intent.putExtra(EXTRA_REQUEST_INTENT, intent(context));
            intent.putExtra(EXTRA_BACK_STACK_ACTIVITIES, backStackItems);

            return intent;
        }

        /**
         * Creates and returns an {@link Intent} for starting a {@link DeepLinkingBroadcastReceiver},
         * for deep-linking to a {@link zendesk.support.request.RequestActivity}.
         * <p>
         * The returned Intent is intended to be wrapped in a {@link android.app.PendingIntent} and set
         * on a Notification (using
         * {@link androidx.core.app.NotificationCompat.Builder#setContentIntent(PendingIntent)}).
         *
         * @param context             the application context
         * @param configurations      Configurations for screen that can be started from RequestActivity.
         * @param backStackActivities an optional list of {@link Intent}s for a backstack of Activities to start
         * @return an Intent for this BroadcastReceiver
         */
        public Intent deepLinkIntent(
                Context context,
                List<Configuration> configurations,
                Intent... backStackActivities) {
            final ArrayList<Intent> backStackItems = new ArrayList<>(Arrays.asList(backStackActivities));
            final Intent intent = new Intent(context, DeepLinkingBroadcastReceiver.class);

            intent.putExtra(EXTRA_REQUEST_INTENT, intent(context, configurations));
            intent.putExtra(EXTRA_BACK_STACK_ACTIVITIES, backStackItems);

            return intent;
        }
    }
}