package zendesk.support.request;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.StringUtils;

import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.GetState;
import zendesk.support.Request;
import zendesk.support.RequestProvider;

/**
 * Load information about the request from the network.
 */
class ActionLoadRequest implements AsyncMiddleware.AsyncAction {

    private final ActionFactory af;
    private final RequestProvider requestProvider;

    ActionLoadRequest(ActionFactory actionFactory, RequestProvider requestProvider) {
        this.af = actionFactory;
        this.requestProvider = requestProvider;
    }

    @Override
    public void actionQueued(Dispatcher dispatcher, GetState state) {
        dispatcher.dispatch(af.loadRequest());
    }

    @Override
    public void execute(final Dispatcher dispatcher, GetState state, final AsyncMiddleware.Callback callback) {
        final StateConversation conversation = StateConversation.fromState(state.getState());
        final String requestId = conversation.getRemoteId();

        // Check if there's a remote id
        if (!StringUtils.hasLength(requestId)) {
            Logger.d(RequestActivity.LOG_TAG, "Skip loading request. No remote id found.");
            dispatcher.dispatch(af.skipAction());
            callback.done();
            return;
        }

        // Check if there's a request status
        if (conversation.getStatus() != null) {
            Logger.d(RequestActivity.LOG_TAG, "Skip loading request. Request status already available.");
            dispatcher.dispatch(af.skipAction());
            callback.done();
            return;
        }

        requestProvider.getRequest(requestId, new ZendeskCallback<Request>() {
            @Override
            public void onSuccess(Request request) {
                dispatcher.dispatch(af.loadRequestSuccess(request));
                callback.done();
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.w(RequestActivity.LOG_TAG, "Error loading request. Error: '%s'", errorResponse.getReason());
                dispatcher.dispatch(af.loadRequestError(errorResponse));
                callback.done();
            }
        });
    }

}
