package zendesk.support.request;

import android.annotation.SuppressLint;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.core.util.Pair;

import com.zendesk.util.CollectionUtils;
import com.zendesk.util.FileUtils;
import com.zendesk.util.MimeUtils;
import com.zendesk.util.StringUtils;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zendesk.support.Attachment;
import zendesk.support.AttachmentFile;
import zendesk.support.CommentResponse;
import zendesk.support.IdUtil;

/**
 * Model class for representing an attachment. A {@link StateMessage} can hold multiple attachments.
 */
class StateRequestAttachment implements Serializable, Comparable<StateRequestAttachment> {

    private static final String DEFAULT_MIME_TYPE = "application/octet-stream";


    static Pair<Map<Long, StateRequestAttachment>, StateIdMapper> convert(List<CommentResponse> comments,
                                                                          Map<Long, MediaResult> localAttachments,
                                                                          StateIdMapper attachmentIdMapper) {
        final List<Attachment> attachments = new ArrayList<>();

        for (CommentResponse comment : comments) {
            attachments.addAll(comment.getAttachments());
        }

        return convert(attachments, attachmentIdMapper, localAttachments);
    }

    static Pair<Map<Long, StateRequestAttachment>, StateIdMapper> convert(List<Attachment> attachments,
                                                                          StateIdMapper idMapper,
                                                                          Map<Long, MediaResult> localAttachments) {

        @SuppressLint("UseSparseArrays")
        final Map<Long, StateRequestAttachment> requestAttachments = new HashMap<>(attachments.size());

        for (Attachment attachment : attachments) {
            if (attachment.getId() == null) {
                continue;
            }

            final long id;
            if (idMapper.hasLocalId(attachment.getId())) {
                id = idMapper.getLocalId(attachment.getId());
            } else {
                id = IdUtil.newLongId();
                idMapper.addIdMapping(attachment.getId(), id);
            }

            File localFile = null;
            String localUri = null;
            if (localAttachments.containsKey(attachment.getId())) {
                final MediaResult mediaResult = localAttachments.get(attachment.getId());
                localFile = mediaResult.getFile();
                localUri = mediaResult.getUri().toString();
            }

            final long size;
            final long width;
            final long height;
            size = attachment.getSize() != null ? attachment.getSize() : -1L;
            width = attachment.getWidth() != null ? attachment.getWidth() : -1L;
            height = attachment.getHeight() != null ? attachment.getHeight() : -1L;

            String thumbnailUrl = StringUtils.EMPTY_STRING;
            if (CollectionUtils.isNotEmpty(attachment.getThumbnails())) {
                thumbnailUrl = attachment.getThumbnails().get(0).getContentUrl();
            }

            final StateRequestAttachment requestAttachment = new StateRequestAttachment(id, localUri,
                    localFile, attachment.getContentUrl(), "", attachment.getContentType(),
                    attachment.getFileName(), size, (int) width, (int) height, thumbnailUrl);

            requestAttachments.put(attachment.getId(), requestAttachment);
        }

        return Pair.create(requestAttachments, idMapper);
    }

    static StateRequestAttachment convert(MediaResult result) {
        return new StateRequestAttachment(
                IdUtil.newLongId(),
                result.getUri().toString(),
                result.getFile(),
                StringUtils.EMPTY_STRING,
                StringUtils.EMPTY_STRING,
                result.getMimeType(),
                result.getName(),
                result.getSize(),
                (int) result.getWidth(),
                (int) result.getHeight(),
                StringUtils.EMPTY_STRING
        );
    }

    static StateRequestAttachment convert(File file) {
        return new StateRequestAttachment(
                IdUtil.newLongId(),
                Uri.fromFile(file).toString(),
                file,
                StringUtils.EMPTY_STRING,
                StringUtils.EMPTY_STRING,
                getMimeTypeForFile(file),
                file.getName(),
                file.length(),
                -1,
                -1,
                StringUtils.EMPTY_STRING
        );
    }

    static StateRequestAttachment convert(AttachmentFile attachmentFile) {
        return new StateRequestAttachment(
                IdUtil.newLongId(),
                Uri.fromFile(attachmentFile.getFile()).toString(),
                attachmentFile.getFile(),
                StringUtils.EMPTY_STRING,
                StringUtils.EMPTY_STRING,
                getMimeTypeForFile(attachmentFile.getFile()),
                attachmentFile.getFileName(),
                attachmentFile.getFile().length(),
                -1,
                -1,
                StringUtils.EMPTY_STRING
        );
    }

    static MediaResult convert(StateRequestAttachment requestAttachment) {
        return new MediaResult(
                requestAttachment.getLocalFile(),
                requestAttachment.getParsedLocalUri(),
                requestAttachment.getParsedLocalUri(),
                requestAttachment.getName(),
                requestAttachment.getMimeType(),
                requestAttachment.getSize(),
                requestAttachment.getWidth(),
                requestAttachment.getHeight()
        );
    }

    private static String getMimeTypeForFile(File file) {
        String extension = FileUtils.getFileExtension(file.getName());
        return MimeUtils.guessMimeTypeFromExtension(extension);
    }

    private final long id;

    private final transient File localFile;
    private final String localUri;
    private final String url;
    private final String token;
    private final String mimeType;
    private final String name;
    private final long size;
    private final int width;
    private final int height;

    private final String thumbnailUrl;

    StateRequestAttachment(long id, String localUri, File localFile,
                           String url, String token, String mimeType, String name, long size,
                           int width, int height, String thumbnailUrl) {
        this.id = id;
        this.localUri = localUri;
        this.localFile = localFile;
        this.url = url;
        this.token = token;
        this.mimeType = mimeType;
        this.name = name;
        this.size = size;
        this.width = width;
        this.height = height;
        this.thumbnailUrl = thumbnailUrl;
    }

    private StateRequestAttachment(Builder builder) {
        this.localFile = builder.localFile;
        this.localUri = builder.localUri;
        this.mimeType = builder.mimeType;
        this.name = builder.name;
        this.id = builder.id;
        this.url = builder.url;
        this.token = builder.token;
        this.size = builder.size;
        this.width = builder.width;
        this.height = builder.height;
        this.thumbnailUrl = builder.thumbnailUrl;
    }

    boolean isAvailableLocally() {
        return localUri != null && getParsedLocalUri() != null && localFile != null;
    }

    String getUrl() {
        return url;
    }

    String getMimeType() {
        return StringUtils.hasLength(mimeType) ? mimeType : DEFAULT_MIME_TYPE;
    }

    String getName() {
        return name;
    }

    long getId() {
        return id;
    }

    String getLocalUri() {
        return localUri;
    }

    Uri getParsedLocalUri() {
        return Uri.parse(localUri);
    }

    File getLocalFile() {
        return localFile;
    }

    String getToken() {
        return token;
    }

    long getSize() {
        return size;
    }

    int getWidth() {
        return width;
    }

    int getHeight() {
        return height;
    }

    String getThumbnailUrl() {
        return thumbnailUrl;
    }

    Builder newBuilder() {
        return new Builder(this);
    }

    @Override
    public String toString() {
        return "RequestAttachment{" +
                "id=" + id +
                ", localUri='" + localUri + '\'' +
                ", localFile=" + localFile +
                ", url='" + url + '\'' +
                ", token='" + token + '\'' +
                ", mimeType='" + mimeType + '\'' +
                ", name='" + name + '\'' +
                ", size='" + size + '\'' +
                ", width='" + width + '\'' +
                ", height='" + height + '\'' +
                '}';
    }

    @Override
    public int compareTo(@NonNull StateRequestAttachment o) {
        return (int) (id - o.id);
    }

    static class Builder {

        private long id;

        private String localUri;
        private File localFile;

        private String url;
        private String token;
        private String mimeType;
        private String name;
        private long size;
        private int width;
        private int height;

        private String thumbnailUrl;

        private Builder(StateRequestAttachment requestAttachment) {
            this.id = requestAttachment.getId();
            this.localFile = requestAttachment.getLocalFile();
            this.localUri = requestAttachment.getLocalUri();
            this.url = requestAttachment.getUrl();
            this.token = requestAttachment.getToken();
            this.mimeType = requestAttachment.getMimeType();
            this.name = requestAttachment.getName();
            this.size = requestAttachment.getSize();
            this.width = requestAttachment.getWidth();
            this.height = requestAttachment.getHeight();
            this.thumbnailUrl = requestAttachment.getThumbnailUrl();
        }

        Builder setId(long id) {
            this.id = id;
            return this;
        }

        Builder setLocalUri(String localUri) {
            this.localUri = localUri;
            return this;
        }

        Builder setLocalFile(File localFile) {
            this.localFile = localFile;
            return this;
        }

        Builder setUrl(String url) {
            this.url = url;
            return this;
        }

        Builder setToken(String token) {
            this.token = token;
            return this;
        }

        Builder setMimeType(String mimeType) {
            this.mimeType = mimeType;
            return this;
        }

        Builder setName(String name) {
            this.name = name;
            return this;
        }

        Builder setSize(long size) {
            this.size = size;
            return this;
        }

        Builder setWidth(int width) {
            this.width = width;
            return this;
        }

        Builder setHeight(int height) {
            this.height = height;
            return this;
        }

        void setThumbnailUrl(String thumbnailUrl) {
            this.thumbnailUrl = thumbnailUrl;
        }

        StateRequestAttachment build() {
            return new StateRequestAttachment(this);
        }
    }
}
