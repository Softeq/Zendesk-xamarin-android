package zendesk.support.request;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import androidx.annotation.NonNull;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.RequestCreator;
import com.squareup.picasso.Target;
import com.zendesk.logger.Logger;
import zendesk.support.R;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zendesk.support.PicassoTransformations;

import static zendesk.support.request.RequestActivity.DEBUG;

/**
 * Helper class for binding image attachments to cells.
 */
class CellAttachmentLoadingUtil {

    private static final String LOG_TAG = "AttachmentLoadingUtil";

    private final ImageSizingLogic imageSizingLogic;
    private final ImageLoadingLogic imageLoadingLogic;

    CellAttachmentLoadingUtil(Picasso picasso, Context context) {
        this.imageSizingLogic = new ImageSizingLogic(picasso, context);
        this.imageLoadingLogic = new ImageLoadingLogic(picasso);
    }

    void bindImage(final ImageView imageView, final StateRequestAttachment requestAttachment) {
        if (!imageLoadingLogic.isImageLoading(imageView, requestAttachment)) {
            imageLoadingLogic.setImageViewLoading(imageView, requestAttachment);

            if (DEBUG) {
                Logger.d(LOG_TAG, "Binding image: %s", requestAttachment);
            }

            adjustImageViewDimensions(imageView, imageSizingLogic.getMaxSize());
            imageLoadingLogic.initImageView(imageView);

            imageSizingLogic.loadDimensionsForAttachment(requestAttachment, new ZendeskCallback<ImageSizingLogic
                    .ImageDimensions>() {
                @Override
                public void onSuccess(ImageSizingLogic.ImageDimensions imageDimensions) {
                    if (imageDimensions.areKnown()) {
                        adjustImageViewDimensions(imageView, imageDimensions);
                        imageLoadingLogic.loadAttachment(imageView, requestAttachment, imageDimensions);
                    } else {
                        Logger.d(RequestActivity.LOG_TAG, "Unable retrieve image size. Id: %s", requestAttachment
                                .getId());
                    }
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    // intentionally empty
                }
            });

        } else {
            if (DEBUG) {
                Logger.d(LOG_TAG, "Already loading RequestAttachment: %s", requestAttachment);
            }
        }
    }

    private void adjustImageViewDimensions(ImageView imageView, ImageSizingLogic.ImageDimensions imageDimensions) {
        ViewGroup.LayoutParams params = imageView.getLayoutParams();
        params.width = imageDimensions.getImageWidth();
        params.height = imageDimensions.getImageHeight();
        imageView.setLayoutParams(params);
    }

    static class ImageLoadingLogic {

        private static final int IMAGE_DOWNSCALE_FACTOR = 2;

        private final Picasso picasso;

        ImageLoadingLogic(Picasso picasso) {
            this.picasso = picasso;
        }

        boolean isImageLoading(ImageView imageView, StateRequestAttachment requestAttachment) {
            final Object viewTag = imageView.getTag();
            return viewTag instanceof StateRequestAttachment
                    && ((StateRequestAttachment) viewTag).getId() == requestAttachment.getId();
        }

        void setImageViewLoading(ImageView imageView, StateRequestAttachment requestAttachment) {
            imageView.setTag(requestAttachment);
        }

        void initImageView(ImageView imageView) {
            picasso.cancelRequest(imageView);
            imageView.setImageResource(R.color.zs_color_transparent);
        }

        void loadAttachment(ImageView imageView, StateRequestAttachment requestAttachment, ImageSizingLogic
                .ImageDimensions imageDimensions) {
            getLoadingStrategy(requestAttachment).load(imageView, imageDimensions);
        }

        private LoadingStrategy getLoadingStrategy(StateRequestAttachment requestAttachment) {
            if (requestAttachment.getLocalFile() != null && requestAttachment.getLocalFile().exists()
                    && requestAttachment.getLocalFile().length() > 0) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Loading local image from disc (File). RequestAttachment %s", requestAttachment);
                }
                return new DisplayImageFromLocalSource(picasso.load(requestAttachment.getLocalFile()));

            } else if (StringUtils.hasLength(requestAttachment.getLocalUri())
                    && Uri.parse(requestAttachment.getLocalUri()) != null) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Loading local image from disc (Uri). RequestAttachment %s", requestAttachment);
                }
                return new DisplayImageFromLocalSource(picasso.load(requestAttachment.getParsedLocalUri()));

            } else if (StringUtils.hasLength(requestAttachment.getUrl())
                    && StringUtils.hasLength(requestAttachment.getThumbnailUrl())) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Loading image from web. RequestAttachment %s", requestAttachment);
                }
                return new DisplayImageFromWeb(picasso,
                        requestAttachment.getUrl(),
                        requestAttachment.getThumbnailUrl());

            } else {
                Logger.d(RequestActivity.LOG_TAG, "Can't load image. Id: %s", requestAttachment.getId());
                return new DefaultDisplayStrategy();
            }
        }

        interface LoadingStrategy {
            void load(ImageView imageView, ImageSizingLogic.ImageDimensions imageDimensions);
        }

        private static class DisplayImageFromLocalSource implements LoadingStrategy {

            private final RequestCreator requestCreator;

            private DisplayImageFromLocalSource(RequestCreator requestCreator) {
                this.requestCreator = requestCreator;
            }

            @Override
            public void load(ImageView imageView, ImageSizingLogic.ImageDimensions imageDimensions) {
                final RequestCreator r = requestCreator.noPlaceholder().noFade();
                loadImage(imageView, r, imageDimensions, null);
            }

        }

        private static class DisplayImageFromWeb implements LoadingStrategy {

            final Picasso picasso;
            final String url;
            final String thumbnailUrl;

            private DisplayImageFromWeb(Picasso picasso, String url, String thumbnailUrl) {
                this.picasso = picasso;
                this.url = url;
                this.thumbnailUrl = thumbnailUrl;
            }

            @Override
            public void load(final ImageView imageView, final ImageSizingLogic.ImageDimensions imageDimensions) {
                final Context context = imageView.getContext().getApplicationContext();
                final RequestCreator placeholder = picasso
                        .load(thumbnailUrl)
                        .transform(PicassoTransformations.getBlurTransformation(context));

                loadImage(imageView, placeholder, imageDimensions, new Callback() {
                    @Override
                    public void onSuccess() {
                        loadImage(imageView, picasso.load(url).noPlaceholder(), imageDimensions, null);
                    }

                    @Override
                    public void onError(Exception exception) {
                        Logger.d(RequestActivity.LOG_TAG,
                                "Unable to load thumbnail. Url: '%s'",
                                thumbnailUrl,
                                exception);
                        loadImage(imageView, picasso.load(url).noPlaceholder(), imageDimensions, null);
                    }
                });
            }
        }

        private static class DefaultDisplayStrategy implements LoadingStrategy {

            @Override
            public void load(ImageView imageView, ImageSizingLogic.ImageDimensions imageDimensions) {
                // intentionally empty
            }
        }

        private static void loadImage(final ImageView imageView, RequestCreator requestCreator, ImageSizingLogic
                .ImageDimensions dimensions, final Callback callback) {
            final int width = dimensions.getImageWidth();
            final int height = dimensions.getImageHeight();
            final int imageCornerRadius =
                    imageView.getContext().getResources().getDimensionPixelOffset(R.dimen
                            .zs_request_attachment_corner_radius)
                            / IMAGE_DOWNSCALE_FACTOR;

            requestCreator
                    .transform(PicassoTransformations.getRoundedTransformation(imageCornerRadius))
                    .resize(width / IMAGE_DOWNSCALE_FACTOR, height / IMAGE_DOWNSCALE_FACTOR)
                    .centerCrop()
                    .into(imageView, callback);
        }

    }

    static class ImageSizingLogic {

        private static final double ASPECT_RATIO = 16.0 / 9.0;

        private final Map<String, ImageDimensions> cachedDimensions;
        private final Picasso picasso;
        private final ImageDimensions maxSize;

        ImageSizingLogic(Picasso picasso, Context context) {
            this.cachedDimensions = new HashMap<>();
            this.picasso = picasso;
            this.maxSize = getMaxSize(context);
        }

        void loadDimensionsForAttachment(final StateRequestAttachment requestAttachment,
                                         final ZendeskCallback<ImageDimensions> callback) {
            final DimensionStrategy dimensionStrategy = getDimensionStrategy(requestAttachment, maxSize);
            dimensionStrategy.findDimensions(new ZendeskCallback<ImageDimensions>() {
                @Override
                public void onSuccess(ImageDimensions imageDimensions) {
                    if (StringUtils.hasLength(requestAttachment.getLocalUri()) && imageDimensions.areKnown()) {
                        cachedDimensions.put(requestAttachment.getLocalUri(), imageDimensions);
                    }
                    callback.onSuccess(imageDimensions);
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    // intentionally empty
                }
            });
        }

        ImageDimensions getMaxSize() {
            return maxSize;
        }

        private ImageDimensions getMaxSize(Context context) {
            int maxWidth = calculateMaxWidth(context);
            int maxHeight = (int) (maxWidth / ASPECT_RATIO);
            return new ImageDimensions(maxWidth, maxHeight);
        }

        private DimensionStrategy getDimensionStrategy(StateRequestAttachment requestAttachment, ImageDimensions
                maxSize) {
            if (requestAttachment.getHeight() > 0 && requestAttachment.getWidth() > 0) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Dimensions available. RequestAttachment: %s", requestAttachment);
                }
                return new ExistingDimensions(requestAttachment.getWidth(), requestAttachment.getHeight(), maxSize);

            } else if (StringUtils.hasLength(requestAttachment.getLocalUri())
                    && cachedDimensions.containsKey(requestAttachment.getLocalUri())) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Cached dimensions available. RequestAttachment: %s", requestAttachment);
                }
                final ImageDimensions imageDimensions = cachedDimensions.get(requestAttachment.getLocalUri());
                return new ExistingDimensions(imageDimensions.getImageWidth(), imageDimensions.getImageHeight(),
                        maxSize);

            } else if (requestAttachment.getLocalFile() != null && requestAttachment.getLocalFile().exists()
                    && requestAttachment.getLocalFile().length() > 0) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Reading dimensions from local file. RequestAttachment: %s", requestAttachment);
                }
                return new ReadFromBitmap(requestAttachment.getLocalFile(), maxSize);

            } else if (StringUtils.hasLength(requestAttachment.getLocalUri())
                    && Uri.parse(requestAttachment.getLocalUri()) != null) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Using picasso for loading dimensions (uri). RequestAttachment: %s",
                            requestAttachment);
                }
                final Uri uri = Uri.parse(requestAttachment.getLocalUri());
                return new ReadFromPicasso(picasso.load(uri), maxSize);

            } else if (StringUtils.hasLength(requestAttachment.getUrl())) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Using picasso for loading dimensions (url). RequestAttachment: %s",
                            requestAttachment);
                }
                return new ReadFromPicasso(picasso.load(requestAttachment.getUrl()), maxSize);

            } else {
                Logger.d(RequestActivity.LOG_TAG, "Can't load dimensions. Id: %s", requestAttachment.getId());
                return new DefaultStrategy();
            }
        }

        static ImageDimensions determineTargetDimensions(int sourceWidth, int sourceHeight, int imageMaxWidth, int
                imageMaxHeight) {
            final ImageDimensions imageDimensions = new ImageDimensions();

            int targetHeight;
            int targetWidth;
            final double aspectRatio = (1.0 * sourceWidth) / sourceHeight;

            final int maxHeight = (int) (imageMaxWidth / aspectRatio);
            // image landscape
            if (sourceWidth > sourceHeight) {
                // width too large
                if (sourceWidth > imageMaxWidth) {
                    targetWidth = imageMaxWidth;
                    targetHeight = (int) (targetWidth / aspectRatio);
                } else { // height too large, centerCrop
                    targetWidth = sourceWidth;
                    targetHeight = sourceHeight;
                }
            } else { // image portrait
                // height too large
                if (sourceHeight > maxHeight) {
                    // adjust width
                    targetHeight = maxHeight;
                    targetWidth = Math.min(imageMaxWidth, sourceWidth);
                } else {
                    targetWidth = sourceWidth;
                    targetHeight = sourceHeight;
                }
            }

            imageDimensions.setDimensions(targetWidth, Math.max(Math.min(imageMaxHeight, targetHeight), 0));

            return imageDimensions;
        }

        private int calculateMaxWidth(Context context) {
            final Resources resources = context.getResources();
            final int orientationAwareDeviceWidth = resources.getDisplayMetrics().widthPixels;
            final int sideMarginStart = resources.getDimensionPixelSize(R.dimen
                    .zs_request_message_composer_expanded_side_margin);
            final int sideMarginEnd = resources.getDimensionPixelSize(R.dimen.zs_request_message_margin_side);

            return orientationAwareDeviceWidth - sideMarginStart - sideMarginEnd;
        }

        private static class ReadFromPicasso implements DimensionStrategy {

            @SuppressWarnings("MismatchedQueryAndUpdateOfCollection")
            private static final List<Target> TARGET_REFERENCE_TRAP = new ArrayList<>();

            private final RequestCreator requestCreator;
            private final ImageDimensions maxSize;

            private ReadFromPicasso(RequestCreator requestCreator, ImageDimensions maxSize) {
                this.requestCreator = requestCreator;
                this.maxSize = maxSize;
            }

            @Override
            public void findDimensions(final ZendeskCallback<ImageDimensions> callback) {
                final Target t = new Target() {
                    @Override
                    public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                        int width = bitmap.getWidth();
                        int height = bitmap.getHeight();
                        callback.onSuccess(determineTargetDimensions(width, height, maxSize.getImageWidth(), maxSize
                                .getImageHeight()));
                        TARGET_REFERENCE_TRAP.remove(this);
                    }

                    @Override
                    public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                        Logger.d(RequestActivity.LOG_TAG, "Unable to load image.");
                        callback.onSuccess(new ImageDimensions());
                        TARGET_REFERENCE_TRAP.remove(this);
                    }

                    @Override
                    public void onPrepareLoad(Drawable placeHolderDrawable) {

                    }
                };
                TARGET_REFERENCE_TRAP.add(t);
                requestCreator.into(t);
            }
        }

        private static class ReadFromBitmap implements DimensionStrategy {

            private final ImageDimensions maxSize;
            final File file;

            ReadFromBitmap(File file, ImageDimensions maxSize) {
                this.maxSize = maxSize;
                this.file = file;
            }

            @Override
            public void findDimensions(ZendeskCallback<ImageDimensions> callback) {
                final ImageDimensions sourceDimensions = loadImageDimensions(file);
                callback.onSuccess(determineTargetDimensions(sourceDimensions.getImageWidth(), sourceDimensions
                        .getImageHeight(), maxSize.getImageWidth(), maxSize.getImageHeight()));
            }

            private ImageDimensions loadImageDimensions(@NonNull File file) {
                final ImageDimensions imageDimensions = new ImageDimensions();

                final BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(file.getAbsolutePath(), options); // I/O on the main thread but only takes
                // ~0.5ms
                imageDimensions.setDimensions(options.outWidth, options.outHeight);

                return imageDimensions;
            }
        }

        private static class ExistingDimensions implements DimensionStrategy {

            private final int width;
            private final int height;
            private final ImageDimensions maxSize;

            ExistingDimensions(int width, int height, ImageDimensions maxSize) {
                this.width = width;
                this.height = height;
                this.maxSize = maxSize;
            }

            @Override
            public void findDimensions(ZendeskCallback<ImageDimensions> callback) {
                callback.onSuccess(determineTargetDimensions(width, height, maxSize.getImageWidth(), maxSize
                        .getImageHeight()));
            }

        }

        private static class DefaultStrategy implements DimensionStrategy {

            @Override
            public void findDimensions(ZendeskCallback<ImageDimensions> callback) {
                callback.onSuccess(new ImageDimensions());
            }

        }

        interface DimensionStrategy {
            void findDimensions(ZendeskCallback<ImageDimensions> callback);
        }

        static class ImageDimensions {
            private static final int UNKNOWN_DIMENSION = -1;
            private int imageWidth = UNKNOWN_DIMENSION;
            private int imageHeight = UNKNOWN_DIMENSION;

            ImageDimensions(int imageWidth, int imageHeight) {
                this.imageWidth = imageWidth;
                this.imageHeight = imageHeight;
            }

            ImageDimensions() {
                // intentionally empty
            }

            boolean areKnown() {
                return imageWidth != UNKNOWN_DIMENSION && imageHeight != UNKNOWN_DIMENSION;
            }

            int getImageWidth() {
                return imageWidth;
            }

            int getImageHeight() {
                return imageHeight;
            }

            void setDimensions(int imageWidth, int imageHeight) {
                this.imageWidth = imageWidth;
                this.imageHeight = imageHeight;
            }

            @Override
            public String toString() {
                return "ImageDimensions{" +
                        "width=" + imageWidth +
                        ", height=" + imageHeight +
                        '}';
            }
        }
    }
}
