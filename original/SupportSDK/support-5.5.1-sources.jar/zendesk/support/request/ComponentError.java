package zendesk.support.request;

import android.app.Activity;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.snackbar.Snackbar;
import android.view.View;

import zendesk.support.R;

import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.Listener;
import zendesk.support.suas.State;
import zendesk.support.suas.StateSelector;

/**
 * Component representing the general error Snackbar.
 */
class ComponentError implements Listener<ComponentError.ErrorStateModel> {

    static ComponentError create(Activity activity, Dispatcher dispatcher, ActionFactory af) {
        final CoordinatorLayout cl = activity.findViewById(R.id.activity_request);
        return new ComponentError(cl, dispatcher, af);
    }

    static StateSelector<ErrorStateModel> getSelector() {
        return new ErrorStateSelector();
    }

    private final CoordinatorLayout container;
    private final Dispatcher dispatcher;
    private final ActionFactory af;

    private Snackbar snackbar;
    private StateError.ErrorType errorState;

    private ComponentError(CoordinatorLayout container, Dispatcher dispatcher, ActionFactory af) {
        this.container = container;
        this.dispatcher = dispatcher;
        this.af = af;
    }

    @Override
    public void update(@NonNull ErrorStateModel state) {

        if (state.errorState == errorState) {
            return;
        } else {
            errorState = state.errorState;
        }

        if (state.errorState != StateError.ErrorType.NoError) {
            snackbar = Snackbar.make(container, state.getErrorMessage(), Snackbar.LENGTH_INDEFINITE);

            switch (state.getErrorState()) {

                case InitialGetComments: {
                    snackbar.setText(R.string.request_error_load_comments);
                    snackbar.setAction(R.string.retry_view_button_label, new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            errorState = StateError.ErrorType.NoError;
                            dispatcher.dispatch(af.initialLoadCommentsAsync());
                        }
                    });
                    snackbar.show();
                    break;
                }

                case InputFormSubmission: {
                    if (!state.isConversationsEnabled()) {
                        snackbar.setText(R.string.request_error_create_request);
                        snackbar.show();
                    }
                    break;
                }

            }

        } else {
            if (snackbar != null) {
                snackbar.dismiss();
            }
        }
    }

    static class ErrorStateSelector implements StateSelector<ErrorStateModel> {

        @Nullable
        @Override
        public ErrorStateModel selectData(@NonNull State state) {
            final StateError errorState = StateError.fromState(state);
            final StateConfig config = StateConfig.fromState(state);

            return new ErrorStateModel(
                    errorState.getState(),
                    errorState.getMessage(),
                    config.getSettings().isConversationsEnabled());
        }
    }


    static class ErrorStateModel {

        private final StateError.ErrorType errorState;
        private final String errorMessage;
        private final boolean conversationsEnabled;

        ErrorStateModel(StateError.ErrorType errorState, String errorMessage, boolean conversationsEnabled) {
            this.errorState = errorState;
            this.errorMessage = errorMessage;
            this.conversationsEnabled = conversationsEnabled;
        }

        StateError.ErrorType getErrorState() {
            return errorState;
        }

        String getErrorMessage() {
            return errorMessage;
        }

        boolean isConversationsEnabled() {
            return conversationsEnabled;
        }
    }

}
