package zendesk.support.request;

import android.content.Context;
import android.graphics.Rect;
import androidx.annotation.VisibleForTesting;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

import com.zendesk.logger.Logger;
import zendesk.support.R;

/**
 * An ItemDecoration that makes sure that the cells in the list are properly spaced.
 *
 * @see "https://github.com/zendesk/zendesk_sdk_android/pull/1290"
 */
class CellMarginDecorator extends RecyclerView.ItemDecoration {

    public static final int CELL = 0b00000001;
    public static final int CELL_START_BLOCK = 0b00000010;
    public static final int CELL_WITH_LABEL = 0b00001000;
    public static final int CELL_LAST = 0b00010000;

    private final ComponentRequestAdapter dataSource;
    private final int verticalMargin;
    private final int groupVerticalMargin;

    CellMarginDecorator(ComponentRequestAdapter dataSource, Context context) {
        this.dataSource = dataSource;
        this.verticalMargin = context.getResources().getDimensionPixelOffset(R.dimen
                .zs_request_message_margin_vertical);
        this.groupVerticalMargin = context.getResources().getDimensionPixelOffset(R.dimen
                .zs_request_message_group_margin_vertical);
    }

    @VisibleForTesting
    CellMarginDecorator(ComponentRequestAdapter dataSource, int verticalMargin, int groupVerticalMargin) {
        this.dataSource = dataSource;
        this.verticalMargin = verticalMargin;
        this.groupVerticalMargin = groupVerticalMargin;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {
        final int childPosition = parent.getChildAdapterPosition(view);

        if (childPosition == RecyclerView.NO_POSITION) {
            return;
        }

        final CellType.Base cell = dataSource.getMessageForPos(childPosition);
        final int positionType = cell.getPositionType();
        final Rect insets = cell.getInsets();

        final boolean startOfBlock = (positionType & CELL_START_BLOCK) == CELL_START_BLOCK;
        final boolean cellWithLabel = (positionType & CELL_WITH_LABEL) == CELL_WITH_LABEL;
        final boolean lastCellInStream = (positionType & CELL_LAST) == CELL_LAST;
        final boolean ordinaryCell = (positionType & CELL) == CELL;

        int left = -insets.left;
        int top = -insets.top;
        int right = -insets.right;
        int bottom = -insets.bottom;

        if (startOfBlock && cellWithLabel) {
            top += groupVerticalMargin;
            bottom += groupVerticalMargin;

        } else if (startOfBlock) {
            top += groupVerticalMargin;
            bottom += verticalMargin;

        } else if (cellWithLabel) {
            top += verticalMargin;
            bottom += groupVerticalMargin;

        } else if (ordinaryCell) {
            top += verticalMargin;
            bottom += verticalMargin;

        } else {
            Logger.d(RequestActivity.LOG_TAG, "Unknown position type: %s", positionType);
        }

        if (lastCellInStream) {
            bottom = -insets.bottom;
        }

        outRect.set(left, top, right, bottom);
    }

}
