package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.core.util.Pair;
import android.view.View;
import zendesk.support.R;
import com.zendesk.util.CollectionUtils;
import java.util.Map;
import zendesk.support.suas.Action;
import zendesk.support.suas.Listener;
import zendesk.support.CommentsResponse;

class RequestAccessibilityHerald implements Listener<Action<?>> {

    static RequestAccessibilityHerald create(RequestActivity activity) {
        final View rootView = activity.findViewById(R.id.activity_request_root);
        return new RequestAccessibilityHerald(rootView);
    }

    private final View view;

    RequestAccessibilityHerald(View view) {
        this.view = view;
    }

    @Override
    public void update(@NonNull Action<?> action) {
        switch (action.getActionType()) {

            case ActionFactory.CREATE_COMMENT_SUCCESS: {
                ActionCreateComment.CreateCommentResult data = action.getData();
                announce(R.string.zs_request_announce_comment_created_accessibility, data.getMessage().getPlainBody());
                break;
            }

            case ActionFactory.CREATE_COMMENT_ERROR: {
                final StateMessage error = action.getData();
                announce(R.string.zs_request_announce_comment_failed_accessibility, error.getPlainBody());
                break;
            }

            case ActionFactory.LOAD_COMMENTS_INITIAL: {
                Pair<CommentsResponse, Map<Long, MediaResult>> data = action.getData();
                if (data != null && data.first != null && CollectionUtils.isNotEmpty(data.first.getComments())) {
                    announce(R.string.zs_request_announce_comments_loaded_accessibility);
                }
                break;
            }

        }
    }

    private void announce(@StringRes int id, Object... objects) {
        final String message = view.getContext().getString(id, objects);
        view.announceForAccessibility(message);
    }

}