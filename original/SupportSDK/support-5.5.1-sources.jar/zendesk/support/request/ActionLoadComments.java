package zendesk.support.request;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.StringUtils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.GetState;
import zendesk.support.Attachment;
import zendesk.support.CommentResponse;
import zendesk.support.CommentsResponse;
import zendesk.support.RequestProvider;

/**
 * Load comments from the network
 */
class ActionLoadComments implements AsyncMiddleware.AsyncAction {

    private final ActionFactory actionFactory;
    private final RequestProvider requestProvider;
    private final MediaResultUtility mediaResultUtility;
    private final Handler handler;
    private final boolean initialLoad;

    ActionLoadComments(ActionFactory actionFactory, RequestProvider requestProvider, boolean initialLoad, MediaResultUtility mediaResultUtility) {
        this(actionFactory, requestProvider, new Handler(Looper.getMainLooper()), initialLoad, mediaResultUtility);
    }

    @VisibleForTesting
    ActionLoadComments(ActionFactory actionFactory, RequestProvider requestProvider,
                        Handler handler, boolean initialLoad, MediaResultUtility mediaResultUtility) {
        this.actionFactory = actionFactory;
        this.requestProvider = requestProvider;
        this.mediaResultUtility = mediaResultUtility;
        this.handler = handler;
        this.initialLoad = initialLoad;
    }

    @Override
    public void actionQueued(Dispatcher dispatcher, GetState state) {
        dispatcher.dispatch(actionFactory.loadComments(initialLoad));
    }

    @Override
    public void execute(final Dispatcher dispatcher, GetState state, final AsyncMiddleware.Callback callback) {
        final StateConversation con = StateConversation.fromState(state.getState());

        if (!StringUtils.hasLength(con.getRemoteId())) {
            Logger.d(RequestActivity.LOG_TAG, "Skip loading comments. No remote id found.");
            dispatcher.dispatch(actionFactory.skipAction());
            callback.done();
            return;
        }

        final ZendeskCallback<CommentsResponse> fetchCommentsCallback =
                new MinimumTimeCallback<CommentsResponse>(handler, 1, TimeUnit.SECONDS) {
                    @Override
                    public void onDelayedSuccess(CommentsResponse commentsResponse) {
                        Set<Long> remoteIds = new HashSet<>(con.getMessageIdMapper().getRemoteIds());

                        for (CommentResponse commentResponse : commentsResponse.getComments()) {
                            remoteIds.add(commentResponse.getId());
                        }

                        requestProvider.markRequestAsRead(con.getRemoteId(), remoteIds.size());

                        final Map<Long, MediaResult> localAttachments =
                                findAttachments(con.getLocalId(), commentsResponse);
                        dispatcher.dispatch(actionFactory
                                .loadCommentsSuccess(initialLoad, commentsResponse, localAttachments));

                        callback.done();
                    }

                    @Override
                    public void onDelayedError(ErrorResponse error) {
                        Logger.w(RequestActivity.LOG_TAG, "Unable to load comments. Error: '%s'", error.getReason());
                        dispatcher.dispatch(actionFactory.loadCommentsError(initialLoad, error));
                        callback.done();
                    }
                };

        StateMessage latestDeliveredMessage = find2ndLastDeliveredMessage(con.getMessages());

        if (latestDeliveredMessage != null) {
            requestProvider.getCommentsSince(con.getRemoteId(), latestDeliveredMessage.getDate(), false,
                    fetchCommentsCallback);
        } else {
            requestProvider.getComments(con.getRemoteId(), fetchCommentsCallback);
        }
    }

    @SuppressLint("UseSparseArrays")
    private Map<Long, MediaResult> findAttachments(String requestId, CommentsResponse commentsResponse) {
        final List<CommentResponse> comments = commentsResponse.getComments();
        final Map<Long, MediaResult> mediaResults = new HashMap<>();

        for (CommentResponse comment : comments) {
            for (Attachment attachment : comment.getAttachments()) {
                final MediaResult result = mediaResultUtility.getLocalFile(requestId, attachment.getId(),
                        attachment.getFileName());
                if (attachment.getSize() == result.getFile().length()) {
                    mediaResults.put(attachment.getId(), result);
                }
            }
        }

        return mediaResults;
    }

    @Nullable
    private StateMessage find2ndLastDeliveredMessage(List<StateMessage> messages) {

        ListIterator<StateMessage> messageListIterator = messages.listIterator(messages.size());
        int delivered = 0;
        while (messageListIterator.hasPrevious()) {
            StateMessage message = messageListIterator.previous();

            if (message.getState().getStatus() == StateMessageStatus.DELIVERED) {
                delivered++;
                if (delivered == 2) {
                    return message;
                }
            }
        }

        return null;
    }

    private abstract static class MinimumTimeCallback<E> extends ZendeskCallback<E> {

        private final long start;
        private final long minTime;
        private final TimeUnit minTimeUnit;
        private final Handler handler;

        MinimumTimeCallback(Handler handler, long minTime, TimeUnit minTimeUnit) {
            this.start = System.nanoTime();
            this.handler = handler;
            this.minTime = minTime;
            this.minTimeUnit = minTimeUnit;
        }

        public abstract void onDelayedSuccess(E result);

        public abstract void onDelayedError(ErrorResponse error);

        @Override
        public void onSuccess(final E e) {
            final long wait = remainingTime();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    onDelayedSuccess(e);
                }
            }, wait);
        }

        @Override
        public void onError(final ErrorResponse errorResponse) {
            final long wait = remainingTime();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    onDelayedError(errorResponse);
                }
            }, wait);
        }

        private long remainingTime() {
            final long timePassedByInNs = System.nanoTime() - start;
            final long waitTimeInNs = TimeUnit.NANOSECONDS.convert(minTime, minTimeUnit);

            if (timePassedByInNs < waitTimeInNs) {
                return TimeUnit.MILLISECONDS.convert(waitTimeInNs - timePassedByInNs, TimeUnit.NANOSECONDS);
            } else {
                return 0L;
            }
        }
    }

}