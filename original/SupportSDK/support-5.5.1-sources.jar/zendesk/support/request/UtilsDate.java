package zendesk.support.request;

import android.text.format.DateUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Collection of utils for handling dates.
 */
class UtilsDate {

    private UtilsDate() {
        // intentionally empty
    }

    static boolean isToday(Date date) {
        return DateUtils.isToday(date.getTime());
    }

    static boolean isYesterday(Date date) {
        final Date yesterday = getYesterday();
        return isSameDay(date, yesterday);
    }

    static boolean isSameDay(Date d1, Date d2) {
        final Calendar c1 = getCalendar(d1);
        final Calendar c2 = getCalendar(d2);

        final boolean year = c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR);
        final boolean month = c1.get(Calendar.MONTH) == c2.get(Calendar.MONTH);
        final boolean day = c1.get(Calendar.DAY_OF_MONTH) == c2.get(Calendar.DAY_OF_MONTH);

        return year && month && day;
    }

    static Date getBeginOfDay(Date date) {
        final Calendar cal = getCalendar(date);

        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        return cal.getTime();
    }

    private static Date getYesterday() {
        final Calendar c1 = getCalendar(new Date());

        c1.add(Calendar.DAY_OF_MONTH, -1);

        return c1.getTime();
    }

    private static Calendar getCalendar(Date date) {
        final Calendar c = new GregorianCalendar(TimeZone.getDefault(), Locale.getDefault());
        c.setTime(date);
        return c;
    }

}
