package zendesk.support.request;

import android.content.Context;
import androidx.annotation.RestrictTo;
import androidx.appcompat.widget.AppCompatTextView;
import android.text.Selection;
import android.text.Spannable;
import android.text.method.LinkMovementMethod;
import android.util.AttributeSet;
import android.view.MotionEvent;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * TextView for displaying comments in message stream. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
class ViewRequestText extends AppCompatTextView {

    public ViewRequestText(Context context) {
        super(context);
        init();
    }

    public ViewRequestText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ViewRequestText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setMovementMethod(LinkMovementMethod.getInstance());
    }

    @Override
    public boolean dispatchTouchEvent(final MotionEvent event) {
        // Workaround to https://code.google.com/p/android/issues/detail?id=191430
        // Bug https://zendesk.atlassian.net/browse/MSDK-2159
        int startSelection = getSelectionStart();
        int endSelection = getSelectionEnd();
        if (startSelection < 0 || endSelection < 0) {
            Selection.setSelection((Spannable) getText(), getText().length());
        } else if (startSelection != endSelection) {
            if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
                final CharSequence text = getText();
                setText(null);
                setText(text);
            }
        }
        return super.dispatchTouchEvent(event);
    }

}
