package zendesk.support.request;

import android.content.Context;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.TextView;

import zendesk.support.R;

import java.util.List;

import zendesk.support.UiUtils;

/**
 * Cell in stream. User. Text message.
 */
class CellUserMessage extends CellBase implements CellType.Message, CellType.Stateful {

    private final CharSequence textMessage;
    private final boolean markAsDelivered;
    private final boolean showError;
    private final StateMessage message;
    private final Rect insets;
    private final List<StateMessage> erroredMessages;
    private final boolean lastErrorCellOfBlock;

    CellUserMessage(CellBindHelper utils, StateMessage message, boolean markAsDelivered, boolean showError,
                    CharSequence textMessage, List<StateMessage> erroredMessages, boolean lastErrorCellOfBlock) {
        super(utils, R.layout.zs_request_user_message, message.getId(), GROUP_ID_END_USER, message.getDate());
        this.textMessage = textMessage;
        this.message = message;
        this.markAsDelivered = markAsDelivered;
        this.showError = showError;
        this.insets = utils.getInsets(0, 0, 0, R.dimen.zs_request_message_inset_user_bottom);
        this.erroredMessages = erroredMessages;
        this.lastErrorCellOfBlock = lastErrorCellOfBlock;
    }

    @Override
    public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
        final ViewRequestText textView = view.findCachedView(R.id.request_user_message_text);
        textView.setText(textMessage);

        final TextView statusMessage = view.findCachedView(R.id.request_user_message_status);
        utils.bindStatusLabel(statusMessage, lastErrorCellOfBlock, markAsDelivered);

        // Error state
        final View bubble = view.findCachedView(R.id.request_user_message_bubble);
        final View.OnClickListener listener = utils.errorClickListener(showError, erroredMessages);

        UiUtils.setTint(utils.colorForError(isErrorShown()), bubble.getBackground(), bubble);
        view.itemView.setOnClickListener(listener);
        bubble.setOnClickListener(listener);
        textView.setOnClickListener(listener);
        statusMessage.setOnClickListener(listener);

        // Talk Back
        bubble.setContentDescription(buildTalkBackString(bubble.getContext()));
    }

    private String buildTalkBackString(Context context) {
        final StringBuilder talkBack = new StringBuilder();
        talkBack.append(context.getString(R.string.zs_request_message_user_text_accessibility, textMessage));
        talkBack.append(" ");

        if (!showError) {
            final CharSequence dateString = DateUtils.getRelativeTimeSpanString(context, message.getDate().getTime(),
                    true);
            talkBack.append(context.getString(R.string.zs_request_message_user_sent_accessibility, dateString));
        } else {
            talkBack.append(context.getString(R.string.zs_request_message_user_error_accessibility));
        }

        return talkBack.toString();
    }

    @Override
    public boolean isMarkedAsDelivered() {
        return markAsDelivered;
    }

    @Override
    public CellType.Stateful markAsDelivered() {
        final CellUserMessage userMessage = new CellUserMessage(utils, message, true, showError, textMessage,
                erroredMessages, lastErrorCellOfBlock);
        userMessage.setPositionType(getPositionType());
        return userMessage;
    }

    @Override
    public CellType.Stateful markAsErrored(List<StateMessage> errorGroup, boolean endOfBlock) {
        final CellUserMessage userMessage = new CellUserMessage(utils, message, markAsDelivered, true, textMessage,
                errorGroup, endOfBlock);
        userMessage.setPositionType(getPositionType());
        return userMessage;
    }

    @Override
    public StateMessage getStateMessage() {
        return message;
    }

    @Override
    public List<StateMessage> getErrorGroupMessages() {
        return erroredMessages;
    }

    @Override
    public boolean isErrorShown() {
        return showError;
    }

    @Override
    public boolean isLastErrorCellOfBlock() {
        return lastErrorCellOfBlock;
    }

    @Override
    public boolean areContentsTheSame(CellType.Base userMessage) {
        final boolean message = utils.areMessageContentsTheSame(this, userMessage);
        final boolean stateful = utils.areStatefulCellContentsTheSame(this, userMessage);
        return message && stateful;
    }

    @Override
    public String getMessage() {
        return message.getBody();
    }

    @Override
    public Rect getInsets() {
        return insets;
    }
}