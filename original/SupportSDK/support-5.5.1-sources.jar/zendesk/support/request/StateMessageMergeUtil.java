package zendesk.support.request;

import android.annotation.SuppressLint;
import androidx.annotation.VisibleForTesting;
import androidx.core.util.Pair;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Helper class for mering a local list of messages with a remote list of messages.
 */
class StateMessageMergeUtil {

    private StateMessageMergeUtil() {
        // intentionally empty
    }

    static List<StateMessage> mergeMessages(List<StateMessage> local, List<StateMessage> remote) {
        final Pair<List<StateMessage>, List<StateMessage>> firstRun = mergeRemoteMessagesById(local, remote);

        if (CollectionUtils.isEmpty(firstRun.second)) {
            return firstRun.first;
        } else {
            return mergeRemoteMessagesBySortOrder(firstRun.first, firstRun.second);
        }
    }

    static List<StateMessage> removeMessageById(long id, List<StateMessage> messages) {
        final List<StateMessage> filteredList = new ArrayList<>(messages.size());
        for (StateMessage m : messages) {
            if (m.getId() != id) {
                filteredList.add(m);
            }
        }
        return filteredList;
    }

    @SuppressLint("UseSparseArrays")
    private static Pair<List<StateMessage>, List<StateMessage>> mergeRemoteMessagesById(List<StateMessage> local,
                                                                                        List<StateMessage> remote) {

        final Map<Long, StateMessage> remoteMapping = new LinkedHashMap<>();
        for (StateMessage m : remote) {
            remoteMapping.put(m.getId(), m);
        }

        final List<StateMessage> mergedList = new ArrayList<>();
        for (StateMessage localMessage : local) {
            if (remoteMapping.containsKey(localMessage.getId())) {
                final StateMessage remoteMessage = remoteMapping.remove(localMessage.getId());
                mergedList.add(synchronizeAttachmentOrder(localMessage, remoteMessage));
            } else {
                mergedList.add(localMessage);
            }
        }

        return Pair.<List<StateMessage>, List<StateMessage>>create(mergedList, new ArrayList<>(remoteMapping.values()));
    }

    private static List<StateMessage> mergeRemoteMessagesBySortOrder(List<StateMessage> local, List<StateMessage>
            remote) {

        final int localSize = local.size();
        final int remoteSize = remote.size();

        final List<StateMessage> messages = new ArrayList<>(localSize + remoteSize);

        int idxLocal = 0;
        int idxRemote = 0;

        while (true) {
            // both lists fully traversed
            if (idxLocal >= localSize && idxRemote >= remoteSize) {
                break;
            }

            // only one list fully traversed, append remaining messages from the other list
            if (idxLocal >= localSize || idxRemote >= remoteSize) {
                if (idxLocal < localSize) {
                    messages.addAll(local.subList(idxLocal, localSize));
                } else {
                    messages.addAll(remote.subList(idxRemote, remoteSize));
                }

                break;

            }

            final StateMessage localMessage = local.get(idxLocal);
            // remote messages sorted in DESC order (timestamp); iterate list from the end
            final StateMessage remoteMessage = remote.get(idxRemote);

            if (localMessage.getId() == remoteMessage.getId()) {
                messages.add(synchronizeAttachmentOrder(localMessage, remoteMessage));

                idxLocal++;
                idxRemote++;
            } else if (localMessage.getDate().before(remoteMessage.getDate())) {
                messages.add(localMessage);
                idxLocal++;
            } else {
                messages.add(remoteMessage);
                idxRemote++;
            }
        }

        return messages;
    }

    @SuppressLint("UseSparseArrays")
    @VisibleForTesting
    static StateMessage synchronizeAttachmentOrder(StateMessage local, StateMessage remote) {

        if (CollectionUtils.isEmpty(remote.getAttachments())) {
            return remote;
        }

        final Map<Long, Integer> sourceList = new HashMap<>();
        for (int i = 0, c = local.getAttachments().size(); i < c; i++) {
            sourceList.put(local.getAttachments().get(i).getId(), i);
        }

        final List<StateRequestAttachment> sortedRequestAttachment = new ArrayList<>(remote.getAttachments());

        Collections.sort(sortedRequestAttachment, new Comparator<StateRequestAttachment>() {
            public int compare(StateRequestAttachment attachment1, StateRequestAttachment attachment2) {
                Integer attachment1LocalId = sourceList.get(attachment1.getId());
                Integer attachment2LocalId = sourceList.get(attachment2.getId());
                if (attachment1LocalId == null && attachment2LocalId == null) {
                    return 0;
                } else if (attachment2LocalId == null) {
                    return 1;
                } else if (attachment1LocalId == null) {
                    return -1;
                }

                return attachment1LocalId - attachment2LocalId;
            }
        });

        return remote.withAttachments(sortedRequestAttachment);
    }

    static List<StateRequestUser> mergeUsers(List<StateRequestUser> currentUsers, List<StateRequestUser> newUsers) {
        final Set<StateRequestUser> users = new TreeSet<>(new Comparator<StateRequestUser>() {
            @Override
            public int compare(StateRequestUser u1, StateRequestUser u2) {
                return (int) (u1.getId() - u2.getId());
            }
        });

        // add users from the network first to ensure the date to be up to date
        users.addAll(newUsers);
        users.addAll(currentUsers);

        return new ArrayList<>(users);
    }
}