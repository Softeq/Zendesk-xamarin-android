package zendesk.support.request;

import android.content.Context;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import zendesk.support.R;

import java.util.Date;

/**
 * Cell in stream. Agent. Image attachment.
 */
class CellAgentAttachmentImage extends CellBase implements CellType.Attachment, CellType.Agent {

    private final StateRequestAttachment attachment;
    private final StateRequestUser user;
    private final Rect insets;
    private boolean isAgentNameVisible;

    CellAgentAttachmentImage(CellBindHelper utils, StateRequestAttachment attachment, StateRequestUser user, Date
            timeStamp) {
        super(utils, R.layout.zs_request_agent_attachment_image, attachment.getId(), user.getId(), timeStamp);
        this.user = user;
        this.attachment = attachment;
        this.isAgentNameVisible = false;
        this.insets = utils.getInsets(0, 0, 0, R.dimen.zs_request_message_inset_agent_attachment_bottom);
    }

    @Override
    public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
        final ImageView imageView = view.findCachedView(R.id.request_agent_message_attachment_image);
        utils.bindImage(imageView, attachment);
        utils.addOnClickListenerForImageAttachment(imageView, attachment);

        final TextView agentName = view.findCachedView(R.id.request_agent_attachment_name);
        utils.bindAgentName(agentName, isAgentNameVisible, user);

        // Talk Back
        final View container = view.findCachedView(R.id.request_agent_attachment_card);
        container.setContentDescription(buildTalkBackString(container.getContext()));
    }

    private String buildTalkBackString(Context context) {
        final StringBuilder talkBack = new StringBuilder();
        talkBack.append(context.getString(R.string.zs_request_message_agent_image_accessibility, attachment.getName()));
        talkBack.append(" ");

        final CharSequence dateString = DateUtils.getRelativeTimeSpanString(context, getTimeStamp().getTime(), true);
        talkBack.append(context.getString(R.string.zs_request_message_agent_sent_accessibility, dateString, user
                .getName()));

        return talkBack.toString();
    }

    @Override
    public StateRequestAttachment getAttachment() {
        return attachment;
    }

    @Override
    public boolean areContentsTheSame(CellType.Base requestMessage) {
        boolean msg = utils.areAttachmentCellContentsTheSame(this, requestMessage);
        boolean agent = utils.areAgentCellContentsTheSame(this, requestMessage);

        return msg && agent;
    }

    @Override
    public Rect getInsets() {
        return insets;
    }

    @Override
    public void showAgentName(boolean visible) {
        this.isAgentNameVisible = visible;
    }

    @Override
    public boolean isAgentNameVisible() {
        return isAgentNameVisible;
    }

    @Override
    public StateRequestUser getAgent() {
        return user;
    }
}
