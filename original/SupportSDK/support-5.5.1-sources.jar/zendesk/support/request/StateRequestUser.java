package zendesk.support.request;

import com.zendesk.util.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import zendesk.support.Attachment;
import zendesk.support.User;

/**
 * Information about the user who created a message.
 */
class StateRequestUser implements Serializable {

    static List<StateRequestUser> convert(List<User> users) {
        final List<StateRequestUser> requestUsers = new ArrayList<>(users.size());

        for (User user : users) {
            if (user.getId() != null) {
                final Attachment attachment = user.getPhoto();
                final String photo = attachment != null && StringUtils.hasLength(attachment.getContentUrl())
                        ? attachment.getContentUrl()
                        : StringUtils.EMPTY_STRING;

                requestUsers.add(new StateRequestUser(user.getName(), photo, user.isAgent(), user.getId()));
            }
        }

        return requestUsers;
    }

    static boolean containsAgent(List<StateRequestUser> users) {
        for (StateRequestUser user : users) {
            if (user.isAgent()) {
                return true;
            }
        }
        return false;
    }

    private final String name;
    private final String avatar;
    private final boolean isAgent;
    private final long id;

    StateRequestUser(String name, String avatar, boolean isAgent, long id) {
        this.name = name;
        this.avatar = avatar;
        this.isAgent = isAgent;
        this.id = id;
    }

    String getName() {
        return name;
    }

    String getAvatar() {
        return avatar;
    }

    boolean isAgent() {
        return isAgent;
    }

    long getId() {
        return id;
    }
}
