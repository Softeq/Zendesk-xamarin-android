package zendesk.support.request;

import androidx.annotation.NonNull;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;

import zendesk.support.suas.Action;
import zendesk.support.suas.Reducer;

/**
 * Reducer for maintaining the progress state.
 */
class ReducerProgress extends Reducer<StateProgress> {

    // Action types that trigger a progress bar
    private static final Collection<String> INCREMENT_ACTIONS = new HashSet<>(Arrays.asList(
            ActionFactory.CREATE_COMMENT,
            ActionFactory.LOAD_SETTINGS,
            ActionFactory.LOAD_COMMENTS_FROM_CACHE,
            ActionFactory.LOAD_COMMENTS_INITIAL,
            ActionFactory.LOAD_REQUEST
    ));

    // Action types that hides the progress bar
    private static final Collection<String> DECREMENT_ACTION = new HashSet<>(Arrays.asList(
            ActionFactory.CREATE_COMMENT_ERROR, ActionFactory.CREATE_COMMENT_SUCCESS,
            ActionFactory.LOAD_SETTINGS_ERROR, ActionFactory.LOAD_SETTINGS_SUCCESS,
            ActionFactory.CREATE_REQUEST_ERROR, ActionFactory.CREATE_REQUEST_SUCCESS,
            ActionFactory.LOAD_COMMENTS_INITIAL_ERROR, ActionFactory.LOAD_COMMENTS_INITIAL_SUCCESS,
            ActionFactory.LOAD_COMMENTS_FROM_CACHE_SUCCESS, ActionFactory.LOAD_COMMENTS_FROM_CACHE_ERROR,
            ActionFactory.LOAD_REQUEST_ERROR, ActionFactory.LOAD_REQUEST_SUCCESS,
            ActionFactory.SKIP_ACTION
    ));

    @Override
    public StateProgress reduce(@NonNull StateProgress oldState, @NonNull Action<?> action) {
        if (INCREMENT_ACTIONS.contains(action.getActionType())) {
            return oldState.increment();
        } else if (DECREMENT_ACTION.contains(action.getActionType())) {
            return oldState.decrement();
        } else {
            return null;
        }
    }

    @NonNull
    @Override
    public StateProgress getInitialState() {
        return new StateProgress();
    }
}
