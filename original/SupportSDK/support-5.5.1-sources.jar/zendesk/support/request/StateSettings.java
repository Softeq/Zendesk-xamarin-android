package zendesk.support.request;

import com.zendesk.util.StringUtils;

import java.io.Serializable;

import zendesk.support.SupportSdkSettings;

/**
 * Representation of {@link SupportSdkSettings} in request screen.
 */
class StateSettings implements Serializable {

    static StateSettings fromSupportSettings(SupportSdkSettings supportSdkSettings,
                                             boolean identityHasEmailAddress, boolean identityHasName) {
        return new StateSettings(
                supportSdkSettings.isConversationsEnabled(),
                supportSdkSettings.isAttachmentsEnabled(),
                supportSdkSettings.getMaxAttachmentSize(),
                supportSdkSettings.isNeverAskForEmailEnabled(),
                identityHasEmailAddress,
                identityHasName,
                supportSdkSettings.isShowReferrerLogoEnabled(),
                supportSdkSettings.getReferrerUrl(),
                supportSdkSettings.getRequestSystemMessage()
        );
    }

    private final boolean settingsLoaded;
    private final boolean conversationsEnabled;
    private final boolean attachmentsEnabled;
    private final long maxAttachmentSize;
    private final boolean neverRequestEmail;
    private final boolean hasIdentityEmailAddress;
    private final boolean hasIdentityName;
    private final boolean showZendeskLogo;
    private final String referrerUrl;
    private final String systemMessage;

    StateSettings(boolean conversationsEnabled, boolean attachmentsEnabled, long maxAttachmentSize,
                  boolean neverRequestEmail, boolean hasIdentityEmailAddress, boolean hasIdentityName,
                  boolean showZendeskLogo, String referrerUrl, String systemMessage) {
        this.settingsLoaded = true;
        this.conversationsEnabled = conversationsEnabled;
        this.attachmentsEnabled = attachmentsEnabled;
        this.maxAttachmentSize = maxAttachmentSize;
        this.neverRequestEmail = neverRequestEmail;
        this.hasIdentityEmailAddress = hasIdentityEmailAddress;
        this.hasIdentityName = hasIdentityName;
        this.showZendeskLogo = showZendeskLogo;
        this.referrerUrl = referrerUrl;
        this.systemMessage = systemMessage;
    }

    StateSettings() {
        this.settingsLoaded = false;
        this.conversationsEnabled = false;
        this.attachmentsEnabled = false;
        this.maxAttachmentSize = -1L;
        this.neverRequestEmail = true;
        this.hasIdentityEmailAddress = false;
        this.hasIdentityName = false;
        this.showZendeskLogo = true;
        this.referrerUrl = StringUtils.EMPTY_STRING;
        this.systemMessage = StringUtils.EMPTY_STRING;
    }

    boolean hasSettings() {
        return settingsLoaded;
    }

    boolean isConversationsEnabled() {
        return conversationsEnabled;
    }

    boolean isNeverRequestEmailOn() {
        return neverRequestEmail;
    }

    boolean isAttachmentsEnabled() {
        return attachmentsEnabled;
    }

    long getMaxAttachmentSize() {
        return maxAttachmentSize;
    }

    boolean hasIdentityEmailAddress() {
        return hasIdentityEmailAddress;
    }

    boolean hasIdentityName() {
        return hasIdentityName;
    }

    String getReferrerUrl() {
        return referrerUrl;
    }

    boolean isShowZendeskLogo() {
        return showZendeskLogo;
    }

    String getSystemMessage() {
        return systemMessage;
    }

    @Override
    public String toString() {
        return "Settings{" +
                "settingsLoaded=" + settingsLoaded +
                ", conversationsEnabled=" + conversationsEnabled +
                ", attachmentsEnabled=" + attachmentsEnabled +
                ", maxAttachmentSize=" + maxAttachmentSize +
                ", neverRequestEmail=" + neverRequestEmail +
                ", hasIdentityEmailAddress=" + hasIdentityEmailAddress +
                ", hasIdentityName=" + hasIdentityName +
                ", referrerUrl=" + referrerUrl +
                ", systemMessage=" + systemMessage +
                '}';
    }
}