package zendesk.support.request;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Helper class for managing attachments in a component.
 */
class AttachmentHelper {

    private final int[] touchableItems;

    private List<StateRequestAttachment> selectedAttachments;
    private long maxFileSize = -1L;

    AttachmentHelper(int... touchableItems) {
        this.touchableItems = touchableItems;
        this.selectedAttachments = new ArrayList<>();
    }

    void updateAttachments(Collection<StateRequestAttachment> selectedAttachments) {
        this.selectedAttachments = CollectionUtils.copyOf(new ArrayList<>(selectedAttachments));
    }

    void updateMaxFileSize(long maxFilesSize) {
        this.maxFileSize = maxFilesSize;
    }

    List<StateRequestAttachment> getSelectedAttachments() {
        return CollectionUtils.copyOf(selectedAttachments);
    }
}
