package zendesk.support.request;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import androidx.annotation.NonNull;

import java.util.List;

import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.Listener;
import zendesk.support.UiUtils;

/**
 * Component representing the retry dialog.
 */
class ComponentDialog implements Listener<StateUi> {

    private final Activity activity;
    private final ActionFactory af;
    private final Dispatcher dispatcher;

    private Dialog dialog;

    ComponentDialog(Activity activity, ActionFactory af, Dispatcher dispatcher) {
        this.activity = activity;
        this.af = af;
        this.dispatcher = dispatcher;
    }

    private Dialog getDialogForState(StateUi.DialogState dialogState) {
        Dialog dialog = null;
        if (dialogState instanceof StateRetryDialog) {
            final RetryDialog retryDialog = new RetryDialog(activity, ((StateRetryDialog) dialogState).getMessage());
            retryDialog.setListener(new RetryDialogListener(af, dispatcher));
            dialog = retryDialog;
        }
        return dialog;
    }

    @Override
    public void update(@NonNull StateUi uiState) {
        StateUi.DialogState dialogState = uiState.getDialogState();
        if (dialogState != null) {
            if (dialog == null || !dialog.isShowing()) {

                UiUtils.dismissKeyboard(activity);

                dialog = getDialogForState(dialogState);
                dialog.setOnDismissListener(new OnDismissedListener(af, dispatcher));
                dialog.show();
            }
        }
    }

    static class RetryDialogListener implements RetryDialog.Listener {

        private final ActionFactory af;
        private final Dispatcher dispatcher;

        RetryDialogListener(ActionFactory af, Dispatcher dispatcher) {
            this.af = af;
            this.dispatcher = dispatcher;
        }

        @Override
        public void onDeleteMessage(List<StateMessage> messages) {
            for (StateMessage message : messages) {
                dispatcher.dispatch(af.deleteMessage(message));
            }
        }

        @Override
        public void onRetryMessage(List<StateMessage> messages) {
            onDeleteMessage(messages);
            for (StateMessage message : messages) {
                dispatcher.dispatch(af.resendCommentAsync(message));
                dispatcher.dispatch(af.updateCommentsAsync());
            }
        }

    }

    static class OnDismissedListener implements DialogInterface.OnDismissListener {

        private final ActionFactory af;
        private final Dispatcher dispatcher;

        OnDismissedListener(ActionFactory af, Dispatcher dispatcher) {
            this.af = af;
            this.dispatcher = dispatcher;
        }

        @Override
        public void onDismiss(DialogInterface dialogInterface) {
            dispatcher.dispatch(af.onDialogDismissed());
        }
    }
}
