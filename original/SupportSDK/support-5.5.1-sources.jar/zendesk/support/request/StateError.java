package zendesk.support.request;

import java.io.Serializable;

import zendesk.support.suas.State;

/**
 * Root state data. Holding information about the current error state.
 */
class StateError implements Serializable {

    static StateError fromState(State state) {
        StateError error = state.getState(StateError.class);
        if (error != null) {
            return error;
        } else {
            return new StateError();
        }
    }

    private final ErrorType state;
    private final String message;

    StateError() {
        this(ErrorType.NoError, "=)");
    }

    StateError(ErrorType state, String message) {
        this.state = state;
        this.message = message;
    }

    ErrorType getState() {
        return state;
    }

    String getMessage() {
        return message;
    }

    enum ErrorType {
        InitialGetComments,
        InputFormSubmission,
        NoAccess,
        NoError
    }
}
