package zendesk.support.request;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

/**
 * Minimum implementation of a screen in {@link RequestActivity}
 */
interface RequestView {

    boolean inflateMenu(MenuInflater menuInflater, Menu menu);

    boolean onOptionsItemClicked(MenuItem item);

    boolean hasUnsavedInput();
}