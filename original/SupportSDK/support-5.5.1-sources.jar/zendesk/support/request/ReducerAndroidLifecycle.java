package zendesk.support.request;

import androidx.annotation.NonNull;

import zendesk.support.suas.Action;
import zendesk.support.suas.Reducer;

/**
 * Reducer for maintaining lifecycle related state.
 */
class ReducerAndroidLifecycle extends Reducer<StateAndroidLifecycle> {

    @Override
    public StateAndroidLifecycle reduce(@NonNull StateAndroidLifecycle oldState, @NonNull Action<?> action) {
        switch (action.getActionType()) {
            case ActionFactory.ANDROID_ON_RESUME: {
                return new StateAndroidLifecycle(StateAndroidLifecycle.STARTED);
            }
            case ActionFactory.ANDROID_ON_PAUSE: {
                return new StateAndroidLifecycle(StateAndroidLifecycle.STOPPED);
            }
        }

        return null;
    }

    @NonNull
    @Override
    public StateAndroidLifecycle getInitialState() {
        return new StateAndroidLifecycle();
    }
}