package zendesk.support.request;


import android.content.Intent;
import android.net.Uri;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.android.material.textfield.TextInputLayout;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import zendesk.support.R;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.List;

import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.Listener;
import zendesk.support.suas.State;
import zendesk.support.suas.StateSelector;

import static androidx.core.util.PatternsCompat.EMAIL_ADDRESS;

/**
 * Component representing the input fields in the conversation off screen.
 */
class ComponentInputForm implements
        Listener<ComponentInputForm.InputFormModel>,
        RequestViewConversationsDisabled.MenuItemsDelegate {

    static ComponentInputForm create(View container, Dispatcher dispatcher,
                                     ActionFactory actionFactory, AttachmentHelper attachmentHelper) {
        final Validator<String> emailValidator = new Validator<String>() {
            @Override
            public boolean isValid(String input) {
                return EMAIL_ADDRESS.matcher(input).matches();
            }
        };

        final TextInputLayout nameLayout = container.findViewById(R.id.request_name_layout);
        final EditText nameField = container.findViewById(R.id.request_name_field);
        final TextInputLayout emailLayout = container.findViewById(R.id.request_email_layout);
        final EditText emailField = container.findViewById(R.id.request_email_field);
        final TextInputLayout messageLayout = container.findViewById(R.id.request_message_layout);
        final EditText messageField = container.findViewById(R.id.request_message_field);
        final View logo = container.findViewById(R.id.request_zendesk_logo);

        return new ComponentInputForm(
                logo, nameField, nameLayout,
                emailField, emailLayout, emailValidator,
                messageField, messageLayout,
                dispatcher, actionFactory, attachmentHelper);
    }

    private final View logo;
    private final EditText nameField;
    private final EditText emailField;
    private final EditText messageField;
    private final TextInputLayout nameLayout;
    private final TextInputLayout emailLayout;
    private final TextInputLayout messageLayout;
    private final Validator<String> emailValidator;
    private final Dispatcher dispatcher;
    private final ActionFactory actionFactory;
    private final AttachmentHelper attachmentHelper;

    private MenuItem sendButton;

    private boolean inlineValidation = false;

    ComponentInputForm(final View logo,
                       final EditText nameField,
                       final TextInputLayout nameLayout,
                       final EditText emailField,
                       final TextInputLayout emailLayout,
                       final Validator<String> emailValidator,
                       final EditText messageField,
                       final TextInputLayout messageLayout,
                       final Dispatcher dispatcher,
                       final ActionFactory actionFactory,
                       final AttachmentHelper attachmentHelper) {
        this.logo = logo;
        this.nameField = nameField;
        this.emailField = emailField;
        this.messageField = messageField;
        this.nameLayout = nameLayout;
        this.emailLayout = emailLayout;
        this.messageLayout = messageLayout;
        this.emailValidator = emailValidator;
        this.dispatcher = dispatcher;
        this.actionFactory = actionFactory;
        this.attachmentHelper = attachmentHelper;

        EditTextTextWatcher.install(this, nameField, emailField, messageField);
        EmailFieldFocusListener.install(this, emailField);
    }

    @Override
    public void update(@NonNull final InputFormModel inputFormModel) {
        logo.setVisibility(inputFormModel.getLogoVisibility());
        nameLayout.setVisibility(inputFormModel.getNameFieldVisibility());
        emailLayout.setVisibility(inputFormModel.getEmailFieldVisibility());
        messageLayout.setVisibility(inputFormModel.getMessageFieldVisibility());

        nameLayout.setEnabled(!inputFormModel.isLoading());
        emailLayout.setEnabled(!inputFormModel.isLoading());
        messageLayout.setEnabled(!inputFormModel.isLoading());

        if (inputFormModel.isLoading()) {
            setSendButtonEnabled(false);
        } else {
            View.OnClickListener logoClickListener = getLogoOnClickListener(inputFormModel);
            logo.setOnClickListener(logoClickListener);
            updateSendButton();
        }
    }

    @Nullable
    private static View.OnClickListener getLogoOnClickListener(@NonNull InputFormModel inputFormModel) {
        View.OnClickListener logoClickListener = null;
        if (inputFormModel.isLogoEnabled() && StringUtils.hasLength(inputFormModel.getReferrerUrl())) {
            logoClickListener = view -> {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(inputFormModel.getReferrerUrl()));
                view.getContext().startActivity(intent);
            };
        }
        return logoClickListener;
    }

    @Override
    public void onMenuItemsInflated(MenuItem send, MenuItem attachment) {
        this.sendButton = send;
        updateSendButton();
    }

    @Override
    public void onMenuItemsClicked(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.request_conversations_disabled_menu_ic_send) {
            onSendMessageRequested();
        }
    }


    StateSelector<InputFormModel> getSelector() {
        return new InputFormSelector();
    }

    void onSendMessageRequested() {

        if (doFieldsContainText() && isEmailInputValid()) {
            if (isNameFieldVisible() || isEmailFieldVisible()) {
                final String name = nameField.getText().toString();
                final String email = emailField.getText().toString();
                dispatcher.dispatch(actionFactory.updateNameEmailAsync(name, email));
            }

            final String message = messageField.getText().toString();
            final List<StateRequestAttachment> attachments = CollectionUtils.ensureEmpty(attachmentHelper
                    .getSelectedAttachments());
            dispatcher.dispatch(actionFactory.clearMessages());
            dispatcher.dispatch(actionFactory.createCommentAsync(message, attachments));

        } else {
            // The order is important!
            updateEmailValidation();
            updateSendButton();
        }
    }

    @SuppressWarnings("SimplifiableIfStatement")
    boolean hasUnsavedInput() {
        final String name = nameField.getText().toString();
        final String email = emailField.getText().toString();
        final String message = messageField.getText().toString();

        if (nameField.isEnabled() && StringUtils.hasLength(name)) {
            return true;
        }

        if (emailField.isEnabled() && StringUtils.hasLength(email)) {
            return true;
        }

        return StringUtils.hasLength(message) || CollectionUtils.isNotEmpty(attachmentHelper.getSelectedAttachments());
    }

    private boolean doFieldsContainText() {
        final String name = nameField.getText().toString();
        final String email = emailField.getText().toString();
        final String message = messageField.getText().toString();

        boolean nameValid = !isNameFieldVisible() || StringUtils.hasLength(name);
        boolean emailValid = !isEmailFieldVisible() || StringUtils.hasLength(email);
        boolean messageValid = StringUtils.hasLength(message);

        return nameValid && emailValid && messageValid;
    }

    private boolean isEmailInputValid() {
        final boolean isEmailFieldVisible = isEmailFieldVisible();
        final String email = emailField.getText().toString();

        return !isEmailFieldVisible || emailValidator.isValid(email);
    }

    private void updateSendButton() {
        final boolean isInputValid;
        if (inlineValidation) {
            isInputValid = doFieldsContainText() && isEmailInputValid();
        } else {
            isInputValid = doFieldsContainText();
        }

        setSendButtonEnabled(isInputValid);
    }

    private void updateEmailValidation() {
        if (isEmailInputValid()) {
            emailLayout.setError(null);
        } else {
            inlineValidation = true;
            emailLayout.setError(emailField.getContext().getString(R.string.error_msg_invalid_email));
        }
    }

    private void setSendButtonEnabled(boolean enabled) {
        if (sendButton != null) {
            final int sendButtonAlpha;
            if (enabled) {
                sendButtonAlpha = 255;
            } else {
                sendButtonAlpha = messageLayout.getContext().getResources()
                        .getInteger(R.integer.zs_request_menu_send_btn_alpha_inactive) * 255 / 100;
            }

            sendButton.getIcon().setAlpha(sendButtonAlpha);
            sendButton.setEnabled(enabled);
        }
    }

    private boolean isNameFieldVisible() {
        return nameLayout.getVisibility() == View.VISIBLE;
    }

    private boolean isEmailFieldVisible() {
        return emailLayout.getVisibility() == View.VISIBLE;
    }

    private static class EmailFieldFocusListener implements View.OnFocusChangeListener {

        static void install(ComponentInputForm componentInputForm, EditText editText) {
            editText.setOnFocusChangeListener(new EmailFieldFocusListener(componentInputForm, editText));
        }

        private final ComponentInputForm componentInputForm;
        private final EditText editText;

        private EmailFieldFocusListener(ComponentInputForm componentInputForm, EditText editText) {
            this.componentInputForm = componentInputForm;
            this.editText = editText;
        }

        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            // Only validate if the user leaves the field
            if (!hasFocus) {
                final String email = editText.getText().toString();
                // Only validate on focus change if text was entered
                if (StringUtils.hasLength(email)) {
                    // Mind the order!
                    componentInputForm.updateEmailValidation();
                    componentInputForm.updateSendButton();
                }
            }
        }
    }

    private static class EditTextTextWatcher implements TextWatcher {

        static void install(ComponentInputForm componentInputForm, EditText... editTexts) {
            for (EditText editText : editTexts) {
                editText.addTextChangedListener(new EditTextTextWatcher(componentInputForm));
            }
        }

        private final ComponentInputForm componentInputForm;

        private EditTextTextWatcher(ComponentInputForm componentInputForm) {
            this.componentInputForm = componentInputForm;
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            // If we started to do inline validation on the email field
            // do validation of the email field on every keystroke
            if (componentInputForm.inlineValidation) {
                componentInputForm.updateEmailValidation();
            }

            // Update the send button on each keystroke
            componentInputForm.updateSendButton();
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // intentionally empty
        }

        @Override
        public void afterTextChanged(Editable s) {
            // intentionally empty
        }
    }

    interface Validator<T> {
        boolean isValid(T input);
    }

    static class InputFormModel {

        private final boolean neverRequestEmail;
        private final boolean hasIdentityEmailAddress;
        private final boolean hasIdentityName;
        private final boolean isLoading;
        private final boolean showZendeskLogo;
        private final String referrerUrl;

        InputFormModel(boolean neverRequestEmail, boolean hasIdentityEmailAddress,
                       boolean hasIdentityName, boolean isLoading, boolean showZendeskLogo,
                       String referrerUrl) {
            this.neverRequestEmail = neverRequestEmail;
            this.hasIdentityEmailAddress = hasIdentityEmailAddress;
            this.hasIdentityName = hasIdentityName;
            this.isLoading = isLoading;
            this.showZendeskLogo = showZendeskLogo;
            this.referrerUrl = referrerUrl;
        }

        private boolean isEmailFieldEnabled() {
            return !hasIdentityEmailAddress && !neverRequestEmail;
        }

        private boolean isNameFieldEnabled() {
            return !hasIdentityName;
        }

        int getEmailFieldVisibility() {
            return isEmailFieldEnabled() ? View.VISIBLE : View.GONE;
        }

        int getNameFieldVisibility() {
            return isNameFieldEnabled() ? View.VISIBLE : View.GONE;
        }

        int getMessageFieldVisibility() {
            return View.VISIBLE;
        }

        int getLogoVisibility() {
            return isLogoEnabled() ? View.VISIBLE : View.GONE;
        }

        boolean isLogoEnabled() {
            return showZendeskLogo;
        }

        String getReferrerUrl() {
            return referrerUrl;
        }

        public boolean isLoading() {
            return isLoading;
        }
    }

    static class InputFormSelector implements StateSelector<InputFormModel> {

        @Nullable
        @Override
        public InputFormModel selectData(@NonNull State state) {
            final StateSettings settings = StateConfig.fromState(state).getSettings();
            final StateProgress progress = StateProgress.fomState(state);

            final boolean isLoading = progress.getRunningRequests() > 0;

            return new InputFormModel(
                    settings.isNeverRequestEmailOn(),
                    settings.hasIdentityEmailAddress(),
                    settings.hasIdentityName(),
                    isLoading,
                    settings.isShowZendeskLogo(),
                    settings.getReferrerUrl()
            );
        }
    }
}