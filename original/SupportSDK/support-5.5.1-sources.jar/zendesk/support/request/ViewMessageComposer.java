package zendesk.support.request;

import android.animation.AnimatorSet;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import androidx.annotation.NonNull;
import androidx.annotation.Px;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.interpolator.view.animation.FastOutSlowInInterpolator;
import androidx.interpolator.view.animation.LinearOutSlowInInterpolator;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.zendesk.logger.Logger;
import zendesk.support.R;
import com.zendesk.util.StringUtils;

import java.util.LinkedList;
import java.util.List;

import zendesk.support.UiUtils;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;
import static zendesk.support.request.UtilsAnimation.bottomPaddingAnimator;
import static zendesk.support.request.UtilsAnimation.minHeightAnimator;
import static zendesk.support.request.UtilsAnimation.sideMarginsAnimator;
import static zendesk.support.request.UtilsAnimation.topPaddingAnimator;
import static zendesk.support.request.ViewMessageComposer.MessageComposerState.BUTTON_ENABLED;
import static zendesk.support.request.ViewMessageComposer.MessageComposerState.BUTTON_HIDDEN;

/**
 * For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
class ViewMessageComposer extends FrameLayout
        implements View.OnClickListener, View.OnFocusChangeListener, View.OnLayoutChangeListener, TextView
        .OnEditorActionListener, TextWatcher {

    private static final String LOG_TAG = "ViewMessageComposer";

    private AnimatorSet attachmentsOnExpandAnimatorSet;
    private AnimatorSet attachmentsOnCollapseAnimatorSet;
    private AnimatorSet attachmentsOffExpandAnimatorSet;
    private AnimatorSet attachmentsOffCollapseAnimatorSet;
    private EditText inputTextField;
    private ImageView sendButton;
    private ViewAttachmentsIndicator attachmentsIndicator;

    private MessageComposerStateHelper stateHelper;

    private OnHeightChangeListener onHeightChangeListener;
    private List<OnFocusChangeListener> onFocusChangeListenerList = new LinkedList<>();
    private List<InputListener> inputListenerList = new LinkedList<>();

    private boolean isSendButtonDisabled = true;
    private boolean isAttachmentsButtonDisabled = true;

    public ViewMessageComposer(Context context) {
        super(context);
        viewInit(context);
    }

    public ViewMessageComposer(Context context, AttributeSet attrs) {
        super(context, attrs);
        viewInit(context);
    }

    public ViewMessageComposer(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        viewInit(context);
    }

    @SuppressWarnings("unused")
    public ViewMessageComposer(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        viewInit(context);
    }

    @VisibleForTesting
    ViewMessageComposer(Context context, ViewAttachmentsIndicator attachmentsIndicator, EditText editText,
                        ImageView sendButton, AnimatorSet attachmentsOnExpandAnimatorSet, AnimatorSet
                                attachmentsOnCollapseAnimatorSet,
                        AnimatorSet attachmentsOffExpandAnimatorSet, AnimatorSet attachmentsOffCollapseAnimatorSet) {
        super(context);
        this.attachmentsIndicator = attachmentsIndicator;
        this.inputTextField = editText;
        this.sendButton = sendButton;
        this.attachmentsOnExpandAnimatorSet = attachmentsOnExpandAnimatorSet;
        this.attachmentsOffExpandAnimatorSet = attachmentsOffExpandAnimatorSet;
        this.attachmentsOnCollapseAnimatorSet = attachmentsOnCollapseAnimatorSet;
        this.attachmentsOffCollapseAnimatorSet = attachmentsOffCollapseAnimatorSet;
        this.stateHelper = new MessageComposerStateHelper();
    }

    private void viewInit(Context context) {
        inflate(context, R.layout.zs_view_request_message_composer, this);

        if (isInEditMode()) {
            return;
        }

        bindViews();
        initListener();
        initAnimationsAndAdjustLeftMargin();
        stateHelper = new MessageComposerStateHelper();
    }

    @Override
    public boolean dispatchKeyEventPreIme(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            inputTextField.clearFocus();
        }
        return super.dispatchKeyEventPreIme(event);
    }

    /**
     * Sets a {@link OnHeightChangeListener} that will be called when height of this view changed.
     *
     * @param listener The listener that will be called when height of this view changed.
     */
    public void setOnHeightChangeListener(final OnHeightChangeListener listener) {
        this.onHeightChangeListener = listener;
    }

    /**
     * Adds a {@link android.view.View.OnFocusChangeListener} that will be called
     * when focus of this view changed and expand/collapse animation ended.
     *
     * @param listener The listener that will be called when focus of this view changed and expand/collapse animation
     *                 ended.
     */
    public void addOnFocusChangeListener(OnFocusChangeListener listener) {
        onFocusChangeListenerList.add(listener);
    }

    /**
     * Sets a {@link InputListener} that will be triggered when an attachments indicator is clicked
     * or the send button is pressed.
     *
     * @param inputListener The listener to be triggered.
     */
    public void addListener(InputListener inputListener) {
        this.inputListenerList.add(inputListener);
    }

    public void removeAllListener() {
        this.inputListenerList.clear();
    }

    /**
     * Sets the internal {@link ViewAttachmentsIndicator} to display the counter
     * with a number of attachments.
     *
     * @param attachmentsCount The number of attachments that the counter will display.
     */
    public void setAttachmentsCount(int attachmentsCount) {
        attachmentsIndicator.setAttachmentsCount(attachmentsCount);
        triggerStateUpdate();
    }

    public void init() {
        triggerStateUpdate();
    }

    public void hide(boolean hide) {
        if (hide) {
            setVisibility(View.GONE);
            onHeightChangeListener.onHeightChange(0);
        } else {
            setVisibility(View.VISIBLE);
            requestLayout();
        }
    }

    private void bindViews() {
        inputTextField = findViewById(R.id.message_composer_input_text);
        attachmentsIndicator = findViewById(R.id.message_composer_attachments_indicator);
        sendButton = findViewById(R.id.message_composer_send_btn);
    }

    private void initListener() {
        attachmentsIndicator.setOnClickListener(this);
        sendButton.setOnClickListener(this);
        inputTextField.addTextChangedListener(this);
        inputTextField.setOnEditorActionListener(this);
        inputTextField.setOnFocusChangeListener(this);
        addOnLayoutChangeListener(this);
    }

    private void initAnimationsAndAdjustLeftMargin() {
        final Resources r = getResources();

        int duration = r.getInteger(R.integer.zs_request_message_composer_animation_duration);

        // cache min height values
        int etMinHeightCollapsed = r.getDimensionPixelSize(R.dimen.zs_request_message_composer_collapsed_height);
        int etMinHeightExpanded = r.getDimensionPixelSize(R.dimen.zs_request_message_composer_expanded_min_height);

        // cache margin values
        int etSideMarginExpanded = r.getDimensionPixelSize(R.dimen.zs_request_message_composer_expanded_side_margin);
        int etSideMarginCollapsed = r.getDimensionPixelSize(R.dimen.zs_request_message_composer_collapsed_side_margin);
        int etTopPaddingExpanded = r.getDimensionPixelSize(R.dimen.zs_request_message_composer_expanded_top_padding);
        int etTopPaddingCollapsed = r.getDimensionPixelSize(R.dimen.zs_request_message_composer_collapsed_top_padding);

        int etBottomPaddingExpanded = r.getDimensionPixelOffset(R.dimen
                .zs_request_message_composer_expanded_bottom_padding);
        int etBottomPaddingCollapsed = 0;

        // configure animations
        attachmentsOnExpandAnimatorSet = new AnimatorSet();
        attachmentsOffExpandAnimatorSet = new AnimatorSet();
        attachmentsOnCollapseAnimatorSet = new AnimatorSet();
        attachmentsOffCollapseAnimatorSet = new AnimatorSet();

        // create & set interpolator
        TimeInterpolator linearOutSlowInInterpolator = new LinearOutSlowInInterpolator();
        TimeInterpolator fastOutSlowInInterpolator = new FastOutSlowInInterpolator();

        attachmentsOnExpandAnimatorSet.setInterpolator(linearOutSlowInInterpolator); // deceleration curve to grow
        attachmentsOffExpandAnimatorSet.setInterpolator(linearOutSlowInInterpolator); // deceleration curve to grow
        attachmentsOnCollapseAnimatorSet.setInterpolator(fastOutSlowInInterpolator); // standard curve to shrink
        attachmentsOffCollapseAnimatorSet.setInterpolator(fastOutSlowInInterpolator); // standard curve to shrink

        attachmentsOnExpandAnimatorSet
                .play(minHeightAnimator(inputTextField, etMinHeightCollapsed, etMinHeightExpanded, duration))
                .with(sideMarginsAnimator(inputTextField, etSideMarginCollapsed, etSideMarginExpanded, duration))
                .with(topPaddingAnimator(inputTextField, etTopPaddingCollapsed, etTopPaddingExpanded, duration))
                .with(bottomPaddingAnimator(inputTextField, etBottomPaddingCollapsed, etBottomPaddingExpanded,
                        duration));

        attachmentsOnCollapseAnimatorSet
                .play(sideMarginsAnimator(inputTextField, etSideMarginExpanded, etSideMarginCollapsed, duration))
                .with(topPaddingAnimator(inputTextField, etTopPaddingExpanded, etTopPaddingCollapsed, duration))
                .with(minHeightAnimator(inputTextField, etMinHeightExpanded, etMinHeightCollapsed, duration))
                .with(bottomPaddingAnimator(inputTextField, etBottomPaddingExpanded, etBottomPaddingCollapsed,
                        duration));

        attachmentsOffExpandAnimatorSet
                .play(minHeightAnimator(inputTextField, etMinHeightCollapsed, etMinHeightExpanded, duration))
                .with(sideMarginsAnimator(inputTextField, etSideMarginExpanded, etSideMarginExpanded, duration))
                .with(topPaddingAnimator(inputTextField, etTopPaddingCollapsed, etTopPaddingExpanded, duration))
                .with(bottomPaddingAnimator(inputTextField, etBottomPaddingCollapsed, etBottomPaddingExpanded,
                        duration));

        attachmentsOffCollapseAnimatorSet
                .play(sideMarginsAnimator(inputTextField, etSideMarginExpanded, etSideMarginExpanded, duration))
                .with(topPaddingAnimator(inputTextField, etTopPaddingExpanded, etTopPaddingCollapsed, duration))
                .with(minHeightAnimator(inputTextField, etMinHeightExpanded, etMinHeightCollapsed, duration))
                .with(bottomPaddingAnimator(inputTextField, etBottomPaddingExpanded, etBottomPaddingCollapsed,
                        duration));

        updateAttachmentButtonPosition();
    }

    private void updateAttachmentButtonPosition() {
        final Resources r = getResources();
        int etSideMarginExpanded = r.getDimensionPixelSize(R.dimen.zs_request_message_composer_expanded_side_margin);
        int etSideMarginCollapsed = r.getDimensionPixelSize(R.dimen.zs_request_message_composer_collapsed_side_margin);
        // update left margin
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) inputTextField.getLayoutParams();
        params.leftMargin = isAttachmentsButtonDisabled
                ? etSideMarginExpanded
                : etSideMarginCollapsed;
        inputTextField.setLayoutParams(params);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == attachmentsIndicator.getId()) {

            applyState(stateHelper.onAttachmentClicked(
                    isSendButtonDisabled,
                    isAttachmentsButtonDisabled,
                    inputTextField,
                    attachmentsIndicator)
            );
            notifyAddAttachmentsRequested();

        } else if (v.getId() == sendButton.getId()) {

            final String inputText = inputTextField.getText().toString().trim();
            inputTextField.setText(StringUtils.EMPTY_STRING);
            attachmentsIndicator.reset();
            triggerStateUpdate();

            notifySendMessageRequested(inputText);
        }
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if (v.getId() == inputTextField.getId()) {
            notifyOnFocusChangeListeners(v, hasFocus);
            triggerStateUpdate();
        }
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (v.getId() == inputTextField.getId() && actionId == EditorInfo.IME_ACTION_DONE) {
            inputTextField.clearFocus();
            UiUtils.dismissKeyboard(inputTextField);
            triggerStateUpdate();
        }
        return false;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        // Intentionally empty
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        // Intentionally empty
    }

    @Override
    public void afterTextChanged(Editable s) {
        triggerStateUpdate();
    }

    @Override
    public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int
            oldRight, int oldBottom) {
        final int currentHeight = bottom - top;
        final int previousHeight = oldBottom - oldTop;

        if (currentHeight != previousHeight && onHeightChangeListener != null) {
            onHeightChangeListener.onHeightChange(currentHeight);
        }
    }

    public void requestFocusForInput() {
        inputTextField.requestFocus();
    }

    public String getMessage() {
        return inputTextField.getText().toString();
    }

    void enableSendButton(boolean enable) {
        isSendButtonDisabled = !enable;
        triggerStateUpdate();
    }

    void enableAttachmentsButton(boolean enable) {
        isAttachmentsButtonDisabled = !enable;
        triggerStateUpdate();
    }

    void triggerStateUpdate() {
        final MessageComposerState state = stateHelper.getState(
                inputTextField,
                attachmentsIndicator,
                isSendButtonDisabled,
                isAttachmentsButtonDisabled);
        applyState(state);
    }

    private void applyState(MessageComposerState state) {
        if (RequestActivity.DEBUG) {
            Logger.d(LOG_TAG, "Apply State: %s", state.toString());
        }

        // collapse - expand
        if (state.getFieldState() == MessageComposerState.FIELD_EXPANDED && !isExpanded()) {
            if (isAttachmentsButtonDisabled) {
                attachmentsOffExpandAnimatorSet.start();
            } else {
                attachmentsOnExpandAnimatorSet.start();
            }
        } else if (state.getFieldState() == MessageComposerState.FIELD_COLLAPSED && isExpanded()) {
            if (isAttachmentsButtonDisabled) {
                attachmentsOffCollapseAnimatorSet.start();
            } else {
                attachmentsOnCollapseAnimatorSet.start();
            }
        }

        // send button
        if (state.getSendButtonState() == MessageComposerState.BUTTON_HIDDEN) {
            updateSendBtn(false, false);

        } else if (state.getSendButtonState() == MessageComposerState.BUTTON_DISABLED) {
            updateSendBtn(true, false);

        } else if (state.getSendButtonState() == MessageComposerState.BUTTON_ENABLED) {
            updateSendBtn(true, true);
        }

        // attachment button visibility
        int newAttachmentButtonVisibility = state.isAttachmentButtonEnabled() ? VISIBLE : GONE;
        if (attachmentsIndicator.getVisibility() != newAttachmentButtonVisibility) {
            updateAttachmentButtonPosition();
            attachmentsIndicator.setVisibility(newAttachmentButtonVisibility);
        }

        // attachment button state
        if (state.isAttachmentButtonEnabled() && attachmentsIndicator.getAttachmentsCount() == 0) {
            attachmentsIndicator.enableActiveState(state.isAttachmentButtonActivated());
            attachmentsIndicator.setBottomBorderVisible(state.isAttachmentButtonActivated());
        }
    }

    private boolean isExpanded() {
        int collapsedHeight = inputTextField.getResources()
                .getDimensionPixelSize(R.dimen.zs_request_message_composer_collapsed_height);
        return inputTextField.getHeight() > collapsedHeight;
    }

    private void updateSendBtn(boolean visible, boolean enabled) {
        final Context context = getContext();
        final int sendButtonColor;
        if (enabled) {
            sendButtonColor = UiUtils.themeAttributeToColor(R.attr.colorPrimary, context, R.color
                    .zs_request_fallback_color_primary);
        } else {
            sendButtonColor = UiUtils.resolveColor(R.color.zs_request_message_composer_send_btn_color_inactive,
                    context);
        }

        sendButton.setEnabled(visible && enabled);
        sendButton.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
        UiUtils.setTint(sendButtonColor, sendButton.getDrawable(), sendButton);
    }

    private void notifyOnFocusChangeListeners(View v, boolean hasFocus) {
        for (View.OnFocusChangeListener l : onFocusChangeListenerList) {
            l.onFocusChange(v, hasFocus);
        }
    }

    private void notifyAddAttachmentsRequested() {
        for (InputListener inputListener : inputListenerList) {
            inputListener.onAddAttachmentsRequested();
        }
    }

    private void notifySendMessageRequested(String message) {
        for (InputListener inputListener : inputListenerList) {
            inputListener.onSendMessageRequested(message);
        }
    }

    /**
     * Interface definition for a callback to be invoked when the height of a {@link ViewMessageComposer}
     * changes due to expand/collapse animation or multiline text input.
     */
    interface OnHeightChangeListener {
        /**
         * Called when the height of a {@link ViewMessageComposer}
         * changes due to expand/collapse animation or multiline text input.
         *
         * @param currentHeight The current height of the {@link ViewMessageComposer}
         */
        void onHeightChange(@Px int currentHeight);
    }

    interface InputListener {
        /**
         * Called when {@link ViewAttachmentsIndicator} view has been clicked.
         */
        void onAddAttachmentsRequested();

        /**
         * Called when the send button has been clicked and the message has passed the validation.
         *
         * @param message Validated input text.
         */
        void onSendMessageRequested(@NonNull String message);
    }

    static class MessageComposerState {

        static final int FIELD_EXPANDED = 1;
        static final int FIELD_COLLAPSED = 2;

        static final int BUTTON_HIDDEN = 10;
        static final int BUTTON_DISABLED = 11;
        static final int BUTTON_ENABLED = 12;

        private final int fieldState;
        private final int sendButtonState;
        private final int attachmentButtonState;

        MessageComposerState(int fieldState, int sendButtonState, int attachmentButtonState) {
            this.fieldState = fieldState;
            this.sendButtonState = sendButtonState;
            this.attachmentButtonState = attachmentButtonState;
        }

        int getFieldState() {
            return fieldState;
        }

        int getSendButtonState() {
            return sendButtonState;
        }

        boolean isAttachmentButtonEnabled() {
            return attachmentButtonState != BUTTON_HIDDEN;
        }

        boolean isAttachmentButtonActivated() {
            return attachmentButtonState == BUTTON_ENABLED;
        }

        @Override
        public String toString() {
            return "MessageComposerState{" +
                    "fieldState=" + fieldState +
                    ", sendButtonState=" + sendButtonState +
                    ", attachmentButtonEnabled=" + attachmentButtonState +
                    '}';
        }
    }

    static class MessageComposerStateHelper {

        MessageComposerStateHelper() {
            // intentionally empty
        }

        MessageComposerState onAttachmentClicked(boolean isSendButtonDisabled, boolean isAttachmentButtonDisabled,
                                                 EditText input, ViewAttachmentsIndicator
                                                         attachments) {

            final MessageComposerState state = getState(input, attachments, true,
                    isAttachmentButtonDisabled);

            final int sendButtonState;
            if (state.getSendButtonState() == BUTTON_HIDDEN) {
                sendButtonState = MessageComposerState.BUTTON_DISABLED;
            } else {
                sendButtonState = state.getSendButtonState();
            }

            final int attachmentButtonState = getAttachmentButtonState(isAttachmentButtonDisabled);

            return new MessageComposerState(MessageComposerState.FIELD_EXPANDED, sendButtonState,
                    attachmentButtonState);
        }

        MessageComposerState getState(EditText input, ViewAttachmentsIndicator attachments,
                                       boolean isSendButtonDisabled, boolean
                                              isAttachmentsButtonDisabled) {
            final String inputText = input.getText().toString();
            final boolean hasText = hasLength(inputText);
            final boolean hasValidText = hasValidText(inputText);
            final boolean hasFocus = input.hasFocus();

            final boolean hasAttachments = hasAttachments(attachments);

            final int fieldState = getFieldState(hasFocus, hasText, hasAttachments);
            final int sendButtonState = getSendButtonState(isSendButtonDisabled, hasValidText, hasAttachments,
                    fieldState);
            final int attachmentButtonState = getAttachmentButtonState(isAttachmentsButtonDisabled);

            return new MessageComposerState(fieldState, sendButtonState, attachmentButtonState);
        }

        @VisibleForTesting
        int getSendButtonState(boolean isSendButtonDisabled, boolean hasValidText, boolean hasAttachments, int
                fieldState) {

            if (hasValidText || (hasAttachments && !isSendButtonDisabled)) {
                return MessageComposerState.BUTTON_ENABLED;

            } else if (fieldState == MessageComposerState.FIELD_EXPANDED) {
                return MessageComposerState.BUTTON_DISABLED;

            } else if (fieldState == MessageComposerState.FIELD_COLLAPSED) {
                return BUTTON_HIDDEN;
            }

            return BUTTON_HIDDEN;
        }

        @VisibleForTesting
        int getAttachmentButtonState(boolean isAttachmentButtonDisabled) {
            if (isAttachmentButtonDisabled) {
                return BUTTON_HIDDEN;
            } else  {
                return BUTTON_ENABLED;
            }
        }

        @VisibleForTesting
        int getFieldState(boolean hasInputFocus, boolean hasText, boolean hasAttachments) {

            if (!hasInputFocus && !hasText && !hasAttachments) {
                return MessageComposerState.FIELD_COLLAPSED;
            }

            return MessageComposerState.FIELD_EXPANDED;
        }

        private boolean hasValidText(String inputText) {
            return StringUtils.hasLength(inputText);
        }

        private boolean hasLength(String inputText) {
            return inputText != null && inputText.length() > 0;
        }

        private boolean hasAttachments(ViewAttachmentsIndicator attachmentsIndicator) {
            return attachmentsIndicator.getAttachmentsCount() > 0;
        }
    }
}