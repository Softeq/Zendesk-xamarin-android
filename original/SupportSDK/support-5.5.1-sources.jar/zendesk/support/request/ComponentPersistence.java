package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;
import zendesk.support.BuildConfig;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

import zendesk.support.suas.Listener;
import zendesk.support.suas.State;
import zendesk.support.suas.StateSelector;
import zendesk.support.SupportUiStorage;

import static zendesk.support.request.RequestActivity.DEBUG;

/**
 * Headless components that is responsible for caching comments and ids on disk using {@link SupportUiStorage}.
 */
class ComponentPersistence implements Listener<ComponentPersistence.RequestPersistenceModel> {

    private static final String LOG_TAG = "ComponentPersistence";

    private final PersistenceQueue queue;
    private final PersistenceSelector persistenceSelector;
    private final SupportUiStorage supportUiStorage;
    private final Executor executor;

    private final AtomicBoolean isMappingComplete = new AtomicBoolean(false);

    ComponentPersistence(SupportUiStorage supportUiStorage, PersistenceQueue queue,
                         Executor executor) {
        this.supportUiStorage = supportUiStorage;
        this.persistenceSelector = new PersistenceSelector();
        this.queue = queue;
        this.executor = executor;
    }

    @Override
    public void update(@NonNull RequestPersistenceModel requestPersistenceModel) {
        persistConversation(requestPersistenceModel);
        persistRequestId(requestPersistenceModel);
    }

    private void persistConversation(RequestPersistenceModel requestPersistenceModel) {
        final boolean isActivityStopped = requestPersistenceModel.isActivityStopped();
        final boolean hasLocalId = StringUtils.hasLength(requestPersistenceModel.getLocalRequestId());
        final boolean hasAtLeasOneMessage = requestPersistenceModel.getConversation().getMessages().size() > 0;

        if (isActivityStopped && hasLocalId && hasAtLeasOneMessage) {
            if (RequestActivity.DEBUG) {
                Logger.d(LOG_TAG, "Writing conversation to disk");
            }
            queue.dispatch(new PersistenceItem(supportUiStorage, requestPersistenceModel));
        }
    }

    private void persistRequestId(final RequestPersistenceModel requestPersistenceModel) {
        if (!isMappingComplete.get()) {

            final String remoteId = requestPersistenceModel.getConversation().getRemoteId();
            final String localId = requestPersistenceModel.getConversation().getLocalId();

            final boolean hasMessages = requestPersistenceModel.getConversation().getMessages().size() > 0;
            final boolean mappingComplete = StringUtils.hasLength(remoteId) && StringUtils.hasLength(localId);

            if (mappingComplete || hasMessages) {

                if (mappingComplete) {
                    isMappingComplete.set(true);
                }

                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        RequestIdMapper requestIdMapper = supportUiStorage.read(SupportUiStorage.REQUEST_MAPPER,
                                ComponentPersistence.RequestIdMapper.class);

                        if (requestIdMapper == null) {
                            requestIdMapper = new RequestIdMapper();
                        }

                        if (mappingComplete) {
                            if (!requestIdMapper.hasLocalId(remoteId) || !requestIdMapper.hasRemoteId(localId)) {
                                if (DEBUG) {
                                    Logger.d(LOG_TAG, "Update mapping on disk. Mapping '%s' -> '%s'", remoteId,
                                            localId);
                                }
                                RequestIdMapper updatedMapper = requestIdMapper.addIdMapping(remoteId, localId);
                                supportUiStorage.write(SupportUiStorage.REQUEST_MAPPER, updatedMapper);
                            }
                        } else {
                            if (!requestIdMapper.hasRemoteId(localId)) {
                                if (DEBUG) {
                                    Logger.d(LOG_TAG, "Store local id on disk. Id '%s'", localId);
                                }
                                RequestIdMapper updatedMapper = requestIdMapper.addLocalId(localId);
                                supportUiStorage.write(SupportUiStorage.REQUEST_MAPPER, updatedMapper);
                            }
                        }
                    }
                });
            }
        } else {
            // remove local id from disk if conversation no longer contains any messages due to deletion of failed ones.
            if (CollectionUtils.isEmpty(requestPersistenceModel.getConversation().getMessages())) {
                executor.execute(new Runnable() {
                    @Override
                    public void run() {
                        RequestIdMapper requestIdMapper = supportUiStorage.read(SupportUiStorage.REQUEST_MAPPER,
                                ComponentPersistence.RequestIdMapper.class);
                        String localId = requestPersistenceModel.getLocalRequestId();

                        if (requestIdMapper != null) {
                            if (DEBUG) {
                                Logger.d(LOG_TAG, "Remove local id from disk. Id '%'", localId);
                            }

                            RequestIdMapper updatedMapper = requestIdMapper.removeLocalIdMapping(localId);
                            supportUiStorage.write(SupportUiStorage.REQUEST_MAPPER, updatedMapper);
                            isMappingComplete.set(false);
                        }
                    }
                });
            }
        }
    }

    StateSelector<RequestPersistenceModel> getSelector() {
        return persistenceSelector;
    }

    interface Item {
        void persist();
    }

    @VisibleForTesting
    static class PersistenceItem implements Item {

        private final SupportUiStorage supportUiStorage;
        private final RequestPersistenceModel model;

        PersistenceItem(SupportUiStorage supportUiStorage, RequestPersistenceModel model) {
            this.supportUiStorage = supportUiStorage;
            this.model = model;
        }

        @Override
        public void persist() {
            supportUiStorage.write(model.getLocalRequestId(), model);
        }
    }

    static class PersistenceQueue {

        private final List<Item> actions;

        private final AtomicBoolean workerRunning;
        private final Executor executor;

        public PersistenceQueue(Executor executor) {
            this.actions = new ArrayList<>(2);
            this.workerRunning = new AtomicBoolean(false);
            this.executor = executor;
        }

        void dispatch(Item action) {
            if (action != null) {
                synchronized (actions) {
                    if (actions.size() >= 2) {
                        actions.set(1, action);
                    } else {
                        actions.add(action);
                    }
                    startWorker();
                }
            }
        }

        private void startWorker() {
            if (workerRunning.compareAndSet(false, true)) {
                executor.execute(new Worker());
            }
        }

        private class Worker implements Runnable {
            @Override
            public void run() {
                while (true) {
                    final Item action;
                    synchronized (actions) {
                        if (actions.size() > 0) {
                            action = actions.get(0);
                        } else {
                            if (DEBUG) {
                                Logger.d(LOG_TAG, "PersistenceQueue empty. Going to sleep.");
                            }
                            workerRunning.set(false);
                            break;
                        }
                    }

                    if (action != null) {
                        try {
                            action.persist();
                        } catch (Exception e) {
                            if (DEBUG) {
                                Logger.w(RequestActivity.LOG_TAG, "Unable to cache item. Error: '%s'", e.getMessage());
                            }
                        } finally {
                            actions.remove(action);
                        }
                    }
                }
            }
        }
    }

    static class PersistenceSelector implements StateSelector<RequestPersistenceModel> {

        @Override
        public RequestPersistenceModel selectData(@NonNull State data) {
            final StateConversation conversation = StateConversation.fromState(data);
            final StateAndroidLifecycle androidLifeCycle = StateAndroidLifecycle.fromState(data);

            final boolean activityStopped = androidLifeCycle.getState() == StateAndroidLifecycle.STOPPED;

            return new RequestPersistenceModel(conversation.getLocalId(), new Date(), BuildConfig.VERSION_NAME,
                    conversation, activityStopped);
        }
    }

    static class RequestPersistenceModel {

        private final Date date;
        private final String version;
        private final StateConversation conversation;
        private final transient String requestId;
        private final transient boolean activityStopped;

        RequestPersistenceModel(String requestId, Date date, String version,
                                StateConversation conversation, boolean activityStopped) {
            this.requestId = requestId;
            this.date = date;
            this.version = version;
            this.conversation = conversation;
            this.activityStopped = activityStopped;
        }

        StateConversation getConversation() {
            return conversation;
        }

        String getLocalRequestId() {
            return requestId;
        }

        Date getDate() {
            return date;
        }

        String getVersion() {
            return version;
        }

        boolean isActivityStopped() {
            return activityStopped;
        }
    }

    static class RequestIdMapper {

        private final Map<String, String> localToRemote = new HashMap<>();
        private final Map<String, String> remoteToLocal = new HashMap<>();

        public RequestIdMapper() {
            // intentionally empty
        }

        boolean hasLocalId(@NonNull String remoteId) {
            return remoteToLocal.containsKey(remoteId) && StringUtils.hasLength(remoteToLocal.get(remoteId));
        }

        boolean hasRemoteId(@NonNull String localId) {
            return localToRemote.containsKey(localId) && StringUtils.hasLength(localToRemote.get(localId));
        }

        Set<String> getLocalIds() {
            return localToRemote.keySet();
        }

        String getRemoteId(String localId) {
            return localToRemote.get(localId);
        }

        String getLocalId(String remoteId) {
            return remoteToLocal.get(remoteId);
        }

        RequestIdMapper addIdMapping(String remoteId, String localId) {
            localToRemote.put(localId, remoteId);
            remoteToLocal.put(remoteId, localId);
            return this;
        }

        RequestIdMapper removeLocalIdMapping(String localId) {
            localToRemote.remove(localId);
            return this;
        }

        RequestIdMapper addLocalId(String localId) {
            localToRemote.put(localId, StringUtils.EMPTY_STRING);
            return this;
        }
    }
}