package zendesk.support.request;



import static zendesk.support.request.MediaResult.UNKNOWN_VALUE;
import static zendesk.support.request.UtilsAttachment.getAttachmentSubDir;
import static zendesk.support.request.UtilsAttachment.getCacheDirForRequestId;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.util.Pair;
import android.webkit.MimeTypeMap;

import androidx.annotation.NonNull;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import zendesk.core.MediaFileResolver;

/**
 * The MediaResultUtility offers a set of utility methods for managing {@link MediaResult}.
 * These include retrieving media information, copying files to cache, and resolving URIs to media results.
 */
class MediaResultUtility {
    private static final String MIME_TYPE_IMAGE = "image";
    static final String TEMPORARY_DIR = "tmp";
    static final String LOG_TAG = "MediaResultUtility";
    private final Context context;
    private final MediaFileResolver mediaFileResolver;

    MediaResultUtility(Context context, MediaFileResolver mediaFileResolver) {
       this.context = context;
       this.mediaFileResolver = mediaFileResolver;
    }

    MediaResult getLocalFile(String requestId, long attachmentId, String fileName) {
        return getMediaResultFromFile(getAttachmentSubDir(getCacheDirForRequestId(requestId), attachmentId), fileName);
    }

    MediaResult getFile(String subDirectory, long attachmentId, String fileName) {
        return getMediaResultFromFile(getAttachmentSubDir(subDirectory, attachmentId), fileName);
    }

    public MediaResult getMediaResultFromFile(@NonNull String dir, @NonNull String fileName) {
        final File file = mediaFileResolver.createCacheFile(dir, fileName);
        final Uri uri;
        if (file != null && (uri = mediaFileResolver.getFileProviderUri(context, file)) != null) {
            final MediaResult r = getMediaResultForUri(context, uri);

            final long width, height;
            if (r.getMimeType().contains(MIME_TYPE_IMAGE)) {
                final Pair<Integer, Integer> imageDimensions = mediaFileResolver.getImageDimensions(file);
                width = imageDimensions.first;
                height = imageDimensions.second;
            } else {
                width = MediaResult.UNKNOWN_VALUE;
                height = MediaResult.UNKNOWN_VALUE;
            }
            return new MediaResult(file, uri, uri, fileName, r.getMimeType(), r.getSize(), width, height);
        }

        return null;
    }

    public List<MediaResult> getListOfSelectedMedia(List<Uri> uris) {
        List<MediaResult> mediaResults = new ArrayList<>();
        if (!uris.isEmpty()) {
            for (Uri uri : uris) {
                MediaResult result = getMediaInfoFromUri(uri);
                mediaResults.add(result);
            }
        }
        return mediaResults;
    }

    public List<MediaResult> getListOfSelectedMedia(Uri uri) {
        List<MediaResult> mediaResults = new ArrayList<>();
        if (uri != null) {
            MediaResult result = getMediaInfoFromUri(uri);
            mediaResults.add(result);
        }
        return mediaResults;
    }

    public MediaResult getMediaInfoFromUri(Uri fileUri) {
        // Get ContentResolver instance
        ContentResolver contentResolver = context.getContentResolver();

        // Query the file
        Cursor cursor = contentResolver.query(fileUri, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Get the columns indices
            int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);

            // Fetch file name and size
            String fileName = cursor.getString(nameIndex);
            long fileSize = cursor.getLong(sizeIndex);

            // Get MIME type
            String fileMimeType = contentResolver.getType(fileUri);

            // If MIME type is null, try to determine it from the file extension
            if (fileMimeType == null) {
                String fileExtension = MimeTypeMap.getFileExtensionFromUrl(fileUri.toString());
                fileMimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension.toLowerCase());
            }

            // Close the cursor
            cursor.close();
            return new MediaResult(null, fileUri, fileUri, fileName, fileMimeType, fileSize, -1,-1);
        } else {
            System.out.println("Failed to retrieve file details.");
            return null;
        }
    }

    /**
     * Creates a URI to save a taken picture
     *
     * @return A URI representing the location where the picture will be saved.
     */
    Uri createUriToSaveTakenPicture() {
        return mediaFileResolver.createUriToSaveTakenPicture();
    }

    static MediaResult getMediaResultForUri(Context context, Uri uri) {
        final String schema = uri.getScheme();
        long size = UNKNOWN_VALUE;
        String name = "";
        String mimeType = "";

        if (ContentResolver.SCHEME_CONTENT.equals(schema)) {
            final String[] projection = {
                    MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.DISPLAY_NAME,
            };

            final ContentResolver contentResolver = context.getContentResolver();
            final Cursor cursor = contentResolver.query(uri, projection, null, null, null);

            mimeType = contentResolver.getType(uri);

            if (cursor != null) {
                try {

                    if (cursor.moveToFirst()) {
                        final int sizeIndex = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE);
                        final int nameIndex = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME);
                        if (sizeIndex != -1){
                            size = cursor.getLong(sizeIndex);
                        }

                        if (nameIndex != -1) {
                            name = cursor.getString(nameIndex);
                        }
                    }
                } finally {
                    cursor.close();
                }
            }
        }

        return new MediaResult(null, uri, uri, name, mimeType, size, UNKNOWN_VALUE, UNKNOWN_VALUE);
    }

    List<MediaResult> getResolvedUris(List<Uri> uris, String subDirectory) {
        List<MediaResult> success = new ArrayList<>();
        byte[] buf = new byte[1_048_576];
        InputStream inputStream = null;
        FileOutputStream fileOutputStream = null;

        for (Uri uri : uris) {
            try {
                inputStream = context.getContentResolver().openInputStream(uri);
                File file = mediaFileResolver.getFileForUri(uri, subDirectory);

                if (inputStream != null && file != null) {
                    Log.d(LOG_TAG, String.format(Locale.US, "Copying media file into private cache - Uri: %s - Dest: %s", uri, file));
                    fileOutputStream = new FileOutputStream(file);

                    int len;
                    while ((len = inputStream.read(buf)) > 0) {
                        fileOutputStream.write(buf, 0, len);
                    }

                    MediaResult r = getMediaResultForUri(context, uri);
                    success.add(new MediaResult(file, mediaFileResolver.getFileProviderUri(context, file), uri, file.getName(), r.getMimeType(), r.getSize(), r.getWidth(), r.getHeight()));
                } else {
                    // Log warnings if necessary
                }
            } catch (FileNotFoundException e) {
                Log.e(LOG_TAG, String.format(Locale.US, "File not found error copying file, uri: %s", uri), e);
            } catch (IOException e) {
                Log.e(LOG_TAG, String.format(Locale.US, "IO Error copying file, uri: %s", uri), e);
            } catch (IllegalStateException e) {
                Log.e(LOG_TAG, String.format(Locale.US, "The file is either partially downloaded or corrupted, uri: %s", uri), e);

            } finally {
                try {
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } catch (IOException e) {
                    Log.e(LOG_TAG, "Error closing InputStream", e);
                }
                try {
                    if (fileOutputStream != null) {
                        fileOutputStream.close();
                    }
                } catch (IOException e) {
                    Log.e(LOG_TAG, "Error closing FileOutputStream", e);
                }
            }
        }

        return success;
    }
}