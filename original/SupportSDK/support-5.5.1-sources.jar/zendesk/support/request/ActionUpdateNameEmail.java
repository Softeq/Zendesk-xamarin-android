package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.StringUtils;

import zendesk.core.AnonymousIdentity;
import zendesk.core.AuthenticationProvider;
import zendesk.core.Identity;
import zendesk.core.Zendesk;
import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.GetState;

/**
 * Update the identity in core with an email and name.
 */
class ActionUpdateNameEmail implements AsyncMiddleware.AsyncAction {

    private final String name;
    private final String email;
    private final AuthenticationProvider authenticationProvider;
    private final Zendesk zendesk;

    ActionUpdateNameEmail(@Nullable String name,
                          @Nullable String email,
                          @NonNull AuthenticationProvider authenticationProvider,
                          @NonNull Zendesk zendesk) {
        this.name = name;
        this.email = email;
        this.authenticationProvider = authenticationProvider;
        this.zendesk = zendesk;
    }

    @Override
    public void actionQueued(Dispatcher dispatcher, GetState state) {
        // Intentionally empty
    }

    @Override
    public void execute(Dispatcher dispatcher, GetState state, AsyncMiddleware.Callback callback) {
        Identity identity = authenticationProvider.getIdentity();

        if (identity instanceof AnonymousIdentity) {
            AnonymousIdentity anonymousIdentity = (AnonymousIdentity) identity;

            if (StringUtils.hasLength(email) && !email.equals(anonymousIdentity.getEmail())) {
                anonymousIdentity = (AnonymousIdentity) new AnonymousIdentity.Builder()
                        .withEmailIdentifier(email)
                        .withNameIdentifier(anonymousIdentity.getName())
                        .build();
            }

            if (StringUtils.hasLength(name) && !name.equals(anonymousIdentity.getName())) {
                anonymousIdentity = (AnonymousIdentity) new AnonymousIdentity.Builder()
                        .withEmailIdentifier(anonymousIdentity.getEmail())
                        .withNameIdentifier(name)
                        .build();
            }

            if (anonymousIdentity != identity) {
                zendesk.setIdentity(anonymousIdentity);
            }
        }

        callback.done();
    }
}