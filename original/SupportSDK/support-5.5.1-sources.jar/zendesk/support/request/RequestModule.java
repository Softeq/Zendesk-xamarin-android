package zendesk.support.request;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.RestrictTo;
import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;


import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

import javax.inject.Named;

import zendesk.commonui.PermissionsHandler;
import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.ActionHandlerRegistry;
import zendesk.core.AuthenticationProvider;
import zendesk.core.MediaFileResolver;
import zendesk.core.Zendesk;
import zendesk.support.ActivityScope;
import zendesk.support.BuildConfig;
import zendesk.support.RequestProvider;
import zendesk.support.SupportBlipsProvider;
import zendesk.support.SupportSettingsProvider;
import zendesk.support.SupportUiStorage;
import zendesk.support.UploadProvider;
import zendesk.support.requestlist.RequestInfoDataSource;

import dagger.Module;
import dagger.Provides;
import dagger.Reusable;
import okhttp3.OkHttpClient;
import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.Filters;
import zendesk.support.suas.Reducer;
import zendesk.support.suas.Store;
import zendesk.support.suas.Suas;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;
import static zendesk.support.SupportSdkComponent.SUPPORT_MAIN_THREAD_EXECUTOR;
import static zendesk.support.request.AttachmentDownloaderComponent.AttachmentDownloader;

/**
 * For Zendesk internal use only.
 */
@Module
@RestrictTo(LIBRARY)
public class RequestModule {

    private final Configuration configuration;
    private final Activity activity;

    RequestModule(Activity activity, Configuration configuration) {
        this.activity = activity;
        this.configuration = configuration;
    }


    @Provides
    @ActivityScope
    static ActionFactory providesActionFactory(RequestProvider requestProvider,
                                               SupportSettingsProvider settingsProvider,
                                               UploadProvider uploadProvider,
                                               SupportUiStorage supportUiStorage,
                                               ExecutorService executor,
                                               @Named(SUPPORT_MAIN_THREAD_EXECUTOR) Executor mainThreadExecutor,
                                               AuthenticationProvider authProvider,
                                               SupportBlipsProvider blipsProvider,
                                               MediaResultUtility mediaResultUtility,
                                               ResolveUri resolveUri) {
        return new ActionFactory(requestProvider, uploadProvider, settingsProvider,
                supportUiStorage, executor, BuildConfig.VERSION_NAME, authProvider, Zendesk.INSTANCE, blipsProvider,
                mainThreadExecutor, mediaResultUtility, resolveUri);
    }

    @Provides
    @ActivityScope
    static List<Reducer> providesReducer() {
        return Arrays.<Reducer>asList(
                new ReducerProgress(),
                new ReducerConfiguration(),
                new ReducerConversation(),
                new ReducerAttachments(),
                new ReducerAndroidLifecycle(),
                new ReducerUiState(),
                new ReducerError()
        );
    }

    @Provides
    @ActivityScope
    static AsyncMiddleware providesAsyncMiddleware() {
        final AsyncMiddleware.Queue queue = new AsyncMiddleware.Queue();
        return new AsyncMiddleware(queue);
    }

    @Provides
    @ActivityScope
    static Store providesStore(List<Reducer> reducers, AsyncMiddleware asyncMiddleware) {
        return Suas.createStore(reducers)
                .withMiddleware(asyncMiddleware)
                .withDefaultFilter(Filters.EQUALS)
                .build();
    }

    @Provides
    @ActivityScope
    static Dispatcher providesDispatcher(Store store) {
        return store;
    }


    @Provides
    @ActivityScope
    static AttachmentDownloadService providesAttachmentToDiskService(OkHttpClient okHttpClient, ExecutorService
            executor) {
        return new AttachmentDownloadService(okHttpClient, executor);
    }

    @Provides
    @ActivityScope
    static AttachmentDownloader providesAttachmentDownloader(AttachmentDownloadService attachmentToDiskService, MediaResultUtility mediaResultUtility) {
        return new AttachmentDownloader(attachmentToDiskService, mediaResultUtility);
    }

    @Provides
    @ActivityScope
    static AttachmentDownloaderComponent providesAttachmentDownloaderComponent(Dispatcher dispatcher,
                                                                               ActionFactory actionFactory,
                                                                               AttachmentDownloader
                                                                                       attachmentDownloader) {
        return new AttachmentDownloaderComponent(dispatcher, actionFactory, attachmentDownloader);
    }

    @Provides
    @ActivityScope
    static ComponentPersistence.PersistenceQueue providesDiskQueue(ExecutorService executorService) {
        return new ComponentPersistence.PersistenceQueue(executorService);
    }

    @Provides
    @ActivityScope
    static ComponentPersistence providesPersistenceComponent(SupportUiStorage supportUiStorage,
                                                             ComponentPersistence.PersistenceQueue queue,
                                                             ExecutorService executorService) {
        return new ComponentPersistence(supportUiStorage, queue, executorService);
    }

    @Provides
    @ActivityScope
    static HeadlessComponentListener providesComponentListener(ComponentPersistence persistence,
                                                               AttachmentDownloaderComponent attachmentDownloader,
                                                               ComponentUpdateActionHandlers updatesComponent) {
        return new HeadlessComponentListener(persistence, attachmentDownloader, updatesComponent);
    }

    @Provides
    @Reusable
    static ComponentUpdateActionHandlers providesConUpdatesComponent(Context context,
                                                                     ActionHandlerRegistry actionHandlerRegistry,
                                                                     RequestInfoDataSource.LocalDataSource dataSource) {
        return new ComponentUpdateActionHandlers(context, actionHandlerRegistry, dataSource);
    }

    @Provides
    @ActivityScope
    CellFactory providesMessageFactory(Context context, Picasso picasso, ActionFactory actionFactory,
                                       Dispatcher dispatcher, ActionHandlerRegistry registry,
                                       ConfigurationHelper configHelper,  MediaResultUtility mediaResultUtility) {
        return new CellFactory(context.getApplicationContext(),
                picasso,
                actionFactory,
                dispatcher,
                registry,
                configHelper,
                configuration,
                mediaResultUtility);
    }

    @Provides
    @ActivityScope
    MediaResultUtility provideMediaResultUtility(Context context, MediaFileResolver mediaFileResolver) {
        return new MediaResultUtility(context, mediaFileResolver);
    }

    @Provides
    @ActivityScope
    static ResolveUri providesResolveUriTask(
            MediaResultUtility mediaResultUtility,
            ExecutorService executor,
            @Named(SUPPORT_MAIN_THREAD_EXECUTOR) Executor mainThreadExecutor
    ){
        return new ResolveUri(mediaResultUtility, executor, mainThreadExecutor);
    }

    @Provides
    @ActivityScope
    PermissionsHandler permissionsHandler() {
        return new PermissionsHandler(activity);
    }

}