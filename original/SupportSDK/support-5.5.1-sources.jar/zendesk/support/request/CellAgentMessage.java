package zendesk.support.request;

import android.content.Context;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.TextView;

import zendesk.support.R;

/**
 * Cell in stream. Agent. Text message.
 */
class CellAgentMessage extends CellBase implements CellType.Message, CellType.Agent {

    private final CharSequence textMessage;
    private final StateMessage message;
    private final StateRequestUser user;
    private final Rect insets;
    private boolean showAgentName;

    CellAgentMessage(CellBindHelper utils, StateMessage message, CharSequence textMessage, StateRequestUser user) {
        super(utils, R.layout.zs_request_agent_message, message.getId(), message.getUserId(), message.getDate());
        this.textMessage = textMessage;
        this.message = message;
        this.user = user;
        this.insets = utils.getInsets(0, R.dimen.zs_request_message_inset_agent_top, 0, R.dimen
                .zs_request_message_inset_agent_bottom);
        this.showAgentName = false;
    }

    @Override
    public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
        final ViewRequestText agentMessage = view.findCachedView(R.id.request_agent_message_text);
        agentMessage.setText(textMessage);

        final TextView agentName = view.findCachedView(R.id.request_agent_name);
        utils.bindAgentName(agentName, showAgentName, user);

        // Talk Back
        final View container = view.findCachedView(R.id.request_agent_message_bubble);
        container.setContentDescription(buildTalkBackString(container.getContext()));
        agentMessage.requestLayout();
    }

    private String buildTalkBackString(Context context) {
        final StringBuilder talkBack = new StringBuilder();
        talkBack.append(context.getString(R.string.zs_request_message_agent_text_accessibility, textMessage));
        talkBack.append(" ");

        final CharSequence dateString = DateUtils.getRelativeTimeSpanString(context, message.getDate().getTime(), true);
        talkBack.append(context.getString(R.string.zs_request_message_agent_sent_accessibility, dateString, user
                .getName()));

        return talkBack.toString();
    }

    @Override
    public boolean areContentsTheSame(CellType.Base agentMessage) {
        boolean msg = utils.areMessageContentsTheSame(this, agentMessage);
        boolean agent = utils.areAgentCellContentsTheSame(this, agentMessage);

        return msg && agent;
    }

    @Override
    public CharSequence getMessage() {
        return message.getBody();
    }

    @Override
    public Rect getInsets() {
        return insets;
    }

    @Override
    public void showAgentName(boolean visible) {
        this.showAgentName = visible;
    }

    @Override
    public boolean isAgentNameVisible() {
        return showAgentName;
    }

    @Override
    public StateRequestUser getAgent() {
        return user;
    }
}
