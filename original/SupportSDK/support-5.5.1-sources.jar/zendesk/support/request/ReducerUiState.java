package zendesk.support.request;

import androidx.annotation.NonNull;

import java.util.List;

import zendesk.support.suas.Action;
import zendesk.support.suas.Reducer;

import static zendesk.support.request.ActionFactory.DIALOG_DISMISSED;
import static zendesk.support.request.ActionFactory.SHOW_RETRY_DIALOG;

class ReducerUiState extends Reducer<StateUi> {

    @Override
    public StateUi reduce(@NonNull StateUi oldState, @NonNull Action<?> action) {
        switch (action.getActionType()) {
            case SHOW_RETRY_DIALOG: {
                List<StateMessage> messages = action.getData();
                return oldState.setDialogState(new StateRetryDialog(messages));
            }
            case DIALOG_DISMISSED: {
                return oldState.setDialogState(null);
            }
        }

        return null;
    }

    @NonNull
    @Override
    public StateUi getInitialState() {
        return new StateUi();
    }
}
