package zendesk.support.request;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.JsonElement;
import com.squareup.picasso.Picasso;
import com.zendesk.logger.Logger;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import zendesk.commonui.BottomSheetAttachmentAction;
import zendesk.commonui.BottomSheetAttachmentViewMenu;
import zendesk.commonui.InsetType;
import zendesk.commonui.PermissionsHandler;
import zendesk.commonui.PhotoPickerLifecycleObserver;
import zendesk.commonui.PhotoPickerSelectionCallback;
import zendesk.commonui.SystemWindowInsets;
import zendesk.configurations.ConfigurationUtil;
import zendesk.core.ActionDescription;
import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.support.Constants;
import zendesk.support.R;
import zendesk.support.SdkDependencyProvider;
import zendesk.support.suas.CombinedSubscription;
import zendesk.support.suas.State;
import zendesk.support.suas.Store;
import zendesk.support.suas.Subscription;

/**
 * This Activity is the main entry point for showing and creating requests.
 * <p>
 * This Activity is designed to be started with the {@link #builder()}
 * </p>
 */
public class RequestActivity extends AppCompatActivity implements PhotoPickerSelectionCallback {

    static final boolean DEBUG = false;

    /**
     * Create a new builder for RequestActivity.
     */
    public static RequestConfiguration.Builder builder() {
        return new RequestConfiguration.Builder();
    }

    static final String LOG_TAG = "RequestActivity";
    private static final String SAVED_STATE = "saved_state";
    private static final String INPUT_URI = "INPUT_URI";
    private static final String[] INPUT_DOCUMENT_MIME_TYPES = new String[]{"*/*"};
    private static final int REQUEST_CAMERA_PERMISSION = 1001;

    private RequestComponent requestComponent;
    private RequestAccessibilityHerald accessibilityHerald;

    private ComponentRequestRouter requestRouter;

    private Subscription subscription;

    private RefreshRequestActionHandler refreshActionHandler;

    private Uri inputUri;

    @Inject
    Store store;
    @Inject
    ActionFactory actionFactory;
    @Inject
    HeadlessComponentListener headlessComponentListener;
    @Inject
    Picasso picasso;
    @Inject
    ActionHandlerRegistry actionHandlerRegistry;

    @Inject
    MediaResultUtility mediaResultUtility;

    @Inject
    PermissionsHandler permissionsHandler;

    private PhotoPickerLifecycleObserver photoPickerVisualMedia;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState != null) {
            inputUri = savedInstanceState.getParcelable(INPUT_URI);
        }

        getTheme().applyStyle(R.style.ZendeskActivityDefaultTheme, true);
        setContentView(R.layout.zs_activity_request);
        photoPickerVisualMedia = createPhotoPickerResultLauncher();
        getLifecycle().addObserver(photoPickerVisualMedia);
        initViews();
        if (!SdkDependencyProvider.INSTANCE.isInitialized()) {
            Logger.e(LOG_TAG, SdkDependencyProvider.NOT_INITIALIZED_LOG);
            finish();
            return;
        }

        // Load Config
        @SuppressLint("RestrictedApi") final RequestConfiguration requestUiConfig =
                ConfigurationUtil.fromBundle(getIntent().getExtras(), RequestConfiguration.class);
        if (requestUiConfig == null) {
            Logger.e(LOG_TAG, "No configuration found. Please use RequestActivity.builder()");
            finish();
            return;
        }

        refreshActionHandler = new RefreshRequestActionHandler(requestUiConfig.getRequestId());

        // Inject dependencies and restore state
        final boolean isCleanStart = initializeStoreAndDependencies(savedInstanceState, requestUiConfig);

        // Load initial data
        if (isCleanStart) {
            headlessComponentListener.startListening(store);

            // Install configuration
            store.dispatch(actionFactory.installStartConfigAsync(requestUiConfig));

            // Load settings
            store.dispatch(actionFactory.loadSettingsAsync());
        }

        subscription = bindComponents(isCleanStart);
    }


    private PhotoPickerLifecycleObserver createPhotoPickerResultLauncher() {
        return new PhotoPickerLifecycleObserver(
                this.getActivityResultRegistry(),
                this /*PhotoPickerSelectionCallback*/,
                () -> inputUri
        );
    }

    private BottomSheetAttachmentViewMenu createBottomSheetAttachmentMenu() {
        return new BottomSheetAttachmentViewMenu(
                this,/*Context*/
                Arrays.asList(
                        getString(R.string.zui_label_camera_menu),
                        getString(R.string.zui_label_gallery_menu),
                        getString(R.string.zui_label_document_menu)
                ),
                createBottomSheetAttachmentActionCallback()
        );
    }

    private BottomSheetAttachmentAction createBottomSheetAttachmentActionCallback() {
        return new BottomSheetAttachmentAction() {
            @Override
            public void onTakePhotoClicked() {
                inputUri = mediaResultUtility.createUriToSaveTakenPicture();
                if (permissionsHandler.checkPermission(Manifest.permission.CAMERA)) {
                    photoPickerVisualMedia.takePicture(inputUri);
                } else {
                    permissionsHandler.requestPermission(Manifest.permission.CAMERA, REQUEST_CAMERA_PERMISSION);
                }
            }

            @Override
            public void onSelectMediaClicked() {
                photoPickerVisualMedia.selectMedia();
            }

            @Override
            public void onSelectDocumentClicked() {
                photoPickerVisualMedia.selectDocument(INPUT_DOCUMENT_MIME_TYPES);
            }
        };
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                photoPickerVisualMedia.takePicture(inputUri);
            } else {
                Snackbar.make(findViewById(R.id.activity_request_root), zendesk.classic.messaging.R.string.zui_camera_permission_denied, Snackbar.LENGTH_LONG)
                        .setAction(getString(zendesk.classic.messaging.R.string.zui_camera_permission_denied_settings), v -> {
                            // Open app settings
                            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            startActivity(intent);
                        })
                        .show();
            }
        }
    }

    @Override
    public void onMediaSelected(@NonNull List<Uri> uris) {
        List<MediaResult> selectedMediaResult = mediaResultUtility.getListOfSelectedMedia(uris);
        store.dispatch(actionFactory.selectAttachment(selectedMediaResult));
    }

    @Override
    public void onPhotoTaken(@NonNull Uri inputUriPhotoTaken) {
        List<MediaResult> selectedMediaResult = mediaResultUtility.getListOfSelectedMedia(inputUriPhotoTaken);
        store.dispatch(actionFactory.selectAttachment(selectedMediaResult));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        final RequestView currentScreen = requestRouter.getCurrentScreen();
        return currentScreen != null && currentScreen.inflateMenu(getMenuInflater(), menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        final RequestView currentScreen = requestRouter.getCurrentScreen();
        if (currentScreen != null) {
            return currentScreen.onOptionsItemClicked(item);
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        store.dispatch(actionFactory.androidOnResume());
        subscription.addListener();
        subscription.informWithCurrentState();
        actionHandlerRegistry.add(refreshActionHandler);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (store != null) {
            store.dispatch(actionFactory.androidOnPause());
        }
        if (subscription != null) {
            subscription.removeListener();
        }
        if (actionHandlerRegistry != null) {
            actionHandlerRegistry.remove(refreshActionHandler);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        getLifecycle().removeObserver(photoPickerVisualMedia);
    }

    @Override
    public void onBackPressed() {
        RequestView requestView = requestRouter.getCurrentScreen();
        if (requestView != null && requestView.hasUnsavedInput()) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.request_dialog_title_unsaved_changes)
                    .setMessage(R.string.request_dialog_body_unsaved_changes)
                    .setPositiveButton(R.string.request_dialog_button_label_delete, new DialogInterface
                            .OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            RequestActivity.super.onBackPressed();
                        }
                    })
                    .setNegativeButton(R.string.request_dialog_button_label_cancel, new DialogInterface
                            .OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                        }
                    }).show();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putSerializable(SAVED_STATE, store.getState());
        outState.putParcelable(INPUT_URI, inputUri);
        super.onSaveInstanceState(outState);
    }

    private Subscription bindComponents(boolean isCleanStart) {
        ComponentToolbar toolbarComponent = bindToolbar();
        ComponentError errorComponent = ComponentError.create(this, store, actionFactory);
        requestRouter = ComponentRequestRouter.create(this, isCleanStart, requestComponent, createBottomSheetAttachmentMenu());
        accessibilityHerald = RequestAccessibilityHerald.create(this);

        Subscription toolbar = store.addListener(toolbarComponent.getToolbarSelector(), toolbarComponent);
        Subscription router = store.addListener(requestRouter.getSelector(), requestRouter);
        Subscription error = store.addListener(ComponentError.getSelector(), errorComponent);
        Subscription accessibility = store.addActionListener(accessibilityHerald);

        return CombinedSubscription.from(toolbar, router, error, accessibility);
    }

    private boolean initializeStoreAndDependencies(Bundle savedInstanceState, RequestConfiguration requestUiConfig) {
        final boolean componentRestored = injectDependencies(requestUiConfig);
        boolean isCleanStart = false;

        if (!componentRestored) {
            final State restoredState = restoreState(savedInstanceState);
            if (restoredState != null) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Restore state from savedInstanceState.");
                }
                store.reset(restoredState);
            } else {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "No state restored. Creating an empty state.");
                }
                isCleanStart = true;
            }
        }

        return isCleanStart;
    }

    private State restoreState(Bundle savedInstanceState) {
        final State state;
        if (savedInstanceState != null && savedInstanceState.containsKey(SAVED_STATE)) {
            if (DEBUG) {
                Logger.d(LOG_TAG, "Get state from savedState");
            }
            state = (State) savedInstanceState.getSerializable(SAVED_STATE);
        } else {
            if (DEBUG) {
                Logger.d(LOG_TAG, "Create new state");
            }
            state = null;
        }
        return state;
    }

    private boolean injectDependencies(RequestConfiguration requestUiConfig) {
        requestComponent = HeadlessFragment.getData(getSupportFragmentManager());
        boolean componentRestored = true;

        if (requestComponent == null) {
            if (DEBUG) {
                Logger.d(LOG_TAG, "Creating new ZendeskSdkComponent");
            }
            componentRestored = false;

            requestComponent = SdkDependencyProvider.INSTANCE
                    .provideSupportSdkComponent()
                    .plus(new RequestModule(this, requestUiConfig));

            HeadlessFragment.install(getSupportFragmentManager(), requestComponent);
        }

        requestComponent.inject(this);
        return componentRestored;
    }

    @SuppressLint("PrivateResource")
    private ComponentToolbar bindToolbar() {
        View appbar = findViewById(R.id.activity_request_appbar);
        Toolbar toolbar = findViewById(R.id.activity_request_toolbar);
        SystemWindowInsets.applyWindowInsets(appbar, InsetType.TOP);
        SystemWindowInsets.applyWindowInsets(toolbar, InsetType.HORIZONTAL);

        ViewAlmostRealProgressBar progressbar = findViewById(R.id.activity_request_progressbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        View toolbarShadow = findViewById(R.id.activity_request_compat_toolbar_shadow);
        toolbarShadow.setVisibility(View.GONE);

        return new ComponentToolbar(picasso, toolbar, progressbar);
    }

    private void initViews() {
        final View viewContainer = findViewById(R.id.activity_request_root);
        SystemWindowInsets.applyWindowInsets(viewContainer, InsetType.HORIZONTAL, InsetType.BOTTOM);
        final CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) viewContainer.getLayoutParams();
        params.setBehavior(new MoveUpWithSnackbarBehaviour());
    }

    /**
     * This class defines the behavior of a View in a CoordinatorLayout so a Snackbar can push it up
     */
    static class MoveUpWithSnackbarBehaviour extends AppBarLayout.ScrollingViewBehavior {

        @Override
        public boolean layoutDependsOn(CoordinatorLayout parent, View child, View dependency) {
            return super.layoutDependsOn(parent, child, dependency) || dependency instanceof Snackbar.SnackbarLayout;
        }

        @Override
        public boolean onDependentViewChanged(CoordinatorLayout parent, View child, View dependency) {
            final boolean viewChanged = super.onDependentViewChanged(parent, child, dependency);

            if (dependency instanceof Snackbar.SnackbarLayout) {
                final int translationY = (int) Math.abs(Math.min(0,
                        dependency.getTranslationY() - dependency.getHeight()));
                child.setPadding(child.getPaddingLeft(), child.getPaddingTop(), child.getPaddingRight(), translationY);
                return true;
            }

            return viewChanged;
        }
    }

    private final class RefreshRequestActionHandler implements ActionHandler {

        private final String requestId;

        RefreshRequestActionHandler(String requestId) {
            this.requestId = requestId;
        }

        @Override
        public boolean canHandle(String s) {
            return s.contains(Constants.ACTION_REFRESH_REQUEST_CONVERSATION) && s.contains(requestId);
        }

        @Override
        public void handle(@Nullable Map<String, Object> map, @NonNull Context context) {
            store.dispatch(actionFactory.updateCommentsAsync());
        }

        @Override
        public int getPriority() {
            return 0;
        }

        @Override
        public ActionDescription getActionDescription() {
            return null;
        }

        @Override
        public void updateSettings(Map<String, JsonElement> settings) {
            // Intentionally empty
        }
    }
}
