package zendesk.support.request;

import java.io.Serializable;

import zendesk.support.suas.State;

/**
 * Root state data. Holding android lifecycle information.
 */
class StateAndroidLifecycle implements Serializable {

    static StateAndroidLifecycle fromState(State state) {
        final StateAndroidLifecycle lifeCycle = state.getState(StateAndroidLifecycle.class);
        if (lifeCycle != null) {
            return lifeCycle;
        } else {
            return new StateAndroidLifecycle();
        }
    }

    public static final int STARTED = 1;
    public static final int STOPPED = 2;

    private final int state;

    public StateAndroidLifecycle() {
        this.state = STARTED;
    }

    public StateAndroidLifecycle(int state) {
        this.state = state;
    }

    public int getState() {
        return state;
    }

    @Override
    public String toString() {
        return "AndroidLifeCycle{" +
                "state=" + state +
                '}';
    }
}
