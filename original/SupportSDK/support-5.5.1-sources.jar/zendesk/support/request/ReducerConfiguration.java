package zendesk.support.request;

import androidx.annotation.NonNull;

import zendesk.support.suas.Action;
import zendesk.support.suas.Reducer;

/**
 * Reducer for handling that configuration.
 */
class ReducerConfiguration extends Reducer<StateConfig> {

    @Override
    public StateConfig reduce(@NonNull StateConfig oldState, @NonNull Action<?> action) {

        switch (action.getActionType()) {
            case ActionFactory.START_CONFIG: {
                final RequestConfiguration config = action.getData();

                return oldState.newBuilder()
                        .setTags(config.getTags())
                        .setTicketForm(config.getTicketForm())
                        .setSubject(config.getRequestSubject())
                        .build();
            }

            case ActionFactory.LOAD_SETTINGS_SUCCESS: {
                final StateSettings data = action.getData();

                return oldState.newBuilder()
                        .setSettings(data)
                        .build();
            }
        }

        return null;
    }

    @NonNull
    @Override
    public StateConfig getInitialState() {
        return new StateConfig();
    }
}
