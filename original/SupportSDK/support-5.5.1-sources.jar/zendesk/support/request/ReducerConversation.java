package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.core.util.Pair;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import zendesk.support.suas.Action;
import zendesk.support.suas.Reducer;
import zendesk.support.CommentResponse;
import zendesk.support.CommentsResponse;
import zendesk.support.Request;
import zendesk.support.RequestStatus;

/**
 * Reducer for maintaining a list of messages (= conversation).
 */
class ReducerConversation extends Reducer<StateConversation> {

    @Override
    public StateConversation reduce(@NonNull StateConversation oldState, @NonNull Action<?> action) {
        switch (action.getActionType()) {

            case ActionFactory.START_CONFIG: {
                final RequestConfiguration startConfig = action.getData();

                return oldState
                        .newBuilder()
                        .setLocalId(startConfig.getLocalRequestId())
                        .setRemoteId(startConfig.getRequestId())
                        .setStatus(startConfig.getRequestStatus())
                        .setHasAgentReplies(startConfig.hasAgentReplies())
                        .build();
            }

            case ActionFactory.LOAD_COMMENTS_INITIAL_SUCCESS:
            case ActionFactory.LOAD_COMMENTS_UPDATE_SUCCESS: {
                final Pair<CommentsResponse, Map<Long, MediaResult>> data = action.getData();

                final List<CommentResponse> comments = data.first.getComments();
                Collections.reverse(comments);
                final Map<Long, MediaResult> localAttachments = data.second;

                final Pair<Map<Long, StateRequestAttachment>, StateIdMapper> mappedAttachments =
                        StateRequestAttachment.convert(comments, localAttachments, oldState.getAttachmentIdMapper());
                final Pair<List<StateMessage>, StateIdMapper> mappedMessages = StateMessage.convert(comments,
                        oldState.getMessageIdMapper(), mappedAttachments.first);
                final List<StateMessage> mergedMessages = StateMessageMergeUtil.mergeMessages(oldState.getMessages(),
                        mappedMessages.first);
                final List<StateRequestUser> requestUsers = StateRequestUser.convert(data.first.getUsers());

                return oldState
                        .newBuilder()
                        .setMessages(mergedMessages)
                        .setAttachmentIdMapper(mappedAttachments.second.copy())
                        .setMessageIdMapper(mappedMessages.second.copy())
                        .setUsers(StateMessageMergeUtil.mergeUsers(oldState.getUsers(), requestUsers))
                        .build();
            }

            case ActionFactory.LOAD_COMMENTS_FROM_CACHE_SUCCESS: {
                StateConversation conversation = action.getData();

                return oldState.newBuilder()
                        .setMessages(conversation.getMessages())
                        .setAttachmentIdMapper(conversation.getAttachmentIdMapper())
                        .setMessageIdMapper(conversation.getMessageIdMapper())
                        .setUsers(conversation.getUsers())
                        .build();
            }

            case ActionFactory.CREATE_REQUEST:
            case ActionFactory.CREATE_COMMENT: {
                final StateConversation.Builder newState = oldState.newBuilder();
                final StateMessage message = action.getData();

                final List<StateMessage> messages = CollectionUtils.copyOf(oldState.getMessages());
                messages.add(message);

                return newState.setMessages(messages).build();
            }

            case ActionFactory.CREATE_REQUEST_ERROR:
            case ActionFactory.CREATE_COMMENT_ERROR: {
                final StateMessage message = action.getData();
                final List<StateMessage> m = StateMessageMergeUtil.mergeMessages(oldState.getMessages(), Collections
                        .singletonList(message));

                return oldState.newBuilder().setMessages(m).build();
            }

            case ActionFactory.CREATE_COMMENT_SUCCESS:
            case ActionFactory.CREATE_REQUEST_SUCCESS: {
                final ActionCreateComment.CreateCommentResult commentResult = action.getData();

                final StateIdMapper messageIdMapper = oldState.getMessageIdMapper()
                        .addIdMapping(commentResult.getCommentRemoteId(), commentResult.getMessage().getId());

                StateIdMapper attachmentIdMapper = oldState.getAttachmentIdMapper();
                for (Map.Entry<Long, Long> entry : commentResult.getLocalToRemoteAttachments().getLocalToRemoteIdMap()
                        .entrySet()) {
                    attachmentIdMapper = attachmentIdMapper.addIdMapping(entry.getValue(), entry.getKey());
                }

                final List<StateMessage> m = StateMessageMergeUtil.mergeMessages(oldState.getMessages(), Collections
                        .singletonList(commentResult.getMessage()));

                return oldState
                        .newBuilder()
                        .setRemoteId(commentResult.getRequestId())
                        .setMessageIdMapper(messageIdMapper)
                        .setAttachmentIdMapper(attachmentIdMapper)
                        .setMessages(m)
                        .build();
            }

            case ActionFactory.DELETE_MESSAGE: {
                final StateMessage message = action.getData();

                final List<StateMessage> newList = StateMessageMergeUtil.removeMessageById(message.getId(), oldState
                        .getMessages());

                return oldState.newBuilder()
                        .setMessages(newList)
                        .build();
            }

            case ActionFactory.ATTACHMENT_DOWNLOADED: {
                final Pair<StateRequestAttachment, MediaResult> p = action.getData();
                final StateRequestAttachment requestAttachment = p.first;
                final MediaResult mediaResult = p.second;
                final StateRequestAttachment updatedRequestAttachment = requestAttachment.newBuilder()
                        .setLocalFile(mediaResult.getFile())
                        .setLocalUri(mediaResult.getUri().toString())
                        .build();

                final List<StateMessage> messages = oldState.getMessages();
                final List<StateMessage> updatedMessages = new ArrayList<>(messages.size());
                for (StateMessage m : messages) {
                    updatedMessages.add(m.withUpdatedAttachment(updatedRequestAttachment));
                }

                return oldState.newBuilder().setMessages(updatedMessages).build();
            }

            case ActionFactory.LOAD_REQUEST_SUCCESS: {
                final Request request = action.getData();

                return oldState.newBuilder()
                        .setStatus(request.getStatus())
                        .setHasAgentReplies(CollectionUtils.isNotEmpty(request.getLastCommentingAgents()))
                        .build();
            }

            case ActionFactory.REQUEST_CLOSED: {
                return oldState.newBuilder()
                        .setStatus(RequestStatus.Closed)
                        .build();
            }

            case ActionFactory.CLEAR_MESSAGES: {
                return oldState.newBuilder()
                        .setMessages(Collections.<StateMessage>emptyList())
                        .setMessageIdMapper(new StateIdMapper())
                        .setAttachmentIdMapper(new StateIdMapper())
                        .build();
            }

        }

        return null;
    }

    @NonNull
    @Override
    public StateConversation getInitialState() {
        return new StateConversation();
    }
}