package zendesk.support.request;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.transition.Fade;
import androidx.transition.TransitionManager;
import androidx.core.util.Pair;
import androidx.appcompat.widget.Toolbar;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import zendesk.support.R;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import zendesk.support.suas.Listener;
import zendesk.support.suas.State;
import zendesk.support.suas.StateSelector;

/**
 * Component representing the Toolbar and its content.
 */
class ComponentToolbar implements Listener<ComponentToolbar.ToolbarModel> {

    private final ToolbarSelector toolbarSelector;

    private final Context context;
    private final Picasso picasso;
    private final Toolbar toolbar;
    private final ViewAlmostRealProgressBar progressBar;
    private final ViewToolbarAvatar avatarContainer;

    private final View container;
    private final TextView title;
    private final TextView subTitle;

    private final Fade fadeTransition = new Fade();

    private ToolbarModel toolbarModel;


    ComponentToolbar(Picasso picasso, Toolbar toolbar, ViewAlmostRealProgressBar progressBar) {
        this.picasso = picasso;
        this.progressBar = progressBar;
        this.toolbar = toolbar;
        this.context = toolbar.getContext();
        this.toolbarSelector = new ToolbarSelector();
        this.container = toolbar.findViewById(R.id.activity_request_toolbar_container);
        this.title = toolbar.findViewById(R.id.activity_request_toolbar_custom_title);
        this.subTitle = toolbar.findViewById(R.id.activity_request_toolbar_custom_sub_title);
        this.avatarContainer = toolbar.findViewById(R.id.activity_request_toolbar_avatar_holder);
    }

    @Override
    public void update(@NonNull ToolbarModel toolbarModel) {
        if (!toolbarModel.equals(this.toolbarModel)) {
            this.toolbarModel = toolbarModel;
            updateProgressBar(toolbarModel.isProgressEnabled());
            updateToolbar(toolbarModel);
        }
    }

    ToolbarSelector getToolbarSelector() {
        return toolbarSelector;
    }

    private void updateToolbar(ToolbarModel toolbarModel) {
        if (toolbarModel.getToolbarContentState() == ToolbarModel.STATE_LOADING) {
            container.setVisibility(View.GONE);
            toolbar.setTitle(StringUtils.EMPTY_STRING);

        } else if (toolbarModel.getToolbarContentState() == ToolbarModel.STATE_AGENT_INFO) {

            // Agent name
            title.setText(toolbarModel.getNameOfFirstAgent());

            // Timestamp
            final CharSequence dateString =
                    DateUtils.getRelativeTimeSpanString(context, toolbarModel.getLastReply().getTime(), true);
            subTitle.setText(context.getString(R.string.request_toolbar_last_reply, dateString));
            toolbar.setTitle(StringUtils.EMPTY_STRING);

            // Avatars
            avatarContainer.setImageUrls(picasso, toolbarModel.getAvatarUrls());

            // Make it visible
            TransitionManager.beginDelayedTransition(toolbar, fadeTransition);
            container.setVisibility(View.VISIBLE);

            // Talk back
            final String talkBack = container.getContext().getString(R.string.zs_request_toolbar_accessibility,
                    toolbarModel.getNameOfFirstAgent(), dateString);
            container.setContentDescription(talkBack);

        } else if (toolbarModel.getToolbarContentState() == ToolbarModel.STATE_TITLE) {
            container.setVisibility(View.GONE);
            toolbar.setTitle(R.string.request_activity_title);
        }
    }

    private void updateProgressBar(boolean isEnabled) {
        if (isEnabled) {
            progressBar.start(ViewAlmostRealProgressBar.DONT_STOP_MOVING);
        } else {
            progressBar.stop(ViewAlmostRealProgressBar.STOP_ANIMATION_DURATION);
        }
    }

    static class ToolbarModel {

        static int STATE_LOADING = 1;
        static int STATE_TITLE = 2;
        static int STATE_AGENT_INFO = 3;

        private final boolean isProgressEnabled;

        private final int toolbarContentState;
        private final List<StateRequestUser> agent;
        private final Date lastReply;

        ToolbarModel(boolean isProgressEnabled, int toolbarContentState, List<StateRequestUser> agent, Date lastReply) {
            this.isProgressEnabled = isProgressEnabled;
            this.toolbarContentState = toolbarContentState;
            this.agent = agent;
            this.lastReply = lastReply;
        }

        List<StateRequestUser> getAgents() {
            return agent;
        }

        Date getLastReply() {
            return lastReply;
        }

        boolean isProgressEnabled() {
            return isProgressEnabled;
        }

        int getToolbarContentState() {
            return toolbarContentState;
        }

        List<Pair<String, String>> getAvatarUrls() {
            final List<Pair<String, String>> urls = new ArrayList<>();
            for (StateRequestUser user : agent) {
                urls.add(Pair.create(user.getAvatar(), user.getName()));
            }
            return urls;
        }

        String getNameOfFirstAgent() {
            if (CollectionUtils.isNotEmpty(agent)) {
                return agent.get(0).getName();
            } else {
                return StringUtils.EMPTY_STRING;
            }
        }

        @SuppressWarnings("SimplifiableIfStatement")
        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            ToolbarModel that = (ToolbarModel) o;

            if (isProgressEnabled != that.isProgressEnabled) {
                return false;
            }
            if (toolbarContentState != that.toolbarContentState) {
                return false;
            }
            if (agent != null ? !agent.equals(that.agent) : that.agent != null) {
                return false;
            }
            return lastReply != null ? lastReply.equals(that.lastReply) : that.lastReply == null;
        }

        @Override
        public int hashCode() {
            int result = (isProgressEnabled ? 1 : 0);
            result = 31 * result + toolbarContentState;
            result = 31 * result + (agent != null ? agent.hashCode() : 0);
            result = 31 * result + (lastReply != null ? lastReply.hashCode() : 0);
            return result;
        }
    }

    static class ToolbarSelector implements StateSelector<ToolbarModel> {

        @Nullable
        @Override
        public ToolbarModel selectData(@NonNull State state) {
            final boolean isProgressEnabled = isProgressEnabled(state);

            final StateConversation con = StateConversation.fromState(state);
            final Map<Long, StateRequestUser> agentMap = mapAgents(con.getUsers());

            final List<StateRequestUser> lastAgents = new ArrayList<>();
            Date lastReply = null;

            int toolbarState;

            // Nothing is initialised, not even ids are set, show empty toolbar
            if (!StringUtils.hasLength(con.getLocalId()) && !StringUtils.hasLength(con.getRemoteId())) {
                toolbarState = ToolbarModel.STATE_LOADING;

                // The passed-in request indicates that there are agent replies, but we haven't gathered
                // the actual users and comments, show empty toolbar
            } else if (con.hasAgentReplies() && agentMap.size() == 0) {
                toolbarState = ToolbarModel.STATE_LOADING;

                // There's a list of commenting agents, show agent info in toolbar
            } else if (con.hasAgentReplies() && agentMap.size() > 0) {
                toolbarState = ToolbarModel.STATE_AGENT_INFO;

                final StateMessage lastAgentMessage = findLastAgentReply(con.getMessages(), agentMap);
                if (lastAgentMessage != null) {
                    lastReply = lastAgentMessage.getDate();
                }

                lastAgents.addAll(getInvolvedAgents(con.getMessages(), agentMap));

                // No agent replies, show default title
            } else {
                toolbarState = ToolbarModel.STATE_TITLE;

            }

            return new ToolbarModel(isProgressEnabled, toolbarState, lastAgents, lastReply);
        }

        private boolean isProgressEnabled(State state) {
            final StateProgress progress = StateProgress.fomState(state);
            return progress.getRunningRequests() > 0;
        }

        private List<StateRequestUser> getInvolvedAgents(List<StateMessage> messages, Map<Long, StateRequestUser>
                agentMap) {
            final Set<StateRequestUser> users = new LinkedHashSet<>();
            for (int i = messages.size() - 1; i >= 0; i--) {
                final StateMessage stateMessage = messages.get(i);
                if (agentMap.containsKey(stateMessage.getUserId())) {
                    users.add(agentMap.get(stateMessage.getUserId()));
                }
            }

            return new ArrayList<>(users);
        }

        private StateMessage findLastAgentReply(List<StateMessage> messages, Map<Long, StateRequestUser> agentMap) {
            for (int i = messages.size() - 1; i >= 0; i--) {
                final StateMessage stateMessage = messages.get(i);
                if (agentMap.containsKey(stateMessage.getUserId())) {
                    return stateMessage;
                }
            }

            return null;
        }

        @SuppressLint("UseSparseArrays")
        private Map<Long, StateRequestUser> mapAgents(List<StateRequestUser> userList) {
            final Map<Long, StateRequestUser> agentMap = new HashMap<>();

            for (StateRequestUser u : userList) {
                if (u.isAgent()) {
                    agentMap.put(u.getId(), u);
                }
            }

            return agentMap;
        }
    }
}
