package zendesk.support.request;

import static zendesk.support.request.MediaResultUtility.TEMPORARY_DIR;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.view.animation.PathInterpolatorCompat;
import com.squareup.picasso.Picasso;
import zendesk.support.R;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import zendesk.support.suas.Dispatcher;

/**
 * Helper class for binding date to descendants of {@link CellBase}
 */
@SuppressWarnings("SimplifiableIfStatement")
class CellBindHelper {

    private final Context context;

    private final CellAttachmentLoadingUtil attachmentUtil;

    private final ActionFactory af;
    private final Dispatcher dispatcher;

    private final String today;
    private final String yesterday;

    private final MediaResultUtility mediaResultUtility;

    CellBindHelper(Context context, Picasso picasso, ActionFactory af, Dispatcher dispatcher, MediaResultUtility mediaResultUtility) {
        this.context = context;
        this.af = af;
        this.dispatcher = dispatcher;
        this.attachmentUtil = new CellAttachmentLoadingUtil(picasso, context);
        this.today = context.getString(R.string.request_message_date_today);
        this.yesterday = context.getString(R.string.request_message_date_yesterday);
        this.mediaResultUtility = mediaResultUtility;
    }

    void addOnClickListenerForFileAttachment(final View view, final StateRequestAttachment requestAttachment) {
        if (requestAttachment.isAvailableLocally()) {
            view.setAlpha(1.0f);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openAttachment(view.getContext(), requestAttachment);
                }
            });
        } else {
            final float alpha =
                    context.getResources().getInteger(R.integer.zs_request_file_attachment_downloading_cell_alpha)
                            / 100.0f;
            view.setAlpha(alpha);
            view.setOnClickListener(new View.OnClickListener() {

                private final String toastMessage = context.getString(R.string
                        .request_file_attachment_download_in_progress);

                @Override
                public void onClick(View view) {
                    Toast.makeText(view.getContext(), toastMessage, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    void addOnClickListenerForImageAttachment(final View view, final StateRequestAttachment requestAttachment) {
        if (requestAttachment.isAvailableLocally()) {
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openAttachment(view.getContext(), requestAttachment);
                }
            });
        } else {
            view.setOnClickListener(null);
        }
    }

    private void openAttachment(Context context, StateRequestAttachment requestAttachment) {
        final Intent intent = getViewIntent(requestAttachment.getParsedLocalUri(), requestAttachment.getMimeType());
        final PackageManager manager = context.getPackageManager();
        if (manager.queryIntentActivities(intent, 0).size() > 0) {
            context.startActivity(intent);
        }
    }

    @NonNull
    public Intent getViewIntent(@NonNull Uri uri, @Nullable String contentType) {
        final Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        if (!TextUtils.isEmpty(contentType)) {
            intent.setDataAndType(uri, contentType);
        }
        grantPermissionsForUri(intent, uri);
        return intent;
    }

    public void grantPermissionsForUri(@NonNull Intent intent, @NonNull Uri uri) {
        int permissions = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            intent.addFlags(permissions);
        } else {
            List<ResolveInfo> resInfoList = context.getPackageManager().queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
            for (ResolveInfo resolveInfo : resInfoList) {
                String packageName = resolveInfo.activityInfo.packageName;
                context.grantUriPermission(packageName, uri, permissions);
            }
        }
    }

    ResolveInfo getAppInfo(String fileName) {
        return UtilsAttachment.getAppInfoForFile(context, mediaResultUtility.getMediaResultFromFile(TEMPORARY_DIR, fileName));
    }

    void bindAppInfo(ResolveInfo appInfo, TextView label, ImageView icon) {
        label.setText(UtilsAttachment.getAppName(context, appInfo));
        icon.setImageDrawable(UtilsAttachment.getAppIcon(context, appInfo));
    }

    void bindStatusLabel(TextView textView, boolean isError, boolean delivered) {
        final int visibility;
        final int textId;
        final int colorId;

        if (isError) {
            visibility = View.VISIBLE;
            colorId = R.color.zs_request_cell_label_color_error;
            textId = R.string.request_messages_status_error;

        } else if (delivered) {
            visibility = View.VISIBLE;
            colorId = R.color.zs_request_cell_label_color;
            textId = R.string.request_message_status_delivered;

        } else {
            visibility = View.INVISIBLE;
            textId = -1;
            colorId = -1;
        }

        if (colorId > 0) {
            textView.setTextColor(ContextCompat.getColor(context, colorId));
        }

        if (textId > 0) {
            textView.setText(textId);
        }

        textView.clearAnimation();

        if (visibility == View.VISIBLE && visibility != textView.getVisibility()) {
            final AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
            fadeIn.setDuration(250L);
            fadeIn.setInterpolator(PathInterpolatorCompat.create(0f, 0f, 0.2f, 1f));
            textView.startAnimation(fadeIn);
        }

        textView.setVisibility(visibility);
    }

    void bindAgentName(TextView label, boolean visible, StateRequestUser user) {
        if (visible) {
            label.setVisibility(View.VISIBLE);
            label.setText(user.getName());
        } else {
            label.setVisibility(View.INVISIBLE);
        }
    }

    int colorForError(boolean isError) {
        final int colorId;
        if (isError) {
            colorId = R.color.zs_request_user_background_color_error;
        } else {
            colorId = R.color.zs_request_user_background_color;
        }
        return ContextCompat.getColor(context, colorId);
    }

    int colorForErrorImage(boolean isError) {
        if (isError) {
            return ContextCompat.getColor(context, R.color.zs_request_user_background_image_color_error);
        } else {
            return Color.TRANSPARENT;
        }
    }

    View.OnClickListener errorClickListener(boolean showError, final List<StateMessage> messages) {
        if (showError) {
            return new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dispatcher.dispatch(af.showRetryDialog(messages));
                }
            };
        } else {
            return null;
        }
    }

    void bindImage(final ImageView imageView, final StateRequestAttachment requestAttachment) {
        attachmentUtil.bindImage(imageView, requestAttachment);
    }

    boolean areMessageContentsTheSame(CellType.Message c1, CellType.Base c2) {
        if (!basicCellChecks(c1, c2)) {
            return false;
        }

        if (!(c2 instanceof CellType.Message)) {
            return false;
        }

        return c1.getMessage().equals(((CellType.Message) c2).getMessage());
    }

    boolean areStatefulCellContentsTheSame(CellType.Stateful s1, CellType.Base b2) {
        if (!basicCellChecks(s1, b2)) {
            return false;
        }

        if (!(b2 instanceof CellType.Stateful)) {
            return false;
        }

        final CellType.Stateful s2 = (CellType.Stateful) b2;

        final boolean errorStateEquals = s1.isErrorShown() == s2.isErrorShown();
        final boolean deliveredStateEquals = s1.isMarkedAsDelivered() == s2.isMarkedAsDelivered();
        final boolean errorMessages = s1.getErrorGroupMessages().size() == s2.getErrorGroupMessages().size();
        final boolean lastCellOfBlock = s1.isLastErrorCellOfBlock() == s2.isLastErrorCellOfBlock();

        return errorStateEquals && deliveredStateEquals && errorMessages && lastCellOfBlock;
    }

    boolean areAttachmentCellContentsTheSame(CellType.Attachment c1, CellType.Base c2) {

        if (!basicCellChecks(c1, c2)) {
            return false;
        }

        if (!(c2 instanceof CellType.Attachment)) {
            return false;
        }

        final StateRequestAttachment a1 = c1.getAttachment();
        final StateRequestAttachment a2 = ((CellType.Attachment) c2).getAttachment();

        final boolean file = nullSafeEquals(a1.getLocalFile(), a2.getLocalFile());
        final boolean uri = nullSafeEquals(a1.getLocalUri(), a2.getLocalUri());
        final boolean url = nullSafeEquals(a1.getUrl(), a2.getUrl());

        return file && uri && url;
    }

    boolean areAgentCellContentsTheSame(CellType.Agent c1, CellType.Base c2) {

        if (!basicCellChecks(c1, c2)) {
            return false;
        }

        if (!(c2 instanceof CellType.Agent)) {
            return false;
        }

        final boolean userId = c1.getAgent().getId() == ((CellType.Agent) c2).getAgent().getId();
        final boolean userName = c1.getAgent().getName().equals(((CellType.Agent) c2).getAgent().getName());
        final boolean agentNameVisible = c1.isAgentNameVisible() == ((CellType.Agent) c2).isAgentNameVisible();

        return userId && userName && agentNameVisible;
    }

    private boolean basicCellChecks(CellType.Base c1, CellType.Base c2) {
        if (c1 == c2) {
            return true;
        }

        if (c1.getPositionType() != c2.getPositionType()) {
            return false;
        }
        //noinspection RedundantIfStatement
        if (!c1.getClass().isInstance(c2)) {
            return false;
        }

        return true;
    }

    private boolean nullSafeEquals(Object o1, Object o2) {
        if (o1 == o2) {
            return true;
        }
        if (o1 == null || o2 == null) {
            return false;
        }
        return o1.equals(o2);
    }

    void bindDate(TextView textView, Date timeStamp) {
        final String label;
        if (UtilsDate.isToday(timeStamp)) {
            label = today;
        } else if (UtilsDate.isYesterday(timeStamp)) {
            label = yesterday;
        } else {
            SimpleDateFormat dateFormat = new SimpleDateFormat("d MMMM yyyy", Locale.getDefault());
            label = dateFormat.format(timeStamp);
        }
        textView.setText(label.toUpperCase(Locale.getDefault()));
    }

    Rect getInsets(int idLeft, int idTop, int idRight, int idBottom) {
        return new Rect(
                getPixelForDp(idLeft),
                getPixelForDp(idTop),
                getPixelForDp(idRight),
                getPixelForDp(idBottom)
        );
    }

    private int getPixelForDp(int resId) {
        final int size;
        if (resId != 0) {
            size = context.getResources().getDimensionPixelOffset(resId);
        } else {
            size = 0;
        }
        return size;
    }
}
