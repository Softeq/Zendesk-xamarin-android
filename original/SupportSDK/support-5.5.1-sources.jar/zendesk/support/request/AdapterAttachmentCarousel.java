package zendesk.support.request;

import static zendesk.support.request.MediaResultUtility.TEMPORARY_DIR;

import android.content.Context;
import android.content.pm.ResolveInfo;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import zendesk.support.R;

import java.util.Collections;
import java.util.List;

import zendesk.support.suas.Dispatcher;

/**
 * RecyclerView adapter for the horizontal attachment list in the conversation off screen.
 */
class AdapterAttachmentCarousel extends RecyclerView.Adapter<AdapterAttachmentCarousel.CarouselViewHolder> {

    private static final int FILE_ATTACHMENT = 1;
    private static final int IMAGE_ATTACHMENT = 2;

    private final AttachmentHelper attachmentHelper;
    private final Picasso picasso;
    private final Dispatcher dispatcher;
    private final ActionFactory af;
    private final MediaResultUtility mediaResultUtility;

    AdapterAttachmentCarousel(AttachmentHelper attachmentHelper, Picasso picasso,
                              ActionFactory af, Dispatcher dispatcher, MediaResultUtility mediaResultUtility) {
        this.attachmentHelper = attachmentHelper;
        this.picasso = picasso;
        this.af = af;
        this.dispatcher = dispatcher;
        this.mediaResultUtility = mediaResultUtility;
        this.setHasStableIds(true);
    }

    @Override
    public CarouselViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        final LayoutInflater li = LayoutInflater.from(parent.getContext());
        switch (viewType) {
            case FILE_ATTACHMENT: {
                return new FileAttachmentViewHolder(li, parent, mediaResultUtility);
            }

            case IMAGE_ATTACHMENT: {
                return new ImageAttachmentViewHolder(li, parent, picasso);
            }

            default: {
                return null;
            }
        }
    }

    @Override
    public void onBindViewHolder(CarouselViewHolder holder, int position) {
        holder.bind(attachmentHelper.getSelectedAttachments().get(position), removeListener);
    }

    @Override
    public int getItemCount() {
        return attachmentHelper.getSelectedAttachments().size();
    }

    @Override
    public long getItemId(int position) {
        return attachmentHelper.getSelectedAttachments().get(position).getLocalUri().hashCode();
    }

    @Override
    public int getItemViewType(int position) {
        final StateRequestAttachment attachment = attachmentHelper.getSelectedAttachments().get(position);
        if (UtilsAttachment.isImageAttachment(attachment)) {
            return IMAGE_ATTACHMENT;
        } else {
            return FILE_ATTACHMENT;
        }
    }

    private final CarouselViewHolder.OnRemoveListener removeListener = new CarouselViewHolder.OnRemoveListener() {
        @Override
        public void onRemove(StateRequestAttachment attachment) {
            final List<MediaResult> mediaResults =
                    Collections.singletonList(StateRequestAttachment.convert(attachment));
            dispatcher.dispatch(af.deselectAttachment(mediaResults));
        }
    };

    abstract static class CarouselViewHolder extends RecyclerView.ViewHolder {

        CarouselViewHolder(View view) {
            super(view);
        }

        abstract void bind(StateRequestAttachment requestAttachment, OnRemoveListener onRemoveListener);

        interface OnRemoveListener {
            void onRemove(StateRequestAttachment attachment);
        }
    }

    static class FileAttachmentViewHolder extends CarouselViewHolder {

        private final TextView name;
        private final TextView appName;
        private final ImageView appIcon;
        private final View remove;
        private final View container;
        private final MediaResultUtility mediaResultUtility;

        FileAttachmentViewHolder(LayoutInflater li, ViewGroup parent, MediaResultUtility mediaResultUtility) {
            super(li.inflate(R.layout.zs_request_carousel_file, parent, false));
            this.name = itemView.findViewById(R.id.request_attachment_carousel_file_title);
            this.appIcon = itemView.findViewById(R.id.request_attachment_carousel_file_icon);
            this.appName = itemView.findViewById(R.id.request_attachment_carousel_file_app_name);
            this.remove = itemView.findViewById(R.id.request_attachment_carousel_remove);
            this.container = itemView.findViewById(R.id.request_attachment_file_carousel_container);
            this.mediaResultUtility = mediaResultUtility;
        }

        @Override
        void bind(final StateRequestAttachment requestAttachment, final OnRemoveListener onRemoveListener) {
            final Context context = itemView.getContext();
            final ResolveInfo info = UtilsAttachment.getAppInfoForFile(
                    context,
                    mediaResultUtility.getMediaResultFromFile(TEMPORARY_DIR, requestAttachment.getName())
            );
            appIcon.setImageDrawable(UtilsAttachment.getAppIcon(context, info));
            appName.setText(UtilsAttachment.getAppName(context, info));
            name.setText(requestAttachment.getName());

            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onRemoveListener.onRemove(requestAttachment);
                }
            });

            // talk back
            remove.setContentDescription(context.getString(R.string
                    .zs_request_attachment_carousel_remove_attachment_accessibility, requestAttachment.getName()));
            container.setContentDescription(context.getString(R.string
                    .zs_request_attachment_carousel_attachment_accessibility, requestAttachment.getName()));
        }
    }

    static class ImageAttachmentViewHolder extends CarouselViewHolder {

        private final ImageView imageView;
        private final View remove;
        private final View container;
        private final Picasso picasso;

        ImageAttachmentViewHolder(LayoutInflater li, ViewGroup parent, Picasso picasso) {
            super(li.inflate(R.layout.zs_request_carousel_image, parent, false));
            this.imageView = itemView.findViewById(R.id.request_attachment_carousel_image);
            this.remove = itemView.findViewById(R.id.request_attachment_carousel_remove);
            this.container = itemView.findViewById(R.id.request_attachment_image_carousel_container);
            this.picasso = picasso;
        }

        @Override
        void bind(final StateRequestAttachment requestAttachment, final OnRemoveListener onRemoveListener) {
            picasso.load(requestAttachment.getParsedLocalUri())
                    .fit()
                    .centerCrop()
                    .into(imageView);

            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onRemoveListener.onRemove(requestAttachment);
                }
            });

            // talk back
            final Context context = itemView.getContext();
            remove.setContentDescription(context.getString(R.string
                    .zs_request_attachment_carousel_remove_attachment_accessibility, requestAttachment.getName()));
            container.setContentDescription(context.getString(R.string
                    .zs_request_attachment_carousel_attachment_accessibility, requestAttachment.getName()));
        }
    }
}
