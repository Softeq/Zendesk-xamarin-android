package zendesk.support.request;

import android.annotation.SuppressLint;
import android.net.Uri;

import androidx.annotation.NonNull;
import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ErrorResponseAdapter;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zendesk.core.Callback;
import zendesk.support.Attachment;
import zendesk.support.UploadProvider;
import zendesk.support.UploadResponse;

/**
 * Service for uploading multiple attachments at once to Zendesk.
 */
class AttachmentUploadService {

    private final Object lock = new Object();

    private final UploadProvider uploadProvider;
    private final List<StateRequestAttachment> itemsForUpload;
    private String subDirectory;
    private ZendeskCallback<AttachmentUploadResult> resultListener;
    private final List<StateRequestAttachment> processedItems;
    private final List<StateRequestAttachment> errorItems;
    private final Map<Long, Long> localToRemoteMap;

    private final ResolveUri resolveUri;
    private final MediaResultUtility mediaResultUtility;

    @SuppressLint("UseSparseArrays")
    AttachmentUploadService(
            UploadProvider uploadProvider,
            List<StateRequestAttachment> itemsForUpload,
            MediaResultUtility mediaResultUtility,
            ResolveUri resolveUri

    ) {
        this.uploadProvider = uploadProvider;
        this.itemsForUpload = itemsForUpload;
        this.subDirectory = UtilsAttachment.getTemporaryRequestCacheDir();
        this.processedItems = new ArrayList<>(itemsForUpload.size());
        this.errorItems = new ArrayList<>(itemsForUpload.size());
        this.localToRemoteMap = new HashMap<>();
        this.resolveUri = resolveUri;
        this.mediaResultUtility = mediaResultUtility;
    }

    void start(String requestId) {

        if (StringUtils.hasLength(requestId)) {
            this.subDirectory = UtilsAttachment.getCacheDirForRequestId(requestId);
        }

        Logger.d(RequestActivity.LOG_TAG, "Start uploading attachments");
        for (StateRequestAttachment requestAttachment : itemsForUpload) {
            uploadAttachment(requestAttachment);
        }
    }

    void setResultListener(ZendeskCallback<AttachmentUploadResult> listener) {
        this.resultListener = listener;
        notifyIfFinished();
    }

    private void uploadAttachment(final StateRequestAttachment requestAttachment) {
        final Uri uri = requestAttachment.getParsedLocalUri();
        if (uri != null && !isUploadFinished()) {
            final ResolveCallback resolveCallback = new ResolveCallback(requestAttachment);
            resolveUris(
                    Collections.singletonList(uri),
                    subDirectory,
                    resolveCallback);
        } else {
            Logger.w(RequestActivity.LOG_TAG, "Unable to parse uri, skipping. | %s", requestAttachment.getLocalUri());
            errorUpload(requestAttachment);
        }
    }

    public void resolveUris(
            @NonNull List<Uri> uris,
            @NonNull String directory,
            @NonNull Callback<List<MediaResult>> resolveCallback)
    {
        if(!uris.isEmpty()) {
            resolveUri.start(uris, directory, resolveCallback);
        } else {
            resolveCallback.internalSuccess(new ArrayList<>(0));
        }
    }

    private boolean isUploadFinished() {
        synchronized (lock) {
            boolean attachmentUploadError = CollectionUtils.isNotEmpty(errorItems);
            boolean allItemsUploaded = processedItems.size() == itemsForUpload.size();
            return attachmentUploadError || allItemsUploaded;
        }
    }

    private StateRequestAttachment updateRequestAttachment(StateRequestAttachment requestAttachment, MediaResult
            mediaResult) {
        return requestAttachment.newBuilder()
                .setLocalFile(mediaResult.getFile())
                .setName(mediaResult.getName())
                .setMimeType(mediaResult.getMimeType())
                .setLocalUri(mediaResult.getUri().toString())
                .build();
    }

    private void uploadSuccess(StateRequestAttachment requestAttachment, UploadResponse uploadResponse) {
        final Attachment attachment = uploadResponse.getAttachment();
        final MediaResult mediaResult = renameFile(requestAttachment.getLocalFile(), attachment.getId());

        final String localUri;
        final File localFile;
        if (mediaResult != null) {
            localUri = mediaResult.getUri().toString();
            localFile = mediaResult.getFile();
        } else {
            localUri = requestAttachment.getLocalUri();
            localFile = requestAttachment.getLocalFile();
        }

        final StateRequestAttachment newRequestAttachment = requestAttachment.newBuilder()
                .setLocalUri(localUri)
                .setLocalFile(localFile)
                .setToken(uploadResponse.getToken())
                .setUrl(attachment.getContentUrl())
                .setMimeType(attachment.getContentType())
                .setName(attachment.getFileName())
                .build();

        synchronized (lock) {
            processedItems.add(newRequestAttachment);
        }

        notifyIfFinished();
    }

    private void errorUpload(StateRequestAttachment requestAttachment) {
        synchronized (lock) {
            errorItems.add(requestAttachment);
        }
        notifyIfFinished();
    }

    private void notifyIfFinished() {
        Logger.d(RequestActivity.LOG_TAG, "Notify if finished. Listener: %s, isUploadFinished: %s", resultListener,
                isUploadFinished());
        if (isUploadFinished() && resultListener != null) {
            if (CollectionUtils.isEmpty(errorItems)) {
                resultListener.onSuccess(new AttachmentUploadResult(CollectionUtils.copyOf(processedItems),
                        localToRemoteMap));
            } else {
                resultListener.onError(new ErrorResponseAdapter("Error uploading attachments."));
            }
            resultListener = null;
        }
    }

    private MediaResult renameFile(File file, long attachmentId) {
        final MediaResult newMediaResult = mediaResultUtility.getFile(subDirectory, attachmentId, file.getName());

        Logger.d(RequestActivity.LOG_TAG, "Rename local file: %s -> %s", file.getAbsolutePath(), newMediaResult
                .getFile().getAbsolutePath());

        final boolean success = file.renameTo(newMediaResult.getFile());
        return success ? newMediaResult : null;
    }

    private class ResolveCallback extends Callback<List<MediaResult>> {

        private final StateRequestAttachment requestAttachment;

        private ResolveCallback(StateRequestAttachment requestAttachment) {
            this.requestAttachment = requestAttachment;
        }

        @Override
        public void success(List<MediaResult> mediaResults) {
            final Uri uri = requestAttachment.getParsedLocalUri();
            if (!mediaResults.isEmpty() && !isUploadFinished()) {
                Logger.w(RequestActivity.LOG_TAG, "Successfully resolved attachment: %s", uri);
                final StateRequestAttachment attachment =
                        updateRequestAttachment(requestAttachment, mediaResults.get(0));
                final AttachmentsCallback attachmentsCallback = new AttachmentsCallback(attachment);

                uploadProvider.uploadAttachment(
                        attachment.getName(),
                        attachment.getLocalFile(),
                        attachment.getMimeType(),
                        attachmentsCallback);

            } else {
                Logger.w(RequestActivity.LOG_TAG, "Unable to resolve attachment: %s", uri);
                errorUpload(requestAttachment);
            }
        }
    }

    private class AttachmentsCallback extends ZendeskCallback<UploadResponse> {

        private final StateRequestAttachment requestAttachment;

        AttachmentsCallback(StateRequestAttachment requestAttachment) {
            this.requestAttachment = requestAttachment;
        }

        @Override
        public void onSuccess(UploadResponse uploadResponse) {
            Logger.d(RequestActivity.LOG_TAG, "Successfully uploaded file: %s | Result: %s", requestAttachment,
                    uploadResponse);
            localToRemoteMap.put(requestAttachment.getId(), uploadResponse.getAttachment().getId());
            uploadSuccess(requestAttachment, uploadResponse);
        }

        @Override
        public void onError(ErrorResponse errorResponse) {
            Logger.w(RequestActivity.LOG_TAG, "Error uploading file: %s | Error: %s", requestAttachment,
                    errorResponse.getReason());
            errorUpload(requestAttachment);
        }
    }

    static class AttachmentUploadResult {

        private final List<StateRequestAttachment> requestAttachments;
        private final Map<Long, Long> localToRemoteIdMap;

        AttachmentUploadResult(List<StateRequestAttachment> requestAttachments, Map<Long, Long> localToRemoteIdMap) {
            this.requestAttachments = requestAttachments;
            this.localToRemoteIdMap = localToRemoteIdMap;
        }

        List<StateRequestAttachment> getRequestAttachments() {
            return requestAttachments;
        }

        Map<Long, Long> getLocalToRemoteIdMap() {
            return localToRemoteIdMap;
        }
    }
}
