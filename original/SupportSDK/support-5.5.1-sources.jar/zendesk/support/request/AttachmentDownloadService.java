package zendesk.support.request;

import androidx.annotation.NonNull;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ErrorResponseAdapter;
import com.zendesk.service.ZendeskCallback;

import java.io.IOException;
import java.util.concurrent.Executor;

import zendesk.support.Streams;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okio.BufferedSink;
import okio.Okio;

/**
 * Service for downloading attachments.
 */
class AttachmentDownloadService {

    private final OkHttpClient okHttpClient;
    private final Executor executor;

    AttachmentDownloadService(OkHttpClient okHttpClient, Executor executor) {
        this.okHttpClient = okHttpClient;
        this.executor = executor;
    }

    void storeAttachment(ResponseBody responseBody, MediaResult destFile, ZendeskCallback<MediaResult> callback) {
        executor.execute(new SaveToFileTask(responseBody, destFile, callback));
    }

    void downloadAttachment(String url, final ZendeskCallback<ResponseBody> callback) {
        final Request request = new Request.Builder().get().url(url).build();
        okHttpClient
                .newCall(request)
                .enqueue(new Callback() {
                    @Override
                    public void onFailure(@NonNull Call call, @NonNull IOException e) {
                        callback.onError(new ErrorResponseAdapter(e.getMessage()));
                    }

                    @Override
                    public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                        if (response.isSuccessful()) {
                            callback.onSuccess(response.body());
                        } else {
                            callback.onError(new ErrorResponseAdapter(response.message()));
                        }
                    }
                });
    }

    private static class SaveToFileTask implements Runnable {

        private final ResponseBody responseBody;
        private final MediaResult destFile;
        private final ZendeskCallback<MediaResult> callback;

        private SaveToFileTask(ResponseBody responseBody, MediaResult destFile,
                               ZendeskCallback<MediaResult> callback) {
            this.responseBody = responseBody;
            this.destFile = destFile;
            this.callback = callback;
        }

        @Override
        public void run() {
            ErrorResponse errorResponse = null;
            BufferedSink bufferedSink = null;

            try {
                bufferedSink = Okio.buffer(Okio.sink(destFile.getFile()));
                bufferedSink.writeAll(responseBody.source());
            } catch (IOException e) {
                Logger.e(RequestActivity.LOG_TAG, "Unable to save attachment to disk. Error: '%s'", e.getMessage());
                errorResponse = new ErrorResponseAdapter(e.getMessage());
            } finally {
                Streams.closeQuietly(bufferedSink);
                Streams.closeQuietly(responseBody);
            }

            if (callback != null) {
                if (errorResponse == null) {
                    callback.onSuccess(destFile);
                } else {
                    callback.onError(errorResponse);
                }
            }
        }
    }
}
