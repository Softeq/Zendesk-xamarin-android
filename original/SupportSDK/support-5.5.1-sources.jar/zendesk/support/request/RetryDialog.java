package zendesk.support.request;

import android.content.Context;
import androidx.annotation.NonNull;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import android.view.View;
import android.widget.FrameLayout;

import zendesk.support.R;

import java.util.List;

/**
 * Bottom sheet dialog. Show if user wants to retry sending a message.
 */
class RetryDialog extends BottomSheetDialog {

    private BottomSheetBehavior<FrameLayout> bottomSheetBehavior;
    private Listener listener;
    private final List<StateMessage> message;

    RetryDialog(@NonNull Context context, List<StateMessage> message) {
        super(context);
        this.message = message;
        init();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (bottomSheetBehavior != null) {
            bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
        }
    }

    private void init() {
        setContentView(R.layout.zs_request_dialog_retry);
        setCancelable(true);
        setCanceledOnTouchOutside(true);
        bottomSheetBehavior = initBottomSheet();
        initListener();
    }

    private void initListener() {
        final View deleteMsg = findViewById(R.id.request_dialog_retry_delete);
        final View retry = findViewById(R.id.request_dialog_retry_retry);

        if (retry != null && deleteMsg != null) {
            deleteMsg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        listener.onDeleteMessage(message);
                    }
                    dismiss();
                }
            });
            retry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        listener.onRetryMessage(message);
                    }
                    dismiss();
                }
            });
        }
    }

    private BottomSheetBehavior<FrameLayout> initBottomSheet() {
        final FrameLayout bottomSheet = findViewById(com.google.android.material.R.id.design_bottom_sheet);
        if (bottomSheet != null) {
            try {
                return BottomSheetBehavior.from(bottomSheet);
            } catch (Exception e) {
                // intentionally empty
            }
        }
        return null;
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    interface Listener {
        void onDeleteMessage(List<StateMessage> message);

        void onRetryMessage(List<StateMessage> message);
    }
}
