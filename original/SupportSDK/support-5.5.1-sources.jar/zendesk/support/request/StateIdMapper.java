package zendesk.support.request;

import android.annotation.SuppressLint;

import com.zendesk.util.CollectionUtils;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Helper to map ids between remote and local ids.
 */
class StateIdMapper implements Serializable {

    private final Map<Long, Long> remoteToLocal;
    private final Map<Long, Long> localToRemote;

    private StateIdMapper(Map<Long, Long> remoteToLocal, Map<Long, Long> localToRemote) {
        this.remoteToLocal = remoteToLocal;
        this.localToRemote = localToRemote;
    }

    @SuppressLint("UseSparseArrays")
    StateIdMapper() {
        this.localToRemote = new HashMap<>();
        this.remoteToLocal = new HashMap<>();
    }

    boolean hasRemoteId(Long localId) {
        return localToRemote.containsKey(localId) && remoteToLocal.containsValue(localId);
    }

    boolean hasLocalId(Long remoteId) {
        return remoteToLocal.containsKey(remoteId) && localToRemote.containsValue(remoteId);
    }

    Long getLocalId(Long remoteId) {
        return remoteToLocal.get(remoteId);
    }

    Long getRemoteId(Long localId) {
        return localToRemote.get(localId);
    }

    StateIdMapper addIdMapping(Long remoteId, Long localId) {
        remoteToLocal.put(remoteId, localId);
        localToRemote.put(localId, remoteId);
        return copy();
    }

    StateIdMapper copy() {
        return new StateIdMapper(CollectionUtils.copyOf(remoteToLocal), CollectionUtils.copyOf(localToRemote));
    }

    Set<Long> getRemoteIds() {
        return remoteToLocal.keySet();
    }

    @Override
    public String toString() {
        return "IdMapper{" +
                " remoteToLocal=" + remoteToLocal +
                " localToRemote=" + localToRemote +
                '}';
    }
}
