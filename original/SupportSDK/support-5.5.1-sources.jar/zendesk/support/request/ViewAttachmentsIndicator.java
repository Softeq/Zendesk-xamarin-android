package zendesk.support.request;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import androidx.annotation.AttrRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.StyleRes;
import androidx.core.graphics.drawable.DrawableCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import zendesk.support.R;

import zendesk.support.UiUtils;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * A view that displays the number of attachments selected. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class ViewAttachmentsIndicator extends FrameLayout {

    private static final int COUNT_THRESHOLD = 9;
    private static final String COUNT_THRESHOLD_TEXT = String.valueOf(COUNT_THRESHOLD) + "+";

    private ImageView attachmentsIndicatorIcon;
    private View attachmentsIndicatorBottomBorder;
    private TextView attachmentsIndicatorCounter;

    private int colorActive;
    private int colorInactive;
    private int attachmentsCount;

    public ViewAttachmentsIndicator(@NonNull Context context) {
        super(context);
        init(context);
    }

    public ViewAttachmentsIndicator(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ViewAttachmentsIndicator(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    @SuppressWarnings("unused")
    public ViewAttachmentsIndicator(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int
            defStyleAttr, @StyleRes int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(context);
    }

    void init(@NonNull Context context) {
        inflate(context, R.layout.zs_view_request_attachments_indicator, this);

        if (isInEditMode()) {
            return;
        }

        // bind views
        attachmentsIndicatorIcon = findViewById(R.id.attachments_indicator_icon);
        attachmentsIndicatorBottomBorder = findViewById(R.id.attachments_indicator_bottom_border);
        attachmentsIndicatorCounter = findViewById(R.id.attachments_indicator_counter);

        // cache colors
        colorActive = UiUtils.themeAttributeToColor(R.attr.colorPrimary, context, R.color
                .zs_request_fallback_color_primary);
        colorInactive = UiUtils.resolveColor(R.color.zs_request_attachment_indicator_color_inactive, context);

        // set the color of a rounded background for TextView
        LayerDrawable drawable = (LayerDrawable) attachmentsIndicatorCounter.getBackground();
        ((GradientDrawable) drawable.findDrawableByLayerId(R.id.inner_circle)).setColor(colorActive);

        // talk back
        getContext().getString(R.string.zs_request_attachment_indicator_accessibility);
        setContentDescription(UtilsAttachment.getContentDescriptionForAttachmentButton(getContext(),
                getAttachmentsCount()));
    }

    /**
     * Gets the number of attachments displayed by the counter.
     *
     * @return The number of attachments displayed by the counter.
     */
    int getAttachmentsCount() {
        return attachmentsCount;
    }

    /**
     * Sets the number of attachments to be displayed by the counter.
     *
     * @param attachmentsCount The number of the attachments selected.
     *                         If greater than 0, shows the counter, the bottom border and enables an active state.
     */
    void setAttachmentsCount(int attachmentsCount) {
        this.attachmentsCount = attachmentsCount;

        int dimenId = attachmentsCount > COUNT_THRESHOLD
                ? R.dimen.zs_request_attachment_indicator_counter_width_double_digit
                : R.dimen.zs_request_attachment_indicator_counter_width_single_digit;
        ViewGroup.LayoutParams layoutParams = attachmentsIndicatorCounter.getLayoutParams();
        layoutParams.width = getResources().getDimensionPixelSize(dimenId);

        attachmentsIndicatorCounter.setLayoutParams(layoutParams);
        attachmentsIndicatorCounter.setText(attachmentsCount > COUNT_THRESHOLD
                ? COUNT_THRESHOLD_TEXT
                : String.valueOf(attachmentsCount));

        boolean hasAttachments = attachmentsCount > 0;
        setCounterVisible(hasAttachments);
        setBottomBorderVisible(hasAttachments);
        enableActiveState(hasAttachments);
        setContentDescription(UtilsAttachment.getContentDescriptionForAttachmentButton(getContext(),
                getAttachmentsCount()));
    }

    /**
     * Toggles the visibility of the counter depending on the argument passed.
     *
     * @param visible true to show the counter, false to hide it.
     */
    void setCounterVisible(boolean visible) {
        attachmentsIndicatorCounter.setVisibility(visible ? VISIBLE : INVISIBLE);
    }

    /**
     * Toggles the visibility of the bottom border depending on the argument passed.
     *
     * @param visible true to show the bottom border, false to hide it.
     */
    void setBottomBorderVisible(boolean visible) {
        attachmentsIndicatorBottomBorder.setVisibility(visible ? VISIBLE : INVISIBLE);
    }

    /**
     * Toggles the background color of the icon depending on the argument passed.
     *
     * @param enable true sets the background color to ?attr/colorPrimary
     *               false sets the background color to attachments_indicator_color_inactive.
     *               <p>
     *               If ?attrs/colorPrimary cannot be resolved,
     *               the background color defaults to attachments_indicator_color_active.
     */
    void enableActiveState(boolean enable) {
        Drawable drawable = DrawableCompat.wrap(attachmentsIndicatorIcon.getDrawable());
        DrawableCompat.setTint(drawable.mutate(), enable ? colorActive : colorInactive);

        attachmentsIndicatorIcon.invalidate();
    }

    /**
     * Resets the attachment indicator to a default state.
     * Hides the counter and bottom border and sets the count to 0.
     */
    void reset() {
        setCounterVisible(false);
        setAttachmentsCount(0);
        setBottomBorderVisible(false);
        enableActiveState(false);
    }
}