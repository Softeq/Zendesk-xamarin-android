package zendesk.support.request;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.util.Pair;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import com.squareup.picasso.Picasso;
import zendesk.support.R;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import zendesk.support.UiUtils;
import zendesk.support.ZendeskAvatarView;

/**
 * View for displaying avatars in a Toolbar. For Zendesk internal use only.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
class ViewToolbarAvatar extends FrameLayout {

    static final int MAX_IMAGES = 5;

    private static final int[] IMAGE_VIEW_IDS = {
            R.id.zs_request_toolbar_avatar_1,
            R.id.zs_request_toolbar_avatar_2,
            R.id.zs_request_toolbar_avatar_3,
            R.id.zs_request_toolbar_avatar_4,
            R.id.zs_request_toolbar_avatar_5
    };

    private int imageRadius;
    private int strokeWidth;
    private int strokeColor;

    private final List<ZendeskAvatarView> avatarViews = new ArrayList<>(MAX_IMAGES);
    private List<Pair<String, String>> userInfo = new ArrayList<>(MAX_IMAGES);

    public ViewToolbarAvatar(Context context) {
        this(context, null);
    }

    public ViewToolbarAvatar(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ViewToolbarAvatar(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        imageRadius = context.getResources().getDimensionPixelOffset(R.dimen.zs_request_toolbar_avatar_radius);
        strokeWidth = context.getResources().getDimensionPixelOffset(R.dimen.zs_request_toolbar_avatar_stroke_width);
        strokeColor = UiUtils.themeAttributeToColor(R.attr.colorPrimary, getContext(), R.color
                .zs_request_fallback_color_primary);

        for (int i = 0; i < MAX_IMAGES; i++) {
            final ZendeskAvatarView view = createAndAddView(i);
            view.setVisibility(ViewToolbarAvatar.GONE);
            avatarViews.add(view);
        }
    }

    void setImageUrls(Picasso picasso, List<Pair<String, String>> urls) {
        if (urls.size() > MAX_IMAGES) {
            this.userInfo = urls.subList(0, MAX_IMAGES);
        } else {
            this.userInfo = CollectionUtils.copyOf(urls);
        }

        Collections.reverse(this.userInfo);
        bindData(picasso);
    }

    private void bindData(Picasso picasso) {
        for (int i = 0; i < avatarViews.size(); i++) {
            final ZendeskAvatarView view = avatarViews.get(i);

            if (i < userInfo.size()) {
                final Pair<String, String> userInfo = this.userInfo.get(i);

                if (StringUtils.hasLength(userInfo.first)) {
                    // url
                    view.showUserWithAvatarImage(picasso, userInfo.first, userInfo.second, imageRadius);

                } else {
                    // name
                    view.showUserWithName(userInfo.second);
                }

                view.setVisibility(View.VISIBLE);
            } else {
                view.setVisibility(View.GONE);
            }
        }
    }

    private ZendeskAvatarView createAndAddView(int position) {
        final ZendeskAvatarView view = new ZendeskAvatarView(getContext());
        view.setId(IMAGE_VIEW_IDS[position]);
        view.setStroke(strokeColor, strokeWidth);

        final int imageSize = imageRadius * 2;
        final int marginRight = position * 2 * (imageSize / 3);

        final LayoutParams params = new LayoutParams(imageSize, imageSize);
        params.gravity = Gravity.END;

        params.setMarginEnd(marginRight);

        addView(view, params);

        return view;
    }

}
