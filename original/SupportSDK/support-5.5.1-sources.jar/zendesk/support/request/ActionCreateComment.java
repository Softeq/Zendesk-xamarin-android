package zendesk.support.request;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.HttpConstants;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.GetState;
import zendesk.support.Comment;
import zendesk.support.CreateRequest;
import zendesk.support.EndUserComment;
import zendesk.support.Request;
import zendesk.support.RequestProvider;

/**
 * Action for creating a comment.
 * <br/>
 * Depending on the state in the store it either creates new request or adds a comment to an
 * existing request.
 */
class ActionCreateComment implements AsyncMiddleware.AsyncAction {

    private final ActionFactory af;
    private final RequestProvider requestProvider;
    private final StateMessage message;

    private final AttachmentUploadService attachmentUploader;
    @SuppressWarnings("FieldCanBeLocal")
    private ZendeskCallback<AttachmentUploadService.AttachmentUploadResult> attachmentCallback;

    ActionCreateComment(ActionFactory af, RequestProvider requestProvider,
                        AttachmentUploadService attachmentUploader, StateMessage message) {
        this.af = af;
        this.requestProvider = requestProvider;
        this.message = message;
        this.attachmentUploader = attachmentUploader;
    }

    @Override
    public void actionQueued(Dispatcher dispatcher, GetState state) {
        final List<StateRequestAttachment> selectedAttachments = message.getAttachments();

        final String requestId = StateConversation.fromState(state.getState()).getLocalId();

        // Immediately start uploading attachments
        if (CollectionUtils.isNotEmpty(selectedAttachments)) {
            Logger.d(RequestActivity.LOG_TAG, "Start uploading %d attachments. Message Id: %s", selectedAttachments
                    .size(), message.getId());
            attachmentUploader.start(requestId);
        }

        dispatcher.dispatch(af.createComment(message.withPending()));
    }

    @Override
    public void execute(final Dispatcher dispatcher, GetState state, final AsyncMiddleware.Callback callback) {
        waitForAttachments(dispatcher, state, callback);
    }

    private void waitForAttachments(final Dispatcher dispatcher, GetState state, final AsyncMiddleware.Callback
            callback) {
        final StateConversation con = StateConversation.fromState(state.getState());
        final StateConfig config = StateConfig.fromState(state.getState());

        Logger.d(RequestActivity.LOG_TAG, "Waiting for attachments to be uploaded. Message Id: %s", message.getId());
        attachmentCallback = new ZendeskCallback<AttachmentUploadService.AttachmentUploadResult>() {
            @Override
            public void onSuccess(AttachmentUploadService.AttachmentUploadResult attachments) {
                Logger.d(RequestActivity.LOG_TAG, "Attachments resolved and uploaded. Message Id: %s", message.getId());
                createMessage(con, config, dispatcher, callback, attachments);
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.w(RequestActivity.LOG_TAG, "Attachment upload error. '%s'. Message Id: %s", errorResponse
                        .getReason(), message.getId());
                final StateMessage messageWithError = message.withError(errorResponse);
                if (StringUtils.hasLength(con.getRemoteId())) {
                    dispatcher.dispatch(af.createCommentError(errorResponse, messageWithError));
                } else {
                    dispatcher.dispatch(af.createRequestError(errorResponse, messageWithError));
                }
                callback.done();
            }
        };

        attachmentUploader.setResultListener(attachmentCallback);
    }

    private void createMessage(StateConversation con, StateConfig config, Dispatcher dispatcher, AsyncMiddleware
            .Callback callback,
                               AttachmentUploadService.AttachmentUploadResult attachments) {
        if (StringUtils.hasLength(con.getRemoteId())) {
            Logger.d(RequestActivity.LOG_TAG,
                    "Adding a comment to an existing request. Message Id %s",
                    message.getId());
            addComment(callback, dispatcher, con, attachments);
        } else {
            Logger.d(RequestActivity.LOG_TAG, "Creating a new request. Message Id %s", message.getId());
            createRequest(callback, dispatcher, attachments, config);
        }
    }

    private void addComment(final AsyncMiddleware.Callback callback, final Dispatcher dispatcher,
                            final StateConversation con, final AttachmentUploadService.AttachmentUploadResult
                                    attachments) {
        final EndUserComment endUserComment = new EndUserComment();
        endUserComment.setValue(message.getBody());
        endUserComment.setAttachments(getAttachmentToken(attachments.getRequestAttachments()));

        final String requestId = con.getRemoteId();

        requestProvider.addComment(requestId, endUserComment, new ZendeskCallback<Comment>() {
            @Override
            public void onSuccess(Comment comment) {
                final StateMessage newMessage = message.withAttachments(attachments.getRequestAttachments())
                        .withDelivered();
                dispatcher.dispatch(af.createCommentSuccess(new CreateCommentResult(newMessage, requestId, comment
                        .getId(), attachments)));
                requestProvider.markRequestAsRead(requestId, con.getMessageIdMapper().getRemoteIds().size());
                callback.done();
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.w(RequestActivity.LOG_TAG, "Unable to add comment to request. Error: '%s'. Message Id: %d",
                        errorResponse.getReason(), message.getId());

                if (errorResponse.isHttpError()
                        && errorResponse.getStatus() == HttpConstants.HTTP_UNPROCESSABLE_ENTITY) {
                    Logger.w(RequestActivity.LOG_TAG, "This request (%s) is closed. Error: '%s'. Message Id: %d",
                            requestId, errorResponse.getReason(), message.getId());
                    dispatcher.dispatch(af.requestClosed());
                }
                dispatcher.dispatch(af.createCommentError(errorResponse, message.withError(errorResponse)));
                callback.done();
            }
        });
    }

    private void createRequest(final AsyncMiddleware.Callback callback, final Dispatcher dispatcher,
                               final AttachmentUploadService.AttachmentUploadResult attachments, StateConfig config) {

        final CreateRequest createRequest = new CreateRequest();
        createRequest.setDescription(message.getBody());
        createRequest.setAttachments(getAttachmentToken(attachments.getRequestAttachments()));

        if (CollectionUtils.isNotEmpty(config.getTags())) {
            createRequest.setTags(config.getTags());
        }

        if (StringUtils.hasLength(config.getSubject())) {
            createRequest.setSubject(config.getSubject());
        }

        if (config.getTicketForm() != null) {
            if (config.getTicketForm().getId() != StateRequestTicketForm.NO_ID) {
                createRequest.setTicketFormId(config.getTicketForm().getId());
            }
            createRequest.setCustomFields(config.getTicketForm().getTicketFieldsForApi());
        }

        requestProvider.createRequest(createRequest, new ZendeskCallback<Request>() {
            @Override
            public void onSuccess(Request request) {
                final StateMessage newMessage = message.withAttachments(attachments.getRequestAttachments())
                        .withDelivered();
                dispatcher.dispatch(af.createRequestSuccess(new CreateCommentResult(newMessage, request.getId(),
                        request.getLastComment().getId(), attachments)));
                callback.done();
                if (request.getId() != null) {
                    requestProvider.markRequestAsRead(request.getId(), 1);
                }
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                dispatcher.dispatch(af.createRequestError(errorResponse, message.withError(errorResponse)));
                callback.done();
            }
        });
    }

    private List<String> getAttachmentToken(List<StateRequestAttachment> requestAttachments) {
        final List<String> tokens = new ArrayList<>();

        for (StateRequestAttachment u : requestAttachments) {
            tokens.add(u.getToken());
        }

        return tokens;
    }

    static class CreateCommentResult {

        private final StateMessage message;
        private final String requestId;
        private final long commentRemoteId;
        private final AttachmentUploadService.AttachmentUploadResult localToRemoteAttachments;

        CreateCommentResult(StateMessage message, String requestId, long commentRemoteId,
                            AttachmentUploadService.AttachmentUploadResult localToRemoteAttachments) {
            this.message = message;
            this.requestId = requestId;
            this.commentRemoteId = commentRemoteId;
            this.localToRemoteAttachments = localToRemoteAttachments;
        }

        StateMessage getMessage() {
            return message;
        }

        String getRequestId() {
            return requestId;
        }

        long getCommentRemoteId() {
            return commentRemoteId;
        }

        AttachmentUploadService.AttachmentUploadResult getLocalToRemoteAttachments() {
            return localToRemoteAttachments;
        }
    }
}
