package zendesk.support.request;

import androidx.annotation.NonNull;
import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.StringUtils;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import okhttp3.ResponseBody;
import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.Listener;

/**
 * Headless component for downloading attachments.
 * <br />
 * It listens for state updates and searched for not downloaded attachments. If one found it will kick
 * off the download and refreshes the ui afterwards.
 */
class AttachmentDownloaderComponent implements Listener<StateConversation> {

    private final Dispatcher dispatcher;
    private final ActionFactory actionFactory;
    private final AttachmentDownloaderSelector selector;

    private final AttachmentDownloader attachmentDownloader;


    AttachmentDownloaderComponent(@NonNull Dispatcher dispatcher,
                                  @NonNull ActionFactory actionFactory,
                                  @NonNull AttachmentDownloader attachmentDownloader) {
        this.dispatcher = dispatcher;
        this.actionFactory = actionFactory;
        this.attachmentDownloader = attachmentDownloader;
        selector = new AttachmentDownloaderSelector();
    }

    @Override
    public void update(@NonNull StateConversation conversation) {
        List<AttachmentDownloader.Request> requests = selector.selectData(conversation);
        for (final AttachmentDownloader.Request request : requests) {
            attachmentDownloader.download(request, new DownloadCallback(request.getRequestAttachment()));
        }
    }

    private class DownloadCallback extends ZendeskCallback<MediaResult> {

        private final StateRequestAttachment requestAttachment;

        DownloadCallback(StateRequestAttachment requestAttachment) {
            this.requestAttachment = requestAttachment;
        }

        @Override
        public void onSuccess(MediaResult result) {
            dispatcher.dispatch(actionFactory.attachmentDownloaded(requestAttachment, result));
        }

        @Override
        public void onError(ErrorResponse errorResponse) {
            Logger.d(RequestActivity.LOG_TAG, "Unable to download attachment. Error: %s", errorResponse.getReason());
        }
    }

    static class AttachmentDownloaderSelector {

        public List<AttachmentDownloader.Request> selectData(StateConversation conversation) {

            final StateIdMapper idMapper = conversation.getAttachmentIdMapper();
            final String requestId = conversation.getLocalId();
            final List<StateMessage> messages = conversation.getMessages();

            final List<AttachmentDownloader.Request> downloadRequests = new LinkedList<>();

            for (StateMessage m : messages) {
                final List<StateRequestAttachment> requestAttachments = m.getAttachments();

                for (StateRequestAttachment requestAttachment : requestAttachments) {
                    final long localId = requestAttachment.getId();

                    final boolean hasLocalFile = requestAttachment.getLocalFile() != null;
                    final boolean hasRemoteId = idMapper.hasRemoteId(localId);
                    final boolean hasDownloadUrl = StringUtils.hasLength(requestAttachment.getUrl());

                    if (!hasLocalFile && hasRemoteId && hasDownloadUrl) {
                        AttachmentDownloader.Request request = new AttachmentDownloader.Request(
                                requestId,
                                idMapper.getRemoteId(localId),
                                requestAttachment
                        );

                        downloadRequests.add(request);
                    }
                }
            }

            return downloadRequests;
        }
    }

    static class AttachmentDownloader {

        private final Set<String> downloadingHistory;
        private final MediaResultUtility mediaResultUtility;
        private final AttachmentDownloadService attachmentIo;

        AttachmentDownloader(AttachmentDownloadService attachmentIo, MediaResultUtility mediaResultUtility) {
            this.mediaResultUtility = mediaResultUtility;
            this.attachmentIo = attachmentIo;
            this.downloadingHistory = new HashSet<>();
        }

        void download(@NonNull final Request request, @NonNull final ZendeskCallback<MediaResult> callback) {
            final StateRequestAttachment requestAttachment = request.getRequestAttachment();
            final String url = requestAttachment.getUrl();

            if (!downloadingHistory.contains(url)) {
                downloadingHistory.add(url);
                attachmentIo.downloadAttachment(url, new HttpCallback(request, requestAttachment, callback, mediaResultUtility));
            }
        }

        private void handleError(String url, ErrorResponse errorMessage, ZendeskCallback callback) {
            downloadingHistory.remove(url);
            if (callback != null) {
                callback.onError(errorMessage);
            }
        }

        class CacheCallback extends ZendeskCallback<MediaResult> {

            private final StateRequestAttachment requestAttachment;
            private final ZendeskCallback<MediaResult> callback;

            CacheCallback(StateRequestAttachment requestAttachment, ZendeskCallback<MediaResult> callback) {
                this.requestAttachment = requestAttachment;
                this.callback = callback;
            }

            @Override
            public void onSuccess(MediaResult result) {
                callback.onSuccess(result);
                downloadingHistory.remove(requestAttachment.getUrl());
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                handleError(requestAttachment.getUrl(), errorResponse, callback);
            }
        }

        class HttpCallback extends ZendeskCallback<ResponseBody> {

            private final StateRequestAttachment requestAttachment;
            private final Request request;
            private final ZendeskCallback<MediaResult> callback;
            private final MediaResultUtility mediaResultUtility;

            HttpCallback(Request request, StateRequestAttachment requestAttachment,
                         ZendeskCallback<MediaResult> callback, MediaResultUtility mediaResultUtility) {
                this.request = request;
                this.requestAttachment = requestAttachment;
                this.callback = callback;
                this.mediaResultUtility = mediaResultUtility;
            }

            @Override
            public void onSuccess(ResponseBody responseBody) {
                final MediaResult mediaResult = mediaResultUtility.getLocalFile(
                        request.getRequestId(),
                        request.getRemoteAttachmentId(),
                        requestAttachment.getName()
                );
                attachmentIo.storeAttachment(responseBody, mediaResult, new CacheCallback(requestAttachment, callback));
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                handleError(requestAttachment.getUrl(), errorResponse, callback);
            }
        }

        static class Request {

            private final String requestId;
            private final long remoteAttachmentId;
            private final StateRequestAttachment requestAttachment;

            Request(String requestId, long remoteAttachmentId, StateRequestAttachment requestAttachment) {
                this.requestId = requestId;
                this.remoteAttachmentId = remoteAttachmentId;
                this.requestAttachment = requestAttachment;
            }

            String getRequestId() {
                return requestId;
            }

            long getRemoteAttachmentId() {
                return remoteAttachmentId;
            }

            StateRequestAttachment getRequestAttachment() {
                return requestAttachment;
            }
        }
    }
}
