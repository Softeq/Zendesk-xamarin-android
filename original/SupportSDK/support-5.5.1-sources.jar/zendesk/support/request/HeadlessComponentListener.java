package zendesk.support.request;

import zendesk.support.suas.Store;

/**
 * Collection of headless components.
 */
class HeadlessComponentListener {

    private final ComponentPersistence persistence;
    private final AttachmentDownloaderComponent attachment;
    private final ComponentUpdateActionHandlers updateActionHandlersComponent;
    private boolean registered = false;

    HeadlessComponentListener(ComponentPersistence persistence,
                              AttachmentDownloaderComponent attachment,
                              ComponentUpdateActionHandlers updateActionHandlersComponent) {
        this.persistence = persistence;
        this.attachment = attachment;
        this.updateActionHandlersComponent = updateActionHandlersComponent;
    }

    void startListening(Store store) {
        if (!registered) {
            store.addListener(persistence.getSelector(), persistence);
            store.addListener(StateConversation.class, attachment);
            store.addListener(StateConversation.class, updateActionHandlersComponent);
            registered = true;
        }
    }
}
