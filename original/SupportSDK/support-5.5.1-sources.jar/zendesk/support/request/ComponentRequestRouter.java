package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.transition.Fade;
import androidx.transition.TransitionManager;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;

import com.zendesk.logger.Logger;

import zendesk.commonui.BottomSheetAttachmentViewMenu;
import zendesk.support.R;
import com.zendesk.util.StringUtils;

import java.util.concurrent.atomic.AtomicReference;

import zendesk.support.suas.Listener;
import zendesk.support.suas.State;
import zendesk.support.suas.StateSelector;

/**
 * Component responsible for routing between screens based on the information found in the store.
 * <br />
 * Available screens:
 * - Conversation enabled (Chat)
 * - Conversation disabled (Input form)
 * - Loading (Empty)
 */
class ComponentRequestRouter implements Listener<ComponentRequestRouter.RequestScreen> {

    static ComponentRequestRouter create(
            AppCompatActivity activity,
            boolean isCleanStart,
            RequestComponent requestComponent,
            BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu
    ) {
        return new ComponentRequestRouter(
                activity,
                activity.<ViewGroup>findViewById(R.id.activity_request_root),
                activity.<RequestViewConversationsDisabled>findViewById(R.id.activity_request_conversation_disabled),
                activity.<RequestViewConversationsEnabled>findViewById(R.id.activity_request_conversation),
                activity.<RequestViewLoading>findViewById(R.id.activity_request_loading),
                requestComponent,
                isCleanStart,
                bottomSheetAttachmentViewMenu
        );
    }

    private final AppCompatActivity activity;

    private RequestView currentScreen;
    private final AtomicReference<RequestScreen> screen;

    private final ViewGroup root;
    private final RequestViewConversationsDisabled disabledView;
    private final RequestViewConversationsEnabled enabledView;
    private final RequestViewLoading loadingView;

    private final RequestComponent component;
    private final boolean isCleanStart;
    BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu;

    ComponentRequestRouter(
            AppCompatActivity activity,
            ViewGroup root,
            RequestViewConversationsDisabled disabledView,
            RequestViewConversationsEnabled enabledView,
            RequestViewLoading loadingView,
            RequestComponent component,
            boolean isCleanStart,
            BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu
    ) {
        this.activity = activity;
        this.root = root;
        this.disabledView = disabledView;
        this.enabledView = enabledView;
        this.loadingView = loadingView;
        this.component = component;
        this.isCleanStart = isCleanStart;
        this.screen = new AtomicReference<>();
        this.bottomSheetAttachmentViewMenu = bottomSheetAttachmentViewMenu;
    }

    RequestView getCurrentScreen() {
        return currentScreen;
    }

    @Override
    public void update(@NonNull RequestScreen state) {
        if (screen.getAndSet(state) == state) {
            return;
        }

        switch (state) {

            case Loading: {
                Logger.d(RequestActivity.LOG_TAG, "Installing screen: 'Loading Screen'");
                currentScreen = loadingView;
                displayView(loadingView, disabledView, enabledView);
                break;
            }

            case EmailForm: {
                Logger.d(RequestActivity.LOG_TAG, "Installing screen: 'Conversations Disabled Screen'");
                currentScreen = disabledView;
                displayView(disabledView, enabledView, loadingView);
                disabledView.init(component, bottomSheetAttachmentViewMenu);
                break;
            }

            case Conversation: {
                Logger.d(RequestActivity.LOG_TAG, "Installing screen: 'Conversations Enabled Screen'");
                currentScreen = enabledView;
                displayView(enabledView, disabledView, loadingView);
                enabledView.init(component, isCleanStart, bottomSheetAttachmentViewMenu);
                break;
            }

            case Fin: {
                Logger.d(RequestActivity.LOG_TAG, "Installing screen: 'Finish'");
                activity.finish();
                break;
            }

        }
    }

    StateSelector<RequestScreen> getSelector() {
        return new RequestRouterSelector();
    }

    private void displayView(View visible, View... hide) {
        TransitionManager.beginDelayedTransition(root, new Fade());
        visible.setVisibility(View.VISIBLE);
        for (View v : hide) {
            v.setVisibility(View.GONE);
        }
        activity.invalidateOptionsMenu();
        TransitionManager.endTransitions(root);
    }

    static class RequestRouterSelector implements StateSelector<RequestScreen> {

        @Nullable
        @Override
        public RequestScreen selectData(@NonNull State state) {
            final StateConfig config = StateConfig.fromState(state);
            final StateConversation conversation = StateConversation.fromState(state);
            final StateSettings settings = config.getSettings();
            final StateError error = StateError.fromState(state);

            final boolean settingsLoaded = settings.hasSettings();
            final boolean hasRequestId = StringUtils.hasLength(conversation.getRemoteId());
            final boolean conversationEnabled = settings.isConversationsEnabled();
            final boolean hasIdentityEmailAddress = settings.hasIdentityEmailAddress();
            final boolean isNeverRequestEmailOn = settings.isNeverRequestEmailOn();

            // A network request returned 401. Core nuked everything.
            // The ticket we're showing isn't valid anymore. Close everything.
            if (error.getState() == StateError.ErrorType.NoAccess) {
                Logger.e(RequestActivity.LOG_TAG, "Network returned 'No Access'. Ticket is not longer valid. Error: "
                        + "'%s'", error.getMessage());
                return RequestScreen.Fin;
            }

            // While loading settings show blank screen
            if (!settingsLoaded) {
                return RequestScreen.Loading;
            }

            // Conversations are enabled, open conversation on screen
            if (conversationEnabled) {
                return RequestScreen.Conversation;
            }

            // Request id provided but conversations are disabled, close request activity
            if (hasRequestId) {
                Logger.w(RequestActivity.LOG_TAG, "Conversations are disabled. Exiting RequestActivity");
                return RequestScreen.Fin;
            }

            // Conversations are off, there's no email address and we're not allowed to ask for an email
            // The ticket would go into a black hole
            if (!hasIdentityEmailAddress && isNeverRequestEmailOn) {
                Logger.w(RequestActivity.LOG_TAG, "Conversations are disabled, never request email is enabled, " +
                        "with this configuration tickets would go into a black hole. Exiting RequestActivity.");
                return RequestScreen.Fin;
            }

            return RequestScreen.EmailForm;
        }
    }

    enum RequestScreen {
        Loading,
        EmailForm,
        Conversation,
        Fin
    }
}