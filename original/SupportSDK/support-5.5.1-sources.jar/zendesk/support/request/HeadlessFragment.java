package zendesk.support.request;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Helper class for storing plain objects during config changes. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class HeadlessFragment<E> extends Fragment {

    private static final String TAG = "ZendeskHeadlessFragment";

    /**
     * Put an object into a fragment.
     *
     * @param fm   the {@link FragmentManager}
     * @param data object to store
     * @param <E>  type object
     */
    static <E> void install(FragmentManager fm, E data) {
        final HeadlessFragment<E> fragment = new HeadlessFragment<>();
        fragment.setData(data);

        fm.beginTransaction()
                .add(fragment, TAG)
                .commit();
    }

    private E data;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle
            savedInstanceState) {
        setRetainInstance(true);
        return null;
    }

    private void setData(E data) {
        this.data = data;
    }

    private E getData() {
        return data;
    }

    /**
     * Retrieve previously stored data.
     *
     * @param fm  the {@link FragmentManager}
     * @param <E> type of the stored object
     * @return the stored data or {@code null} if fragment wasn't installed or no data is available
     */
    static <E> E getData(FragmentManager fm) {
        final Fragment fragment = fm.findFragmentByTag(TAG);

        if (fragment instanceof HeadlessFragment<?>) {
            //noinspection unchecked
            return ((HeadlessFragment<E>) fragment).getData();
        } else {
            return null;
        }
    }

}
