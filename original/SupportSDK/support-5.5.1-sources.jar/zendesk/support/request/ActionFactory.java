package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.util.Pair;

import com.zendesk.service.ErrorResponse;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

import zendesk.core.AuthenticationProvider;
import zendesk.core.Zendesk;
import zendesk.support.suas.Action;
import zendesk.support.CommentsResponse;
import zendesk.support.Request;
import zendesk.support.RequestProvider;
import zendesk.support.SupportBlipsProvider;
import zendesk.support.SupportSettingsProvider;
import zendesk.support.SupportUiStorage;
import zendesk.support.UploadProvider;

/**
 * So many actions.
 */
class ActionFactory {

    static final String START_CONFIG = "START_CONFIG";

    static final String LOAD_SETTINGS = "LOAD_SETTINGS";
    static final String LOAD_SETTINGS_SUCCESS = "LOAD_SETTINGS_SUCCESS";
    static final String LOAD_SETTINGS_ERROR = "LOAD_SETTINGS_ERROR";

    static final String LOAD_COMMENTS_UPDATE = "LOAD_COMMENTS_UPDATE";
    static final String LOAD_COMMENTS_UPDATE_SUCCESS = "LOAD_COMMENTS_UPDATE_SUCCESS";
    static final String LOAD_COMMENTS_UPDATE_ERROR = "LOAD_COMMENTS_UPDATE_ERROR";

    static final String LOAD_COMMENTS_INITIAL = "LOAD_COMMENT_INITIAL";
    static final String LOAD_COMMENTS_INITIAL_SUCCESS = "LOAD_COMMENTS_INITIAL_SUCCESS";
    static final String LOAD_COMMENTS_INITIAL_ERROR = "LOAD_COMMENTS_INITIAL_ERROR";

    static final String LOAD_COMMENTS_FROM_CACHE = "LOAD_COMMENTS_FROM_CACHE";
    static final String LOAD_COMMENTS_FROM_CACHE_SUCCESS = "LOAD_COMMENTS_FROM_CACHE_SUCCESS";
    static final String LOAD_COMMENTS_FROM_CACHE_ERROR = "LOAD_COMMENTS_FROM_CACHE_ERROR";

    static final String CREATE_COMMENT = "CREATE_COMMENT";
    static final String CREATE_COMMENT_SUCCESS = "CREATE_COMMENT_SUCCESS";
    static final String CREATE_COMMENT_ERROR = "CREATE_COMMENT_ERROR";

    static final String CREATE_REQUEST = "CREATE_REQUEST";
    static final String CREATE_REQUEST_SUCCESS = "CREATE_REQUEST_SUCCESS";
    static final String CREATE_REQUEST_ERROR = "CREATE_REQUEST_ERROR";

    static final String LOAD_REQUEST = "LOAD_REQUEST";
    static final String LOAD_REQUEST_SUCCESS = "LOAD_REQUEST_SUCCESS";
    static final String LOAD_REQUEST_ERROR = "LOAD_REQUEST_ERROR";

    static final String DELETE_MESSAGE = "DELETE_MESSAGE";

    static final String CLEAR_ATTACHMENTS = "CLEAR_ATTACHMENTS";
    static final String ATTACHMENTS_SELECTED = "ATTACHMENTS_SELECTED";
    static final String ATTACHMENTS_DESELECTED = "ATTACHMENTS_DESELECTED";
    static final String ATTACHMENT_DOWNLOADED = "ATTACHMENT_DOWNLOADED";

    static final String ANDROID_ON_RESUME = "ANDROID_ON_RESUME";
    static final String ANDROID_ON_PAUSE = "ANDROID_ON_PAUSE";

    static final String SHOW_RETRY_DIALOG = "SHOW_RETRY_DIALOG";
    static final String DIALOG_DISMISSED = "DIALOG_DISMISSED";

    static final String REQUEST_CLOSED = "REQUEST_CLOSED";
    static final String SKIP_ACTION = "SKIP_ACTION";
    static final String CLEAR_MESSAGES = "CLEAR_MESSAGES";

    private final RequestProvider requestProvider;
    private final UploadProvider uploadProvider;
    private final SupportSettingsProvider settingsProvider;
    private final SupportUiStorage supportUiStorage;
    private final Executor executorService;
    private final Executor mainThreadExecutor;
    private final String sdkVersion;
    private final AuthenticationProvider authProvider;
    private final Zendesk zendesk;
    private final SupportBlipsProvider supportBlipsProvider;
    private final MediaResultUtility mediaResultUtility;
    private final ResolveUri resolveUri;

    ActionFactory(RequestProvider requestProvider, UploadProvider uploadProvider,
                  SupportSettingsProvider settingsProvider,
                  SupportUiStorage supportUiStorage, Executor executorService,
                  String sdkVersion, AuthenticationProvider authProvider, Zendesk zendesk,
                  SupportBlipsProvider supportBlipsProvider, Executor mainThreadExecutor,
                  MediaResultUtility mediaResultUtility, ResolveUri resolveUri) {
        this.requestProvider = requestProvider;
        this.uploadProvider = uploadProvider;
        this.settingsProvider = settingsProvider;
        this.supportUiStorage = supportUiStorage;
        this.executorService = executorService;
        this.mainThreadExecutor = mainThreadExecutor;
        this.sdkVersion = sdkVersion;
        this.authProvider = authProvider;
        this.zendesk = zendesk;
        this.supportBlipsProvider = supportBlipsProvider;
        this.mediaResultUtility = mediaResultUtility;
        this.resolveUri = resolveUri;
    }

    /**
     * Used in AsyncActions if they don't have enough information to run.
     */
    Action skipAction() {
        return new Action<>(SKIP_ACTION);
    }

    Action startConfig(RequestConfiguration startConfig) {
        return new Action<>(START_CONFIG, startConfig);
    }

    /**
     * Initialise the store with the passed in configuration.
     */
    Action installStartConfigAsync(RequestConfiguration startConfig) {
        final ActionInstallConfiguration installConfig =
                new ActionInstallConfiguration(supportUiStorage, startConfig, executorService, mainThreadExecutor, this,
                        supportBlipsProvider);
        return AsyncMiddleware.createAction(installConfig);
    }

    /**
     * Request settings from Core SDK
     */
    Action loadSettingsAsync() {
        final ActionLoadSettings loadSettingsAsync = new ActionLoadSettings(this, settingsProvider, authProvider);
        return AsyncMiddleware.createAction(loadSettingsAsync);
    }

    Action loadSettings() {
        return new Action<>(LOAD_SETTINGS);
    }

    Action loadSettingsSuccess(StateSettings settings) {
        return new Action<>(LOAD_SETTINGS_SUCCESS, settings);
    }

    Action loadSettingsError(ErrorResponse errorResponse) {
        return new ErrorAction(LOAD_SETTINGS_ERROR, errorResponse);
    }

    /**
     * Initial load comments action.
     * <br />
     * If an error occurs a Snackbar is shown that allows the user to retry.
     */
    Action initialLoadCommentsAsync() {
        final ActionLoadComments loadCommentsAsync = new ActionLoadComments(
                this,
                requestProvider,
                true,
                mediaResultUtility
        );
        return AsyncMiddleware.createAction(loadCommentsAsync);
    }

    /**
     * Refresh comments.
     * <br />
     * If an error occurs nothing is shown to the user.
     */
    Action updateCommentsAsync() {
        final ActionLoadComments loadCommentsAsync = new ActionLoadComments(
                this,
                requestProvider,
                false,
                mediaResultUtility
        );
        return AsyncMiddleware.createAction(loadCommentsAsync);
    }

    /**
     * Load cached comments from disk.
     */
    Action loadCommentsFromCacheAsync() {
        final ActionLoadCachedComments loadCachedComments = new ActionLoadCachedComments(
                this,
                supportUiStorage,
                executorService,
                sdkVersion,
                mediaResultUtility
        );
        return AsyncMiddleware.createAction(loadCachedComments);
    }

    Action loadComments(boolean initialLoad) {
        if (initialLoad) {
            return new Action<>(LOAD_COMMENTS_INITIAL);
        } else {
            return new Action<>(LOAD_COMMENTS_UPDATE);
        }
    }

    Action loadCommentsSuccess(boolean initialLoad, CommentsResponse commentsResponse, Map<Long, MediaResult>
            localAttachments) {
        Pair<CommentsResponse, Map<Long, MediaResult>> data = new Pair<>(commentsResponse, localAttachments);
        if (initialLoad) {
            return new Action<>(LOAD_COMMENTS_INITIAL_SUCCESS, data);
        } else {
            return new Action<>(LOAD_COMMENTS_UPDATE_SUCCESS, data);
        }
    }

    Action loadCommentsFromCache() {
        return new Action<>(LOAD_COMMENTS_FROM_CACHE);
    }

    Action loadCommentsFromCacheSuccess(StateConversation conversation) {
        return new Action<>(LOAD_COMMENTS_FROM_CACHE_SUCCESS, conversation);
    }

    Action loadCommentsFromCacheError() {
        return new Action<>(LOAD_COMMENTS_FROM_CACHE_ERROR);
    }

    Action loadCommentsError(boolean initialLoad, ErrorResponse errorResponse) {
        if (initialLoad) {
            return new ErrorAction<>(LOAD_COMMENTS_INITIAL_ERROR, errorResponse);
        } else {
            return new ErrorAction<>(LOAD_COMMENTS_UPDATE_ERROR, errorResponse);
        }
    }

    Action loadRequest() {
        return new Action<>(LOAD_REQUEST);
    }

    Action loadRequestSuccess(Request request) {
        return new Action<>(LOAD_REQUEST_SUCCESS, request);
    }

    Action loadRequestError(ErrorResponse errorResponse) {
        return new ErrorAction(LOAD_REQUEST_ERROR, errorResponse);
    }

    /**
     * Load request information from the network.
     */
    Action loadRequestAsync() {
        final ActionLoadRequest requestAsync = new ActionLoadRequest(this, requestProvider);
        return AsyncMiddleware.createAction(requestAsync);
    }

    /**
     * Create a comment.
     * <br />
     * Depending on information in the state. It will either create a new request or adds a comment.
     */
    Action createCommentAsync(final String message, final List<StateRequestAttachment> attachments) {
        final AttachmentUploadService attachmentUploader = new AttachmentUploadService(
                uploadProvider,
                attachments,
                mediaResultUtility,
                resolveUri
        );
        final ActionCreateComment createCommentAsync = new ActionCreateComment(this, requestProvider,
                attachmentUploader, new StateMessage(message, attachments));
        return AsyncMiddleware.createAction(createCommentAsync);
    }

    /**
     * Resend a previously failed comment.
     */
    Action resendCommentAsync(StateMessage message) {
        final AttachmentUploadService attachmentUploader = new AttachmentUploadService(
                uploadProvider,
                message.getAttachments(),
                mediaResultUtility,
                resolveUri
        );
        final ActionCreateComment createCommentAsync = new ActionCreateComment(this, requestProvider,
                attachmentUploader, message);
        return AsyncMiddleware.createAction(createCommentAsync);
    }

    /**
     * Add a name and email to the installed identity in Core.
     */
    Action updateNameEmailAsync(String name, String email) {
        final ActionUpdateNameEmail updateNameEmailAsync = new ActionUpdateNameEmail(name, email, authProvider,
                zendesk);
        return AsyncMiddleware.createAction(updateNameEmailAsync);
    }

    Action createComment(StateMessage message) {
        return new Action<>(CREATE_COMMENT, message);
    }

    Action createCommentSuccess(ActionCreateComment.CreateCommentResult createCommentResult) {
        return new Action<>(CREATE_COMMENT_SUCCESS, createCommentResult);
    }

    Action createCommentError(ErrorResponse errorResponse, StateMessage message) {
        return new ErrorAction<>(CREATE_COMMENT_ERROR, errorResponse, message);
    }

    Action createRequestSuccess(ActionCreateComment.CreateCommentResult createCommentResult) {
        return new Action<>(CREATE_REQUEST_SUCCESS, createCommentResult);
    }

    Action createRequestError(ErrorResponse errorResponse, StateMessage message) {
        return new ErrorAction<>(CREATE_REQUEST_ERROR, errorResponse, message);
    }

    /**
     * Remove a comment.
     * <br />
     * This Action only removes the comment locally.
     */
    Action deleteMessage(StateMessage message) {
        return new Action<>(DELETE_MESSAGE, message);
    }

    /**
     * Mark an attachment as selected.
     * <br />
     * The selected attachment will be added to the next comment.
     */
    Action selectAttachment(List<MediaResult> mediaResult) {
        return new Action<>(ATTACHMENTS_SELECTED, mediaResult);
    }

    /**
     * Deselect an attachment.
     */
    Action deselectAttachment(List<MediaResult> mediaResult) {
        return new Action<>(ATTACHMENTS_DESELECTED, mediaResult);
    }

    /**
     * Reset all state that is related to attachments.
     */
    Action clearAttachments() {
        return new Action<>(CLEAR_ATTACHMENTS);
    }

    /**
     * Notify that an attachment was downloaded.
     */
    Action attachmentDownloaded(StateRequestAttachment requestAttachment, MediaResult mediaResult) {
        return new Action<>(ATTACHMENT_DOWNLOADED, Pair.create(requestAttachment, mediaResult));
    }


    Action androidOnResume() {
        return new Action<>(ANDROID_ON_RESUME);
    }

    Action androidOnPause() {
        return new Action<>(ANDROID_ON_PAUSE);
    }


    /**
     * Trigger the retry dialog.
     */
    Action showRetryDialog(List<StateMessage> messages) {
        return new Action<>(SHOW_RETRY_DIALOG, messages);
    }

    Action onDialogDismissed() {
        return new Action<>(DIALOG_DISMISSED);
    }

    Action requestClosed() {
        return new Action<>(REQUEST_CLOSED);
    }

    /**
     * Remove all added messages
     */
    Action clearMessages() {
        return new Action(CLEAR_MESSAGES);
    }


    static class ErrorAction<E> extends Action<E> {

        private final ErrorResponse errorResponse;

        ErrorAction(@NonNull String actionType, @NonNull ErrorResponse error) {
            this(actionType, error, null);
        }

        ErrorAction(@NonNull String actionType, @NonNull ErrorResponse error, @Nullable E data) {
            super(actionType, data);
            this.errorResponse = error;
        }

        public ErrorResponse getErrorResponse() {
            return errorResponse;
        }
    }
}