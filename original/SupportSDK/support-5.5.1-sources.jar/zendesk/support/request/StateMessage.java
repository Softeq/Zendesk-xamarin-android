package zendesk.support.request;

import androidx.core.util.Pair;

import com.zendesk.service.ErrorResponse;
import com.zendesk.util.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import zendesk.support.Attachment;
import zendesk.support.CommentResponse;
import zendesk.support.IdUtil;

/**
 * A single message in a conversation.
 */
class StateMessage implements Serializable {

    static Pair<List<StateMessage>, StateIdMapper> convert(List<CommentResponse> comments, StateIdMapper
            messageIdMapper,
                                                           Map<Long, StateRequestAttachment> mappedAttachments) {

        final List<StateMessage> messages = new ArrayList<>(comments.size());
        StateIdMapper idMapper = messageIdMapper;

        for (CommentResponse comment : comments) {
            Long commentId = comment.getId();
            Long authorId = comment.getAuthorId();

            if (commentId != null && authorId != null) {

                final List<StateRequestAttachment> attachments = new ArrayList<>();
                for (Attachment attachment : comment.getAttachments()) {
                    if (mappedAttachments.containsKey(attachment.getId())) {
                        attachments.add(mappedAttachments.get(attachment.getId()));
                    }
                }

                final long id;
                if (idMapper.hasLocalId(commentId)) {
                    id = idMapper.getLocalId(commentId);
                } else {
                    id = IdUtil.newLongId();
                    idMapper = idMapper.addIdMapping(commentId, id);
                }

                final StateMessage message = new StateMessage(
                        comment.getHtmlBody(),
                        comment.getBody(),
                        comment.getCreatedAt(),
                        id,
                        authorId,
                        StateMessageStatus.delivered(),
                        attachments);

                messages.add(message);
            }
        }

        return Pair.create(messages, idMapper.copy());
    }

    private final String htmlBody;
    private final String plainBody;
    private final Date date;
    private final long id;
    private final long userId;
    private final StateMessageStatus state;
    private final List<StateRequestAttachment> attachments;

    StateMessage(String plainBody, List<StateRequestAttachment> attachments) {
        this.htmlBody = null;
        this.plainBody = plainBody;
        this.date = new Date();
        this.id = IdUtil.newLongId();
        this.userId = -1L;
        this.state = StateMessageStatus.pending();
        this.attachments = attachments;
    }

    StateMessage(String htmlBody, String plainBody, Date date, long localId, long userId, StateMessageStatus state,
                 List<StateRequestAttachment> attachments) {
        this.htmlBody = htmlBody;
        this.plainBody = plainBody;
        this.date = date;
        this.id = localId;
        this.userId = userId;
        this.state = state;
        this.attachments = attachments;
    }

    String getHtmlBody() {
        return htmlBody;
    }

    String getPlainBody() {
        return plainBody;
    }

    String getBody() {
        return StringUtils.hasLength(plainBody) ? plainBody
                : UtilsAttachment.getMessageBodyForAttachments(getAttachments());
    }

    Date getDate() {
        return date;
    }

    long getId() {
        return id;
    }

    long getUserId() {
        return userId;
    }

    StateMessageStatus getState() {
        return state;
    }

    List<StateRequestAttachment> getAttachments() {
        return attachments;
    }

    StateMessage withAttachments(List<StateRequestAttachment> updatedAttachments) {
        return new StateMessage(htmlBody, plainBody, date, id, userId, state, updatedAttachments);
    }

    StateMessage withDelivered() {
        return new StateMessage(htmlBody, plainBody, date, id, userId, StateMessageStatus.delivered(), attachments);
    }

    StateMessage withError(ErrorResponse error) {
        return new StateMessage(htmlBody, plainBody, date, id, userId, StateMessageStatus.error(error.getReason()),
                attachments);
    }

    StateMessage withPending() {
        return new StateMessage(htmlBody, plainBody, date, id, userId, StateMessageStatus.pending(), attachments);
    }

    StateMessage withUpdatedAttachment(StateRequestAttachment updatedAttachment) {
        final List<StateRequestAttachment> updatedAttachments = new ArrayList<>(attachments.size());

        for (StateRequestAttachment attachment : attachments) {
            updatedAttachments.add(attachment.getId() == updatedAttachment.getId() ? updatedAttachment : attachment);
        }

        return new StateMessage(htmlBody, plainBody, date, id, userId, state, updatedAttachments);
    }

    @SuppressWarnings("SimplifiableIfStatement")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        StateMessage message = (StateMessage) o;

        if (id != message.id) {
            return false;
        }
        if (userId != message.userId) {
            return false;
        }
        if (htmlBody != null ? !htmlBody.equals(message.htmlBody) : message.htmlBody != null) {
            return false;
        }
        if (plainBody != null ? !plainBody.equals(message.plainBody) : message.plainBody != null) {
            return false;
        }
        if (date != null ? !date.equals(message.date) : message.date != null) {
            return false;
        }
        if (state != null ? !state.equals(message.state) : message.state != null) {
            return false;
        }
        return attachments != null ? attachments.equals(message.attachments) : message.attachments == null;
    }

    @Override
    public int hashCode() {
        final Object[] objects = new Object[]{htmlBody, plainBody, date, id, userId, state, attachments};
        return Arrays.hashCode(objects);
    }

    @Override
    public String toString() {
        return "Message{" +
                "htmlBody='" + htmlBody + '\'' +
                ", plainBody='" + plainBody + '\'' +
                ", date=" + date +
                ", id=" + id +
                ", userId=" + userId +
                ", state=" + state +
                '}';
    }
}
