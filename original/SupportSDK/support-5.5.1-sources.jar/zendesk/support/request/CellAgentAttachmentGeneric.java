package zendesk.support.request;

import android.content.Context;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import zendesk.support.R;

import java.util.Date;

/**
 * Cell in stream. Agent. File attachment.
 */
class CellAgentAttachmentGeneric extends CellBase implements CellType.Attachment, CellType.Agent {

    private final StateRequestAttachment requestAttachment;
    private final StateRequestUser user;
    private final ResolveInfo appInfo;
    private final Rect insets;
    private boolean isAgentNameVisible;

    CellAgentAttachmentGeneric(CellBindHelper utils, StateRequestAttachment requestAttachment, StateRequestUser user,
                               Date timeStamp) {
        super(utils, R.layout.zs_request_agent_attachment_generic, requestAttachment.getId(), user.getId(), timeStamp);
        this.requestAttachment = requestAttachment;
        this.user = user;
        this.isAgentNameVisible = false;
        this.appInfo = utils.getAppInfo(requestAttachment.getName());
        this.insets = utils.getInsets(0, 0, 0, R.dimen.zs_request_message_inset_agent_attachment_bottom);
    }

    public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
        final TextView fileName = view.findCachedView(R.id.request_agent_attachment_generic_name);
        fileName.setText(requestAttachment.getName());

        final TextView appName = view.findCachedView(R.id.request_agent_attachment_generic_type);
        final ImageView appIcon = view.findCachedView(R.id.request_agent_attachment_generic_icon);
        utils.bindAppInfo(appInfo, appName, appIcon);

        final View container = view.findCachedView(R.id.request_agent_attachment_generic_container);
        utils.addOnClickListenerForFileAttachment(container, requestAttachment);

        final TextView agentName = view.findCachedView(R.id.request_agent_attachment_generic_agent_name);
        utils.bindAgentName(agentName, isAgentNameVisible, user);

        // Talk Back
        container.setContentDescription(buildTalkBackString(container.getContext()));
    }

    private String buildTalkBackString(Context context) {
        final StringBuilder talkBack = new StringBuilder();
        talkBack.append(context.getString(R.string.zs_request_message_agent_file_accessibility, requestAttachment
                .getName()));
        talkBack.append(" ");

        final CharSequence dateString = DateUtils.getRelativeTimeSpanString(context, getTimeStamp().getTime(), true);
        talkBack.append(context.getString(R.string.zs_request_message_agent_sent_accessibility, dateString, user
                .getName()));

        return talkBack.toString();
    }

    @Override
    public boolean areContentsTheSame(CellType.Base requestMessage) {
        boolean msg = utils.areAttachmentCellContentsTheSame(this, requestMessage);
        boolean agent = utils.areAgentCellContentsTheSame(this, requestMessage);

        return msg && agent;
    }

    @Override
    public StateRequestAttachment getAttachment() {
        return requestAttachment;
    }

    @Override
    public Rect getInsets() {
        return insets;
    }

    @Override
    public void showAgentName(boolean visible) {
        this.isAgentNameVisible = visible;
    }

    @Override
    public boolean isAgentNameVisible() {
        return isAgentNameVisible;
    }

    @Override
    public StateRequestUser getAgent() {
        return user;
    }
}