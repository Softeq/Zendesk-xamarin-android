package zendesk.support.request;

import java.io.Serializable;
import java.util.List;

class StateRetryDialog implements StateUi.DialogState, Serializable {

    private final List<StateMessage> message;
    private final boolean visible;

    StateRetryDialog(List<StateMessage> message) {
        this(message, false);
    }

    private StateRetryDialog(List<StateMessage> message, boolean visible) {
        this.message = message;
        this.visible = visible;
    }

    List<StateMessage> getMessage() {
        return message;
    }

    @Override
    public StateUi.DialogState setVisible(boolean visible) {
        return new StateRetryDialog(message, visible);
    }

    @Override
    public boolean isVisible() {
        return visible;
    }
}
