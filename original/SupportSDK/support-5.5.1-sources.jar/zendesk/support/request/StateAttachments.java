package zendesk.support.request;

import com.zendesk.util.CollectionUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import zendesk.support.suas.State;

/**
 * Root state data. Holding information about selected attachments.
 */
class StateAttachments implements Serializable {

    static StateAttachments fromState(State state) {
        final Object attachments = state.getState(StateAttachments.class.getSimpleName());
        if (attachments instanceof StateAttachments) {
            return (StateAttachments) attachments;
        } else {
            return new StateAttachments();
        }
    }

    private final List<StateRequestAttachment> selectedAttachments;
    private final Set<StateRequestAttachment> allSelectedAttachments;

    StateAttachments(List<StateRequestAttachment> selectedAttachments, Set<StateRequestAttachment>
            allSelectedAttachments) {
        this.selectedAttachments = selectedAttachments;
        this.allSelectedAttachments = allSelectedAttachments;
    }

    StateAttachments() {
        this.selectedAttachments = new ArrayList<>();
        this.allSelectedAttachments = new TreeSet<>(new UriComparator());
    }

    List<StateRequestAttachment> getSelectedAttachments() {
        return selectedAttachments;
    }

    Set<StateRequestAttachment> getAllSelectedAttachments() {
        return allSelectedAttachments;
    }

    Builder newBuilder() {
        return new Builder(this);
    }

    @Override
    public String toString() {
        return "Attachments{" +
                "selectedAttachments=" + selectedAttachments +
                ", allSelectedAttachments=" + allSelectedAttachments +
                '}';
    }

    public static class Builder {
        private List<StateRequestAttachment> selectedAttachments;
        private Set<StateRequestAttachment> attachmentNotSelectedButVisible;

        private Builder(StateAttachments attachments) {
            this.selectedAttachments = CollectionUtils.copyOf(attachments.getSelectedAttachments());
            this.attachmentNotSelectedButVisible = new TreeSet<>(new UriComparator());
            this.attachmentNotSelectedButVisible.addAll(attachments.getAllSelectedAttachments());
        }

        Builder setSelectedAttachments(List<StateRequestAttachment> selectedAttachments) {
            this.selectedAttachments = CollectionUtils.copyOf(selectedAttachments);
            return this;
        }

        Builder addAllSelectedAttachments(List<StateRequestAttachment> attachmentNotSelectedButVisible) {
            Collections.reverse(attachmentNotSelectedButVisible);
            this.attachmentNotSelectedButVisible.addAll(attachmentNotSelectedButVisible);
            return this;
        }

        StateAttachments build() {
            return new StateAttachments(selectedAttachments, attachmentNotSelectedButVisible);
        }
    }

    static class UriComparator implements Comparator<StateRequestAttachment>, Serializable {
        @Override
        public int compare(StateRequestAttachment o1, StateRequestAttachment o2) {
            return o1.getLocalUri().compareTo(o2.getLocalUri());
        }
    }
}
