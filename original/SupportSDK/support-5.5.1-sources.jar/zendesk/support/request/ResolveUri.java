package zendesk.support.request;

import android.content.ContentResolver;
import android.net.Uri;

import java.io.InputStream;
import java.util.List;
import java.util.concurrent.Executor;

import zendesk.core.Callback;


/**
 * ResolveUri tries to open an {@link InputStream} from an {@link Uri}
 * by calling {@link ContentResolver#openInputStream(Uri)}.
 * If an {@link InputStream} was successfully opened, the file will
 * be copied into the private cache of the app.
 */
class ResolveUri {

    private final MediaResultUtility mediaResultUtility;
    private final Executor executor;
    private final Executor mainThreadExecutor;

   ResolveUri(
            MediaResultUtility mediaResultUtility,
            Executor executor,
            Executor mainThreadExecutor
    ) {
        this.mediaResultUtility = mediaResultUtility;
        this.executor = executor;
        this.mainThreadExecutor = mainThreadExecutor;
    }

    public void start(
            List<Uri> listUris,
            String subDirectory,
            Callback<List<MediaResult>> resolveCallback
    ) {
        executor.execute(() -> {
            List<MediaResult> resolvedUris = mediaResultUtility.getResolvedUris(listUris, subDirectory);
            mainThreadExecutor.execute(() -> resolveCallback.internalSuccess(resolvedUris));
        });
    }
}

