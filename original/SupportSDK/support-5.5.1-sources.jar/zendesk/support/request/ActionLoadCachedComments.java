package zendesk.support.request;

import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

import zendesk.support.BuildConfig;
import zendesk.support.suas.Action;
import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.GetState;
import zendesk.support.SupportUiStorage;

/**
 * Load cached comments from {@link SupportUiStorage}
 */
class ActionLoadCachedComments implements AsyncMiddleware.AsyncAction {

    private final ActionFactory actionFactory;
    private final SupportUiStorage supportUiStorage;
    private final Executor executorService;
    private final String sdkVersion;
    private final MediaResultUtility mediaResultUtility;

    ActionLoadCachedComments(
            ActionFactory actionFactory,
            SupportUiStorage supportUiStorage,
            Executor executorService,
            String sdkVersion,
            MediaResultUtility mediaResultUtility
    ) {
        this.actionFactory = actionFactory;
        this.supportUiStorage = supportUiStorage;
        this.executorService = executorService;
        this.sdkVersion = sdkVersion;
        this.mediaResultUtility = mediaResultUtility;
    }

    @Override
    public void actionQueued(Dispatcher dispatcher, GetState state) {
        dispatcher.dispatch(actionFactory.loadCommentsFromCache());
    }

    @Override
    public void execute(Dispatcher dispatcher, GetState state, AsyncMiddleware.Callback callback) {
        final StateConversation conversation = StateConversation.fromState(state.getState());
        if (StringUtils.hasLength(conversation.getLocalId())) {
            executorService.execute(
                    new LoadComments(
                            conversation.getLocalId(),
                            dispatcher,
                            callback,
                            supportUiStorage,
                            actionFactory,
                            sdkVersion,
                            mediaResultUtility
                    )
            );
        } else {
            dispatcher.dispatch(actionFactory.skipAction());
            callback.done();
        }
    }

    @VisibleForTesting
    static class LoadComments implements Runnable {

        private final String id;
        private final Dispatcher dispatcher;
        private final AsyncMiddleware.Callback callback;
        private final SupportUiStorage supportUiStorage;
        private final ActionFactory af;
        private final MediaResultUtility mediaResultUtility;
        private final String sdkVersion;

        LoadComments(String id, Dispatcher dispatcher, AsyncMiddleware.Callback callback,
                     SupportUiStorage supportUiStorage, ActionFactory af, String sdkVersion, MediaResultUtility mediaResultUtility) {
            this.id = id;
            this.dispatcher = dispatcher;
            this.callback = callback;
            this.supportUiStorage = supportUiStorage;
            this.af = af;
            this.mediaResultUtility = mediaResultUtility;
            this.sdkVersion = sdkVersion;
        }

        @Override
        public void run() {
            final ComponentPersistence.RequestPersistenceModel retrieve =
                    supportUiStorage.read(id, ComponentPersistence.RequestPersistenceModel.class);
            final Action action;

            if (retrieve != null && retrieve.getConversation() != null) {
                if (sdkVersion.equals(retrieve.getVersion())) {
                    Logger.d(RequestActivity.LOG_TAG, "Successfully loaded request from disk");
                    final StateConversation conversation = resolveAttachments(retrieve.getConversation());
                    action = af.loadCommentsFromCacheSuccess(conversation);
                } else {
                    Logger.d(RequestActivity.LOG_TAG,
                            "Cached version doesn't match with SDK version. Ignoring cached data. [%s, %s]",
                            retrieve.getVersion(), BuildConfig.VERSION_NAME);
                    action = af.loadCommentsFromCacheError();
                }
            } else {
                Logger.d(RequestActivity.LOG_TAG, "Unable to loaded request from disk");
                action = af.loadCommentsFromCacheError();
            }

            dispatcher.dispatch(action);
            callback.done();
        }

        StateConversation resolveAttachments(StateConversation conversation) {
            final List<StateMessage> newMessages = new ArrayList<>(conversation.getMessages().size());
            for (StateMessage message : conversation.getMessages()) {
                newMessages.add(findLocalAttachmentForMessage(message, conversation.getAttachmentIdMapper(), conversation.getLocalId()));
            }
            return conversation.newBuilder().setMessages(newMessages).build();
        }

        private StateMessage findLocalAttachmentForMessage(StateMessage message, StateIdMapper idMapper, String requestId) {
            final List<StateRequestAttachment> attachments = message.getAttachments();

            if (CollectionUtils.isNotEmpty(attachments)) {
                final List<StateRequestAttachment> updatedAttachments =
                        new ArrayList<>(message.getAttachments().size());
                for (StateRequestAttachment requestAttachment : attachments) {
                    if (idMapper.hasRemoteId(requestAttachment.getId())) {
                        final long id = idMapper.getRemoteId(requestAttachment.getId());
                        final MediaResult result = mediaResultUtility.getLocalFile(requestId, id,
                                requestAttachment.getName());
                        updatedAttachments.add(updateAttachment(requestAttachment, result));
                    } else {
                        updatedAttachments.add(requestAttachment);
                    }
                }
                return message.withAttachments(updatedAttachments);

            } else {
                return message;
            }
        }

        private StateRequestAttachment updateAttachment(StateRequestAttachment requestAttachment, MediaResult result) {
            File localFile = null;
            String localUri = null;

            if (requestAttachment.getSize() == result.getFile().length()) {
                localFile = result.getFile();
                localUri = result.getUri().toString();
            }

            return requestAttachment.newBuilder()
                    .setLocalFile(localFile)
                    .setLocalUri(localUri)
                    .build();
        }

        @VisibleForTesting
        String getId() {
            return id;
        }
    }
}
