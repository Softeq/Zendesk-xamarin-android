package zendesk.support.request;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.GetState;
import zendesk.support.AttachmentFile;
import zendesk.support.IdUtil;
import zendesk.support.SupportBlipsProvider;
import zendesk.support.SupportUiStorage;

/**
 * Load further information about the request from {@link SupportUiStorage} and apply the initial
 * configuration to the store.
 */
class ActionInstallConfiguration implements AsyncMiddleware.AsyncAction {

    private final SupportUiStorage supportUiStorage;
    private final RequestConfiguration startConfig;
    private final Executor executor;
    private final Executor mainThreadExecutor;
    private final ActionFactory af;
    private final SupportBlipsProvider blipsProvider;

    ActionInstallConfiguration(SupportUiStorage supportUiStorage, RequestConfiguration startConfig,
                               Executor executor, Executor mainThreadExecutor, ActionFactory af,
                               SupportBlipsProvider blipsProvider) {
        this.supportUiStorage = supportUiStorage;
        this.startConfig = startConfig;
        this.executor = executor;
        this.mainThreadExecutor = mainThreadExecutor;
        this.af = af;
        this.blipsProvider = blipsProvider;
    }

    @Override
    public void actionQueued(Dispatcher dispatcher, GetState state) {
        // intentionally empty
    }

    @Override
    public void execute(final Dispatcher dispatcher, final GetState state, final AsyncMiddleware.Callback callback) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                final boolean hasRemoteId = StringUtils.hasLength(startConfig.getRequestId());
                final boolean hasLocalId = StringUtils.hasLength(startConfig.getLocalRequestId());

                String remoteId = startConfig.getRequestId();
                String localId = startConfig.getLocalRequestId();

                if (!hasRemoteId || !hasLocalId) {

                    // Load Mapper form disk
                    final ComponentPersistence.RequestIdMapper requestIdMapper =
                            supportUiStorage.read(SupportUiStorage.REQUEST_MAPPER, ComponentPersistence.RequestIdMapper
                                    .class);

                    if (requestIdMapper != null) {
                        if (hasLocalId) {
                            // there's a local id, try to load remote id
                            remoteId = requestIdMapper.getRemoteId(localId);

                        } else if (hasRemoteId) {
                            // there's a remote id, let's see if there's local id
                            localId = requestIdMapper.getLocalId(remoteId);
                        }
                    }

                    if (!StringUtils.hasLength(localId)) {
                        // there's still no local id, let's generate one
                        localId = IdUtil.newStringId();
                    }
                }

                if (StringUtils.hasLength(remoteId)) {
                    blipsProvider.requestViewed(remoteId);
                }

                Logger.d(RequestActivity.LOG_TAG, "Request information loaded from disk. Remote id: '%s'. Local id: "
                        + "'%s'", remoteId, localId);

                List<AttachmentFile> files = StringUtils.isEmpty(remoteId)
                        ? startConfig.getFilesAsAttachments()
                        : new ArrayList<AttachmentFile>();

                final RequestConfiguration newConfig = new RequestConfiguration(
                        startConfig.getRequestSubject(),
                        startConfig.getTags(),
                        remoteId, localId,
                        startConfig.getRequestStatus(),
                        startConfig.getCustomFields(),
                        startConfig.getTicketFormId(),
                        files,
                        startConfig.hasAgentReplies(),
                        startConfig.getConfigurations());

                mainThreadExecutor.execute(new Runnable() {
                    @Override
                    public void run() {
                        dispatcher.dispatch(af.startConfig(newConfig));
                        callback.done();
                    }
                });
            }
        });
    }
}
