package zendesk.support.request;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;

import zendesk.support.R;

import zendesk.support.UiUtils;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * ActionView for attachments menu button in conversations off screen. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
class ViewCellAttachmentMenuItem extends FrameLayout {

    private View badgeContainer;
    private View shadow;
    private TextView badge;

    public ViewCellAttachmentMenuItem(@NonNull Context context) {
        super(context);
        viewInit();
    }

    public ViewCellAttachmentMenuItem(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        viewInit();
    }

    public ViewCellAttachmentMenuItem(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        viewInit();
    }

    void setBadgeCount(int count) {
        if (count > 0) {
            badgeContainer.setVisibility(View.VISIBLE);
            badge.setText(String.valueOf(count));
        } else {
            badgeContainer.setVisibility(View.GONE);
        }

        setContentDescription(UtilsAttachment.getContentDescriptionForAttachmentButton(getContext(), count));
    }

    private void viewInit() {
        inflate(getContext(), R.layout.zs_request_attachment_actionview, this);
        bindViews();
        tintBadge();

        setContentDescription(UtilsAttachment.getContentDescriptionForAttachmentButton(getContext(), 0));
    }

    private void tintBadge() {
        final int colorAccent = UiUtils.themeAttributeToColor(R.attr.colorAccent, getContext(), R.color
                .zs_request_fallback_color_primary);
        final Drawable background = badge.getBackground();
        UiUtils.setTint(colorAccent, background, badge);
    }

    private void bindViews() {
        this.badgeContainer = findViewById(R.id.request_actionview_badge_container);
        this.badge = findViewById(R.id.request_actionview_attachment_count);
        this.shadow = findViewById(R.id.request_actionview_compat_shadow);
    }

}
