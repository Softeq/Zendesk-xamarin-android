package zendesk.support.request;

import androidx.annotation.NonNull;

import zendesk.commonui.BottomSheetAttachmentViewMenu;
import zendesk.support.R;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;
import java.util.ArrayList;
import java.util.List;
import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.Listener;
import zendesk.support.suas.State;
import zendesk.support.suas.StateSelector;
import zendesk.support.RequestStatus;
import zendesk.support.UiUtils;

/**
 * Component representing the input box in the conversation on screen.
 */
class ComponentMessageComposer implements Listener<ComponentMessageComposer.MessageComposerModel>,
        ViewMessageComposer.InputListener {

    private final ViewMessageComposer messageComposerView;
    private final Dispatcher dispatcher;
    private final ActionFactory actionFactory;

    private final MessageComposerSelector messageFieldSelector;

    private final AttachmentHelper attachmentHelper;

    private final BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu;

    ComponentMessageComposer(ViewMessageComposer messageComposer, Dispatcher dispatcher,
                             ActionFactory actionFactory, BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu) {
        this.messageComposerView = messageComposer;
        this.dispatcher = dispatcher;
        this.actionFactory = actionFactory;
        this.bottomSheetAttachmentViewMenu = bottomSheetAttachmentViewMenu;
        this.messageFieldSelector = new MessageComposerSelector();
        this.attachmentHelper = new AttachmentHelper(R.id.attachments_indicator_icon, R.id.message_composer_send_btn);

        messageComposer.addListener(this);
    }



    @Override
    public void update(@NonNull MessageComposerModel messageFieldModel) {
        attachmentHelper.updateMaxFileSize(messageFieldModel.getMaxFileSize());
        attachmentHelper.updateAttachments(messageFieldModel.getRequestAttachments());

        messageComposerView.setAttachmentsCount(messageFieldModel.getRequestAttachments().size());
        messageComposerView.enableSendButton(messageFieldModel.isSendButtonEnabled());
        messageComposerView.enableAttachmentsButton(messageFieldModel.isAttachmentsButtonEnabled());
        messageComposerView.hide(!messageFieldModel.isMessageComposerVisible());

        if (!messageFieldModel.isMessageComposerVisible()) {
            UiUtils.dismissKeyboard(messageComposerView);
        }

    }

    public StateSelector<MessageComposerModel> getSelector() {
        return messageFieldSelector;
    }

    @Override
    public void onAddAttachmentsRequested() {
        bottomSheetAttachmentViewMenu.showMenu();
    }

    @Override
    public void onSendMessageRequested(@NonNull String message) {
        dispatcher.dispatch(actionFactory.createCommentAsync(message, attachmentHelper.getSelectedAttachments()));
        dispatcher.dispatch(actionFactory.clearAttachments());
        dispatcher.dispatch(actionFactory.updateCommentsAsync());
    }


    boolean hasUnsavedInput() {
        return StringUtils.hasLength(messageComposerView.getMessage())
                || CollectionUtils.isNotEmpty(attachmentHelper.getSelectedAttachments());
    }

    static class MessageComposerSelector implements StateSelector<MessageComposerModel> {

        @Override
        public MessageComposerModel selectData(@NonNull State data) {
            final StateAttachments attachments = StateAttachments.fromState(data);
            final StateConfig config = StateConfig.fromState(data);
            final StateConversation conversation = StateConversation.fromState(data);

            final List<StateRequestAttachment> allSelectedAttachments = new ArrayList<>(attachments
                    .getAllSelectedAttachments());
            final List<StateRequestAttachment> selectedAttachments = CollectionUtils.copyOf(attachments
                    .getSelectedAttachments());
            final boolean isSendButtonEnabled = StringUtils.hasLength(conversation.getRemoteId());
            final boolean isAttachmentsButtonEnabled = config.getSettings().isAttachmentsEnabled();
            final boolean showMessageComposer = conversation.getStatus() != RequestStatus.Closed;

            return new MessageComposerModel(
                    selectedAttachments,
                    allSelectedAttachments,
                    config.getSettings().getMaxAttachmentSize(),
                    isSendButtonEnabled,
                    isAttachmentsButtonEnabled,
                    showMessageComposer
            );
        }
    }

    static class MessageComposerModel {

        private final List<StateRequestAttachment> requestAttachments;
        private final List<StateRequestAttachment> extraAttachments;
        private final long maxFileSize;
        private final boolean sendButtonEnabled;
        private final boolean attachmentsButtonEnabled;
        private final boolean messageComposerVisible;

        MessageComposerModel(List<StateRequestAttachment> requestAttachments,
                             List<StateRequestAttachment> extraAttachments,
                             long maxFileSize,
                             boolean sendButtonEnabled,
                             boolean attachmentsButtonEnabled,
                             boolean messageComposerVisible) {
            this.requestAttachments = requestAttachments;
            this.extraAttachments = extraAttachments;
            this.maxFileSize = maxFileSize;
            this.sendButtonEnabled = sendButtonEnabled;
            this.attachmentsButtonEnabled = attachmentsButtonEnabled;
            this.messageComposerVisible = messageComposerVisible;
        }

        List<StateRequestAttachment> getRequestAttachments() {
            return requestAttachments;
        }

        long getMaxFileSize() {
            return maxFileSize;
        }

        boolean isSendButtonEnabled() {
            return sendButtonEnabled;
        }

        boolean isAttachmentsButtonEnabled() {
            return attachmentsButtonEnabled;
        }

        boolean isMessageComposerVisible() {
            return messageComposerVisible;
        }
    }
}
