package zendesk.support.request;

import android.content.Context;
import android.content.pm.ResolveInfo;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import zendesk.support.R;

import java.util.Date;
import java.util.List;

/**
 * Cell in stream. User. File attachment.
 */
class CellUserAttachmentGeneric extends CellBase implements CellType.Attachment, CellType.Stateful {

    private final StateRequestAttachment requestAttachment;
    private final StateMessage message;
    private final ResolveInfo appInfo;
    private final boolean markAsDelivered;
    private final boolean showError;
    private final Rect insets;
    private final List<StateMessage> erroredMessages;
    private final boolean lastErrorCellOfBlock;

    CellUserAttachmentGeneric(CellBindHelper utils, StateMessage message, StateRequestAttachment requestAttachment,
                              Date timeStamp, boolean markAsDelivered, boolean showError, List<StateMessage>
                                      erroredMessages,
                              boolean lastErrorCellOfBlock) {
        super(utils, R.layout.zs_request_user_attachment_generic, requestAttachment.getId(), GROUP_ID_END_USER,
                timeStamp);
        this.requestAttachment = requestAttachment;
        this.markAsDelivered = markAsDelivered;
        this.message = message;
        this.showError = showError;
        this.erroredMessages = erroredMessages;
        this.lastErrorCellOfBlock = lastErrorCellOfBlock;
        this.appInfo = utils.getAppInfo(requestAttachment.getName());
        this.insets = utils.getInsets(0, 0, 0, R.dimen.zs_request_message_inset_user_bottom);
    }

    @Override
    public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
        final TextView fileName = view.findCachedView(R.id.request_user_attachment_generic_name);
        fileName.setText(requestAttachment.getName());

        final TextView appName = view.findCachedView(R.id.request_user_attachment_generic_type);
        final ImageView appIcon = view.findCachedView(R.id.request_user_attachment_generic_icon);
        utils.bindAppInfo(appInfo, appName, appIcon);

        final CardView container = view.findCachedView(R.id.request_user_attachment_generic_container);
        utils.addOnClickListenerForFileAttachment(container, requestAttachment);

        final TextView statusLabel = view.findCachedView(R.id.request_user_attachment_generic_status);
        utils.bindStatusLabel(statusLabel, lastErrorCellOfBlock, markAsDelivered);

        // Error state
        final View.OnClickListener listener = utils.errorClickListener(showError, erroredMessages);
        view.itemView.setOnClickListener(listener);
        container.setCardBackgroundColor(utils.colorForError(showError));
        if (listener != null) {
            container.setOnClickListener(listener);
        }

        // Talk Back
        container.setContentDescription(buildTalkBackString(container.getContext()));
    }

    private String buildTalkBackString(Context context) {
        final StringBuilder talkBack = new StringBuilder();
        talkBack.append(context.getString(R.string.zs_request_message_user_file_accessibility, requestAttachment
                .getName()));
        talkBack.append(" ");

        if (!showError) {
            final CharSequence dateString = DateUtils.getRelativeTimeSpanString(context, message.getDate().getTime(),
                    true);
            talkBack.append(context.getString(R.string.zs_request_message_user_sent_accessibility, dateString));
        } else {
            talkBack.append(context.getString(R.string.zs_request_message_user_error_accessibility));
        }

        return talkBack.toString();
    }

    @Override
    public boolean areContentsTheSame(CellType.Base requestMessage) {
        boolean attachmentCell = utils.areAttachmentCellContentsTheSame(this, requestMessage);
        boolean stateFulCell = utils.areStatefulCellContentsTheSame(this, requestMessage);
        return attachmentCell && stateFulCell;
    }

    @Override
    public StateRequestAttachment getAttachment() {
        return requestAttachment;
    }

    @Override
    public boolean isMarkedAsDelivered() {
        return markAsDelivered;
    }

    @Override
    public CellType.Stateful markAsDelivered() {
        return new CellUserAttachmentGeneric(utils, message, requestAttachment, getTimeStamp(), true, showError,
                erroredMessages, lastErrorCellOfBlock);
    }

    @Override
    public CellType.Stateful markAsErrored(List<StateMessage> errorGroup, boolean endOfBlock) {
        return new CellUserAttachmentGeneric(utils, message, requestAttachment, getTimeStamp(), markAsDelivered,
                true, errorGroup, endOfBlock);
    }

    @Override
    public StateMessage getStateMessage() {
        return message;
    }

    @Override
    public List<StateMessage> getErrorGroupMessages() {
        return erroredMessages;
    }

    @Override
    public boolean isErrorShown() {
        return showError;
    }

    @Override
    public boolean isLastErrorCellOfBlock() {
        return lastErrorCellOfBlock;
    }

    @Override
    public Rect getInsets() {
        return insets;
    }
}