package zendesk.support.request;

import android.net.Uri;

import androidx.annotation.NonNull;

import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import zendesk.support.suas.Action;
import zendesk.support.suas.Reducer;

/**
 * Reducer for maintaining attachment related state, like selected attachments.
 */
class ReducerAttachments extends Reducer<StateAttachments> {

    private static final String LOG_FORMAT_ATTACHMENT_DROPPED = "Cannot add attachment %s. Size is %d, max attachment"
            + " size is %d.";
    private static final String LOG_MESSAGE_ATTACHMENTS_DISABLED = "Cannot add attachments, they are disabled in your"
            + " Zendesk settings.";


    public static List<StateRequestAttachment> updateSelectedAttachments(
            List<StateRequestAttachment> newAttachments,
            StateAttachments oldState
    ) {
        // Create a set of existing attachment identifiers from the old state
        Set<String> existingAttachmentIds = new HashSet<>();
        for (StateRequestAttachment attachment : oldState.getSelectedAttachments()) {
            existingAttachmentIds.add(attachment.getLocalUri());
        }

        // Filter new attachments to exclude those that already exist
        List<StateRequestAttachment> filteredNewAttachments = new ArrayList<>();
        for (StateRequestAttachment attachment : newAttachments) {
            if (!existingAttachmentIds.contains(attachment.getLocalUri())) {
                filteredNewAttachments.add(attachment);
            }
        }

        // Combine the old and new filtered lists
        return CollectionUtils.combineLists(filteredNewAttachments, oldState.getSelectedAttachments());
    }

    @Override
    public StateAttachments reduce(@NonNull StateAttachments oldState, @NonNull Action<?> action) {

        switch (action.getActionType()) {

            case ActionFactory.ATTACHMENTS_SELECTED: {
                final List<MediaResult> data = action.getData();

                final List<StateRequestAttachment> attachments = new ArrayList<>();
                for (MediaResult result : data) {
                    attachments.add(StateRequestAttachment.convert(result));
                }

                final List<StateRequestAttachment> selectedAttachments = updateSelectedAttachments(attachments, oldState);

                return oldState.newBuilder()
                        .addAllSelectedAttachments(attachments)
                        .setSelectedAttachments(selectedAttachments)
                        .build();
            }

            case ActionFactory.START_CONFIG: {
                final RequestConfiguration data = action.getData();

                final List<StateRequestAttachment> attachments = data.getFiles();

                return oldState.newBuilder()
                        .addAllSelectedAttachments(attachments)
                        .setSelectedAttachments(attachments)
                        .build();
            }

            case ActionFactory.ATTACHMENTS_DESELECTED: {
                final List<MediaResult> data = action.getData();

                final Set<Uri> attachments = new HashSet<>();
                for (MediaResult result : data) {
                    attachments.add(result.getOriginalUri());
                }

                final List<StateRequestAttachment> selectedAttachments = new ArrayList<>();
                for (StateRequestAttachment attachment : oldState.getSelectedAttachments()) {
                    if (!attachments.contains(attachment.getParsedLocalUri())) {
                        selectedAttachments.add(attachment);
                    }
                }

                return oldState.newBuilder()
                        .setSelectedAttachments(selectedAttachments)
                        .build();
            }

            case ActionFactory.LOAD_SETTINGS_SUCCESS: {
                final StateSettings data = action.getData();

                List<StateRequestAttachment> validAttachments = new ArrayList<>();

                if (data.isAttachmentsEnabled()) {
                    long maxAttachmentSize = data.getMaxAttachmentSize();

                    for (StateRequestAttachment attachment : oldState.getSelectedAttachments()) {
                        if (attachment.getSize() > maxAttachmentSize) {
                            Logger.d(RequestActivity.LOG_TAG, LOG_FORMAT_ATTACHMENT_DROPPED,
                                    attachment.getName(), attachment.getSize(), maxAttachmentSize);
                        } else {
                            validAttachments.add(attachment);
                        }
                    }
                } else {
                    Logger.w(RequestActivity.LOG_TAG, LOG_MESSAGE_ATTACHMENTS_DISABLED);
                    return new StateAttachments();
                }
                return oldState.newBuilder()
                        .setSelectedAttachments(validAttachments)
                        .build();
            }

            case ActionFactory.CLEAR_ATTACHMENTS: {
                return new StateAttachments();
            }

        }

        return null;
    }

    @NonNull
    @Override
    public StateAttachments getInitialState() {
        return new StateAttachments();
    }
}
