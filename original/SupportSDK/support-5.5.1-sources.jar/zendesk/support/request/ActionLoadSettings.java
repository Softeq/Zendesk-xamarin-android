package zendesk.support.request;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.StringUtils;

import zendesk.core.AnonymousIdentity;
import zendesk.core.AuthenticationProvider;
import zendesk.core.Identity;
import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.GetState;
import zendesk.support.SupportSdkSettings;
import zendesk.support.SupportSettingsProvider;

/**
 * Load settings from Core.
 */
class ActionLoadSettings implements AsyncMiddleware.AsyncAction {

    private final ActionFactory actionFactory;
    private final SupportSettingsProvider settingsProvider;
    private final AuthenticationProvider authProvider;

    ActionLoadSettings(ActionFactory actionFactory, SupportSettingsProvider settingsProvider,
                       AuthenticationProvider authProvider) {
        this.actionFactory = actionFactory;
        this.settingsProvider = settingsProvider;
        this.authProvider = authProvider;
    }

    @Override
    public void actionQueued(Dispatcher dispatcher, GetState state) {
        dispatcher.dispatch(actionFactory.loadSettings());
    }

    @Override
    public void execute(final Dispatcher dispatcher, GetState state, final AsyncMiddleware.Callback callback) {
        settingsProvider.getSettings(new ZendeskCallback<SupportSdkSettings>() {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                final StateSettings settings = constructSettings(supportSdkSettings);
                dispatcher.dispatch(actionFactory.loadSettingsSuccess(settings));
                callback.done();
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.w(RequestActivity.LOG_TAG, "Error loading settings. Error: '%s'", errorResponse.getReason());
                dispatcher.dispatch(actionFactory.loadSettingsError(errorResponse));
                callback.done();
            }
        });
    }

    private StateSettings constructSettings(SupportSdkSettings supportSdkSettings) {
        Identity identity = authProvider.getIdentity();

        if (identity instanceof AnonymousIdentity) {
            AnonymousIdentity anonymousIdentity = (AnonymousIdentity) identity;
            boolean hasEmailAddress = StringUtils.hasLength(anonymousIdentity.getEmail());
            boolean hasName = StringUtils.hasLength(anonymousIdentity.getName());

            return StateSettings.fromSupportSettings(supportSdkSettings, hasEmailAddress, hasName);
        } else {
            return StateSettings.fromSupportSettings(supportSdkSettings, true, true);
        }
    }
}