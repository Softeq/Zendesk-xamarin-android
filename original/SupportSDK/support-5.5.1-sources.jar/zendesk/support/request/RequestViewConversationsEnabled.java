package zendesk.support.request;

import android.annotation.SuppressLint;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ListUpdateCallback;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import com.squareup.picasso.Picasso;
import javax.inject.Inject;

import zendesk.commonui.BottomSheetAttachmentViewMenu;
import zendesk.commonui.SystemWindowInsets;
import zendesk.support.R;
import zendesk.commonui.InsetType;
import zendesk.support.suas.CombinedSubscription;
import zendesk.support.suas.Store;
import zendesk.support.suas.Subscription;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Screen: Conversations enabled. Chat. For Zendesk internal use only.
 */
@SuppressLint("ViewConstructor")
@RestrictTo(LIBRARY)
public class RequestViewConversationsEnabled extends FrameLayout implements RequestView {

    private AppCompatActivity activity;
    private Subscription subscription;
    private ViewMessageComposer messageComposerView;
    private ComponentMessageComposer messageComposerComponent;
    private RecyclerView recyclerView;
    private View toolbarContainer;
    private View toolbar;
    private BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu;

    @Inject
    Store store;
    @Inject
    ActionFactory actionFactory;
    @Inject
    CellFactory cellFactory;
    @Inject
    Picasso picasso;

    public RequestViewConversationsEnabled(@NonNull Context context) {
        super(context);
        viewInit(context);
    }

    public RequestViewConversationsEnabled(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        viewInit(context);
    }

    public RequestViewConversationsEnabled(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        viewInit(context);
    }

    private void viewInit(Context context) {
        inflate(context, R.layout.zs_view_request_conversations_enabled, this);
        activity = (AppCompatActivity) context;
    }

    void init(
            RequestComponent component,
            boolean isCleanStart,
            BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu
    ) {
        component.inject(this);
        bindViews();
        this.bottomSheetAttachmentViewMenu = bottomSheetAttachmentViewMenu;
        subscription = bindComponents(store);
        subscription.informWithCurrentState();

        if (isCleanStart) {

            // load comments from cache
            store.dispatch(actionFactory.loadCommentsFromCacheAsync());

            // load request info
            store.dispatch(actionFactory.loadRequestAsync());

            // load comments from network
            store.dispatch(actionFactory.initialLoadCommentsAsync());

            messageComposerView.requestFocusForInput();
        }
    }

    @Override
    public boolean inflateMenu(MenuInflater menuInflater, Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemClicked(MenuItem item) {
        return false;
    }

    @Override
    public boolean hasUnsavedInput() {
        return messageComposerComponent != null && messageComposerComponent.hasUnsavedInput();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (subscription != null) {
            subscription.removeListener();
        }
    }

    private void bindViews() {
        recyclerView = findViewById(R.id.activity_request_recycler_view);
        messageComposerView = findViewById(R.id.activity_request_message_composer);
        toolbarContainer = activity.findViewById(R.id.activity_request_appbar);
        toolbar = activity.findViewById(R.id.activity_request_toolbar);
        applyWindowInsets();
        messageComposerView.init();
    }

    private void applyWindowInsets(){
        SystemWindowInsets.applyWindowInsets(recyclerView, InsetType.HORIZONTAL);
    }

    private Subscription bindComponents(Store store) {
        return CombinedSubscription.from(
                bindMessageComposer(store),
                bindRecycler(store),
                bindDialogComponent(store)
        );
    }

    private Subscription bindMessageComposer(final Store store) {
        messageComposerComponent = new ComponentMessageComposer(
                messageComposerView,
                store,
                actionFactory,
                bottomSheetAttachmentViewMenu
        );

        return store.addListener(messageComposerComponent.getSelector(), messageComposerComponent);
    }

    private Subscription bindRecycler(final Store store) {
        final LinearLayoutManager layoutManager = new LinearLayoutManager(activity);
        final RecyclerListener recyclerListener = new RecyclerListener(recyclerView, layoutManager);
        final ComponentRequestAdapter component = new ComponentRequestAdapter(recyclerListener, cellFactory,
                recyclerView);
        final RecyclerView.ItemDecoration marginDecorator = new CellMarginDecorator(component, activity);
        final RecyclerView.ItemAnimator itemAnimator = new RequestItemAnimator(component);
        final RecyclerView.Adapter adapter = new ComponentRequestAdapter.RequestAdapter(component);

        recyclerView.setItemAnimator(itemAnimator);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(marginDecorator);
        recyclerView.setAdapter(adapter);
        recyclerView.setNestedScrollingEnabled(false);

        messageComposerView.setOnHeightChangeListener(recyclerListener);
        messageComposerView.addOnFocusChangeListener(recyclerListener);
        recyclerView.addOnLayoutChangeListener(recyclerListener);

        return store.addListener(component.getSelector(), component);
    }

    private Subscription bindDialogComponent(final Store store) {
        final ComponentDialog component = new ComponentDialog(activity, actionFactory, store);

        return store.addListener(StateUi.class, component);
    }


    /**
     * ItemAnimator for RecyclerView.
     * <br />
     * It makes sure that image attachments don't flicker on an update.
     */
    static class RequestItemAnimator extends DefaultItemAnimator {

        private final ComponentRequestAdapter component;

        RequestItemAnimator(ComponentRequestAdapter component) {
            this.component = component;
            setSupportsChangeAnimations(false);
        }

        @Override
        public boolean canReuseUpdatedViewHolder(@NonNull RecyclerView.ViewHolder viewHolder) {
            if (component.getMessageForPos(viewHolder.getAdapterPosition()) instanceof CellType.Attachment) {
                // Tell the RecyclerView to use the same ViewHolder for onItemChangeAnimations and
                // don't create a new one.
                // This prevents flickering and double loading of images during onItemChangeAnimations.
                return true;
            }

            return super.canReuseUpdatedViewHolder(viewHolder);
        }
    }

    /**
     * Helper class for implementing the scrolling behavior of our RecyclerView.
     */
    static class RecyclerListener implements ViewMessageComposer.OnHeightChangeListener,
            OnFocusChangeListener, OnLayoutChangeListener, ListUpdateCallback {

        private static final int SCROLL_INSTANT = 1;
        private static final int SCROLL_SMOOTH_FIXED_VELOCITY = 2;
        private static final int SCROLL_SMOOTH_FIXED_TIME = 3;

        private static final int FIXED_SCROLL_TIME = 50;

        private final RecyclerView recyclerView;
        private final LinearLayoutManager linearLayoutManager;
        private final int recyclerDefaultBottomPadding;

        RecyclerListener(RecyclerView recyclerView, LinearLayoutManager linearLayoutManager) {
            this.recyclerView = recyclerView;
            this.linearLayoutManager = linearLayoutManager;
            this.recyclerDefaultBottomPadding = recyclerView.getResources().getDimensionPixelOffset(R.dimen
                    .zs_request_recycler_padding_bottom);
        }

        @Override
        public void onHeightChange(final int currentHeight) {
            recyclerView.post(new Runnable() {
                @Override
                public void run() {
                    final int paddingLeft = recyclerView.getPaddingLeft();
                    final int paddingRight = recyclerView.getPaddingRight();
                    final int paddingTop = recyclerView.getPaddingTop();

                    int paddingBottom = recyclerDefaultBottomPadding;
                    if (currentHeight > 0) {
                        paddingBottom += currentHeight;
                    }

                    if (paddingBottom != recyclerView.getPaddingBottom()) {
                        recyclerView.setPadding(paddingLeft, paddingTop, paddingRight, paddingBottom);
                        scrollToBottom(SCROLL_INSTANT);
                    }
                }
            });
        }

        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            // scroll to bottom if the message input got focus
            if (hasFocus) {
                postScrollToBottom(SCROLL_SMOOTH_FIXED_VELOCITY);
            }
        }

        @Override
        public void onLayoutChange(View v, int left, int top, int right, int bottom,
                                   int oldLeft, int oldTop, int oldRight, int oldBottom) {
            // scroll to bottom if keyboard appears
            if (bottom < oldBottom) {
                postScrollToBottom(SCROLL_INSTANT);
            }
        }

        @Override
        public void onInserted(final int position, final int count) {
            // scroll to bottom if a new item was added to the stream
            recyclerView.getAdapter().notifyItemRangeChanged(position, count);
            postScrollToBottom(SCROLL_SMOOTH_FIXED_TIME);
        }

        @Override
        public void onRemoved(int position, int count) {
            recyclerView.getAdapter().notifyItemRangeRemoved(position, count);
        }

        @Override
        public void onMoved(int fromPosition, int toPosition) {
            recyclerView.getAdapter().notifyItemMoved(fromPosition, toPosition);
        }

        @Override
        public void onChanged(int position, int count, Object payload) {
            recyclerView.getAdapter().notifyItemRangeChanged(position, count, payload);
        }

        private void scrollToBottom(final int scrollMode) {
            final int lastItem = recyclerView.getAdapter().getItemCount() - 1;
            if (lastItem >= 0) {
                if (scrollMode == SCROLL_INSTANT) {
                    final RecyclerView.ViewHolder lastViewHolder =
                            recyclerView.findViewHolderForAdapterPosition(lastItem);
                    final int lastItemHeight = lastViewHolder != null && lastViewHolder.itemView != null
                            ? lastViewHolder.itemView.getHeight()
                            : 0;

                    final int offset = (recyclerView.getPaddingBottom() + lastItemHeight) * -1;
                    linearLayoutManager.scrollToPositionWithOffset(lastItem, offset);

                } else if (scrollMode == SCROLL_SMOOTH_FIXED_TIME) {
                    final LinearSmoothScroller linearSmoothScroller = new LinearSmoothScroller(recyclerView
                            .getContext()) {
                        @Override
                        protected int calculateTimeForScrolling(int dx) {
                            return FIXED_SCROLL_TIME;
                        }
                    };

                    linearSmoothScroller.setTargetPosition(lastItem);
                    recyclerView.getLayoutManager().startSmoothScroll(linearSmoothScroller);

                } else if (scrollMode == SCROLL_SMOOTH_FIXED_VELOCITY) {
                    final LinearSmoothScroller linearSmoothScroller = new LinearSmoothScroller(recyclerView
                            .getContext());
                    linearSmoothScroller.setTargetPosition(lastItem);
                    recyclerView.getLayoutManager().startSmoothScroll(linearSmoothScroller);
                }
            }
        }

        private void postScrollToBottom(final int scrollMode) {
            recyclerView.post(new Runnable() {
                @Override
                public void run() {
                    scrollToBottom(scrollMode);
                }
            });
        }
    }
}