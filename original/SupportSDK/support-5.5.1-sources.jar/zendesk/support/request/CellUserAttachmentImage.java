package zendesk.support.request;

import android.content.Context;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import android.text.format.DateUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import zendesk.support.R;

import java.util.Date;
import java.util.List;

/**
 * Cell in stream. User. Image attachment.
 */
class CellUserAttachmentImage extends CellBase implements CellType.Attachment, CellType.Stateful {

    private final StateRequestAttachment attachment;
    private final StateMessage message;
    private final boolean markAsDelivered;
    private final boolean showError;
    private final Rect insets;
    private final List<StateMessage> erroredMessages;
    private final boolean lastErrorCellOfBlock;

    CellUserAttachmentImage(CellBindHelper utils, StateMessage message, StateRequestAttachment attachment, Date
            timeStamp,
                            boolean markAsDelivered, boolean showError, List<StateMessage> erroredMessages, boolean
                                    lastErrorCellOfBlock) {
        super(utils, R.layout.zs_request_user_attachment_image, attachment.getId(), GROUP_ID_END_USER, timeStamp);
        this.message = message;
        this.attachment = attachment;
        this.markAsDelivered = markAsDelivered;
        this.showError = showError;
        this.erroredMessages = erroredMessages;
        this.insets = utils.getInsets(0, 0, 0, R.dimen.zs_request_message_inset_user_bottom);
        this.lastErrorCellOfBlock = lastErrorCellOfBlock;
    }

    @Override
    public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
        final ImageView imageView = view.findCachedView(R.id.request_user_message_attachment_image);
        utils.bindImage(imageView, attachment);
        utils.addOnClickListenerForImageAttachment(imageView, attachment);

        final TextView statusLabel = view.findCachedView(R.id.request_user_attachment_image_status);
        utils.bindStatusLabel(statusLabel, lastErrorCellOfBlock, markAsDelivered);

        // Error state
        final View.OnClickListener listener = utils.errorClickListener(showError, erroredMessages);
        view.itemView.setOnClickListener(listener);
        imageView.setColorFilter(utils.colorForErrorImage(showError));
        if (listener != null) {
            imageView.setOnClickListener(listener);
        }

        // Talk Back
        final View container = view.findCachedView(R.id.request_user_message_attachment_container);
        container.setContentDescription(buildTalkBackString(container.getContext()));
    }

    private String buildTalkBackString(Context context) {
        final StringBuilder talkBack = new StringBuilder();
        talkBack.append(context.getString(R.string.zs_request_message_user_image_accessibility, attachment.getName()));
        talkBack.append(" ");

        if (!showError) {
            final CharSequence dateString = DateUtils.getRelativeTimeSpanString(context, message.getDate().getTime(),
                    true);
            talkBack.append(context.getString(R.string.zs_request_message_user_sent_accessibility, dateString));
        } else {
            talkBack.append(context.getString(R.string.zs_request_message_user_error_accessibility));
        }

        return talkBack.toString();
    }

    @Override
    public StateRequestAttachment getAttachment() {
        return attachment;
    }

    @Override
    public boolean isMarkedAsDelivered() {
        return markAsDelivered;
    }

    @Override
    public CellType.Stateful markAsDelivered() {
        return new CellUserAttachmentImage(utils, message, attachment, getTimeStamp(), true, showError,
                erroredMessages, lastErrorCellOfBlock);
    }

    @Override
    public CellType.Stateful markAsErrored(List<StateMessage> errorGroup, boolean endOfBlock) {
        return new CellUserAttachmentImage(utils, message, attachment, getTimeStamp(), markAsDelivered, true,
                errorGroup, endOfBlock);
    }

    @Override
    public StateMessage getStateMessage() {
        return message;
    }

    @Override
    public List<StateMessage> getErrorGroupMessages() {
        return erroredMessages;
    }

    @Override
    public boolean isErrorShown() {
        return showError;
    }

    @Override
    public boolean isLastErrorCellOfBlock() {
        return lastErrorCellOfBlock;
    }

    @Override
    public boolean areContentsTheSame(CellType.Base requestMessage) {
        boolean attachmentCell = utils.areAttachmentCellContentsTheSame(this, requestMessage);
        boolean statefulCell = utils.areStatefulCellContentsTheSame(this, requestMessage);
        return attachmentCell && statefulCell;
    }

    @Override
    public Rect getInsets() {
        return insets;
    }
}