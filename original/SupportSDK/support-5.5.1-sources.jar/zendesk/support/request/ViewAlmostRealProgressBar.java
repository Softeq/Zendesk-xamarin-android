package zendesk.support.request;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.view.animation.DecelerateInterpolator;
import android.widget.ProgressBar;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * It's a {@link ProgressBar} that pretends to be deterministic but it's not. For Zendesk internal
 * use only.
 */
@RestrictTo(LIBRARY)
public class ViewAlmostRealProgressBar extends ProgressBar {

    public static final long STOP_ANIMATION_DURATION = 300L;
    public static final long ALPHA_FADE_DURATION = 100L;

    public static final long STOP_DEBOUNCE_TIME = 200L;
    public static final long START_DEBOUNCE_TIME = 100L;

    public static final List<Step> SIMPLE_PROGRESSBAR =
            Collections.singletonList(new Step(60, 4000L));

    public static final List<Step> DONT_STOP_MOVING =
            Arrays.asList(new Step(60, 4000L), new Step(90, 15000L));

    private StateAwareAnimator progressAnimator;
    private StateAwareAnimator finishAnimator;
    private List<Step> steps;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable stopDebounceRunnable;
    private Runnable startDebounceRunnable;

    public ViewAlmostRealProgressBar(Context context) {
        super(context);
    }

    public ViewAlmostRealProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ViewAlmostRealProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public void start(final List<Step> steps) {
        if (stopDebounceRunnable != null) {
            // Stop called, but still debouncing, remove callback and we're fine
            handler.removeCallbacks(stopDebounceRunnable);
            stopDebounceRunnable = null;

        } else if (startDebounceRunnable == null) {
            // Start animation
            startDebounceRunnable = new Runnable() {
                @Override
                public void run() {
                    startDebounceRunnable = null;
                    final List<Step> sortedSteps = CollectionUtils.copyOf(steps);
                    Collections.sort(sortedSteps);
                    ViewAlmostRealProgressBar.this.steps = sortedSteps;
                    kickOffAnimation(ViewAlmostRealProgressBar.this.steps, 0);
                }
            };
            handler.postDelayed(startDebounceRunnable, START_DEBOUNCE_TIME);

        }
    }

    public void stop(final long animationTime) {
        if (startDebounceRunnable != null) {
            // Animation never started, no need to stop it
            handler.removeCallbacks(startDebounceRunnable);
            startDebounceRunnable = null;

        } else if (stopDebounceRunnable == null) {
            stopDebounceRunnable = new Runnable() {
                @Override
                public void run() {
                    stopDebounceRunnable = null;
                    finishAnimation(animationTime);
                }
            };
            handler.postDelayed(stopDebounceRunnable, STOP_DEBOUNCE_TIME);

        }
    }

    private void finishAnimation(long animationTime) {
        if (progressAnimator != null) {

            progressAnimator.get().cancel();
            progressAnimator = null;

            finishAnimator = endAnimation(animationTime);
            finishAnimator.get().start();
        }
    }

    private void kickOffAnimation(List<Step> steps, int startValue) {
        if (progressAnimator == null) {
            long offset = 0;
            if (finishAnimator != null && finishAnimator.isStarted() && !finishAnimator.isEnded()) {
                offset = finishAnimator.get().getDuration();
            }

            finishAnimator = null;
            progressAnimator = startAnimation(steps, startValue, offset);
            progressAnimator.get().start();
        }
    }

    private StateAwareAnimator startAnimation(List<Step> steps, int start, long offset) {
        final List<Animator> animations = new ArrayList<>(steps.size());
        int prevTarget = start;

        for (Step step : steps) {
            final Animator animator = progressAnimator(prevTarget, step.target, step.time);
            prevTarget = step.target;
            animations.add(animator);
        }

        final AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.playSequentially(animations);
        animatorSet.setStartDelay(offset);

        return new StateAwareAnimator(animatorSet);
    }

    private StateAwareAnimator endAnimation(long time) {
        final Animator finishProgressbar = progressAnimator(getProgress(), 100, time);
        final Animator fadeProgressbarOut = progressBarAlphaAnimator(1f, 0f, ALPHA_FADE_DURATION);

        final Animator resetProgressbarToZero = progressAnimator(100, 0, 0L);
        final Animator fadeProgressbarIn = progressBarAlphaAnimator(0f, 1f, 0L);

        final AnimatorSet finishProgressbarAnimatorSet = new AnimatorSet();
        finishProgressbarAnimatorSet
                .play(finishProgressbar)
                .before(fadeProgressbarOut);

        final AnimatorSet resetAnimatorSet = new AnimatorSet();
        resetAnimatorSet
                .play(resetProgressbarToZero)
                .before(fadeProgressbarIn);

        final AnimatorSet finishAnimatorSet = new AnimatorSet();
        finishAnimatorSet.setDuration(time);
        finishAnimatorSet
                .play(finishProgressbarAnimatorSet)
                .before(resetAnimatorSet);

        return new StateAwareAnimator(finishAnimatorSet);
    }

    private void restoreProgress(State state) {
        if (state.progress > 0) {
            final List<Step> restoredSteps = new ArrayList<>(state.steps);
            final List<Step> remainingSteps = new ArrayList<>();

            int previousStep = 0;
            for (Step step : state.steps) {
                if (state.progress < step.target) {
                    remainingSteps.add(step);
                } else {
                    previousStep = step.target;
                }
            }

            if (CollectionUtils.isNotEmpty(remainingSteps)) {
                final Step step = remainingSteps.remove(0);
                remainingSteps.add(0, adjustTime(state.progress, previousStep, step));
            }

            kickOffAnimation(remainingSteps, state.progress);
            this.steps = restoredSteps;

        } else {
            setProgress(0);
        }
    }

    private Step adjustTime(int progress, int previousStepTarget, Step currentStep) {
        final float range = currentStep.target - previousStepTarget;
        final float posInRange = progress - previousStepTarget;

        final long adjustedTime = (long) (currentStep.time * (1.f - (posInRange / range)));
        return new Step(currentStep.target, adjustedTime);
    }

    private Animator progressBarAlphaAnimator(float start, float end, long duration) {
        final ObjectAnimator animator = ObjectAnimator.ofFloat(this, "alpha", start, end);
        animator.setDuration(duration);
        return animator;
    }

    private Animator progressAnimator(int start, int end, long duration) {
        final ObjectAnimator animator = ObjectAnimator.ofInt(this, "progress", start, end);
        animator.setInterpolator(new DecelerateInterpolator());
        animator.setDuration(duration);
        return animator;
    }

    @Override
    public Parcelable onSaveInstanceState() {
        if (progressAnimator != null && stopDebounceRunnable == null) {
            final Parcelable superState = super.onSaveInstanceState();
            return new State(superState, getProgress(), steps);

        } else {
            setProgress(0);
            return super.onSaveInstanceState();
        }
    }

    @Override
    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable progressBarState = parcelable;
        if (parcelable instanceof State) {
            final State state = (State) parcelable;
            restoreProgress(state);
            progressBarState = state.getSuperState();
        }

        super.onRestoreInstanceState(progressBarState);
    }

    static class Step implements Parcelable, Comparable<Step> {

        private final int target;
        private final long time;

        Step(int target, long time) {
            this.target = target;
            this.time = time;
        }

        Step(Parcel in) {
            target = in.readInt();
            time = in.readLong();
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel dest, int flags) {
            dest.writeInt(target);
            dest.writeLong(time);
        }

        public static final Creator<Step> CREATOR = new Creator<Step>() {
            @Override
            public Step createFromParcel(Parcel in) {
                return new Step(in);
            }

            @Override
            public Step[] newArray(int size) {
                return new Step[size];
            }
        };

        @Override
        public int compareTo(@NonNull Step o) {
            return target - o.target;
        }
    }

    static class State extends BaseSavedState {

        private final int progress;
        private final List<Step> steps;

        public State(Parcelable source, int progress, List<Step> steps) {
            super(source);
            this.progress = progress;
            this.steps = steps;
        }

        private State(Parcel in) {
            super(in);
            this.progress = in.readInt();
            this.steps = new ArrayList<>();
            in.readTypedList(steps, Step.CREATOR);
        }

        @Override
        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(progress);
            out.writeTypedList(steps);
        }

        public static final Parcelable.Creator<State> CREATOR =
                new Parcelable.Creator<State>() {
                    public State createFromParcel(Parcel in) {
                        return new State(in);
                    }

                    public State[] newArray(int size) {
                        return new State[size];
                    }
                };
    }

    private static class StateAwareAnimator extends AnimatorListenerAdapter {

        private final Animator animatorSet;

        private boolean started = false;
        private boolean ended = false;

        StateAwareAnimator(Animator animatorSet) {
            this.animatorSet = animatorSet;
            this.animatorSet.addListener(this);
        }

        Animator get() {
            return animatorSet;
        }

        boolean isStarted() {
            return started;
        }

        boolean isEnded() {
            return ended;
        }

        @Override
        public void onAnimationStart(Animator animation) {
            started = true;
            ended = false;
        }

        @Override
        public void onAnimationEnd(Animator animation) {
            started = false;
            ended = true;
        }

        @Override
        public void onAnimationCancel(Animator animation) {
            started = false;
            ended = true;
        }

        @Override
        public void onAnimationRepeat(Animator animation) {
            started = true;
            ended = false;
        }
    }
}