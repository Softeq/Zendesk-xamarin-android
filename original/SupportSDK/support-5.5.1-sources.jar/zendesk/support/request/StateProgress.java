package zendesk.support.request;

import java.io.Serializable;

import zendesk.support.suas.State;

/**
 * Root state data. Holding information about whether to show the progressbar or not.
 */
class StateProgress implements Serializable {

    static StateProgress fomState(State state) {
        final StateProgress progress = state.getState(StateProgress.class);
        if (progress != null) {
            return progress;
        } else {
            return new StateProgress();
        }
    }

    private final int runningRequests;

    StateProgress() {
        runningRequests = 0;
    }

    StateProgress(int runningRequests) {
        this.runningRequests = runningRequests;
    }

    int getRunningRequests() {
        return runningRequests;
    }

    StateProgress increment() {
        return new StateProgress(runningRequests + 1);
    }

    StateProgress decrement() {
        if (runningRequests > 0) {
            return new StateProgress(runningRequests - 1);
        } else {
            return new StateProgress(0);
        }
    }

    @Override
    public String toString() {
        return "Progress{" +
                "runningRequests=" + runningRequests +
                '}';
    }
}
