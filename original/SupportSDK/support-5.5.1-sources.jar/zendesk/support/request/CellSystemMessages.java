package zendesk.support.request;

import androidx.annotation.NonNull;
import android.widget.TextView;

import zendesk.support.R;

import java.util.Date;

import zendesk.support.RequestStatus;

/**
 * All the system message cells.
 */
class CellSystemMessages {

    /**
     * Cell in stream. System. Date.
     */
    static class CellDateMessage extends CellBase {

        CellDateMessage(CellBindHelper utils, long id, Date timestamp) {
            super(utils, R.layout.zs_request_date_message, id, GROUP_ID_SYSTEM_MESSAGE, timestamp);
        }

        @Override
        public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
            final TextView label = view.findCachedView(R.id.request_date_message_text);
            utils.bindDate(label, getTimeStamp());
        }

        @Override
        public boolean areContentsTheSame(CellType.Base requestMessage) {
            return getTimeStamp().equals(requestMessage.getTimeStamp());
        }
    }

    /**
     * Cell in stream. System message. Marks request as closed.
     */
    static class CellRequestStatus extends CellBase {

        private final RequestStatus requestStatus;

        CellRequestStatus(CellBindHelper utils, RequestStatus requestStatus) {
            super(utils, R.layout.zs_request_system_message, ID_SYSTEM_MESSAGE_REQUEST_CLOSED,
                    GROUP_ID_SYSTEM_MESSAGE, new Date());
            this.requestStatus = requestStatus;
        }

        @Override
        public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
            final TextView systemMessage = view.findCachedView(R.id.request_system_message_text);

            if (requestStatus == RequestStatus.Closed) {
                systemMessage.setText(R.string.request_system_message_closed_ticket);
            }
        }

        @Override
        public boolean areContentsTheSame(CellType.Base requestMessage) {
            return requestMessage instanceof CellRequestStatus;
        }
    }

    /**
     * Cell in stream. System message. Message after first delivered comment.
     */
    static class CellSystemMessage extends CellBase {

        private final String message;

        CellSystemMessage(Date timestamp, String message) {
            super(
                    null,
                    R.layout.zs_request_system_message,
                    ID_SYSTEM_MESSAGE_REQUEST_CREATED,
                    GROUP_ID_SYSTEM_MESSAGE,
                    timestamp
            );
            this.message = message;
        }

        @Override
        public void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view) {
            final TextView messageView = view.findCachedView(R.id.request_system_message_text);
            messageView.setText(message);
        }

        @Override
        public boolean areContentsTheSame(CellType.Base requestMessage) {
            return requestMessage instanceof CellSystemMessage;
        }
    }
}
