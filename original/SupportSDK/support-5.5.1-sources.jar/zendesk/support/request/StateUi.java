package zendesk.support.request;

import java.io.Serializable;

import zendesk.support.suas.State;

class StateUi implements Serializable {

    static StateUi fromState(State state) {
        final StateUi uiState = state.getState(StateUi.class);
        if (uiState != null) {
            return uiState;
        } else {
            return new StateUi();
        }
    }

    private final DialogState dialogState;

    StateUi(DialogState dialogState) {
        this.dialogState = dialogState;
    }

    StateUi() {
        dialogState = null;
    }

    DialogState getDialogState() {
        return dialogState;
    }

    StateUi setDialogState(DialogState dialogState) {
        return new StateUi(dialogState);
    }

    @Override
    public String toString() {
        return "UiState{" +
                "dialogState=" + dialogState +
                '}';
    }

    interface DialogState {

        DialogState setVisible(boolean visible);

        boolean isVisible();
    }
}
