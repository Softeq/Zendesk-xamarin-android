package zendesk.support.request;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import zendesk.core.ActionHandlerRegistry;
import zendesk.support.suas.Listener;
import zendesk.support.RequestStatus;
import zendesk.support.requestlist.RequestInfo;
import zendesk.support.requestlist.RequestInfoDataSource;
import zendesk.support.requestlist.RequestListActivity;

/**
 * Headless component for notifying the RequestList on changes.
 */
class ComponentUpdateActionHandlers implements Listener<StateConversation> {
    private final Context context;
    private final ActionHandlerRegistry actionHandlerRegistry;
    private final RequestInfoDataSource.LocalDataSource localDataSource;
    private final AsyncMiddleware.Queue queue = new AsyncMiddleware.Queue();

    ComponentUpdateActionHandlers(Context context, ActionHandlerRegistry actionHandlerRegistry,
                                  RequestInfoDataSource.LocalDataSource localDataSource) {
        this.context = context;
        this.actionHandlerRegistry = actionHandlerRegistry;
        this.localDataSource = localDataSource;
    }

    @Override
    public void update(@NonNull final StateConversation conversation) {
        final RequestInfo requestInfo = map(conversation);

        if (requestInfo != null) {
            if (!hasPendingMessages(conversation)) {
                queue.dispatch(new AsyncMiddleware.Item() {
                    @Override
                    public void execute(final AsyncMiddleware.Callback callback) {
                        localDataSource.insert(requestInfo, new RefreshCallback(callback));
                    }
                });
            }
        } else {
            queue.dispatch(new AsyncMiddleware.Item() {
                @Override
                public void execute(final AsyncMiddleware.Callback callback) {
                    localDataSource.remove(conversation.getLocalId(), new RefreshCallback(callback));
                }
            });
        }
    }

    private class RefreshCallback extends ZendeskCallback<List<RequestInfo>> {

        private final AsyncMiddleware.Callback callback;

        private RefreshCallback(AsyncMiddleware.Callback callback) {
            this.callback = callback;
        }

        @Override
        public void onSuccess(List<RequestInfo> requestInfos) {
            callback.done();
            if (!queue.isRunning()) {
                RequestListActivity.refresh(context, actionHandlerRegistry);
            }
        }

        @Override
        public void onError(ErrorResponse errorResponse) {
            callback.done();
            if (!queue.isRunning()) {
                RequestListActivity.refresh(context, actionHandlerRegistry);
            }
        }
    }

    private boolean hasPendingMessages(StateConversation conversation) {
        List<StateMessage> messages = conversation.getMessages();

        for (StateMessage message : messages) {
            if (message.getState().getStatus() == StateMessageStatus.PENDING) {
                return true;
            }
        }

        return false;
    }

    @Nullable
    private RequestInfo map(StateConversation conversation) {
        List<StateMessage> messages = conversation.getMessages();
        if (CollectionUtils.isEmpty(messages)) {
            return null;
        }

        String localId = conversation.getLocalId();
        String remoteId = conversation.getRemoteId();
        RequestStatus requestStatus = conversation.getStatus();
        StateMessage firstMessage = messages.get(0);
        int messageCount = conversation.getMessages().size();
        StateMessage lastMessage = messages.get(messageCount - 1);
        Date lastUpdated = lastMessage.getDate();
        List<RequestInfo.AgentInfo> agentInfos = getLast5AgentInfos(
                conversation.getMessages(), conversation.getUsers());
        RequestInfo.MessageInfo firstMessageInfo = new RequestInfo.MessageInfo(
                String.valueOf(firstMessage.getId()), firstMessage.getDate(), firstMessage.getBody());
        RequestInfo.MessageInfo lastMessageInfo = new RequestInfo.MessageInfo(
                String.valueOf(lastMessage.getId()), lastMessage.getDate(), lastMessage.getBody());

        Set<String> failedMessageIds = new HashSet<>();
        for (StateMessage message : messages) {
            String messageId = String.valueOf(message.getId());
            if (message.getState().getStatus() == StateMessageStatus.ERROR) {
                failedMessageIds.add(messageId);
            }
        }

        return new RequestInfo(localId, remoteId, requestStatus, false, lastUpdated,
                agentInfos, firstMessageInfo, lastMessageInfo, failedMessageIds);
    }

    private List<RequestInfo.AgentInfo> getLast5AgentInfos(List<StateMessage> messages,
                                                           List<StateRequestUser> users) {
        @SuppressLint("UseSparseArrays")
        Map<Long, StateRequestUser> agentMap = new HashMap<>(users.size());
        for (StateRequestUser user : users) {
            long userId = user.getId();
            if (user.isAgent() && !agentMap.containsKey(userId)) {
                agentMap.put(userId, user);
            }
        }

        List<RequestInfo.AgentInfo> agentInfos = new ArrayList<>();
        List<StateMessage> reversedMessage = CollectionUtils.copyOf(messages);
        Collections.reverse(reversedMessage);

        for (StateMessage message : reversedMessage) {
            long userId = message.getUserId();
            if (agentMap.containsKey(userId)) {
                StateRequestUser agent = agentMap.get(userId);
                RequestInfo.AgentInfo agentInfo = new RequestInfo.AgentInfo(
                        String.valueOf(userId), agent.getName(), agent.getAvatar());
                agentInfos.add(agentInfo);
                if (agentInfos.size() == 5) {
                    break;
                }
            }
        }

        Collections.reverse(agentInfos);

        return agentInfos;
    }
}
