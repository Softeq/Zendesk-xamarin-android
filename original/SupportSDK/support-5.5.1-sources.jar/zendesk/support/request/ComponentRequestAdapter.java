package zendesk.support.request;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.core.view.animation.PathInterpolatorCompat;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListUpdateCallback;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zendesk.support.suas.Listener;
import zendesk.support.suas.State;
import zendesk.support.suas.StateSelector;
import zendesk.support.RequestStatus;

/**
 * Component representing the message stream in the conversation on screen.
 */
class ComponentRequestAdapter implements Listener<List<CellType.Base>> {

    private static final long UPDATE_TIME_WINDOW = 200;

    private final List<CellType.Base> requestMessageList;
    private final ListUpdateCallback listUpdateCallback;
    private final RequestAdapterSelector requestAdapterSelector;
    private final RecyclerView recyclerView;

    private Runnable updateRunnable = null;

    ComponentRequestAdapter(ListUpdateCallback listUpdateCallback, CellFactory messageFactory, RecyclerView
            recyclerView) {
        this.listUpdateCallback = listUpdateCallback;
        this.recyclerView = recyclerView;
        this.requestMessageList = new ArrayList<>();
        this.requestAdapterSelector = new RequestAdapterSelector(messageFactory);
    }

    @VisibleForTesting
    ComponentRequestAdapter(List<CellType.Base> requestMessageList, ListUpdateCallback listUpdateCallback,
                            RequestAdapterSelector requestAdapterSelector, RecyclerView recyclerView) {
        this.requestMessageList = requestMessageList;
        this.listUpdateCallback = listUpdateCallback;
        this.requestAdapterSelector = requestAdapterSelector;
        this.recyclerView = recyclerView;
    }

    CellType.Base getMessageForPos(int position) {
        return requestMessageList.get(position);
    }

    int getMessageCount() {
        return requestMessageList.size();
    }

    @Override
    public void update(@NonNull final List<CellType.Base> cells) {
        recyclerView.removeCallbacks(updateRunnable);
        updateRunnable = new Runnable() {
            @Override
            public void run() {
                final List<CellType.Base> oldMessages = CollectionUtils.copyOf(requestMessageList);
                final List<CellType.Base> newMessages = CollectionUtils.copyOf(cells);

                updateDataSet(oldMessages, newMessages);
            }
        };

        recyclerView.postDelayed(updateRunnable, UPDATE_TIME_WINDOW);
    }

    StateSelector<List<CellType.Base>> getSelector() {
        return requestAdapterSelector;
    }

    private void updateDataSet(List<CellType.Base> oldList, List<CellType.Base> newList) {
        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(new DiffCalculator(oldList, newList), true);

        requestMessageList.clear();
        requestMessageList.addAll(newList);

        diffResult.dispatchUpdatesTo(listUpdateCallback);
    }

    private static class DiffCalculator extends DiffUtil.Callback {

        private final List<CellType.Base> oldList;
        private final List<CellType.Base> newList;

        private DiffCalculator(List<CellType.Base> oldList, List<CellType.Base> newList) {
            this.oldList = oldList;
            this.newList = newList;
        }

        @Override
        public int getOldListSize() {
            return oldList.size();
        }

        @Override
        public int getNewListSize() {
            return newList.size();
        }

        @Override
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            return oldList.get(oldItemPosition).getUniqueId() == newList.get(newItemPosition).getUniqueId();
        }

        @Override
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
            return oldList.get(oldItemPosition).areContentsTheSame(newList.get(newItemPosition));
        }
    }

    /**
     * {@link RecyclerView.Adapter} that powers the message stream in {@link RequestActivity}
     */
    static class RequestAdapter extends RecyclerView.Adapter<RequestViewHolder> {

        private final ComponentRequestAdapter dataSource;
        private int lastPosition = -1;

        RequestAdapter(ComponentRequestAdapter dataSource) {
            setHasStableIds(true);
            this.dataSource = dataSource;
        }

        @NonNull
        @Override
        public RequestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
            return new RequestViewHolder(v);
        }

        @Override
        @SuppressLint("RecyclerView")
        public void onBindViewHolder(@NonNull RequestViewHolder holder, int position) {
            dataSource.getMessageForPos(position).bind(holder);

            if (position > lastPosition && lastPosition != -1) {
                lastPosition = position;
                holder.startAnimation();

            }
            if (lastPosition == -1) {
                lastPosition = position;
            }
        }

        @Override
        public long getItemId(int position) {
            return dataSource.getMessageForPos(position).getUniqueId();
        }

        @Override
        public int getItemViewType(int position) {
            return dataSource.getMessageForPos(position).getLayoutId();
        }

        @Override
        public int getItemCount() {
            return dataSource.getMessageCount();
        }

        @Override
        public void onViewDetachedFromWindow(@NonNull RequestViewHolder holder) {
            super.onViewDetachedFromWindow(holder);
            holder.clearAnimation();
        }
    }

    static class RequestAdapterSelector implements StateSelector<List<CellType.Base>> {

        private final CellFactory messageFactory;

        RequestAdapterSelector(CellFactory messageFactory) {
            this.messageFactory = messageFactory;
        }

        @Nullable
        @Override
        public List<CellType.Base> selectData(@NonNull State state) {
            final StateConversation conversation = StateConversation.fromState(state);
            final StateSettings settings = StateConfig.fromState(state).getSettings();

            final RequestStatus ticketStatus = conversation.getStatus();
            final String systemMessage = settings.getSystemMessage();

            return messageFactory.generateCells(conversation.getMessages(), conversation.getUsers(), ticketStatus,
                    systemMessage);
        }
    }

    static class RequestViewHolder extends RecyclerView.ViewHolder {

        private static final TimeInterpolator TIME_INTERPOLATOR =
                PathInterpolatorCompat.create(0.2f, 0f, .4f, 1f);

        private static final long ANIMATION_DURATION = 250L;
        private static final float ANIMATION_HEIGHT_RATIO = 2f / 3f;

        @SuppressLint("UseSparseArrays")
        private final Map<Integer, View> viewCache = new HashMap<>();
        private ValueAnimator animation;

        RequestViewHolder(View itemView) {
            super(itemView);
        }

        void clearAnimation() {
            if (animation != null) {
                animation.cancel();
                itemView.setTranslationY(0);
            }
        }

        void startAnimation() {

            int height = itemView.getMeasuredHeight();
            if (height == 0) {
                itemView.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
                height = itemView.getMeasuredHeight();
            }

            animation = ValueAnimator.ofFloat(height * ANIMATION_HEIGHT_RATIO, 0);
            animation.setInterpolator(TIME_INTERPOLATOR);
            animation.setDuration(ANIMATION_DURATION);

            animation.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    itemView.setTranslationY((float) valueAnimator.getAnimatedValue());
                }
            });

            animation.start();
        }

        <E extends View> E findCachedView(@IdRes int id) {
            E result;

            synchronized (viewCache) {
                if (viewCache.containsKey(id)) {
                    //noinspection unchecked
                    result = (E) viewCache.get(id);
                } else {
                    result = itemView.findViewById(id);
                    viewCache.put(id, result);
                }
            }

            return result;
        }
    }
}
