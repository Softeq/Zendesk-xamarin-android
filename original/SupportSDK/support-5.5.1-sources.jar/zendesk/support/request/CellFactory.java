package zendesk.support.request;

import android.content.Context;
import androidx.annotation.VisibleForTesting;

import com.squareup.picasso.Picasso;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.ActionHandlerRegistry;
import zendesk.support.suas.Dispatcher;
import zendesk.support.RequestStatus;

/**
 * Factory for converting the request comments found in the store to cells we can render in the UI.
 */
class CellFactory {

    private final CellBindHelper utils;
    private final DocumentRenderer documentRenderer;
    private final DocumentRenderer.HtmlParser htmlParser;

    CellFactory(Context context, Picasso picasso, ActionFactory af, Dispatcher store,
                ActionHandlerRegistry registry, ConfigurationHelper configHelper, Configuration configuration, MediaResultUtility mediaResultUtility) {
        this.utils = new CellBindHelper(context, picasso, af, store, mediaResultUtility);
        this.htmlParser = new DocumentRenderer.HtmlParser();
        this.documentRenderer = new DocumentRenderer(context, registry, configHelper, configuration);
    }

    @VisibleForTesting
    CellFactory(CellBindHelper requestMessageUtil, DocumentRenderer.HtmlParser htmlParser, DocumentRenderer
            documentRenderer) {
        this.utils = requestMessageUtil;
        this.htmlParser = htmlParser;
        this.documentRenderer = documentRenderer;
    }

    public List<CellType.Base> generateCells(List<StateMessage> messages, List<StateRequestUser> users,
                                             RequestStatus requestStatus, String systemMessage) {

        final List<CellType.Base> viewModelList = new ArrayList<>();
        final StateMessage firstDeliveredMessage = findFirstDelivered(messages);

        for (StateMessage message : messages) {

            // Check if it's an agent message
            final StateRequestUser user = findUserForId(users, message.getUserId());
            final boolean isAgentMessage = isUserAgent(user);

            // Convert the message into 0-n separate cells
            final List<CellType.Base> cellsForMessage = getViewModelsForMessage(message, isAgentMessage, user);

            // Add the system message from settings to the stream
            final List<CellType.Base> cellsWithSystemMessage = insertSystemMessage(firstDeliveredMessage, message,
                    cellsForMessage, systemMessage, !isAgentMessage);

            viewModelList.addAll(cellsWithSystemMessage);
        }

        // Mark cells as errored
        final List<CellType.Base> erroredCells = markCellsErrored(viewModelList);

        // Mark the last delivered cell as delivered
        final List<CellType.Base> lastDeliveredCellMarked = markLastDeliveredCell(erroredCells);

        // Inject date system messages
        final List<CellType.Base> cellsWithDateMessages = insertDateCells(lastDeliveredCellMarked);

        // Check the request status. If closed add a system message to the end.
        final List<CellType.Base> cellsWithTicketStatus = insertRequestStatus(cellsWithDateMessages, requestStatus);

        // Make sure that we show the name of the agent beneath a block of agent messages
        final List<CellType.Base> cellsWithAgents = markAgentCells(cellsWithTicketStatus);

        // Calculate position types. To make sure that CellMarginDecorator knows what to do.
        // This must be the last operation.
        return calculatePositionTypes(cellsWithAgents);
    }

    @VisibleForTesting
    List<CellType.Base> markAgentCells(List<CellType.Base> cells) {

        long prevId = Long.MIN_VALUE;

        for (int i = cells.size() - 1; i >= 0; i--) {
            if (cells.get(i) instanceof CellType.Agent) {
                CellType.Agent agentCell = (CellType.Agent) cells.get(i);
                if (prevId != agentCell.getAgent().getId()) {
                    agentCell.showAgentName(true);
                    prevId = agentCell.getAgent().getId();
                } else {
                    agentCell.showAgentName(false);
                }
            } else {
                prevId = Long.MIN_VALUE;
            }
        }

        return cells;
    }

    @VisibleForTesting
    List<CellType.Base> markCellsErrored(List<CellType.Base> cells) {

        final List<CellType.Stateful> carryOver = new ArrayList<>();
        final Set<StateMessage> carryOverMessages = new LinkedHashSet<>();

        final List<CellType.Base> newList = new ArrayList<>();

        for (CellType.Base cell : cells) {
            if (cell instanceof CellType.Stateful) {
                final CellType.Stateful stateful = (CellType.Stateful) cell;

                if (stateful.getStateMessage().getState().getStatus() == StateMessageStatus.ERROR) {
                    carryOver.add(stateful);
                    carryOverMessages.add(stateful.getStateMessage());

                } else {
                    newList.addAll(markMessagesAsErrored(carryOver, carryOverMessages));
                    newList.add(cell);
                    carryOver.clear();
                    carryOverMessages.clear();
                }

            } else {
                newList.addAll(markMessagesAsErrored(carryOver, carryOverMessages));
                newList.add(cell);
                carryOver.clear();
                carryOverMessages.clear();
            }
        }

        newList.addAll(markMessagesAsErrored(carryOver, carryOverMessages));

        return newList;
    }

    private List<CellType.Base> markMessagesAsErrored(Collection<CellType.Stateful> cells, Collection<StateMessage>
            messages) {
        final List<CellType.Base> newCells = new ArrayList<>(cells.size());

        final Iterator<CellType.Stateful> iterator = cells.iterator();
        while (iterator.hasNext()) {
            CellType.Stateful cell = iterator.next();
            boolean isLastCell = !iterator.hasNext();
            newCells.add(cell.markAsErrored(new ArrayList<>(messages), isLastCell));
        }

        return newCells;
    }

    @VisibleForTesting
    List<CellType.Base> insertRequestStatus(List<CellType.Base> cells, RequestStatus ticketStatus) {
        if (ticketStatus == RequestStatus.Closed && cells.size() > 0) {
            cells.add(new CellSystemMessages.CellRequestStatus(utils, ticketStatus));
        }

        return cells;
    }

    @VisibleForTesting
    List<CellType.Base> calculatePositionTypes(List<CellType.Base> cells) {

        if (CollectionUtils.isEmpty(cells)) {
            return cells;
        }

        final List<CellType.Base> newCells = new ArrayList<>(cells.size());
        long prevGroupId = -1;

        for (int i = 0; i < cells.size(); i++) {
            final CellType.Base cell = cells.get(i);

            if (i == 0 || cell.getGroupId() != prevGroupId) {
                cell.setPositionType(CellMarginDecorator.CELL_START_BLOCK);
            }

            if (cell instanceof CellType.Stateful) {
                CellType.Stateful stateful = (CellType.Stateful) cell;
                if (stateful.isMarkedAsDelivered() || stateful.isLastErrorCellOfBlock()) {
                    cell.setPositionType(CellMarginDecorator.CELL_WITH_LABEL);
                }
            }

            prevGroupId = cell.getGroupId();
            newCells.add(cell);
        }

        newCells.get(newCells.size() - 1).setPositionType(CellMarginDecorator.CELL_LAST);

        return newCells;
    }

    @VisibleForTesting
    List<CellType.Base> insertSystemMessage(StateMessage firstDelivered, StateMessage current, List<CellType.Base>
            cells, String systemMessage, boolean isUserMessage) {
        if (isUserMessage && current == firstDelivered && StringUtils.hasLength(systemMessage)) {
            cells.add(new CellSystemMessages.CellSystemMessage(current.getDate(), systemMessage));
        }

        return cells;
    }

    @VisibleForTesting
    StateMessage findFirstDelivered(List<StateMessage> messages) {
        for (StateMessage message : messages) {
            if (message.getState().getStatus() == StateMessageStatus.DELIVERED) {
                return message;
            }
        }

        return null;
    }

    @VisibleForTesting
    List<CellType.Base> insertDateCells(List<CellType.Base> cells) {
        final List<CellType.Base> cellsWithDate = new ArrayList<>(cells.size());

        Date lastDate = new Date(0);

        for (CellType.Base cell : cells) {
            if (!UtilsDate.isSameDay(lastDate, cell.getTimeStamp())) {
                final Date timestamp = cell.getTimeStamp();
                final long id = UtilsDate.getBeginOfDay(timestamp).getTime(); // stable ids for free
                cellsWithDate.add(new CellSystemMessages.CellDateMessage(utils, id, timestamp));
                lastDate = timestamp;
            }
            cellsWithDate.add(cell);
        }

        return cellsWithDate;
    }

    @VisibleForTesting
    List<CellType.Base> markLastDeliveredCell(List<CellType.Base> requestMessages) {

        boolean pending = false;
        for (CellType.Base cell : requestMessages) {
            if (cell instanceof CellType.Stateful) {
                if (((CellType.Stateful) cell).getStateMessage().getState().getStatus() == StateMessageStatus.PENDING) {
                    pending = true;
                    break;
                }
            }
        }

        final List<CellType.Base> result = new ArrayList<>(requestMessages.size());

        if (!pending) {

            boolean lastStateFulCellFound = false;
            for (int i = requestMessages.size() - 1; i >= 0; i--) {

                CellType.Base cell = requestMessages.get(i);
                if (cell instanceof CellType.Stateful && !lastStateFulCellFound) {
                    lastStateFulCellFound = true;
                    final CellType.Stateful statefulCell = (CellType.Stateful) cell;
                    if (statefulCell.getStateMessage().getState().getStatus() == StateMessageStatus.DELIVERED) {
                        cell = statefulCell.markAsDelivered();
                    }
                }

                result.add(cell);
            }

            Collections.reverse(result);

        } else {
            result.addAll(requestMessages);
        }

        return result;
    }

    List<CellType.Base> getViewModelsForMessage(StateMessage message, boolean isAgentMessage, StateRequestUser user) {
        final List<StateRequestAttachment> attachments = message.getAttachments();
        final List<CellType.Base> requestMessages = new ArrayList<>();

        if (isAgentMessage) {
            requestMessages.add(getAgentMessage(message, user));
        } else {
            requestMessages.addAll(getUserMessage(message));
        }

        for (int i = 0, c = attachments.size(); i < c; i++) {
            final StateRequestAttachment attachment = attachments.get(i);

            if (isAgentMessage) {
                requestMessages.add(getAgentAttachment(attachment, user, message.getDate()));
            } else {
                requestMessages.add(getUserAttachment(message, attachment, message.getDate()));
            }
        }

        return requestMessages;
    }

    @VisibleForTesting
    CellType.Base getAgentAttachment(StateRequestAttachment attachment, StateRequestUser user, Date timeStamp) {
        if (UtilsAttachment.isImageAttachment(attachment)) {
            return new CellAgentAttachmentImage(utils, attachment, user, timeStamp);
        } else {
            return new CellAgentAttachmentGeneric(utils, attachment, user, timeStamp);
        }
    }

    @VisibleForTesting
    CellType.Base getAgentMessage(StateMessage message, StateRequestUser user) {
        return new CellAgentMessage(
                utils,
                message,
                generateRichText(message.getHtmlBody(), message.getPlainBody()),
                user
        );
    }

    @VisibleForTesting
    CellType.Base getUserAttachment(StateMessage message, StateRequestAttachment attachment, Date timeStamp) {
        if (UtilsAttachment.isImageAttachment(attachment)) {
            return new CellUserAttachmentImage(utils, message, attachment, timeStamp, false, false, new
                    ArrayList<StateMessage>(0), false);
        } else {
            return new CellUserAttachmentGeneric(utils, message, attachment, timeStamp, false, false, new
                    ArrayList<StateMessage>(0), false);
        }
    }

    @VisibleForTesting
    List<CellType.Base> getUserMessage(StateMessage message) {
        if (!UtilsAttachment.hasAttachmentBody(message)) {
            final CharSequence body = generateRichText(message.getHtmlBody(), message.getPlainBody());
            final CellUserMessage userMessage = new CellUserMessage(utils, message, false, false, body, new
                    ArrayList<StateMessage>(0), false);
            return Collections.<CellType.Base>singletonList(userMessage);
        }

        return new ArrayList<>();
    }

    @VisibleForTesting
    boolean isUserAgent(StateRequestUser requestUser) {
        return requestUser != null && requestUser.isAgent();
    }

    @VisibleForTesting
    StateRequestUser findUserForId(List<StateRequestUser> users, long id) {
        for (StateRequestUser requestUser : users) {
            if (requestUser.getId() == id) {
                return requestUser;
            }
        }
        return null;
    }

    private CharSequence generateRichText(String htmlBody, String plainBody) {
        return documentRenderer.render(htmlParser.parse(htmlBody, plainBody));
    }
}
