package zendesk.support.request;

import java.io.Serializable;

/**
 * The status of a {@link StateMessage}.
 */
class StateMessageStatus implements Serializable {

    static StateMessageStatus delivered() {
        return new StateMessageStatus(DELIVERED, null);
    }

    static StateMessageStatus pending() {
        return new StateMessageStatus(PENDING, null);
    }

    static StateMessageStatus error(String msg) {
        return new StateMessageStatus(ERROR, msg);
    }

    static final int ERROR = 1;
    static final int DELIVERED = 2;
    static final int PENDING = 3;

    private final int status;
    private final String errorResponse;

    private StateMessageStatus(int status, String errorResponse) {
        this.status = status;
        this.errorResponse = errorResponse;
    }

    int getStatus() {
        return status;
    }

    String getErrorResponse() {
        return errorResponse;
    }

    @Override
    public String toString() {
        final String statusString;
        switch (status) {
            case ERROR:
                statusString = "Error";
                break;
            case DELIVERED:
                statusString = "Delivered";
                break;
            case PENDING:
                statusString = "Pending";
                break;
            default: {
                statusString = "Unknown";
            }
        }

        return "MessageState{" +
                "status=" + statusString +
                ", errorResponse=" + errorResponse +
                '}';
    }
}
