package zendesk.support.request;

import com.zendesk.util.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import zendesk.support.RequestStatus;
import zendesk.support.suas.State;

/**
 * Root state data. Holding the conversation itself.
 */
class StateConversation implements Serializable {

    static StateConversation fromState(State state) {
        final StateConversation conversation = state.getState(StateConversation.class);
        if (conversation != null) {
            return conversation;
        } else {
            return new StateConversation();
        }
    }

    private final String localId;
    private final String remoteId;
    private final RequestStatus status;
    private final boolean hasAgentReplies;
    private final List<StateMessage> messages;
    private final List<StateRequestUser> users;
    private final StateIdMapper attachmentIdMapper;
    private final StateIdMapper messageIdMapper;


    private StateConversation(String localId, String remoteId, RequestStatus status, boolean hasAgentReplies,
                              List<StateMessage> messages, List<StateRequestUser> users,
                              StateIdMapper attachmentIdMapper, StateIdMapper messageIdMapper) {
        this.localId = localId;
        this.remoteId = remoteId;
        this.status = status;
        this.hasAgentReplies = hasAgentReplies;
        this.messages = messages;
        this.users = users;
        this.attachmentIdMapper = attachmentIdMapper;
        this.messageIdMapper = messageIdMapper;
    }

    StateConversation() {
        this.localId = StringUtils.EMPTY_STRING;
        this.remoteId = StringUtils.EMPTY_STRING;
        this.status = null;
        this.hasAgentReplies = false;
        this.messages = new ArrayList<>();
        this.users = new ArrayList<>();
        this.attachmentIdMapper = new StateIdMapper();
        this.messageIdMapper = new StateIdMapper();
    }

    String getLocalId() {
        return localId;
    }

    String getRemoteId() {
        return remoteId;
    }

    List<StateMessage> getMessages() {
        return messages;
    }

    List<StateRequestUser> getUsers() {
        return users;
    }

    StateIdMapper getAttachmentIdMapper() {
        return attachmentIdMapper;
    }

    StateIdMapper getMessageIdMapper() {
        return messageIdMapper;
    }

    RequestStatus getStatus() {
        return status;
    }

    boolean hasAgentReplies() {
        return hasAgentReplies;
    }

    Builder newBuilder() {
        return new Builder(localId, remoteId, status, hasAgentReplies, messages, users, attachmentIdMapper,
                messageIdMapper);
    }

    @Override
    public String toString() {
        return "Conversation{" +
                "localId='" + localId + '\'' +
                ", remoteId='" + remoteId + '\'' +
                ", messages=" + messages +
                ", users=" + users +
                ", attachmentIdMapper=" + attachmentIdMapper +
                ", messageIdMapper=" + messageIdMapper +
                '}';
    }

    static class Builder {

        private String localId;
        private String remoteId;
        private RequestStatus status;
        private boolean hasAgentReplies;
        private List<StateMessage> messages;
        private List<StateRequestUser> users;
        private StateIdMapper attachmentIdMapper;
        private StateIdMapper messageIdMapper;


        private Builder(String localId, String remoteId, RequestStatus status, boolean hasAgentReplies,
                        List<StateMessage> messages, List<StateRequestUser> users,
                        StateIdMapper attachmentIdMapper, StateIdMapper messageIdMapper) {
            this.localId = localId;
            this.remoteId = remoteId;
            this.status = status;
            this.hasAgentReplies = hasAgentReplies;
            this.messages = messages;
            this.users = users;
            this.attachmentIdMapper = attachmentIdMapper;
            this.messageIdMapper = messageIdMapper;
        }

        Builder setLocalId(String localId) {
            this.localId = localId;
            return this;
        }

        Builder setRemoteId(String remoteId) {
            this.remoteId = remoteId;
            return this;
        }

        Builder setStatus(RequestStatus status) {
            this.status = status;
            return this;
        }

        Builder setMessages(List<StateMessage> messages) {
            this.messages = messages;
            return this;
        }

        Builder setUsers(List<StateRequestUser> users) {
            this.users = users;
            if (!hasAgentReplies) {
                this.hasAgentReplies = StateRequestUser.containsAgent(users);
            }
            return this;
        }

        Builder setAttachmentIdMapper(StateIdMapper attachmentIdMapper) {
            this.attachmentIdMapper = attachmentIdMapper;
            return this;
        }

        Builder setMessageIdMapper(StateIdMapper messageIdMapper) {
            this.messageIdMapper = messageIdMapper;
            return this;
        }

        Builder setHasAgentReplies(boolean hasAgentReplies) {
            this.hasAgentReplies = hasAgentReplies;
            return this;
        }

        StateConversation build() {
            return new StateConversation(localId, remoteId, status, hasAgentReplies, messages, users,
                    attachmentIdMapper, messageIdMapper);
        }
    }
}
