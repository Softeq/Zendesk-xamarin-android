package zendesk.support.request;

import android.annotation.SuppressLint;

import com.zendesk.util.StringUtils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zendesk.support.CustomField;

/**
 * Model for representing ticket forms in the state.
 */
class StateRequestTicketForm implements Serializable {

    static final long NO_ID = -1L;

    private final long id;
    private final Map<Long, String> ticketFields;

    public StateRequestTicketForm(long ticketFormId, List<CustomField> customFields) {
        this.id = ticketFormId;
        this.ticketFields = fieldsToMap(customFields);
    }

    StateRequestTicketForm(List<CustomField> customFields) {
        this(NO_ID, customFields);
    }

    long getId() {
        return id;
    }

    Map<Long, String> getTicketFields() {
        return ticketFields;
    }

    List<CustomField> getTicketFieldsForApi() {
        return mapToFields(ticketFields);
    }

    private static List<CustomField> mapToFields(Map<Long, String> customFields) {
        final List<CustomField> result = new ArrayList<>(customFields.size());

        for (Map.Entry<Long, String> entry : customFields.entrySet()) {
            result.add(new CustomField(entry.getKey(), entry.getValue()));
        }

        return result;
    }

    @SuppressLint("UseSparseArrays")
    private static Map<Long, String> fieldsToMap(List<CustomField> customFields) {
        final Map<Long, String> result = new HashMap<>(customFields.size());

        for (CustomField customField : customFields) {
            if (customField != null && StringUtils.hasLength(customField.getValueString())) {
                result.put(customField.getId(), customField.getValueString());
            }
        }

        return result;
    }
}
