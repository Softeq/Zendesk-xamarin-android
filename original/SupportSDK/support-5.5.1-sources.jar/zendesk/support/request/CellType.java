package zendesk.support.request;

import android.graphics.Rect;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;

import java.util.Date;
import java.util.List;

/**
 * All the different cell types
 */
interface CellType {

    /**
     * The minimum implementation of a cell. For convenience use {@link CellBase}
     */
    interface Base {

        int getPositionType();

        void setPositionType(int positionType);

        long getUniqueId();

        long getGroupId();

        @LayoutRes
        int getLayoutId();

        void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view);

        boolean areContentsTheSame(CellType.Base requestMessage);

        Date getTimeStamp();

        Rect getInsets();

    }

    /**
     * A cell that has text.
     */
    interface Message extends Base {

        CharSequence getMessage();

    }

    /**
     * A cell that can has different states (Failed, delivered, ...)
     */
    interface Stateful extends Base {

        Stateful markAsDelivered();

        Stateful markAsErrored(List<StateMessage> errorGroup, boolean endOfBlock);

        StateMessage getStateMessage();

        List<StateMessage> getErrorGroupMessages();

        boolean isMarkedAsDelivered();

        boolean isErrorShown();

        boolean isLastErrorCellOfBlock();

    }

    /**
     * A cell that renders some kind of attachment.
     */
    interface Attachment extends Base {

        StateRequestAttachment getAttachment();

    }

    /**
     * A cell that was send by an agent.
     */
    interface Agent extends Base {

        void showAgentName(boolean visible);

        boolean isAgentNameVisible();

        StateRequestUser getAgent();

    }

}
