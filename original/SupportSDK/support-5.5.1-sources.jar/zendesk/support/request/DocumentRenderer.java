package zendesk.support.request;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.text.style.QuoteSpan;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.util.Xml;
import android.view.View;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;
import zendesk.support.R;
import com.zendesk.util.StringUtils;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import okhttp3.HttpUrl;
import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.support.Constants;
import zendesk.support.UiUtils;

/**
 * lol
 * <p>
 * Rich rendering and that kind of stuff.
 * <p>
 * Good luck with that.
 * <p>
 * I was here. Good luck was not had.
 */
class DocumentRenderer {

    private final Style.Factory styleFactory;
    private final ActionHandlerRegistry actionHandlerRegistry;
    private final ConfigurationHelper configHelper;
    private final Configuration configuration;

    DocumentRenderer(@NonNull Context context, @NonNull ActionHandlerRegistry actionHandlerRegistry,
                     @NonNull ConfigurationHelper configHelper, @Nullable Configuration
            configuration) {
        this.styleFactory = new Style.Factory(context);
        this.actionHandlerRegistry = actionHandlerRegistry;
        this.configHelper = configHelper;
        this.configuration = configuration;
    }

    @VisibleForTesting
    DocumentRenderer(Style.Factory styleFactory, ActionHandlerRegistry actionHandlerRegistry,
                     ConfigurationHelper configHelper, Configuration configuration) {
        this.styleFactory = styleFactory;
        this.actionHandlerRegistry = actionHandlerRegistry;
        this.configHelper = configHelper;
        this.configuration = configuration;
    }

    CharSequence render(RichRenderingDocument document) {
        return document.isValid()
                ? render(document.getNodeTree())
                : installClickableLinks(new SpannableString(document.getFallbackText()));
    }

    private CharSequence render(Node node) {
        final Spannable reducedSpannable = reduce(node);
        final Spannable deepLinkedSpannable = installClickableLinks(reducedSpannable);

        return Style.SpannableHelper.trimSpannable(deepLinkedSpannable);
    }

    private Spannable installClickableLinks(Spannable spannable) {
        final Spannable sp = linkifyAll(spannable);
        return replaceUrlSpans(sp);
    }

    @VisibleForTesting
    Spannable reduce(Node node) {
        Node.Type nodeType = node.getType();
        final List<Node> children = node.getChildren();

        if (nodeType == Node.Type.Text) {
            return styleFactory.getStyledText(node.getText());
        }

        if (nodeType == Node.Type.Ol || nodeType == Node.Type.Ul) {

            int loopIndex = 0;
            
            for (Node child: node.children) {
                child.attributes.put(Style.Li.PARENT_ATTRIBUTE, nodeType.name());

                int listItemIndex = loopIndex + 1;
                child.attributes.put(Style.Li.INDEX_ATTRIBUTE, String.valueOf(listItemIndex));
                loopIndex++;
            }
        }

        final List<CharSequence> styledChildren = new ArrayList<>(children.size());
        for (Node child : children) {
            styledChildren.add(reduce(child));
        }

        return styleFactory.getStyleForType(nodeType).applyStyle(styledChildren, node.getAttributes());
    }

    private Spannable replaceUrlSpans(Spannable spannableString) {
        final SpannableString copy = new SpannableString(spannableString);
        final URLSpan[] spans = copy.getSpans(0, copy.length(), URLSpan.class);

        for (URLSpan span : spans) {
            String url = span.getURL();

            int start = copy.getSpanStart(span);
            int end = copy.getSpanEnd(span);
            copy.removeSpan(span);
            copy.setSpan(new ZendeskUrlSpan(url, actionHandlerRegistry, configHelper, configuration), start, end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }

        return copy;
    }

    private static Spannable linkifyAll(Spannable spannable) {
        final Spannable copy = new SpannableString(spannable);
        final boolean linksFound = Linkify.addLinks(copy, Linkify.ALL);

        if (linksFound) {
            final URLSpan[] spans = copy.getSpans(0, copy.length(), URLSpan.class);
            for (URLSpan urlSpan : spans) {
                spannable.setSpan(urlSpan, copy.getSpanStart(urlSpan), copy.getSpanEnd(urlSpan), Spanned
                        .SPAN_EXCLUSIVE_EXCLUSIVE);
            }
        }

        return spannable;
    }

    interface Style {

        Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes);

        class Factory {

            private final Context context;

            Factory(Context context) {
                this.context = context;
            }

            Style getStyleForType(Node.Type nodeType) {

                switch (nodeType) {
                    case B:
                        return new Bold();
                    case H1:
                    case H2:
                    case H3:
                    case H4:
                    case H5:
                    case H6:
                        return new Header();
                    case I:
                        return new Italic();
                    case Code:
                        return new CodeSpan();
                    case A:
                        return new Link();
                    case P:
                    case Div:
                    case Br:
                        return new Br();
                    case Img:
                        return new Image(context.getResources());
                    case Li:
                        return new Li();
                    case Quote:
                        int color = UiUtils.themeAttributeToColor(
                                android.R.attr.textColorHint, context, R.color.zs_fallback_text_color);
                        return new QuotationSpan(color);
                }

                return new Unknown();
            }

            @SuppressLint("InlinedApi")
            Spannable getStyledText(CharSequence text) {

                if (text != null) {
                    String textWithoutEntities = text.toString().replaceAll("&nbsp;", " ");
                    return new SpannableString(textWithoutEntities);
                } else {
                    return new SpannableString(StringUtils.EMPTY_STRING);
                }
            }
        }

        class Header extends Bold {
            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                return Style.SpannableHelper.foldStrings(Arrays.asList(super.applyStyle(strings, attributes),
                        StringUtils.LINE_SEPARATOR));
            }
        }

        class Bold implements Style {
            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                SpannableString styledChildren = SpannableHelper.foldStrings(strings);
                return SpannableHelper.applySpans(styledChildren, new StyleSpan(Typeface.BOLD));
            }
        }

        class Italic implements Style {
            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                SpannableString styledChildren = SpannableHelper.foldStrings(strings);
                return SpannableHelper.applySpans(styledChildren, new StyleSpan(Typeface.ITALIC));
            }
        }

        class CodeSpan implements Style {
            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                SpannableString styledChildren = SpannableHelper.foldStrings(strings);
                return SpannableHelper.applySpans(styledChildren, new TypefaceSpan("monospace"));
            }
        }

        class QuotationSpan implements Style {

            private int quoteColor;

            QuotationSpan(@ColorInt int quoteColor) {
                this.quoteColor = quoteColor;
            }

            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {

                List<CharSequence> string = new ArrayList<>();
                string.add(" ");
                string.addAll(strings);

                SpannableString styledChildren = SpannableHelper.foldStrings(string);

                return SpannableHelper.applySpans(
                        styledChildren,
                        new QuoteSpan(quoteColor),
                        new ForegroundColorSpan(quoteColor));
            }
        }


        class Unknown implements Style {
            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                return SpannableHelper.foldStrings(strings);
            }
        }

        class Link implements Style {
            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                SpannableString styledChildren = SpannableHelper.foldStrings(strings);
                String url = attributes.get("href");

                return StringUtils.hasLength(url)
                        ? SpannableHelper.applySpans(styledChildren, new URLSpan(url))
                        : styledChildren;
            }
        }

        class Br implements Style {
            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                return SpannableHelper.foldStrings(Arrays.asList(
                        SpannableHelper.foldStrings(strings), StringUtils.LINE_SEPARATOR));
            }
        }

        class Image implements Style {

            private final Resources resources;

            Image(Resources resources) {
                this.resources = resources;
            }

            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                String url = attributes.get("src");
                if (url == null || url.isEmpty()) {
                    return SpannableHelper.applySpans(new SpannableString("Image"));
                }
                HttpUrl httpUrl = HttpUrl.parse(url);
                String nullableName = httpUrl.queryParameter("name");
                String label = String.format(resources.getString(R.string.request_message_inline_image_title_format),
                        nullableName != null
                                ? nullableName
                                : "Image");

                return SpannableHelper.applySpans(new SpannableString(label), new URLSpan(url));
            }
        }

        class Li implements Style {

            public static final String UNICODE_BULLET = "\u2022";
            public static final String PARENT_ATTRIBUTE = "_parent";
            public static final String INDEX_ATTRIBUTE = "_index";

            @Override
            public Spannable applyStyle(List<CharSequence> strings, Map<String, String> attributes) {
                final SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("");

                String parent = StringUtils.EMPTY_STRING;
                String index = StringUtils.EMPTY_STRING;

                if (attributes != null && attributes.containsKey(PARENT_ATTRIBUTE)) {
                    parent = attributes.get(PARENT_ATTRIBUTE);
                }

                if (attributes != null && attributes.containsKey(INDEX_ATTRIBUTE)) {
                    index = attributes.get(INDEX_ATTRIBUTE);
                }

                for (CharSequence s : strings) {

                    if (StringUtils.hasLength(parent)) {
                        if (parent.equalsIgnoreCase("ol")) {

                            spannableStringBuilder.append(index);

                            if (StringUtils.hasLength(index)) {
                                spannableStringBuilder.append(". ");
                            }

                        } else if (parent.equalsIgnoreCase("ul")) {
                            spannableStringBuilder.append(UNICODE_BULLET)
                                    .append(" ");
                        }
                    }

                    spannableStringBuilder.append(s);
                    spannableStringBuilder.append(StringUtils.LINE_SEPARATOR);
                }

                return new SpannableString(spannableStringBuilder);
            }
        }

        class SpannableHelper {

            private SpannableHelper() {
                // Intentionally empty
            }

            static SpannableString foldStrings(List<CharSequence> spannableStrings) {
                final CharSequence[] children = new CharSequence[spannableStrings.size()];
                final CharSequence joined = TextUtils.concat(spannableStrings.toArray(children));
                return new SpannableString(joined);
            }

            static SpannableString applySpans(CharSequence string, Object... spans) {
                final SpannableString result = new SpannableString(string);

                if (spans != null) {
                    for (Object span: spans) {
                        if (span != null) {
                            result.setSpan(span, 0, result.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                        }
                    }
                }

                return result;
            }

            static SpannableString trimSpannable(Spannable spannable) {
                int trimStart = 0;
                int trimEnd = 0;

                String text = spannable.toString();

                while (text.length() > 0 && text.startsWith("\n")) {
                    text = text.substring(1);
                    trimStart += 1;
                }

                while (text.length() > 0 && text.endsWith("\n")) {
                    text = text.substring(0, text.length() - 1);
                    trimEnd += 1;
                }

                SpannableStringBuilder ssb = new SpannableStringBuilder(spannable);
                if (ssb.length() > 0 && (spannable.length() - trimEnd) > 0
                        && (spannable.length() - trimEnd) != spannable.length()) {
                    ssb = ssb.delete(spannable.length() - trimEnd, spannable.length());
                }

                if (trimStart > 0 && trimStart < spannable.length()) {
                    ssb = ssb.delete(0, trimStart);
                }

                return new SpannableString(ssb);
            }
        }
    }

    static class Node {

        static Node withTag(String tag, Node parent, Map<String, String> attributes) {
            return new Node(Node.Type.forTag(tag), null, new ArrayList<Node>(), parent, attributes);
        }

        static Node withContent(Node parent, String text, Map<String, String> attributes) {
            return new Node(Node.Type.Text, text, new ArrayList<Node>(), parent, attributes);
        }

        private final Type type;
        private final String text;
        private final List<Node> children;
        private final Node parent;
        private final Map<String, String> attributes;


        private Node(Type type, String text, List<Node> children, Node parent, Map<String, String> attributes) {
            this.type = type;
            this.text = text;
            this.children = children;
            this.parent = parent;
            this.attributes = attributes;
        }

        void addChild(Node node) {
            children.add(node);
        }

        public Type getType() {
            return type;
        }

        public CharSequence getText() {
            return text;
        }

        List<Node> getChildren() {
            return children;
        }

        public Node getParent() {
            return parent;
        }

        Map<String, String> getAttributes() {
            return attributes;
        }

        enum Type {
            B("b"),
            I("i"),
            Code("code"),
            H1("h1"),
            H2("h2"),
            H3("h3"),
            H4("h4"),
            H5("h5"),
            H6("h6"),

            Strong("strong"),
            U("u"),

            Em("em"),
            Br("br"),
            Hr("hr"),
            Div("div"),
            P("p"),
            Li("li"),
            A("a"),
            Ol("ol"),
            Ul("ul"),
            Img("img"),
            Quote("blockquote"),

            Text("$text"),
            Document("$document"),
            Unknown("$unknown"),;

            private final String tag;

            Type(String tag) {
                this.tag = tag;
            }

            public String getTag() {
                return tag;
            }

            static Type forTag(String tag) {
                final Type[] types = Type.values();
                for (Type type : types) {
                    if (type.getTag().equalsIgnoreCase(tag)) {
                        return type;
                    }
                }

                return Unknown;
            }
        }
    }

    static class HtmlParser {

        private static final Set<String> UNCLOSED_TAGS = new HashSet<>(Arrays.asList("br", "hr", "img"));
        private final XmlPullParser xpp;

        HtmlParser() {
            XmlPullParser xmlPullParser = null;

            try {
                final XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setValidating(false);
                factory.setFeature(Xml.FEATURE_RELAXED, true);
                xmlPullParser = factory.newPullParser();
            } catch (XmlPullParserException e) {
                Logger.w(RequestActivity.LOG_TAG, "Unable to parse rich text. Error: '%s' | '%s'", e
                        .getLocalizedMessage());
            } finally {
                xpp = xmlPullParser;
            }
        }

        @SuppressWarnings("WeakerAccess")
        @VisibleForTesting
        HtmlParser(XmlPullParser xpp) {
            this.xpp = xpp;
        }

        @NonNull
        RichRenderingDocument parse(String htmlBody, String plainBody) {

            try {
                Node rootNode = null;
                Node currentNode = null;

                xpp.setInput(new StringReader(htmlBody));
                int eventType = xpp.getEventType();

                while (eventType != XmlPullParser.END_DOCUMENT) {

                    if (eventType == XmlPullParser.START_DOCUMENT) {
                        currentNode = rootNode = startDocument();

                    } else if (eventType == XmlPullParser.START_TAG) {
                        currentNode = startTag(currentNode);

                    } else if (eventType == XmlPullParser.END_TAG) {
                        currentNode = endTag(currentNode);

                    } else if (eventType == XmlPullParser.TEXT) {
                        text(currentNode);

                    }

                    eventType = xpp.next();
                }

                if (rootNode == currentNode) {
                    return new RichRenderingDocument(rootNode, plainBody);
                }

            } catch (Exception e) {
                Logger.w(RequestActivity.LOG_TAG, "Unable to parse rich text. Error: '%s' | '%s'", e
                        .getLocalizedMessage(), htmlBody);
            }

            return new RichRenderingDocument(null, plainBody);
        }

        private Node startDocument() {
            return Node.withTag(Node.Type.Document.getTag(), null, getAttributes());
        }

        private Node startTag(Node parent) {
            final String tag = xpp.getName();

            final Node node = Node.withTag(tag, parent, getAttributes());
            parent.addChild(node);

            return UNCLOSED_TAGS.contains(tag) ? parent : node;
        }

        private Node endTag(Node node) {
            return node.getParent();
        }

        private void text(Node node) {
            final String text = xpp.getText();
            if (StringUtils.hasLength(text)) {
                node.addChild(Node.withContent(node, text, getAttributes()));
            }
        }

        private Map<String, String> getAttributes() {
            final int attributeCount = xpp.getAttributeCount();
            final Map<String, String> attributes = new HashMap<>(Math.max(0, attributeCount));
            if (attributeCount > 0) {
                for (int i = 0; i < attributeCount; i++) {
                    attributes.put(xpp.getAttributeName(i), xpp.getAttributeValue(i));
                }
            }
            return attributes;
        }
    }

    static class ZendeskUrlSpan extends URLSpan {

        private final ActionHandlerRegistry registry;
        private final ConfigurationHelper configHelper;
        private final Configuration configuration;

        ZendeskUrlSpan(String url, @NonNull ActionHandlerRegistry registry, @NonNull ConfigurationHelper configHelper,
                       @Nullable Configuration configuration) {
            super(url);
            this.registry = registry;
            this.configHelper = configHelper;
            this.configuration = configuration;
        }

        @Override
        public void onClick(View widget) {
            String url = getURL();

            if (StringUtils.isEmpty(url)) {
                super.onClick(widget);
                return;
            }

            ActionHandler actionHandler = registry.handlerByAction(url);
            if (actionHandler == null) {
                super.onClick(widget);
                return;
            }

            Map<String, Object> payload = new HashMap<>();
            payload.put(Constants.KEY_HELP_CENTER_ARTICLE_URL, url);
            configHelper.addToMap(payload, configuration);
            actionHandler.handle(payload, widget.getContext());
        }
    }

    static class RichRenderingDocument {

        private final Node tree;
        private final String fallbackText;

        RichRenderingDocument(Node tree, String fallbackText) {
            this.tree = tree;
            this.fallbackText = fallbackText;
        }

        boolean isValid() {
            return tree != null && !tree.getChildren().isEmpty();
        }

        Node getNodeTree() {
            return tree;
        }

        String getFallbackText() {
            return fallbackText;
        }
    }
}
