package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.HttpConstants;

import zendesk.support.suas.Action;
import zendesk.support.suas.Reducer;

/**
 * Reducer for maintaining the error state.
 */
class ReducerError extends Reducer<StateError> {

    @Nullable
    @Override
    public StateError reduce(@NonNull StateError state, @NonNull Action<?> action) {

        if (action instanceof ActionFactory.ErrorAction) {
            final ErrorResponse error = ((ActionFactory.ErrorAction) action).getErrorResponse();
            if (error.isHttpError() && error.getStatus() == HttpConstants.HTTP_UNAUTHORIZED) {
                return new StateError(StateError.ErrorType.NoAccess, error.getReason());
            }
        }

        switch (action.getActionType()) {

            case ActionFactory.LOAD_COMMENTS_INITIAL_ERROR: {
                if (action instanceof ActionFactory.ErrorAction) {
                    final ErrorResponse error = ((ActionFactory.ErrorAction) action).getErrorResponse();
                    return new StateError(StateError.ErrorType.InitialGetComments, error.getReason());
                }
            }

            case ActionFactory.LOAD_COMMENTS_INITIAL:
            case ActionFactory.LOAD_COMMENTS_INITIAL_SUCCESS:
            case ActionFactory.LOAD_COMMENTS_UPDATE_SUCCESS: {
                if (state.getState() == StateError.ErrorType.InitialGetComments) {
                    return new StateError();
                }
            }

            case ActionFactory.CREATE_REQUEST_ERROR: {
                if (action instanceof ActionFactory.ErrorAction) {
                    final ErrorResponse error = ((ActionFactory.ErrorAction) action).getErrorResponse();
                    return new StateError(StateError.ErrorType.InputFormSubmission, error.getReason());
                }
            }

            case ActionFactory.CREATE_COMMENT: {
                if (state.getState() == StateError.ErrorType.InputFormSubmission) {
                    return new StateError();
                }
            }

        }

        return null;
    }

    @NonNull
    @Override
    public StateError getInitialState() {
        return new StateError();
    }

}
