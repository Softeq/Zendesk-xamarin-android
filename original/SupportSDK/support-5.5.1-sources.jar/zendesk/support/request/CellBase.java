package zendesk.support.request;

import android.graphics.Rect;
import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;

import java.util.Date;

/**
 * Definition of an item displayed in RequestAdapter
 */
abstract class CellBase implements CellType.Base {

    static final int GROUP_ID_SYSTEM_MESSAGE = Integer.MIN_VALUE;
    static final int GROUP_ID_END_USER = Integer.MIN_VALUE + 1;

    static final long ID_SYSTEM_MESSAGE_REQUEST_CREATED = Long.MIN_VALUE;
    static final long ID_SYSTEM_MESSAGE_REQUEST_CLOSED = Long.MIN_VALUE + 1;

    protected final CellBindHelper utils;
    private final int layoutId;
    private final long id;
    private final long groupId;
    private int positionType;
    private final Date timestamp;
    private Rect insets;

    CellBase(CellBindHelper utils, @LayoutRes int layoutId, long id, long groupId, Date timestamp) {
        this.utils = utils;
        this.layoutId = layoutId;
        this.id = id;
        this.groupId = groupId;
        this.positionType = CellMarginDecorator.CELL;
        this.timestamp = timestamp;
        this.insets = new Rect(0, 0, 0, 0);
    }

    /**
     * Gets the timestamp of the message.
     */
    @Override
    public Date getTimeStamp() {
        return timestamp;
    }

    /**
     * The unique identifier of the item.
     */
    @Override
    public long getUniqueId() {
        return id;
    }

    /**
     * Gets the layout id of the item.
     */
    @Override
    @LayoutRes
    public int getLayoutId() {
        return layoutId;
    }

    /**
     * Gets the position type.
     */
    @Override
    public int getPositionType() {
        return positionType;
    }

    @Override
    public void setPositionType(int positionType) {
        this.positionType |= positionType;
    }

    @Override
    public long getGroupId() {
        return groupId;
    }

    @Override
    public Rect getInsets() {
        return insets;
    }

    /**
     * Bind present data to the given view.
     */
    @Override
    public abstract void bind(@NonNull ComponentRequestAdapter.RequestViewHolder view);

    /**
     * Check if the content of the messages are identical.
     */
    @Override
    public abstract boolean areContentsTheSame(CellType.Base requestMessage);

}
