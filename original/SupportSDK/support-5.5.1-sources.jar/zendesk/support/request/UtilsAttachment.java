package zendesk.support.request;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import android.text.TextUtils;

import zendesk.support.R;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.io.File;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

import zendesk.support.IdUtil;

/**
 * Collection of utils for handling attachments.
 */
class UtilsAttachment {

    private static final String PATH_PLACEHOLDER = "%s%s%s";

    private static final String SUPPORT_BELVEDERE_BASE_PATH =
            String.format(Locale.US, PATH_PLACEHOLDER, "zendesk", File.separator, "support");
    private static final String REQUEST_BELVEDERE_PATH =
            String.format(Locale.US, PATH_PLACEHOLDER, SUPPORT_BELVEDERE_BASE_PATH, File.separator, "request");

    private static final AttachmentNameComparator REQUEST_ATTACHMENT_COMPARATOR = new AttachmentNameComparator();
    private static final String ATTACHMENT_TEXT_BODY = "[%s]";
    private static final String ATTACHMENT_SEPARATOR = ", ";

    private UtilsAttachment() {
        // intentionally empty
    }

    static String getAttachmentSubDir(String path, long attachmentId) {
        return String.format(Locale.US, PATH_PLACEHOLDER, path, File.separator, attachmentId);
    }

    static String getTemporaryRequestCacheDir() {
        return String.format(Locale.US, PATH_PLACEHOLDER, REQUEST_BELVEDERE_PATH, File.separator, IdUtil.newStringId());
    }

    static String getCacheDirForRequestId(String requestId) {
        return String.format(Locale.US, PATH_PLACEHOLDER, REQUEST_BELVEDERE_PATH, File.separator, requestId);
    }


    static String getMessageBodyForAttachments(List<StateRequestAttachment> attachmentList) {
        final List<StateRequestAttachment> attachmentSortedByName = CollectionUtils.copyOf(attachmentList);
        Collections.sort(attachmentSortedByName, REQUEST_ATTACHMENT_COMPARATOR);

        final StringBuilder str = new StringBuilder();
        for (int i = 0, c = attachmentSortedByName.size(); i < c; i++) {
            str.append(attachmentSortedByName.get(i).getName());
            if (i < (c - 1)) {
                str.append(ATTACHMENT_SEPARATOR);
            }
        }

        return String.format(Locale.US, ATTACHMENT_TEXT_BODY, str.toString());
    }

    static boolean hasAttachmentBody(StateMessage message) {
        if (CollectionUtils.isNotEmpty(message.getAttachments())) {
            final String expectedAttachmentBody = getMessageBodyForAttachments(message.getAttachments());
            return message.getBody().equals(expectedAttachmentBody);
        } else {
            return false;
        }
    }

    static boolean isImageAttachment(StateRequestAttachment attachment) {
        final String mimeType = attachment.getMimeType();
        return StringUtils.hasLength(mimeType) && mimeType.toLowerCase(Locale.US).startsWith("image");
    }

    static ResolveInfo getAppInfoForFile(Context context, MediaResult file) {
        final PackageManager pm = context.getPackageManager();
        if (file == null) {
            return null;
        }

        final Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(file.getUri());

        final List<ResolveInfo> matchingApps =
                pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);

        if (!CollectionUtils.isEmpty(matchingApps)) {
            return matchingApps.get(0);
        }

        return null;
    }

    static CharSequence getAppName(Context context, @Nullable ResolveInfo resolveInfo) {
        CharSequence appName = "";

        if (resolveInfo != null) {
            final PackageManager pm = context.getPackageManager();
            appName = resolveInfo.loadLabel(pm);
        }

        if (!TextUtils.isEmpty(appName)) {
            return appName;
        } else {
            return context.getString(R.string.request_attachment_generic_unknown_app);
        }
    }

    static Drawable getAppIcon(Context context, @Nullable ResolveInfo resolveInfo) {
        Drawable appIcon = null;

        if (resolveInfo != null) {
            final PackageManager pm = context.getPackageManager();
            appIcon = resolveInfo.loadIcon(pm);
        }

        if (appIcon != null) {
            return appIcon;
        } else {
            return ContextCompat.getDrawable(context, android.R.drawable.sym_def_app_icon);
        }
    }

    static String getContentDescriptionForAttachmentButton(Context context, int attachmentCount) {
        StringBuilder string = new StringBuilder();
        string.append(context.getString(R.string.request_menu_button_label_add_attachments));
        string.append(". ");

        if (attachmentCount == 0) {
            string.append(context.getString(R.string
                    .zs_request_attachment_indicator_no_attachments_selected_accessibility));
        } else if (attachmentCount == 1) {
            string.append(context.getString(R.string
                    .zs_request_attachment_indicator_one_attachments_selected_accessibility));
        } else {
            string.append(context.getString(R.string
                    .zs_request_attachment_indicator_n_attachments_selected_accessibility, attachmentCount));
        }

        return string.toString();
    }

    private static class AttachmentNameComparator implements Comparator<StateRequestAttachment> {

        @Override
        public int compare(StateRequestAttachment a1, StateRequestAttachment a2) {
            return a1.getName().compareTo(a2.getName());
        }

    }
}
