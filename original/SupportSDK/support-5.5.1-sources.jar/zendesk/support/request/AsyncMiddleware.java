package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;

import java.util.LinkedList;
import java.util.concurrent.atomic.AtomicBoolean;

import zendesk.support.suas.Action;
import zendesk.support.suas.Continuation;
import zendesk.support.suas.Dispatcher;
import zendesk.support.suas.GetState;
import zendesk.support.suas.Middleware;
import zendesk.support.suas.State;
import zendesk.support.suas.Store;

import static zendesk.support.request.RequestActivity.DEBUG;

/**
 * Middleware for serially running {@link AsyncMiddleware.AsyncAction}s.
 */
class AsyncMiddleware implements Middleware {

    private static final String LOG_TAG = "AsyncMiddleware";

    private static final String ACTION_TYPE = "async_action";

    static Action createAction(AsyncMiddleware.AsyncAction asyncAction) {
        return new Action<>(ACTION_TYPE, asyncAction);
    }

    private final Queue queue;

    AsyncMiddleware(Queue queue) {
        this.queue = queue;
    }

    @Override
    public void onAction(@NonNull Action<?> action, @NonNull GetState getState,
                         @NonNull Dispatcher dispatcher, @NonNull Continuation continuation) {
        final AsyncAction asyncAction = action.getData(AsyncAction.class);
        if (asyncAction != null) {
            asyncAction.actionQueued(dispatcher, getState);
            queue.dispatch(new QueueItem(asyncAction, getState, dispatcher));
        } else {
            continuation.next(action);
        }
    }

    interface Callback {
        void done();
    }

    interface Item {
        void execute(Callback callback);
    }

    private static class QueueItem implements Item {

        private final AsyncAction asyncAction;
        private final GetState getState;
        private final Dispatcher dispatcher;

        private QueueItem(AsyncAction asyncAction, GetState getState, Dispatcher dispatcher) {
            this.asyncAction = asyncAction;
            this.getState = getState;
            this.dispatcher = dispatcher;
        }

        @Override
        public void execute(final Callback callback) {
            asyncAction.execute(dispatcher, getState, callback);
        }
    }

    /**
     * A serial queue for executing {@link Item}. This implementation is not using a background thread.
     * <br />
     * Do not block it.
     */
    static class Queue {

        private final java.util.Queue<Item> items;
        private final AtomicBoolean isRunning;
        private final Callback dispatchCallback;

        Queue() {
            this.items = new LinkedList<>();
            this.isRunning = new AtomicBoolean(false);
            this.dispatchCallback = new QueueCallback();
        }

        @VisibleForTesting
        Queue(LinkedList<Item> items) {
            this.items = items;
            this.isRunning = new AtomicBoolean(false);
            this.dispatchCallback = new QueueCallback();
        }

        void dispatch(Item action) {

            if (action == null) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Provided item is null.");
                }
                return;
            }

            if (DEBUG) {
                Logger.d(LOG_TAG, "Dispatch item %s", action.hashCode());
            }

            // Add item to queue
            synchronized (items) {
                items.add(action);
            }

            // Check if it is already dispatching an item
            // If it is, the item will be picked up
            // If not, start dispatching it
            if (isRunning.compareAndSet(false, true)) {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Dispatch not running, starting it now");
                }
                dispatchInternal();
            } else {
                if (DEBUG) {
                    Logger.d(LOG_TAG, "Dispatch running, it will be processed soon.");
                }
            }
        }

        boolean isRunning() {
            return isRunning.get();
        }

        private void dispatchInternal() {
            final Item action;
            synchronized (items) {
                if (!items.isEmpty()) {
                    action = items.peek();
                } else {
                    if (DEBUG) {
                        Logger.d(LOG_TAG, "PersistenceQueue is empty. Going to sleep. Zzzz...");
                    }
                    isRunning.set(false);
                    action = null;
                }
            }

            if (action != null) {
                action.execute(dispatchCallback);
            }
        }

        private class QueueCallback implements Callback {

            @Override
            public void done() {
                synchronized (items) {
                    final Item item = items.poll();
                    if (DEBUG) {
                        Logger.d(LOG_TAG, "Successfully executed item: %s", item);
                    }
                }
                dispatchInternal();
            }

        }
    }

    /**
     * Asynchronous action that can be dispatched by a {@link Store} by calling
     * {@link Store#dispatch(Action)}
     */
    interface AsyncAction {

        /**
         * Called as soon as the {@link AsyncAction} gets queued.
         *
         * @param dispatcher a {@link Dispatcher} for dispatching {@link Action}
         * @param state      a copy of the current {@link State}
         */
        void actionQueued(Dispatcher dispatcher, GetState state);

        /**
         * Called when the {@link AsyncAction} should do its main work.
         * <br/>
         * Don't do blocking callas in this method. Use the provided callback to notify that the
         * action was finished.
         *
         * @param dispatcher a {@link Dispatcher} for dispatching {@link Action}
         * @param state      a copy of the current {@link GetState}
         * @param callback   notify the underlying structure that this action completed
         */
        void execute(Dispatcher dispatcher, GetState state, Callback callback);

    }
}
