package zendesk.support.request;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.FrameLayout;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;
import javax.inject.Inject;
import zendesk.commonui.BottomSheetAttachmentViewMenu;
import zendesk.support.R;
import zendesk.support.suas.CombinedSubscription;
import zendesk.support.suas.Store;
import zendesk.support.suas.Subscription;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Screen: Conversations disabled. Input form. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class RequestViewConversationsDisabled extends FrameLayout implements RequestView {

    private AppCompatActivity activity;

    private Subscription subscription;
    private AttachmentHelper attachmentHelper;

    private List<MenuItemsDelegate> menuItemsDelegates = new ArrayList<>();
    private ComponentInputForm inputFormComponent;

    @Inject
    Store store;
    @Inject
    ActionFactory actionFactory;
    @Inject
    Picasso picasso;

    @Inject
    MediaResultUtility mediaResultUtility;

    BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu;

    public RequestViewConversationsDisabled(Context context) {
        super(context);
        viewInit(context);
    }

    public RequestViewConversationsDisabled(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        viewInit(context);
    }

    public RequestViewConversationsDisabled(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        viewInit(context);
    }

    private void viewInit(final Context context) {
        inflate(context, R.layout.zs_view_request_conversations_disabled, this);
        activity = (AppCompatActivity) context;
    }

    public void init(RequestComponent component, BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu) {
        component.inject(this);
        attachmentHelper = new AttachmentHelper();
        this.bottomSheetAttachmentViewMenu = bottomSheetAttachmentViewMenu;
        subscription = bindComponents(store, actionFactory);
        subscription.informWithCurrentState();
    }

    @Override
    public boolean hasUnsavedInput() {
        return inputFormComponent != null && inputFormComponent.hasUnsavedInput();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (subscription != null) {
            subscription.removeListener();
        }
    }

    private Subscription bindComponents(Store store, ActionFactory af) {
        return CombinedSubscription.from(
                bindInput(store),
                bindAttachmentCarousel(store, af)
        );
    }

    private Subscription bindInput(Store store) {
        inputFormComponent =
                ComponentInputForm.create(this, store, actionFactory, attachmentHelper);
        menuItemsDelegates.add(inputFormComponent);

        return store.addListener(inputFormComponent.getSelector(), inputFormComponent);
    }

    private Subscription bindAttachmentCarousel(Store store, ActionFactory actionFactory) {

        final RecyclerView recyclerView = activity.findViewById(R.id.request_attachment_carousel);
        final AdapterAttachmentCarousel adapter = new AdapterAttachmentCarousel(
                attachmentHelper,
                picasso,
                actionFactory,
                store,
                mediaResultUtility
        );

        final ComponentAttachmentCarousel carouselComponent = new ComponentAttachmentCarousel(
                activity,
                attachmentHelper,
                recyclerView,
                bottomSheetAttachmentViewMenu
        );

        recyclerView.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setAdapter(adapter);

        menuItemsDelegates.add(carouselComponent);

        return store.addListener(carouselComponent.getSelector(), carouselComponent);
    }

    @Override
    public boolean inflateMenu(MenuInflater menuInflater, Menu menu) {
        menuInflater.inflate(R.menu.zs_view_request_conversations_disabled_menu, menu);
        final MenuItem sendMessageItem = menu.findItem(R.id.request_conversations_disabled_menu_ic_send);
        final MenuItem addAttachmentsItem = menu.findItem(R.id.request_conversations_disabled_menu_ic_add_attachments);

        for (MenuItemsDelegate delegate : menuItemsDelegates) {
            delegate.onMenuItemsInflated(sendMessageItem, addAttachmentsItem);
        }

        return true;
    }

    @Override
    public boolean onOptionsItemClicked(MenuItem item) {
        for (MenuItemsDelegate delegate : menuItemsDelegates) {
            delegate.onMenuItemsClicked(item);
        }
        return true;
    }

    interface MenuItemsDelegate {
        void onMenuItemsInflated(MenuItem send, MenuItem attachment);

        void onMenuItemsClicked(MenuItem menuItem);
    }
}