package zendesk.support.request;

import androidx.annotation.RestrictTo;

import zendesk.support.ActivityScope;

import dagger.Subcomponent;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
@ActivityScope
@Subcomponent(modules = {RequestModule.class})
public interface RequestComponent {
    void inject(RequestActivity createRequestActivity);

    void inject(RequestViewConversationsEnabled conversationsEnabledView);

    void inject(RequestViewConversationsDisabled conversationsDisabledView);
}
