package zendesk.support.request;

import android.animation.ValueAnimator;
import androidx.annotation.NonNull;
import android.view.View;
import android.widget.FrameLayout;

/**
 * Collection of utils for handling animations.
 */
class UtilsAnimation {

    private UtilsAnimation() {
        // Intentionally empty.
    }

    /**
     * Gets a {@link ValueAnimator} that will animate changes to the top padding of the {@link View}.
     *
     * @param view         The animated view.
     * @param initPadding  The top padding at the start of animation.
     * @param finalPadding The top padding at the end of animation.
     * @param duration     The duration of an animation in milliseconds.
     * @return {@link ValueAnimator} that animates changes to the top padding.
     */
    static ValueAnimator topPaddingAnimator(@NonNull final View view, int initPadding, final int finalPadding, int
            duration) {
        final ValueAnimator valueAnimator = ValueAnimator.ofInt(initPadding, finalPadding);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            final int paddingLeft = view.getPaddingLeft();
            final int paddingRight = view.getPaddingRight();
            final int paddingBottom = view.getPaddingBottom();

            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                view.setPadding(
                        paddingLeft,
                        (int) valueAnimator.getAnimatedValue(),
                        paddingRight,
                        paddingBottom
                );
            }
        });

        valueAnimator.setDuration(duration);
        return valueAnimator;
    }

    /**
     * Gets a {@link ValueAnimator} that will animate changes to the bottom padding of the {@link View}.
     *
     * @param view         The animated view.
     * @param initPadding  The bottom padding at the start of animation.
     * @param finalPadding The bottom padding at the end of animation.
     * @param duration     The duration of an animation in milliseconds.
     * @return {@link ValueAnimator} that animates changes to the bottom padding.
     */
    static ValueAnimator bottomPaddingAnimator(@NonNull final View view, int initPadding, final int finalPadding, int
            duration) {
        final ValueAnimator valueAnimator = ValueAnimator.ofInt(initPadding, finalPadding);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            final int paddingLeft = view.getPaddingLeft();
            final int paddingRight = view.getPaddingRight();
            final int paddingTop = view.getPaddingTop();

            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                view.setPadding(
                        paddingLeft,
                        paddingTop,
                        paddingRight,
                        (int) valueAnimator.getAnimatedValue()
                );
            }
        });

        valueAnimator.setDuration(duration);
        return valueAnimator;
    }

    /**
     * Gets a {@link ValueAnimator} that will animate changes to the left and right margins of the {@link View}.
     *
     * @param view        The animated view.
     * @param initMargin  Left and right margins at the start of animation.
     * @param finalMargin left and right margins at the end of animation.
     * @param duration    The duration of an animation in milliseconds.
     * @return {@link ValueAnimator} that animates changes to the left and right margins.
     */
    static ValueAnimator sideMarginsAnimator(@NonNull final View view, int initMargin, final int finalMargin, int
            duration) {
        final FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) view.getLayoutParams();

        final ValueAnimator valueAnimator = ValueAnimator.ofInt(initMargin, finalMargin);
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                params.leftMargin = (int) animation.getAnimatedValue();
                params.rightMargin = (int) animation.getAnimatedValue();
                view.requestLayout();
            }
        });

        valueAnimator.setDuration(duration);
        return valueAnimator;
    }

    /**
     * Gets a {@link ValueAnimator} that will animate changes to the minimum height of the {@link View}.
     *
     * @param view           The animated view.
     * @param initMinHeight  The minimum height at the start of animation.
     * @param finalMinHeight The minimum height at the end of animation.
     * @param duration       The duration of an animation in milliseconds.
     * @return {@link ValueAnimator} that animates changes to the bottom padding.
     */
    static ValueAnimator minHeightAnimator(@NonNull final View view, int initMinHeight, final int finalMinHeight,
                                           final int duration) {
        final ValueAnimator valueAnimator = ValueAnimator.ofInt(initMinHeight, finalMinHeight);

        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                view.setMinimumHeight((int) animation.getAnimatedValue());
            }
        });

        valueAnimator.setDuration(duration);
        return valueAnimator;
    }
}
