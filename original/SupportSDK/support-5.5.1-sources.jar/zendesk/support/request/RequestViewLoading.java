package zendesk.support.request;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Screen: Loading settings. Empty. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
class RequestViewLoading extends View implements RequestView {

    public RequestViewLoading(Context context) {
        super(context);
    }

    public RequestViewLoading(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public RequestViewLoading(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean inflateMenu(MenuInflater menuInflater, Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemClicked(MenuItem item) {
        return false;
    }

    @Override
    public boolean hasUnsavedInput() {
        return false;
    }
}
