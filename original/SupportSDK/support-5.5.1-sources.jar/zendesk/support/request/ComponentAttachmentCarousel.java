package zendesk.support.request;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ScrollView;
import zendesk.commonui.BottomSheetAttachmentViewMenu;
import zendesk.support.R;
import java.util.Collection;
import zendesk.support.suas.Listener;
import zendesk.support.suas.State;
import zendesk.support.suas.StateSelector;

/**
 * Component representing the attachment carousel in the conversation off screen.
 */
class ComponentAttachmentCarousel implements
        Listener<ComponentAttachmentCarousel.AttachmentCarouselModel>,
        RequestViewConversationsDisabled.MenuItemsDelegate {

    private final AttachmentHelper attachmentHelper;
    private final RecyclerView recyclerView;
    private final ScrollView scrollView;

    private MenuItem attachmentButton;
    private boolean attachmentSupportEnabled = false;

    private final StateSelector<AttachmentCarouselModel> selector;

    private final BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu;

    ComponentAttachmentCarousel(
            AppCompatActivity activity,
            AttachmentHelper attachmentHelper,
            RecyclerView recyclerView,
            BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu
    ) {
        this.attachmentHelper = attachmentHelper;
        this.recyclerView = recyclerView;
        this.scrollView = activity.findViewById(R.id.request_conversations_disabled_scrollview);
        this.selector = new AttachmentCarouselSelector();
        this.bottomSheetAttachmentViewMenu = bottomSheetAttachmentViewMenu;
    }



    @Override
    public void update(@NonNull AttachmentCarouselModel state) {
        this.attachmentSupportEnabled = state.isAttachmentSupportEnabled();
        attachmentButtonVisibility(attachmentSupportEnabled, !state.isLoading());

        if (!state.isLoading()) {
            attachmentHelper.updateAttachments(state.getSelectedAttachments());
            attachmentHelper.updateMaxFileSize(state.getMaxAttachmentSize());
            attachmentCount(attachmentHelper.getSelectedAttachments().size());

            if (attachmentHelper.getSelectedAttachments().size() > 0) {
                scroll(View.FOCUS_DOWN);
            } else {
                scroll(View.FOCUS_UP);
            }

            recyclerView.getAdapter().notifyDataSetChanged();
        }
    }

    private void onAddAttachmentsRequested() {
        bottomSheetAttachmentViewMenu.showMenu();
    }

    private void scroll(final int direction) {
        scrollView.post(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(direction);
            }
        });
    }

    @Override
    public void onMenuItemsInflated(MenuItem send, MenuItem attachment) {
        attachmentButton = attachment;

        attachment.getActionView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onAddAttachmentsRequested();
            }
        });

        attachmentButtonVisibility(attachmentSupportEnabled, true);
    }

    @Override
    public void onMenuItemsClicked(MenuItem menuItem) {
        // intentionally empty
    }

    StateSelector<AttachmentCarouselModel> getSelector() {
        return selector;
    }

    private void attachmentButtonVisibility(boolean visible, boolean enabled) {
        if (attachmentButton != null) {
            attachmentButton.setVisible(visible);
            attachmentButton.getActionView().setEnabled(enabled);
        }
    }

    private void attachmentCount(int selectedAttachments) {
        if (attachmentButton != null) {
            final ViewCellAttachmentMenuItem actionView = (ViewCellAttachmentMenuItem) attachmentButton.getActionView();
            actionView.setBadgeCount(selectedAttachments);
        }
    }

    static class AttachmentCarouselModel {

        private final Collection<StateRequestAttachment> selectedAttachments;
        private final Collection<StateRequestAttachment> additionalAttachments;
        private final boolean isLoading;
        private final boolean isAttachmentSupportEnabled;
        private final long maxAttachmentSize;

        AttachmentCarouselModel(Collection<StateRequestAttachment> selectedAttachments,
                                Collection<StateRequestAttachment> additionalAttachments,
                                boolean isLoading, boolean isAttachmentSupportEnabled, long maxAttachmentSize) {
            this.selectedAttachments = selectedAttachments;
            this.additionalAttachments = additionalAttachments;
            this.isLoading = isLoading;
            this.isAttachmentSupportEnabled = isAttachmentSupportEnabled;
            this.maxAttachmentSize = maxAttachmentSize;
        }

        Collection<StateRequestAttachment> getSelectedAttachments() {
            return selectedAttachments;
        }

        Collection<StateRequestAttachment> getAdditionalAttachments() {
            return additionalAttachments;
        }

        boolean isLoading() {
            return isLoading;
        }

        boolean isAttachmentSupportEnabled() {
            return isAttachmentSupportEnabled;
        }

        long getMaxAttachmentSize() {
            return maxAttachmentSize;
        }
    }

    static class AttachmentCarouselSelector implements StateSelector<AttachmentCarouselModel> {

        @Nullable
        @Override
        public AttachmentCarouselModel selectData(@NonNull State state) {
            final StateAttachments attachments = StateAttachments.fromState(state);
            final StateConfig config = StateConfig.fromState(state);
            final StateProgress progress = StateProgress.fomState(state);

            return new AttachmentCarouselModel(
                    attachments.getSelectedAttachments(),
                    attachments.getAllSelectedAttachments(),
                    progress.getRunningRequests() > 0,
                    config.getSettings().isAttachmentsEnabled(),
                    config.getSettings().getMaxAttachmentSize());
        }
    }
}
