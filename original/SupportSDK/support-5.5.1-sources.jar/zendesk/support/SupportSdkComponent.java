package zendesk.support;

import androidx.annotation.RestrictTo;

import javax.inject.Singleton;

import zendesk.core.CoreModule;
import zendesk.support.request.RequestComponent;
import zendesk.support.request.RequestModule;
import zendesk.support.requestlist.RequestListComponent;
import zendesk.support.requestlist.RequestListModule;
import zendesk.support.requestlist.RequestListViewModule;

import dagger.Component;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@Singleton
@Component(modules = {
        CoreModule.class,
        SupportModule.class,
        SupportSdkModule.class
})
@RestrictTo(LIBRARY)
public interface SupportSdkComponent {

    String SUPPORT_MAIN_THREAD_EXECUTOR = "SUPPORT_MAIN_THREAD_EXECUTOR";

    void inject(SdkDependencyProvider sdkDependencyProvider);

    void inject(DeepLinkingBroadcastReceiver deepLinkingBroadcastReceiver);

    RequestComponent plus(RequestModule requestModule);

    RequestListComponent plus(RequestListModule requestListModule, RequestListViewModule requestListViewModule);
}
