package zendesk.support;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.RestrictTo;

import com.zendesk.logger.Logger;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.support.request.RequestConfiguration;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * BroadcastReceiver for deep-linking to a specific Zendesk Support request, intended for use with
 * push notifications for request updates.
 * <p>
 * Create an instance of the {@link RequestConfiguration.Builder} and use its
 * {@link RequestConfiguration.Builder#deepLinkIntent(Context, Intent...)} or
 * {@link RequestConfiguration.Builder#deepLinkIntent(Context, List, Intent...)} to
 * create an {@link Intent} to start the BroadcastReceiver. Wrap the Intent in a
 * {@link android.app.PendingIntent} and set it as the content on your notification, for example:
 *
 * <pre>
 *     {@code
 *      final Intent deepLinkIntent = new RequestConfiguration.Builder()
 *          .withRequestId(requestId)
 *          .deepLinkIntent(getApplicationContext(), uiConfigs, mainActivity);
 *     final PendingIntent contentIntent = PendingIntent
 *          .getBroadcast(getApplicationContext(), 1, requestIntent, PendingIntent.FLAG_UPDATE_CURRENT);
 *     }
 *
 *     final Notification notification = new NotificationCompat.Builder(getApplicationContext(), channelId)
 *          ...
 *          .setContentIntent(contentIntent)
 *          .build();
 * </pre>
 * <p>
 * When the notification is clicked, the BroadcastReceiver is fired, which will start the {@link
 * zendesk.support.request.RequestActivity} on the specified request ID. The
 * {@link zendesk.support.requestlist.RequestListActivity} is started behind
 * {@link zendesk.support.request.RequestActivity}, and any specified backstack Activites behind
 * that. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class DeepLinkingBroadcastReceiver extends BroadcastReceiver {

    private static final String LOG_TAG = "DeepLinkingBroadcastReceiver";
    public static final String EXTRA_BACK_STACK_ACTIVITIES = "extra_follow_up_activities";
    public static final String EXTRA_REQUEST_INTENT = "extra_request_intent";

    @Inject
    ActionHandlerRegistry registry;

    @Override
    public void onReceive(Context context, Intent intent) {

        if (!SdkDependencyProvider.INSTANCE.isInitialized()) {
            Logger.e(LOG_TAG, "Cannot use Support SDK without initializing Zendesk. Call Zendesk.INSTANCE.init(...) "
                    + "and Support.INSTANCE.init(Zendesk)");
            return;
        }

        SdkDependencyProvider.INSTANCE.provideSupportSdkComponent().inject(this);

        Intent requestIntent = intent.getParcelableExtra(EXTRA_REQUEST_INTENT);
        List<Intent> backStackActivities = intent.getParcelableArrayListExtra(EXTRA_BACK_STACK_ACTIVITIES);

        ActionHandler handler = registry.handlerByAction(
                DeepLinkToRequestActionHandler.REQUEST_VIEW_CONVERSATION);

        if (handler != null) {
            Map<String, Object> payload = DeepLinkToRequestActionHandler.data(requestIntent, backStackActivities);
            handler.handle(payload, context);
        }
    }

}
