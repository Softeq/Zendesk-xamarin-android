package zendesk.support;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.google.gson.JsonElement;
import com.zendesk.logger.Logger;

import java.util.List;
import java.util.Map;

import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationUtil;
import zendesk.core.ActionDescription;
import zendesk.core.ActionHandler;
import zendesk.core.Zendesk;
import zendesk.support.request.RequestActivity;

public final class CreateRequestActionHandler implements ActionHandler {

    private static final String LOG_TAG = "CreateRequestActionHandler";
    private final Context context;

    CreateRequestActionHandler(Context context) {
        this.context = context;
    }

    @Override
    public boolean canHandle(@NonNull String actionName) {
        //check sdk is inited and able to handle the action
        return isInitialized() && Constants.ACTION_CONTACT_OPTION.equals(actionName);
    }

    @SuppressLint("RestrictedApi")
    @Override
    public void handle(@Nullable Map<String, Object> data, @NonNull Context context) {
        //check sdk is inited and able to handle the action
        if (isInitialized()) {
            List<Configuration> configs = extractConfigs(data);

            if (configs != null) {
                RequestActivity.builder().show(context, configs);
            } else {
                RequestActivity.builder().show(context);
            }
        }
    }

    @Override
    public int getPriority() {
        return 0;
    }

    @Override
    public ActionDescription getActionDescription() {
        final String contactUs = context.getString(R.string.zs_request_contact_option_leave_a_message);
        // TODO accessibility label for the "leave a message button"
        return new ActionDescription(contactUs, contactUs, R.drawable.zs_contact_leave_message);
    }

    @Override
    public void updateSettings(Map<String, JsonElement> settings) {
        // Intentionally empty
    }

    @VisibleForTesting
    @SuppressLint("RestrictedApi")
    List<Configuration> extractConfigs(Map<String, Object> data) {
        Configuration configuration = ConfigurationUtil.fromMap(data, Configuration.class);
        return configuration != null ? configuration.getConfigurations() : null;
    }

    private static boolean isInitialized() {
        if (Support.INSTANCE.isInitialized() && Zendesk.INSTANCE.isInitialized()) {
            return true;
        } else {
            Logger.w(LOG_TAG, "Support SDK contact handler returning false because Support.init(..) or Zendesk.init"
                    + "(..) has not been called!");
            return false;
        }
    }
}
