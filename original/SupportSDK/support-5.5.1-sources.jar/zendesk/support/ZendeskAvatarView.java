package zendesk.support;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import androidx.annotation.ColorRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.content.ContextCompat;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.zendesk.util.StringUtils;

@RestrictTo(RestrictTo.Scope.LIBRARY)
public class ZendeskAvatarView extends FrameLayout {

    private static final int[] AVATAR_COLORS = {
            R.color.zs_avatar_view_color_01, R.color.zs_avatar_view_color_02,
            R.color.zs_avatar_view_color_03, R.color.zs_avatar_view_color_04,
            R.color.zs_avatar_view_color_05, R.color.zs_avatar_view_color_06,
            R.color.zs_avatar_view_color_07, R.color.zs_avatar_view_color_08,
            R.color.zs_avatar_view_color_09, R.color.zs_avatar_view_color_10,
            R.color.zs_avatar_view_color_11, R.color.zs_avatar_view_color_12,
            R.color.zs_avatar_view_color_13, R.color.zs_avatar_view_color_14,
            R.color.zs_avatar_view_color_15, R.color.zs_avatar_view_color_16,
            R.color.zs_avatar_view_color_17, R.color.zs_avatar_view_color_18,
            R.color.zs_avatar_view_color_19,
    };

    private ImageView imageView;
    private TextView textView;
    private boolean enableOutline = false;
    private int strokeColor = 0;
    private int strokeWidth = 0;

    public ZendeskAvatarView(@NonNull Context context) {
        this(context, null, 0);
    }

    public ZendeskAvatarView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ZendeskAvatarView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initViews();
    }

    private void initViews() {
        textView = new TextView(getContext());
        textView.setId(R.id.zs_avatar_view_text_view);
        textView.setTextColor(ContextCompat.getColor(getContext(), R.color.zs_avatar_text_color));
        textView.setGravity(Gravity.CENTER);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);

        imageView = new ImageView(getContext());
        imageView.setId(R.id.zs_avatar_view_image_view);

        addView(textView);
        addView(imageView);
    }

    public void setStroke(int strokeColor, int strokeWidth) {
        this.strokeColor = strokeColor;
        this.strokeWidth = strokeWidth;
        this.enableOutline = true;
    }

    public void showUserWithAvatarImage(@NonNull Picasso picasso,
                                        @NonNull final String url,
                                        @Nullable final String
            name, int imageRadius) {
        imageView.setVisibility(VISIBLE);
        imageView.setImageResource(R.color.zs_color_transparent);

        // Show letter as place holder
        if (StringUtils.hasLength(name)) {
            textView.setVisibility(View.VISIBLE);
            setTextView(name);
        }

        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        picasso.load(url)
                .resize(imageRadius * 2, imageRadius * 2)
                .centerCrop()
                .noPlaceholder()
                .transform(PicassoTransformations.getRoundWithBorderTransformation(imageRadius, strokeColor,
                        strokeWidth))
                .into(imageView);
    }

    public void showUserWithName(@NonNull String name) {
        if (StringUtils.hasLength(name)) {
            setTextView(name);

            textView.setVisibility(View.VISIBLE);
            imageView.setVisibility(View.INVISIBLE);
        }
    }

    public void showUserWithIdentifier(@Nullable Object token) {
        if (token != null) {
            setBackground(getBackgroundShape(getColorId(token)));
            imageView.setScaleType(ImageView.ScaleType.CENTER);
            imageView.setImageResource(R.drawable.zs_request_list_account_icon);

            textView.setVisibility(View.INVISIBLE);
            imageView.setVisibility(View.VISIBLE);
        }
    }

    private void setTextView(@NonNull String text) {
        setBackground(getBackgroundShape(getColorId(text)));
        textView.setText(String.valueOf(Character.toUpperCase(text.charAt(0))));
    }

    private int getColorId(Object id) {
        return AVATAR_COLORS[Math.abs(id.hashCode() % AVATAR_COLORS.length)];
    }

    private Drawable getBackgroundShape(@ColorRes int colorId) {
        final ShapeDrawable filledBackground = new ShapeDrawable(new OvalShape());
        final int color = ContextCompat.getColor(getContext(), colorId);
        filledBackground.getPaint().setColor(color);

        if (enableOutline) {
            final ShapeDrawable outline = new ShapeDrawable(new OvalShape());
            final Paint paint = outline.getPaint();
            paint.setStyle(Paint.Style.STROKE);
            paint.setAntiAlias(true);
            paint.setColor(strokeColor);
            paint.setStrokeWidth(strokeWidth);

            final Drawable[] layer = new Drawable[]{
                    filledBackground,
                    new InsetDrawable(outline, strokeWidth / 2)};
            return new LayerDrawable(layer);

        } else {
            return filledBackground;
        }
    }
}
