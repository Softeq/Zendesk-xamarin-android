package zendesk.support;

import android.util.Patterns;

/**
 * Simple class for validating that strings conform to an email address regex pattern, abstracted
 * for the sake of testability. This implementation uses {@link Patterns#EMAIL_ADDRESS} to
 * perform the validation.
 */
class EmailValidator {

    boolean isValidEmail(String emailText) {
        return Patterns.EMAIL_ADDRESS.matcher(emailText).matches();
    }
}
