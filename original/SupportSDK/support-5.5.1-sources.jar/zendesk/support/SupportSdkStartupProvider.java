package zendesk.support;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import zendesk.core.ActionHandlerRegistry;
import zendesk.core.SdkStartUpProvider;
import zendesk.core.Zendesk;

@SuppressLint("RestrictedApi")
@RestrictTo(RestrictTo.Scope.LIBRARY)
public final class SupportSdkStartupProvider extends SdkStartUpProvider {

    @Nullable
    private CreateRequestActionHandler createRequestActionHandler;

    @Nullable
    private RequestListActionHandler requestListActionHandler;

    @Override
    protected void onStartUp(Context context) {
        final ActionHandlerRegistry handlerRegistry = Zendesk.INSTANCE.actionHandlerRegistry();
        //make sure there is no duplicates in case the content provider is called twice
        if (createRequestActionHandler != null) {
            handlerRegistry.remove(createRequestActionHandler);
        }
        if (requestListActionHandler != null) {
            handlerRegistry.remove(requestListActionHandler);
        }

        createRequestActionHandler = new CreateRequestActionHandler(context);
        requestListActionHandler = new RequestListActionHandler();

        handlerRegistry.add(createRequestActionHandler);
        handlerRegistry.add(requestListActionHandler);
    }

}
