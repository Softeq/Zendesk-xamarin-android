package zendesk.support;

import androidx.annotation.RestrictTo;
import androidx.annotation.WorkerThread;

import com.google.gson.Gson;
import com.jakewharton.disklrucache.DiskLruCache;
import com.zendesk.logger.Logger;
import com.zendesk.util.DigestUtils;

import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;

import okio.Okio;
import okio.Sink;
import okio.Source;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class SupportUiStorage {

    private static final String LOG_TAG = "SupportUiStorage";

    private static final int CACHE_INDEX = 0;
    public static final String REQUEST_MAPPER = "request_id_mapper";

    private final DiskLruCache storage;
    private final Gson gson;

    public SupportUiStorage(DiskLruCache storage, Gson gson) {
        this.storage = storage;
        this.gson = gson;
    }

    @WorkerThread
    public void write(String key, Object data) {
        DiskLruCache.Editor edit = null;
        try {
            synchronized (storage) {
                edit = storage.edit(key(key));
            }

            if (edit != null) {
                final Sink sink = Okio.sink(edit.newOutputStream(CACHE_INDEX));
                Streams.toJson(gson, sink, data);
                edit.commit();
            }

        } catch (IOException e) {
            abortEdit(edit);
        }
    }

    @WorkerThread
    public <E> E read(String key, final Type type) {
        try {
            synchronized (storage) {
                final DiskLruCache.Snapshot snapshot = storage.get(key(key));
                return Streams.use(snapshot, new Streams.Use<E, DiskLruCache.Snapshot>() {
                    @Override
                    public E use(DiskLruCache.Snapshot closable) throws Exception {
                        final Source source = Okio.source(closable.getInputStream(CACHE_INDEX));
                        final Reader reader = Streams.toReader(source);
                        return gson.fromJson(reader, type);
                    }
                });
            }
        } catch (IOException e) {
            Logger.w(LOG_TAG, "Unable to read from cache");
        }
        return null;
    }

    private static String key(String key) {
        return DigestUtils.sha1(key);
    }

    private static void abortEdit(DiskLruCache.Editor editor) {
        Logger.w(LOG_TAG, "Unable to cache data");
        if (editor != null) {
            try {
                editor.abort();
            } catch (IOException e) {
                Logger.w(LOG_TAG, "Unable to abort write", e);
            }
        }
    }
}
