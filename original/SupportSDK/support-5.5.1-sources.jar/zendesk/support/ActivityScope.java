package zendesk.support;

import androidx.annotation.RestrictTo;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import javax.inject.Scope;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@Scope
@Retention(RetentionPolicy.RUNTIME)
@RestrictTo(LIBRARY)
public @interface ActivityScope {
}