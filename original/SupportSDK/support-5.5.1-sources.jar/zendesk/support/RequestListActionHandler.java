package zendesk.support;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonSyntaxException;
import com.zendesk.logger.Logger;
import java.util.Map;
import zendesk.configurations.ConfigurationUtil;
import zendesk.core.ActionDescription;
import zendesk.core.ActionHandler;
import zendesk.support.requestlist.RequestListActivity;
import zendesk.support.requestlist.RequestListConfiguration;

class RequestListActionHandler implements ActionHandler {

    private static final String LOG_TAG = "RequestListActionHandler";

    private boolean conversationsEnabled;

    @Override
    public boolean canHandle(@NonNull String actionName) {
        return actionName.equals(Constants.ACTION_CONVERSATION_LIST) && conversationsEnabled;
    }

    @Override
    public void handle(@Nullable Map<String, Object> data, @NonNull Context context) {
        RequestListConfiguration config = ConfigurationUtil.fromMap(data, RequestListConfiguration.class);

        RequestListActivity.builder()
                .show(context, config);
    }

    @Override
    public int getPriority() {
        return 0;
    }

    @Nullable
    @Override
    public ActionDescription getActionDescription() {
        return null;
    }

    @Override
    public void updateSettings(Map<String, JsonElement> settings) {
        try {
            JsonElement jsonElement = (settings == null) ? null
                    : settings.get(ZendeskSupportSettingsProvider.SUPPORT_KEY);
            Gson gson = new GsonBuilder().create();
            SupportSettings supportSettings = gson.fromJson(jsonElement, SupportSettings.class);

            if (supportSettings != null) {
                this.conversationsEnabled = supportSettings.getConversations().isEnabled();
            }
        } catch (JsonSyntaxException exception) {
            Logger.w(LOG_TAG, "Unable to read settings.", exception);
        }
    }
}
