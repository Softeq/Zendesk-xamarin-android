package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import com.google.gson.Gson;
import com.zendesk.logger.Logger;

import java.io.Closeable;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;

import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import okio.Sink;
import okio.Source;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Collection of utils for working with streams, inspired by the Kotlin stdlib. For Zendesk
 * internal use only.
 */
@RestrictTo(LIBRARY)
public class Streams {

    /**
     * Converts an okio {@link Source} to a {@link Reader}
     */
    public static Reader toReader(Source source) {
        if (source instanceof BufferedSource) {
            return new InputStreamReader(((BufferedSource) source).inputStream());
        } else {
            return new InputStreamReader(Okio.buffer(source).inputStream());
        }
    }

    /**
     * Converts an okio {@link Sink} to a {@link Writer}
     */
    public static Writer toWriter(Sink sink) {
        if (sink instanceof BufferedSink) {
            return new OutputStreamWriter(((BufferedSink) sink).outputStream());
        } else {
            return new OutputStreamWriter(Okio.buffer(sink).outputStream());
        }
    }

    /**
     * Converts an okio json {@link Source source} to a model using the gson stream API
     */
    public static <T> T fromJson(final Gson gson, final Source source, final Type type) {
        return use(Streams.toReader(source), new Use<T, Reader>() {
            @Override
            public T use(Reader closable) throws Exception {
                return gson.fromJson(closable, type);
            }
        });
    }

    /**
     * Converts a model to json using the gson stream API and writes it to an Okio {@link Sink}
     */
    public static void toJson(final Gson gson, final Sink sink, final Object data) {
        use(Streams.toWriter(sink), new Use<Void, Writer>() {
            @Override
            public Void use(Writer closable) throws Exception {
                gson.toJson(data, closable);
                return null;
            }
        });
    }


    /**
     * Used on a Closeable and is closed automatically when
     * the useFunction has executed
     */
    public static <R, P extends Closeable> R use(@Nullable P closable, @NonNull Use<R, P> useFunction) {
        if (closable == null) {
            return null;
        }
        try {
            return useFunction.use(closable);
        } catch (Exception e) {
            Logger.i("Streams", "Error using stream", e);
            return null;
        } finally {
            closeQuietly(closable);
        }
    }

    /**
     * Function for working with Closeable types
     */
    public interface Use<R, P extends Closeable> {
        R use(P closable) throws Exception;
    }

    /**
     * Quietly closes a stream and ignored the errors
     * <p>
     * Clone of the internal method from OKHttp.
     */
    public static void closeQuietly(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (RuntimeException rethrown) {
                throw rethrown;
            } catch (Exception ignored) {
                // intentionally empty
            }
        }
    }
}
