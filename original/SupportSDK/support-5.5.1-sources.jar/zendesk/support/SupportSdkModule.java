package zendesk.support;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

import com.google.gson.Gson;
import com.jakewharton.disklrucache.DiskLruCache;
import com.squareup.picasso.OkHttp3Downloader;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.ActionHandler;
import zendesk.core.ApplicationConfiguration;
import zendesk.core.SessionStorage;
import zendesk.support.requestlist.RequestInfoDataSource;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@Module
@RestrictTo(LIBRARY)
class SupportSdkModule {

    private static final int MAX_DISK_CACHE_SIZE = 20 * 1024 * 1024; // 20mb

    @Singleton
    @Provides
    Picasso providesPicasso(Context context, OkHttp3Downloader okHttp3Downloader, ExecutorService executorService) {
        return new Picasso.Builder(context)
                .downloader(okHttp3Downloader)
                .executor(executorService)
                .defaultBitmapConfig(Bitmap.Config.RGB_565)
                .build();
    }

    @Singleton
    @Provides
    OkHttp3Downloader okHttp3Downloader(OkHttpClient okHttpClient) {
        return new OkHttp3Downloader(okHttpClient);
    }

    @SuppressLint("RestrictedApi")
    @Singleton
    @Provides
    String providesZendeskUrl(ApplicationConfiguration applicationConfiguration) {
        return applicationConfiguration.getZendeskUrl();
    }

    @Provides
    @Singleton
    List<ActionHandler> providesActionHandlers() {
        List<ActionHandler> actionHandlers = new ArrayList<>();
        actionHandlers.add(new DeepLinkToRequestActionHandler());
        return actionHandlers;
    }

    @Provides
    @Singleton
    DiskLruCache providesRequestDiskLruCache(SessionStorage sessionStorage) {
        try {
            final File dataDir = new File(sessionStorage.getZendeskDataDir(), "request");
            return DiskLruCache.open(dataDir, 1, 1, MAX_DISK_CACHE_SIZE);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Provides
    @Singleton
    Gson provides() {
        return new Gson();
    }

    @Provides
    @Singleton
    @Named(SupportSdkComponent.SUPPORT_MAIN_THREAD_EXECUTOR)
    Executor mainThreadExecutor() {
        return new Executor() {

            Handler handler = new Handler(Looper.getMainLooper());

            @Override
            public void execute(@NonNull Runnable command) {
                handler.post(command);
            }
        };
    }

    @Provides
    @Singleton
    SupportUiStorage supportUiStorage(DiskLruCache diskLruCache, Gson gson) {
        return new SupportUiStorage(diskLruCache, gson);
    }

    @Provides
    RequestInfoDataSource.LocalDataSource requestInfoDataSource(SupportUiStorage supportUiStorage,
                                                                @Named(SupportSdkComponent
                                                                        .SUPPORT_MAIN_THREAD_EXECUTOR) Executor
                                                                        mainThreadExecutor,
                                                                ExecutorService backgroundThreadExecutor) {
        return new RequestInfoDataSource.LocalDataSource(new RequestInfoDataSource.Disk(
                mainThreadExecutor, backgroundThreadExecutor, supportUiStorage, RequestInfoDataSource.LOCAL));
    }

    @Provides
    ConfigurationHelper configurationHelper() {
        return new ConfigurationHelper();
    }

}
