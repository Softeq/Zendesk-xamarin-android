package zendesk.support;

import androidx.annotation.RestrictTo;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.SafeZendeskCallback;
import com.zendesk.service.ZendeskCallback;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * ZendeskCallback implementation that holds a Set of callbacks. When this callback is triggered
 * it calls all the callbacks in the set. Its will then remove the callbacks from the set. This is
 * used to group multiple calls to the same resource to prevent loading the resource multiple times
 */
@RestrictTo(RestrictTo.Scope.LIBRARY)
public final class AggregatedCallback<T> extends ZendeskCallback<T> {

    private final Set<SafeZendeskCallback<T>> callbackSet =
            Collections.synchronizedSet(new HashSet<SafeZendeskCallback<T>>());

    @Override
    public void onSuccess(T o) {
        for (SafeZendeskCallback<T> callback : callbackSet) {
            callback.onSuccess(o);
        }
        callbackSet.clear();
    }

    @Override
    public void onError(ErrorResponse errorResponse) {
        for (SafeZendeskCallback<T> callback : callbackSet) {
            callback.onError(errorResponse);
        }
        callbackSet.clear();
    }

    /**
     * @return true if the callback is empty and should load the
     * data into this callback. false if there is already callbacks waiting and the resource
     * is loading
     */
    public boolean add(ZendeskCallback<T> callback) {
        boolean empty = callbackSet.isEmpty();
        callbackSet.add(SafeZendeskCallback.from(callback));
        return empty;
    }

    public void cancel() {
        for (SafeZendeskCallback<T> callback : callbackSet) {
            callback.cancel();
        }
        callbackSet.clear();
    }

}
