package zendesk.support;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import androidx.annotation.AttrRes;
import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import android.text.Html;
import android.util.TypedValue;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.zendesk.logger.Logger;

import java.util.Locale;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Conversion utils for screen related items. For Zendesk internal use only.
 */
@SuppressWarnings("unused")
@RestrictTo(LIBRARY)
public class UiUtils {

    private static final String LOG_TAG = "UiUtils";
    private static UiUtils IMPL = new UiUtils();

    @SuppressWarnings("WeakerAccess")
    public enum ScreenSize {
        UNKNOWN, UNDEFINED, X_LARGE, LARGE, NORMAL, SMALL
    }

    private UiUtils() {
        // Intentionally empty
    }

    @VisibleForTesting
    public static void setUiUtils(UiUtils uiUtils) {
        IMPL = uiUtils;
    }


    /**
     * Converts a attribute id in the current theme to the corresponding resolved color value.
     * <p>
     * This method will resolve a color that has been specified in a style XML file like this:
     * <br>
     * {@code <item name="colorPrimary">@color/my_primary_color</item>}
     * <br>
     * This will return the value of {@code @color/my_primary_color}.
     * </p>
     *
     * @param themeAttributeId The color attr id
     * @param context          Must be a UI context, must not be an application context. It must also be
     *                         using the theme the attribute is declared in.
     * @param fallbackColorId  Only used when there was an issue looking up the attribute color ID,
     *                         as a second choice. This should be a color reference directly, as in
     *                         {@code R.color} rather than {@code R.attr}
     * @return The resolved color value of themeAttributeId, if found, or fallbackColorId, if not.
     * If invalid IDs, or a null context is supplied, then {@link Color#BLACK} will be returned
     */
    @ColorInt
    public static int themeAttributeToColor(@AttrRes int themeAttributeId, @NonNull Context context,
                                            @ColorRes int fallbackColorId) {
        return IMPL.internalThemeAttributeToColor(themeAttributeId, context, fallbackColorId);
    }

    /**
     * Resolves a color ID to a color resource.
     *
     * @param colorId The color ID.
     * @param context Must be a UI context, must not an application context.
     * @return The resolved color resource.
     */
    public static int resolveColor(@ColorRes int colorId, @NonNull Context context) {
        return IMPL.internalResolveColor(colorId, context);
    }

    /**
     * Sets a view's visibility to one of {@link View#VISIBLE}, {@link View#INVISIBLE} or
     * {@link View#GONE}.
     * <p>
     * If the supplied view is null then no action will be attempted.
     * </p>
     *
     * @param view            The view to change the visibility of
     * @param visibilityState The visibility to set
     */
    public static void setVisibility(View view, int visibilityState) {

        if (view == null) {

            Logger.w(LOG_TAG, "View is null and can't change visibility");

        } else {
            view.setVisibility(visibilityState);
        }
    }

    /**
     * Attempts to dismiss the software keyboard.
     *
     * @param activity The activity used to obtain an {@link android.view.inputmethod.InputMethodManager}
     *                 and the current focus' window token
     */
    public static void dismissKeyboard(@Nullable Activity activity) {
        IMPL.internalDismissKeyboard(activity);
    }

    /**
     * Attemps to dismiss the software keyboard.
     *
     * @param view The current focus' window token
     */
    public static void dismissKeyboard(@Nullable View view) {
        IMPL.internalDismissKeyboard(view);
    }

    /**
     * Attempts to show the software keyboard.
     *
     * @param view The view, which would like to receive soft keyboard input.
     */
    public static void showKeyboard(@Nullable View view) {
        IMPL.internalShowKeyboard(view);
    }

    /**
     * Sets a tint on a drawable and updates the view displaying it.
     *
     * @param color    The tint color to be applied to a drawable.
     * @param drawable The drawable to be tinted.
     * @param view     The view to be invalidated.
     */
    public static void setTint(@ColorInt int color, @NonNull Drawable drawable, @Nullable View view) {
        IMPL.internalSetTint(color, drawable, view);
    }

    @VisibleForTesting
    public void internalSetTint(@ColorInt int color, Drawable drawable, View view) {
        if (drawable == null) {
            Logger.e(LOG_TAG, "Drawable is null, cannot apply a tint");
            return;
        }

        Drawable d = DrawableCompat.wrap(drawable);
        DrawableCompat.setTint(d.mutate(), color);

        if (view != null) {
            view.invalidate();
        }
    }

    @VisibleForTesting
    @SuppressWarnings("WeakerAccess")
    public int internalThemeAttributeToPixels(@AttrRes int themeAttributeId, Context context, int fallbackUnitType,
                                              float fallbackUnitValue) {
        TypedValue outValue = new TypedValue();

        Resources.Theme theme = context.getTheme();

        boolean wasFound = theme.resolveAttribute(themeAttributeId, outValue, true);

        if (!wasFound) {
            String errorMessage =
                    String.format(
                            Locale.US,
                            "Resource %d not found. Resource is either missing or you are using a non-ui context.",
                            themeAttributeId);

            Logger.e(LOG_TAG, errorMessage);
            return Math.round(TypedValue.applyDimension(fallbackUnitType, fallbackUnitValue, context.getResources()
                    .getDisplayMetrics()));

        } else {
            return Math.round(outValue.getDimension(context.getResources().getDisplayMetrics()));
        }
    }

    @VisibleForTesting
    @SuppressWarnings("WeakerAccess")
    public int internalThemeAttributeToColor(@AttrRes int themeAttributeId, @NonNull Context context,
                                             @ColorRes int fallbackColorId) {
        //noinspection ConstantConditions
        if (themeAttributeId == 0 || context == null || fallbackColorId == 0) {
            Logger.d(LOG_TAG, "themeAttributeId, context, and fallbackColorId are required.");
            return Color.BLACK;
        }

        TypedValue outValue = new TypedValue();
        Resources.Theme theme = context.getTheme();

        boolean wasResolved = theme.resolveAttribute(themeAttributeId, outValue, true);

        if (!wasResolved) {
            String errorMessage =
                    String.format(
                            Locale.US,
                            "Resource %d not found. Resource is either missing or you are using a non-ui context.",
                            themeAttributeId);
            Logger.e(LOG_TAG, errorMessage);

            return resolveColor(fallbackColorId, context);
        } else {

            /*
                Whoa Nelly! What's going on here. Well, it turns out that if you have an
                attribute pointing to a literal color as opposed to an @color/foo reference,
                then you get the actual color in outValue.data rather than getting a resourceId.
             */
            return outValue.resourceId == 0
                    ? outValue.data
                    : resolveColor(outValue.resourceId, context);
        }
    }

    @VisibleForTesting
    @SuppressWarnings("WeakerAccess")
    public int internalResolveColor(@ColorRes int colorId, @NonNull Context context) {
        return ContextCompat.getColor(context, colorId);
    }

    @VisibleForTesting
    @SuppressWarnings("WeakerAccess")
    public void internalDismissKeyboard(Activity activity) {
        if (activity == null) {
            Logger.w(LOG_TAG, "Cannot dismiss the keyboard when fragment is detached or the activity is null.");
            return;
        }

        Object systemService = activity.getSystemService(Context.INPUT_METHOD_SERVICE);

        if (systemService instanceof InputMethodManager) {
            InputMethodManager inputMethodManager = (InputMethodManager) systemService;

            View currentFocus = activity.getCurrentFocus();

            if (currentFocus != null) {
                inputMethodManager.hideSoftInputFromWindow(currentFocus.getWindowToken(), 0);
            } else {
                Logger.w(LOG_TAG, "Cannot hide soft input because window token could not be obtained");
            }
        } else {
            Logger.w(LOG_TAG, "Cannot hide soft input because we could not get the InputMethodManager");
        }
    }

    @VisibleForTesting
    @SuppressWarnings("WeakerAccess")
    public void internalDismissKeyboard(View focusedView) {
        if (focusedView == null) {
            Logger.w(LOG_TAG, "Cannot hide soft input because window token could not be obtained");
            return;
        }

        Object systemService = focusedView.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);

        if (systemService instanceof InputMethodManager) {
            InputMethodManager inputMethodManager = (InputMethodManager) systemService;

            inputMethodManager.hideSoftInputFromWindow(focusedView.getWindowToken(), 0);

        } else {
            Logger.w(LOG_TAG, "Cannot hide soft input because we could not get the InputMethodManager");
        }
    }

    @VisibleForTesting
    @SuppressWarnings("WeakerAccess")
    public void internalShowKeyboard(View view) {
        if (view == null) {
            Logger.w(LOG_TAG, "Cannot show soft input because window token could not be obtained");
            return;
        }

        Object systemService = view.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);

        if (systemService instanceof InputMethodManager) {
            InputMethodManager inputMethodManager = (InputMethodManager) systemService;

            inputMethodManager.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT);

        } else {
            Logger.w(LOG_TAG, "Cannot hide soft input because we could not get the InputMethodManager");
        }
    }

    public static CharSequence decodeHtmlEntities(String html) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        } else {
            return Html.fromHtml(html);
        }
    }
}
