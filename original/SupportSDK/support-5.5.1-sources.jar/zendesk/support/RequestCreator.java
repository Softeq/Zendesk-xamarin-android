package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import zendesk.support.request.RequestConfiguration;

@RestrictTo(RestrictTo.Scope.LIBRARY)
public class RequestCreator {

    private final RequestProvider requestProvider;
    private final UploadProvider uploadProvider;


    public RequestCreator(RequestProvider requestProvider, UploadProvider uploadProvider) {
        this.requestProvider = requestProvider;
        this.uploadProvider = uploadProvider;
    }

    void createRequest(@NonNull String description,
                       @NonNull RequestConfiguration config,
                       @Nullable ZendeskCallback<Request> callback) {

        CreateRequest request = buildCreateRequestObject(description, config);

        List<AttachmentFile> attachments = config.getFilesAsAttachments();

        if (CollectionUtils.isNotEmpty(attachments)) {
            uploadAttachments(request, attachments, callback);
        } else {
            requestProvider.createRequest(request, callback);
        }
    }

    private void uploadAttachments(final CreateRequest request, List<AttachmentFile> attachments,
                                   final ZendeskCallback<Request> callback) {
        final int attachmentCount = attachments.size();

        final AtomicInteger uploadCounter = new AtomicInteger();

        final List<String> attachmentTokens = new ArrayList<>(attachmentCount);

        for (AttachmentFile attachment: attachments) {
            uploadProvider.uploadAttachment(
                    attachment.getFileName(),
                    attachment.getFile(),
                    attachment.getMimeType(),
                    new ZendeskCallback<UploadResponse>() {
                        @Override
                        public void onSuccess(UploadResponse uploadResponse) {
                            attachmentTokens.add(uploadResponse.getToken());

                            proceedWithRequestCreationIfFinishedUploading();
                        }

                        @Override
                        public void onError(ErrorResponse errorResponse) {
                            proceedWithRequestCreationIfFinishedUploading();
                        }

                        private void proceedWithRequestCreationIfFinishedUploading() {
                            if (uploadCounter.incrementAndGet() == attachmentCount) {
                                request.setAttachments(attachmentTokens);
                                requestProvider.createRequest(request, callback);
                            }
                        }
                    });
        }
    }

    private CreateRequest buildCreateRequestObject(String description,
                                                   RequestConfiguration config) {
        CreateRequest request = new CreateRequest();

        request.setDescription(description);

        if (StringUtils.hasLength(config.getRequestSubject())) {
            request.setSubject(config.getRequestSubject());
        }

        if (CollectionUtils.isNotEmpty(config.getTags())) {
            request.setTags(config.getTags());
        }

        if (config.getTicketFormId() != RequestConfiguration.NO_TICKET_FORM_ID) {
            request.setTicketFormId(config.getTicketFormId());
        }

        if (CollectionUtils.isNotEmpty(config.getCustomFields())) {
            request.setCustomFields(config.getCustomFields());
        }

        return request;
    }
}
