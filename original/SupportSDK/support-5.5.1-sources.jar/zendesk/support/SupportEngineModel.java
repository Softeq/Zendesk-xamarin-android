package zendesk.support;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import zendesk.core.JwtIdentity;
import zendesk.classic.messaging.AgentDetails;
import zendesk.classic.messaging.components.bot.BotMessageDispatcher;
import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.AnonymousIdentity;
import zendesk.core.AuthenticationProvider;
import zendesk.core.Identity;
import zendesk.core.Zendesk;
import zendesk.classic.messaging.MessagingApi;
import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.Update;
import zendesk.support.request.RequestConfiguration;
import zendesk.support.requestlist.RequestListActivity;

class SupportEngineModel {

    private static final String LOG_TAG = "SupportEngine";
    private static final String REQUEST_LIST_ACTION_ID = "REQUEST_LIST_ACTION_ID";
    private static final String RETRY_BUTTON_ID = "zs_engine_retry_request_creation";

    private final SupportSettingsProvider settingsProvider;
    private final RequestCreator requestCreator;
    private final Zendesk zendesk;
    private final AuthenticationProvider authenticationProvider;
    private final EmailValidator emailValidator;
    private final ConfigurationHelper configHelper;
    private final AtomicBoolean conversationStarted;

    private BotMessageDispatcher<MessagingItem> messageDispatcher;

    private Context context;
    private List<Configuration> configurations;

    @NonNull
    // Initialised with a default, blank value for agentLabelState for safety
    private AgentDetails agentDetails =
            new AgentDetails(StringUtils.EMPTY_STRING, StringUtils.EMPTY_STRING, false);

    private String message;

    private enum State {
        AWAITING_MESSAGE,
        AWAITING_EMAIL,
        COMPLETE
    }

    private State state;

    SupportEngineModel(SupportSettingsProvider settingsProvider,
                       RequestCreator requestCreator,
                       Zendesk zendesk,
                       AuthenticationProvider authenticationProvider,
                       EmailValidator emailValidator,
                       ConfigurationHelper configHelper,
                       AtomicBoolean conversationStarted,
                       BotMessageDispatcher<MessagingItem> messageDispatcher) {
        this.settingsProvider = settingsProvider;
        this.requestCreator = requestCreator;
        this.zendesk = zendesk;
        this.authenticationProvider = authenticationProvider;
        this.emailValidator = emailValidator;
        this.configHelper = configHelper;
        this.conversationStarted = conversationStarted;
        this.messageDispatcher = messageDispatcher;
    }

    void start(final Context context,
               final MessagingApi messagingApi) {
        this.context = context;
        this.configurations = messagingApi.getConfigurations();
        this.agentDetails = messagingApi.getBotAgentDetails();

        if (conversationStarted.get()) {
            return; // Prevent re-starting the Engine in config changes, onResumes etc.
        }
        conversationStarted.set(true);

        this.message = messagingApi.getConversationLog().getLog();
        boolean conversationHasPreviousContent = StringUtils.hasLength(message);

        showGreeting(conversationHasPreviousContent);

        if (conversationHasPreviousContent) {
            processUserRequestMessage(message);
        } else {
            state = State.AWAITING_MESSAGE;
        }
    }

    private void processUserRequestMessage(@NonNull final String message) {
        this.message = message;
        settingsProvider.getSettings(new ZendeskCallback<SupportSdkSettings>() {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                if (userNeedsToAddEmailAddress(supportSdkSettings)) {
                    state = State.AWAITING_EMAIL;
                    promptForEmail();
                } else {
                    createRequest(message);
                }
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.w(LOG_TAG, "Error fetching settings.", errorResponse);
            }
        });
    }

    private void showGreeting(boolean conversationHasPreviousContent) {
        if (conversationHasPreviousContent) {
            displayUserTextInput(context.getString(R.string.zs_request_contact_option_leave_a_message));
        } else {
            messageDispatcher.addMessageWithTypingIndicator(new MessagingItem.TextResponse(
                    new Date(),
                    newId(),
                    agentDetails,
                    context.getString(R.string.zs_engine_greeting_message)));
        }
    }

    private void promptForEmail() {
        messageDispatcher.addMessageWithTypingIndicator(
                new MessagingItem.TextResponse(new Date(), newId(), agentDetails,
                        context.getString(R.string.zs_engine_request_creation_email_prompt_message)),
                Update.State.UpdateInputFieldState.updateHint(
                        context.getString(R.string.zs_engine_request_creation_email_prompt_hint)));
    }

    /**
     * Returns {@code true} if:
     * 1. conversations is disabled (ie {@link SupportSdkSettings#isConversationsEnabled()} returns
     * false)
     * 2. and the user is using {@link AnonymousIdentity} identity
     * 3. and the user has not set an email address
     * <p>
     * If any of these three statements are false, it returns {@code false}.
     */
    private boolean userNeedsToAddEmailAddress(SupportSdkSettings settings) {
        Identity identity = authenticationProvider.getIdentity();

        return !settings.isConversationsEnabled() && identity instanceof AnonymousIdentity
                && StringUtils.isEmpty(((AnonymousIdentity) identity).getEmail());
    }

    private void createRequest(String message) {
        messageDispatcher.dispatchUpdate(Update.State.UpdateInputFieldState.updateInputFieldEnabled(false));

        requestCreator.createRequest(message, getRequestConfiguration(), new ZendeskCallback<Request>() {
            @Override
            public void onSuccess(Request request) {
                showRequestCreatedConfirmationMessage();
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                showRequestCreatedErrorMessage();
                Logger.w(LOG_TAG, "Ticket not created: ", errorResponse);
            }
        });
    }

    private RequestConfiguration getRequestConfiguration() {
        RequestConfiguration configuration = configHelper.findConfigForType(configurations,
                RequestConfiguration.class);

        if (configuration == null) {
            configuration = (RequestConfiguration) new RequestConfiguration.Builder().config();
        }

        return configuration;
    }

    private void showRequestCreatedConfirmationMessage() {
        settingsProvider.getSettings(new ZendeskCallback<SupportSdkSettings>() {
            @Override
            public void onSuccess(SupportSdkSettings supportSdkSettings) {
                if (supportSdkSettings.isConversationsEnabled()) {
                    addConversationsEnabledConfirmation();
                } else {
                    addConversationsDisabledConfirmation();
                }

                state = State.COMPLETE;
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                Logger.w(LOG_TAG, "Error fetching settings after ticket creation.", errorResponse);
            }
        });
    }

    private void addConversationsEnabledConfirmation() {
        MessagingItem.Action action = new MessagingItem.Action(REQUEST_LIST_ACTION_ID,
                context.getString(R.string.zs_engine_request_created_request_list_button));
        List<MessagingItem.Action> actions = Collections.singletonList(action);

        messageDispatcher.addMessageWithTypingIndicator(
                new MessagingItem.ActionResponse(new Date(), newId(),
                        agentDetails,
                        context.getString(R.string.zs_engine_request_created_conversations_enabled_message),
                        actions));
    }

    private void addConversationsDisabledConfirmation() {
        Identity identity = authenticationProvider.getIdentity();

        // This check should never fail, if we've gotten this far
        if ((identity instanceof AnonymousIdentity
                && StringUtils.hasLength(((AnonymousIdentity) identity).getEmail()))
                || identity instanceof JwtIdentity) {

            String confirmationMessage = context.getString(
                    R.string.zs_engine_request_created_conversations_off_message);

            messageDispatcher.addMessageWithTypingIndicator(
                    new MessagingItem.TextResponse(new Date(), newId(),
                            agentDetails, confirmationMessage));
        }
    }

    private void showRequestCreatedErrorMessage() {
        List<MessagingItem> messagingItems = new ArrayList<>(2);

        String errorMessage = context.getString(R.string.zs_engine_message_send_error_message);
        messagingItems.add(new MessagingItem.TextResponse(new Date(), newId(),
                agentDetails, errorMessage));

        String retryMessage = context.getString(R.string.zs_engine_message_retry_button);
        MessagingItem.Option retryOption = new MessagingItem.Option(newId(), retryMessage);
        messagingItems.add(new MessagingItem.OptionsResponse(new Date(), RETRY_BUTTON_ID,
                Collections.singletonList(retryOption)));

        messageDispatcher.addMessagesWithTypingIndicator(messagingItems);
    }

    void actionItemClicked() {
        Intent intent = RequestListActivity.builder().intent(context, configurations);

        messageDispatcher.dispatchUpdate(new Update.Action.Navigation(intent));
    }

    void textEntered(String text) {
        if (state != null && state != State.COMPLETE) {
            displayUserTextInput(text);
            switch (state) {
                case AWAITING_MESSAGE: {
                    processUserRequestMessage(text);
                    break;
                }
                case AWAITING_EMAIL: {
                    if (emailValidator.isValidEmail(text)) {
                        updateIdentityAndCreateRequest(text, message);
                    } else {
                        showInvalidEmailMessage();
                    }
                    break;
                }
            }
        }
    }

    private void updateIdentityAndCreateRequest(String emailAddress, String message) {
        Identity identity = authenticationProvider.getIdentity();

        if (identity instanceof AnonymousIdentity) {
            Identity newIdentity = new AnonymousIdentity.Builder()
                    .withNameIdentifier(((AnonymousIdentity) identity).getName())
                    .withEmailIdentifier(emailAddress)
                    .build();

            zendesk.setIdentity(newIdentity);

            createRequest(message);
        }
    }

    private void showInvalidEmailMessage() {
        messageDispatcher.addMessageWithTypingIndicator(new MessagingItem.TextResponse(
                new Date(),
                newId(),
                agentDetails,
                context.getString(R.string.zs_engine_request_creation_email_validation_failed_message)
        ));
    }

    private void displayUserTextInput(String textInput) {
        messageDispatcher.addMessage(new MessagingItem.TextQuery(new Date(),
                newId(),
                MessagingItem.Query.Status.DELIVERED,
                textInput));
    }

    void retryClicked() {
        messageDispatcher.replaceMessage(RETRY_BUTTON_ID,
                new MessagingItem.TextQuery(new Date(), newId(),
                        MessagingItem.Query.Status.DELIVERED,
                        context.getString(R.string.zs_engine_message_retry_button)));

        createRequest(message);
    }

    private static String newId() {
        return UUID.randomUUID().toString();
    }

}
