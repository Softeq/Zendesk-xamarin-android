package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;

import java.io.File;
import java.io.Serializable;

/**
 * Model class representing a file to be uploaded to Zendesk Support as an attachment to a request
 * comment.
 *
 * This class is a convenience, a holder for the parameters required by
 * {@link UploadProvider#uploadAttachment(String, File, String, ZendeskCallback)}.
 */
public class AttachmentFile implements Serializable {

    private String fileName;
    private String mimeType;
    private File file;

    /**
     * Construct a new instance of an AttachmentFile with the provided file name, MIME type, and
     * file. The arguments are not checked for nullability or content. Their values can be retrieved
     * using the corresponding getters.
     *
     * @param fileName the text to be used as the name of the file when uploading it.
     * @param mimeType the String representation of the MIME type of the file to be used when
     *                 uploading it.
     * @param file the {@link File} to be uploaded.
     */
    public AttachmentFile(@NonNull String fileName, @NonNull String mimeType, @NonNull File file) {
        this.fileName = fileName;
        this.mimeType = mimeType;
        this.file = file;
    }

    /**
     * @return the fileName passed in the constructor.
     */
    @Nullable
    public String getFileName() {
        return fileName;
    }

    /**
     * @return the mimeType passed in the constructor.
     */
    @Nullable
    public String getMimeType() {
        return mimeType;
    }

    /**
     * @return the {@link File} passed in the constructor.
     */
    @Nullable
    public File getFile() {
        return file;
    }
}
