package zendesk.support;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import androidx.annotation.RestrictTo;

import com.squareup.picasso.Transformation;

import java.util.Locale;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class PicassoTransformations {

    private PicassoTransformations() {
        // intentionally empty
    }

    public static Transformation getRoundedTransformation(int radius) {
        return new RoundedTransformation(radius);
    }

    public static Transformation getBlurTransformation(Context context) {
        return new BlurTransformation(context);
    }

    public static Transformation getRoundWithBorderTransformation(int radius, int color, int strokeWith) {
        return new RoundedTransformation(radius, color, strokeWith);
    }

    private static class BlurTransformation implements Transformation {

        private final RenderScript rs;

        BlurTransformation(Context context) {
            rs = RenderScript.create(context);
        }

        @Override
        public Bitmap transform(Bitmap bitmap) {

            final Bitmap blurredBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
            final ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
            Allocation input = null;
            Allocation output = null;

            try {
                input = Allocation.createFromBitmap(rs, blurredBitmap, Allocation.MipmapControl.MIPMAP_FULL,
                        Allocation.USAGE_SHARED);
                output = Allocation.createTyped(rs, input.getType());

                script.setInput(input);
                script.setRadius(25);
                script.forEach(output);
                output.copyTo(blurredBitmap);

            } finally {
                bitmap.recycle();
                rs.destroy();
                script.destroy();

                if (input != null) {
                    input.destroy();
                }
                if (output != null) {
                    output.destroy();
                }
            }

            return blurredBitmap;

        }

        @Override
        public String key() {
            return "blur";
        }
    }

    private static class RoundedTransformation implements Transformation {

        private final int radius;
        private final int strokeWidth;
        private final int strokeColor;

        RoundedTransformation(int radius) {
            this(radius, Color.TRANSPARENT, -1);
        }

        RoundedTransformation(int radius, int strokeColor, int strokeWidth) {
            this.radius = radius;
            this.strokeColor = strokeColor;
            this.strokeWidth = strokeWidth;
        }

        @Override
        public Bitmap transform(final Bitmap source) {

            Bitmap bitmap = source;

            // draw border
            if (strokeWidth > 0) {
                if (!source.isMutable()) {
                    bitmap = source.copy(Bitmap.Config.ARGB_8888, true);
                    if (bitmap != source) {
                        source.recycle();
                    }
                }

                final Canvas canvas = new Canvas(bitmap);
                final Paint paint = strokePaint();

                final Path circle = new Path();
                circle.setFillType(Path.FillType.INVERSE_EVEN_ODD);

                final RectF borderMask = getMask(bitmap.getWidth(), bitmap.getHeight(), strokeWidth);
                circle.addRoundRect(borderMask, radius, radius, Path.Direction.CW);

                canvas.drawPath(circle, paint);
            }

            // cut out
            final Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
            final Canvas canvas = new Canvas(output);
            final Paint shapePaint = shapePaint(bitmap);
            final RectF mask = getMask(bitmap.getWidth(), bitmap.getHeight(), 0);
            canvas.drawRoundRect(mask, radius, radius, shapePaint);

            if (bitmap != output) {
                bitmap.recycle();
            }

            return output;
        }

        private RectF getMask(int width, int height, int offset) {
            return new RectF(offset, offset, width - offset, height - offset);
        }

        private Paint shapePaint(Bitmap source) {
            final Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setShader(new BitmapShader(source, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
            return paint;
        }

        private Paint strokePaint() {
            final Paint paint = new Paint();
            paint.setAntiAlias(true);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(strokeColor);
            return paint;
        }

        @Override
        public String key() {
            String keyFormat = "rounded-%s-%s-%s";

            return String.format(Locale.US, keyFormat, radius, strokeColor, strokeWidth);
        }
    }
}
