package zendesk.support.requestlist;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.func.ZFunc1;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.Date;
import java.util.List;

import zendesk.support.request.RequestConfiguration;

/**
 * UI model for the list. For Zendesk internal use only.
 */
class RequestListItem {

    private final RequestInfo requestInfo;


    RequestListItem(@NonNull RequestInfo requestInfo) {
        this.requestInfo = requestInfo;
    }

    boolean isFailed() {
        return CollectionUtils.isNotEmpty(requestInfo.getFailedMessageIds());
    }

    boolean isClosed() {
        return requestInfo.isClosed();
    }

    boolean isUnread() {
        return requestInfo.isUnread();
    }

    @NonNull
    String getFirstMessage() {
        return requestInfo.getFirstMessageInfo().getBody();
    }

    @NonNull
    String getLastMessage() {
        return requestInfo.getLastMessageInfo().getBody();
    }

    @Nullable
    Date getLastUpdated() {
        return requestInfo.getLastUpdated();
    }

    boolean hasAgentReplied() {
        return CollectionUtils.isNotEmpty(requestInfo.getAgentInfos());
    }

    @NonNull
    List<String> getLastCommentingAgentNames() {
        return CollectionUtils.map(requestInfo.getAgentInfos(), new ZFunc1<RequestInfo.AgentInfo, String>() {
            @Override
            public String apply(RequestInfo.AgentInfo agentInfo) {
                return agentInfo.getName();
            }
        });
    }

    @Nullable
    String getAvatar() {
        if (hasAgentReplied()) {
            return requestInfo.getAgentInfos().get(0).getAvatar();
        }
        return StringUtils.EMPTY_STRING;
    }

    long getItemId() {
        String localId = requestInfo.getLocalId();
        String remoteId = requestInfo.getRemoteId();

        return StringUtils.hasLength(localId)
                ? localId.hashCode()
                : remoteId.hashCode();
    }

    RequestConfiguration.Builder configure(RequestConfiguration.Builder configBuilder) {
        return configBuilder.withRequestInfo(requestInfo);
    }
}
