package zendesk.support.requestlist;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationUtil;

/**
 * Data class, that represents the initial configuration of {@link RequestListActivity}. Use the
 * {@link Builder} to create an instance.
 */
public class RequestListConfiguration implements Configuration {

    private final List<Configuration> configurations;

    private final boolean contactUsButtonVisible;

    private RequestListConfiguration(Builder builder) {
        this.contactUsButtonVisible = builder.contactUsButtonVisible;
        this.configurations = builder.configurations;
    }

    @SuppressLint("RestrictedApi")
    @Override
    public List<Configuration> getConfigurations() {
        return ConfigurationUtil.addSelfIfNotInList(configurations, this);
    }

    boolean isContactUsButtonVisible() {
        return contactUsButtonVisible;
    }

    public static class Builder {

        private List<Configuration> configurations = new ArrayList<>();

        private boolean contactUsButtonVisible = true;

        public Builder() {
            // intentionally empty
        }

        /**
         Define whether or not to display the "ContactUs" Floating Action Button.
         *
         * @param showContactUsButton Boolean value to determine whether the contact button is visible
         * @return The Builder
         */
        public RequestListConfiguration.Builder withContactUsButtonVisible(boolean showContactUsButton) {
            this.contactUsButtonVisible = showContactUsButton;
            return this;
        }

        /**
         * Configurations for screen that can be started from RequestListActivity.
         */
        private void setConfigurations(@NonNull List<Configuration> configurations) {
            this.configurations = configurations;
        }

        /**
         * Show the {@link RequestListActivity} with the specified
         * configuration options.
         *
         * @param context   The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for screens that can be started from RequestListActivity.
         */
        public void show(@NonNull Context context, Configuration... configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Show the {@link RequestListActivity} with the specified
         * configuration options.
         *
         * @param context   The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for screens that can be started from RequestListActivity.
         */
        public void show(@NonNull Context context, List<Configuration> configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Create an {@link Intent} to start the {@link RequestListActivity} with the specified
         * configuration options.
         *
         * @param context   The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for screens that can be started from RequestListActivity.
         * @return An {@link Intent} for {@link RequestListActivity} with the specified configuration
         * options
         */
        public Intent intent(@NonNull Context context, Configuration... configurations) {
            return intent(context, Arrays.asList(configurations));
        }

        /**
         * Create an {@link Intent} to start the {@link RequestListActivity} with the specified
         * configuration options.
         *
         * @param context   The context which {@code startActivity} will be invoked on
         * @param configurations Configurations for screens that can be started from RequestListActivity.
         * @return An {@link Intent} for {@link RequestListActivity} with the specified configuration
         * options
         */
        @SuppressLint("RestrictedApi")
        public Intent intent(@NonNull Context context, List<Configuration> configurations) {
            setConfigurations(configurations);

            final Configuration config = config();
            final Intent intent = new Intent(context, RequestListActivity.class);
            ConfigurationUtil.addToIntent(intent, config);
            return intent;
        }

        /**
         * Create a {@link Configuration} for the passed in configuration options.
         */
        @NonNull
        public Configuration config() {
            return new RequestListConfiguration(this);
        }
    }

}
