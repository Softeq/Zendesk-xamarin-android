package zendesk.support.requestlist;

import android.content.Context;
import android.graphics.Typeface;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import zendesk.support.R;
import zendesk.support.UiUtils;
import zendesk.support.ZendeskAvatarView;


class RequestListViewHolder extends RecyclerView.ViewHolder {

    static RequestListViewHolder create(Context context, ViewGroup viewGroup, RequestListView.OnItemClick listener,
                                        Picasso picasso) {
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        View view = layoutInflater.inflate(R.layout.zs_request_list_ticket_item, viewGroup, false);
        return new RequestListViewHolder(view, listener, picasso);
    }

    private final RequestListView.OnItemClick listener;

    private final Context context;
    private final Picasso picasso;
    private final ZendeskAvatarView avatarView;
    private final TextView timeText;
    private final TextView userText;
    private final TextView subjectText;
    private final TextView commentText;
    private final int avatarRadius;


    private RequestListViewHolder(View itemView, final RequestListView.OnItemClick listener, Picasso picasso) {
        super(itemView);
        this.listener = listener;
        this.picasso = picasso;
        context = itemView.getContext();

        avatarView = itemView.findViewById(R.id.request_list_item_avatar);

        timeText = itemView.findViewById(R.id.request_list_item_time);
        userText = itemView.findViewById(R.id.request_list_item_user);
        subjectText = itemView.findViewById(R.id.request_list_item_subject);
        commentText = itemView.findViewById(R.id.request_list_item_body);

        avatarRadius = context.getResources().getDimensionPixelOffset(R.dimen.zs_request_list_avatar_radius);
    }

    void bind(@NonNull final RequestListItem requestListItem) {
        userText.setText(generateUserText(context.getString(R.string.request_list_me), requestListItem
                .getLastCommentingAgentNames()));
        subjectText.setText(requestListItem.hasAgentReplied()
                ? context.getString(R.string.request_list_re, requestListItem.getFirstMessage())
                : requestListItem.getFirstMessage());

        if (requestListItem.isClosed()) {
            commentText.setText(R.string.request_list_ticket_closed);
        } else if (requestListItem.isFailed()) {
            commentText.setText(R.string.ask_request_list_failed_request_message);
        } else {
            commentText.setText(requestListItem.getLastMessage());
        }

        Date lastUpdated = requestListItem.getLastUpdated();
        timeText.setText(lastUpdated != null ? getDateTimeString(lastUpdated) : StringUtils.EMPTY_STRING);

        bindAvatar(requestListItem.hasAgentReplied(), requestListItem.getLastCommentingAgentNames(), requestListItem
                .getAvatar());
        style(requestListItem.isUnread(), requestListItem.isFailed(), requestListItem.isClosed());

        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onClick(requestListItem);
            }
        });
    }

    @NonNull
    private String generateUserText(String me, List<String> lastCommentingAgents) {
        List<String> users = new ArrayList<>(lastCommentingAgents);
        users.add(me);

        return TextUtils.join(", ", users);
    }

    private void bindAvatar(boolean hasAgentReplied, List<String> agentNames, String avatar) {
        if (hasAgentReplied) {
            boolean avatarUrlAvailable = StringUtils.hasLength(avatar);

            if (avatarUrlAvailable) {
                avatarView.showUserWithAvatarImage(picasso, avatar, agentNames.get(0), avatarRadius);
            } else {
                //noinspection ConstantConditions
                avatarView.showUserWithName(agentNames.get(0));
            }
        } else {
            avatarView.showUserWithIdentifier(R.string.request_list_me);
        }
    }

    private void style(boolean isUnread, boolean isFailed, boolean isClosed) {
        if (isUnread) {
            subjectText.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            userText.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
            commentText.setTextColor(ContextCompat.getColor(context, R.color.zs_request_list_dark_text_color));
            timeText.setTextColor(UiUtils.themeAttributeToColor(R.attr.colorPrimary, context, R.color
                    .zs_request_list_light_text_color));
        } else {
            subjectText.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
            userText.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
            commentText.setTextColor(ContextCompat.getColor(context, R.color.zs_request_list_light_text_color));
            timeText.setTextColor(ContextCompat.getColor(context, R.color.zs_request_list_light_text_color));
        }

        if (isFailed) {
            commentText.setTextColor(ContextCompat.getColor(context, R.color.zs_request_cell_label_color_error));
        }
        itemView.setBackgroundColor(ContextCompat.getColor(context, R.color.zs_request_list_white));
    }

    private CharSequence getDateTimeString(@NonNull Date lastUpdated) {
        return DateUtils.getRelativeTimeSpanString(context, lastUpdated.getTime(), false);
    }
}
