package zendesk.support.requestlist;

import androidx.annotation.RestrictTo;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

import javax.inject.Named;

import zendesk.core.MemoryCache;
import zendesk.support.ActivityScope;
import zendesk.support.RequestProvider;
import zendesk.support.SupportBlipsProvider;
import zendesk.support.SupportSdkComponent;
import zendesk.support.SupportSettingsProvider;
import zendesk.support.SupportUiStorage;

import dagger.Module;
import dagger.Provides;

/**
 * For Zendesk internal use only.
 */
@Module
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class RequestListModule {

    @Provides
    @ActivityScope
    RequestListPresenter presenter(RequestListModel model) {
        return new RequestListPresenter(model);
    }

    @Provides
    @ActivityScope
    static RequestInfoDataSource.Repository repository(RequestInfoDataSource.LocalDataSource localDataSource,
                                                       SupportUiStorage supportUiStorage, RequestProvider
                                                               requestProvider,
                                                       @Named(SupportSdkComponent.SUPPORT_MAIN_THREAD_EXECUTOR)
                                                               Executor mainThreadExecutor,
                                                       ExecutorService backgroundThreadExecutor) {
        final RequestInfoDataSource.Network network = new RequestInfoDataSource.Network(requestProvider);
        final RequestInfoDataSource.Disk disk = new RequestInfoDataSource.Disk(mainThreadExecutor,
                backgroundThreadExecutor, supportUiStorage, RequestInfoDataSource.REMOTE);
        final RequestInfoDataSource remoteDataSource = new RequestInfoDataSource.RemoteDataSource(network, disk);
        return new RequestInfoDataSource.Repository(localDataSource, remoteDataSource, new RequestInfoMerger());
    }

    @Provides
    @ActivityScope
    RequestListModel model(RequestInfoDataSource.Repository requestInfoDataSource, MemoryCache memoryCache,
                                  SupportBlipsProvider blipsProvider, SupportSettingsProvider settingsProvider) {
        return new RequestListModel(requestInfoDataSource, memoryCache, blipsProvider, settingsProvider);
    }

    @Provides
    @ActivityScope
    static RequestListSyncHandler refreshHandler(RequestListPresenter presenter) {
        return new RequestListSyncHandler(presenter);
    }
}
