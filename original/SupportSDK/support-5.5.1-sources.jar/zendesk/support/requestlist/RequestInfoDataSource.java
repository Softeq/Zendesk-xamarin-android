package zendesk.support.requestlist;

import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.reflect.TypeToken;
import com.zendesk.func.ZFunc1;
import com.zendesk.func.ZFunc2;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.Executor;

import zendesk.support.Attachment;
import zendesk.support.Comment;
import zendesk.support.Request;
import zendesk.support.RequestProvider;
import zendesk.support.RequestUpdates;
import zendesk.support.SupportUiStorage;
import zendesk.support.User;

public interface RequestInfoDataSource {

    String LOCAL = "local_request_infos";
    String REMOTE = "remote_request_infos";

    void load(@NonNull ZendeskCallback<List<RequestInfo>> callback);

    class Repository implements RequestInfoDataSource {

        private final RequestInfoDataSource localDataSource;
        private final RequestInfoDataSource remoteDataSource;
        private final RequestInfoMerger merger;

        Repository(@NonNull RequestInfoDataSource localDataSource,
                   @NonNull RequestInfoDataSource remoteDataSource,
                   @NonNull RequestInfoMerger merger) {
            this.localDataSource = localDataSource;
            this.remoteDataSource = remoteDataSource;
            this.merger = merger;
        }

        @MainThread
        @Override
        public void load(@NonNull final ZendeskCallback<List<RequestInfo>> callback) {
            localDataSource.load(new ZendeskCallback<List<RequestInfo>>() {
                @Override
                public void onSuccess(final List<RequestInfo> localInfos) {
                    remoteDataSource.load(new ZendeskCallback<List<RequestInfo>>() {
                        @Override
                        public void onSuccess(List<RequestInfo> remoteInfos) {
                            callback.onSuccess(merger.merge(localInfos, remoteInfos));
                        }

                        @Override
                        public void onError(ErrorResponse errorResponse) {
                            callback.onError(errorResponse);
                        }
                    });
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    // Intentionally empty
                }
            });
        }
    }

    class Disk implements RequestInfoDataSource {

        private final Executor mainThreadExecutor;
        private final Executor backgroundThreadExecutor;
        private final SupportUiStorage supportUiStorage;
        private final String cacheKey;

        public Disk(@NonNull Executor mainThreadExecutor,
                    @NonNull Executor backgroundThreadExecutor,
                    @NonNull SupportUiStorage supportUiStorage, @NonNull String cacheKey) {
            this.mainThreadExecutor = mainThreadExecutor;
            this.backgroundThreadExecutor = backgroundThreadExecutor;
            this.supportUiStorage = supportUiStorage;
            this.cacheKey = cacheKey;
        }

        @MainThread
        @Override
        public void load(@NonNull final ZendeskCallback<List<RequestInfo>> callback) {
            backgroundThreadExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    final Type type = new TypeToken<List<RequestInfo>>() {
                    }.getType();
                    final List<RequestInfo> requestInfos = supportUiStorage.read(cacheKey, type);

                    mainThreadExecutor.execute(new Runnable() {
                        @Override
                        public void run() {
                            callback.onSuccess(CollectionUtils.ensureEmpty(requestInfos));
                        }
                    });
                }
            });
        }

        void save(@NonNull final List<RequestInfo> requestInfos, @Nullable final ZendeskCallback<List<RequestInfo>>
                callback) {
            backgroundThreadExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    supportUiStorage.write(cacheKey, requestInfos);

                    if (callback != null) {
                        mainThreadExecutor.execute(new Runnable() {
                            @Override
                            public void run() {
                                callback.onSuccess(requestInfos);
                            }
                        });
                    }
                }
            });
        }
    }

    class Network implements RequestInfoDataSource {

        private final RequestProvider requestProvider;

        Network(@NonNull RequestProvider requestProvider) {
            this.requestProvider = requestProvider;
        }

        @MainThread
        @Override
        public void load(@NonNull final ZendeskCallback<List<RequestInfo>> callback) {
            requestProvider.getAllRequests(new ZendeskCallback<List<Request>>() {
                @Override
                public void onSuccess(final List<Request> requests) {
                    requestProvider.getUpdatesForDevice(new ZendeskCallback<RequestUpdates>() {
                        @Override
                        public void onSuccess(final RequestUpdates requestUpdates) {
                            final List<RequestInfo> fetchedItems = CollectionUtils.map(requests, new ZFunc1<Request,
                                    RequestInfo>() {
                                @Override
                                public RequestInfo apply(Request request) {
                                    return map(request, requestUpdates.isRequestUnread(request.getId()));
                                }
                            });

                            callback.onSuccess(fetchedItems);
                        }

                        @Override
                        public void onError(ErrorResponse errorResponse) {
                            callback.onError(errorResponse);
                        }
                    });
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    callback.onError(errorResponse);
                }
            });
        }

        private RequestInfo map(Request request, boolean unread) {
            Comment firstComment = request.getFirstComment();
            Comment lastComment = request.getLastComment();
            final List<User> filteredAgents = CollectionUtils.filter(request.getLastCommentingAgents(), new
                    ZFunc1<User, Boolean>() {
                        @Override
                        public Boolean apply(User user) {
                            return user != null;
                        }
                    });
            List<RequestInfo.AgentInfo> lastCommentingAgents = CollectionUtils.map(filteredAgents,
                    new ZFunc1<User, RequestInfo.AgentInfo>() {
                        @Override
                        public RequestInfo.AgentInfo apply(User user) {
                            Attachment attachment = user.getPhoto();
                            String avatar = attachment != null ? attachment.getContentUrl() : StringUtils.EMPTY_STRING;
                            return new RequestInfo.AgentInfo(String.valueOf(user.getId()), user.getName(), avatar);
                        }
                    });
            // noinspection ConstantConditions
            return new RequestInfo(StringUtils.EMPTY_STRING, request.getId(), request.getStatus(),
                    unread, request.getPublicUpdatedAt(), lastCommentingAgents,
                    new RequestInfo.MessageInfo(String.valueOf(firstComment.getId()), firstComment.getCreatedAt(),
                            firstComment.getBody()),
                    new RequestInfo.MessageInfo(String.valueOf(lastComment.getId()), lastComment.getCreatedAt(),
                            lastComment.getBody()),
                    new HashSet<String>());
        }
    }

    class RemoteDataSource implements RequestInfoDataSource {

        private final Network network;
        private final Disk disk;

        RemoteDataSource(@NonNull Network network, @NonNull Disk disk) {
            this.network = network;
            this.disk = disk;
        }

        @Override
        public void load(@NonNull final ZendeskCallback<List<RequestInfo>> callback) {
            network.load(new ZendeskCallback<List<RequestInfo>>() {
                @Override
                public void onSuccess(List<RequestInfo> requestInfos) {
                    disk.save(requestInfos, callback);
                }

                @Override
                public void onError(final ErrorResponse errorResponse) {
                    disk.load(new ZendeskCallback<List<RequestInfo>>() {
                        @Override
                        public void onSuccess(List<RequestInfo> requestInfos) {
                            callback.onSuccess(requestInfos);
                            callback.onError(errorResponse);
                        }

                        @Override
                        public void onError(ErrorResponse errorResponse) {
                            callback.onError(errorResponse);
                        }
                    });
                }
            });
        }
    }

    class LocalDataSource implements RequestInfoDataSource {

        private static final Comparator<RequestInfo> REQUEST_INFO_COMPARATOR = new RequestInfo.LastUpdatedComparator();

        private final Disk disk;

        public LocalDataSource(Disk disk) {
            this.disk = disk;
        }

        @MainThread
        @Override
        public void load(@NonNull final ZendeskCallback<List<RequestInfo>> callback) {
            disk.load(callback);
        }

        public void insert(@NonNull final RequestInfo requestInfo, @Nullable final ZendeskCallback<List<RequestInfo>>
                callback) {
            disk.load(new ZendeskCallback<List<RequestInfo>>() {
                @Override
                public void onSuccess(List<RequestInfo> requestInfos) {
                    final List<RequestInfo> mergedItems = CollectionUtils.appendOrReplace(requestInfos, requestInfo,
                            new ZFunc2<RequestInfo, RequestInfo, Boolean>() {
                                @Override
                                public Boolean apply(RequestInfo current, RequestInfo updated) {
                                    final boolean sameLocalIds = updated.getLocalId().equals(current.getLocalId());
                                    final boolean sameRemoteIds = StringUtils.hasLength(updated.getRemoteId())
                                            && updated.getRemoteId().equals(current.getRemoteId());
                                    return sameLocalIds || sameRemoteIds;
                                }
                            });

                    Collections.sort(mergedItems, REQUEST_INFO_COMPARATOR);

                    disk.save(mergedItems, callback);
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    if (callback != null) {
                        callback.onError(errorResponse);
                    }
                }
            });
        }

        public void remove(@NonNull final String id, @Nullable final ZendeskCallback<List<RequestInfo>> callback) {
            disk.load(new ZendeskCallback<List<RequestInfo>>() {
                @Override
                public void onSuccess(List<RequestInfo> requestInfos) {
                    List<RequestInfo> filtered = CollectionUtils.filter(requestInfos, new ZFunc1<RequestInfo,
                            Boolean>() {
                        @Override
                        public Boolean apply(RequestInfo requestInfo) {
                            return !id.equals(requestInfo.getLocalId());
                        }
                    });

                    disk.save(filtered, callback);
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    if (callback != null) {
                        callback.onError(errorResponse);
                    }
                }
            });
        }
    }
}
