package zendesk.support.requestlist;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import android.view.View;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.SafeZendeskCallback;
import com.zendesk.service.ZendeskCallback;

import java.util.List;

import zendesk.support.SupportSdkSettings;
import zendesk.support.request.RequestActivity;
import zendesk.support.request.RequestConfiguration;


class RequestListPresenter {

    private final CancelableCompositeCallback callbacks = new CancelableCompositeCallback();

    private RequestListView view;
    private final RequestListModel model;


    public RequestListPresenter(RequestListModel model) {
        this.model = model;
    }

    void onCreate(final boolean init, RequestListView requestListView) {

        this.view = requestListView;

        //Listeners setup
        setupItemClickListener();
        setupPullToRefreshListener();
        setupNavigationClickListener();
        setupErrorClickListener();
        setupCreateTicketClickListener();

        loadSettings(new SettingsCallback() {
            @Override
            public void onSettings(@Nullable SupportSdkSettings supportSdkSettings) {
                if (supportSdkSettings == null || !supportSdkSettings.isConversationsEnabled()) {
                    if (view != null) {
                        view.finish("Conversations are disabled in sdk settings, closing the request list screen!");
                    }
                    return;
                }
                // Toggle Zendesk logo
                setupLogoView(view, supportSdkSettings.isShowReferrerLogoEnabled(),
                        supportSdkSettings.getReferrerUrl());
                loadItems(init, supportSdkSettings);

                if (init) {
                    model.trackRequestListViewed();
                }
            }
        });
    }

    void refresh() {
        loadSettings(new SettingsCallback() {
            @Override
            public void onSettings(@Nullable SupportSdkSettings supportSdkSettings) {
                if (supportSdkSettings == null || !supportSdkSettings.isConversationsEnabled()) {
                    if (view != null) {
                        view.finish("Conversations are disabled in sdk settings, closing the request list screen!");
                    }
                    return;
                }
                loadItems(true, supportSdkSettings);
            }
        });
    }

    /**
     * called on destroy in activity. If the isChangingConfiguration param is false then
     * the presenter should clean up any cached data.
     *
     * @param isChangingConfiguration true if the activity is being recreated
     */
    void onDestroy(boolean isChangingConfiguration) {
        if (!isChangingConfiguration) {
            model.cleanup();
        }
        view = null;
        callbacks.cancel();
    }

    @VisibleForTesting
    void loadItems(boolean fresh, SupportSdkSettings supportSdkSettings) {
        ZendeskCallback<List<RequestListItem>> callback = new ZendeskCallback<List<RequestListItem>>() {
            @Override
            public void onSuccess(List<RequestListItem> items) {
                showRequestList(items);
            }

            @Override
            public void onError(ErrorResponse errorResponse) {
                showError(errorResponse);
            }
        };

        callbacks.add(SafeZendeskCallback.from(callback));
        view.setLoading(true);
        model.loadItems(fresh, supportSdkSettings, callback);
    }

    @VisibleForTesting
    void showRequestList(List<RequestListItem> items) {
        if (view != null) {
            view.showRequestList(items);
            view.setLoading(false);
        }
    }

    @VisibleForTesting
    void showError(ErrorResponse errorResponse) {
        if (view != null) {
            view.setLoading(false);
            view.showErrorMessage();
        }
    }

    private void loadSettings(SettingsCallback callback) {
        //check the cached conversations enabled after rotation
        //if not cached load from the provider
        SupportSdkSettings settings = model.getCachedSettings();
        if (settings == null) {
            fetchSettingsFromNetwork(callback);
        } else {
            callback.onSettings(settings);
        }
    }

    private void fetchSettingsFromNetwork(final SettingsCallback callback) {
        final SafeZendeskCallback<SupportSdkSettings> settingsCallback =
                SafeZendeskCallback.from(new ZendeskCallback<SupportSdkSettings>() {
                    @Override
                    public void onSuccess(SupportSdkSettings supportSdkSettings) {
                        model.cacheSupportSdkSettings(supportSdkSettings);
                        callback.onSettings(supportSdkSettings);
                    }

                    @Override
                    public void onError(ErrorResponse errorResponse) {
                        callback.onSettings(null);
                        if (view != null) {
                            view.finish("Conversations are disabled in sdk settings, closing the request list screen!");
                        }
                    }
                });
        callbacks.add(settingsCallback);
        view.setLoading(true);
        model.loadSettings(settingsCallback);
    }

    /**
     * Listen for back clicks
     */
    private void setupNavigationClickListener() {
        final View.OnClickListener navigationClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.finish();
            }
        };
        view.setBackClickListener(navigationClickListener);
    }


    /**
     * Listen for retry clicks
     */
    private void setupErrorClickListener() {
        final View.OnClickListener errorClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refresh();
            }
        };
        view.setRetryClickListener(errorClickListener);
    }

    /**
     * Listen for list item clicks
     */
    private void setupItemClickListener() {
        final RequestListView.OnItemClick itemClickListener = new RequestListView.OnItemClick() {
            @Override
            public void onClick(RequestListItem requestListItem) {
                RequestConfiguration.Builder configBuilder = RequestActivity.builder();
                view.startRequestActivity(requestListItem.configure(configBuilder));
            }
        };
        view.setItemClickListener(itemClickListener);
    }

    /**
     * Listen for pull to refresh
     */
    private void setupPullToRefreshListener() {
        final SwipeRefreshLayout.OnRefreshListener onRefreshListener = new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                refresh();
            }
        };
        view.setSwipeRefreshListener(onRefreshListener);
    }

    /**
     * Listen for create ticket clicks
     */
    private void setupCreateTicketClickListener() {
        final View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.startRequestActivity(RequestActivity.builder());
            }
        };
        view.setCreateRequestListener(onClickListener);
    }

    private void setupLogoView(final RequestListView view, final boolean logoVisible, final String url) {
        view.setLogoClickListener(logoVisible, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.startReferrerPage(url);
            }
        });
    }

    private interface SettingsCallback {
        void onSettings(@Nullable SupportSdkSettings supportSdkSettings);
    }
}
