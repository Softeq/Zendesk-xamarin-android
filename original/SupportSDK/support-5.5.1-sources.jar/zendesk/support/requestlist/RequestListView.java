package zendesk.support.requestlist;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.annotation.VisibleForTesting;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import androidx.transition.Fade;
import androidx.transition.Scene;
import androidx.transition.TransitionManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.squareup.picasso.Picasso;
import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.List;

import zendesk.commonui.SystemWindowInsets;
import zendesk.support.R;
import zendesk.commonui.InsetType;
import zendesk.support.UiUtils;
import zendesk.support.request.RequestConfiguration;
import zendesk.support.request.ViewAlmostRealProgressBar;

@SuppressLint("ViewConstructor")
class RequestListView extends FrameLayout {

    interface OnItemClick {
        void onClick(final RequestListItem requestListItem);
    }

    private static final String REQUEST_LIST_VIEW_SUPERSTATE_KEY = "request_list_view_superstate";
    private static final String IS_SHOWING_SNACKBAR_KEY = "is_showing_snackbar";

    private final ViewAlmostRealProgressBar progressBar;
    private final RecyclerView recyclerView;
    private final ViewGroup sceneRoot;
    private final SwipeRefreshLayout swipeRefreshLayout;
    private final SwipeRefreshLayout swipeRefreshLayoutEmpty;
    private final RequestListAdapter adapter;
    private final Toolbar toolbar;
    private final ViewGroup rootLayout;
    private final FloatingActionButton createTicketFab;
    private final View startConversationButton;
    private final View logoImage;
    private final View logoImageEmpty;
    private final View listSceneView;

    private enum SceneState {
        LIST,
        EMPTY,
        NONE
    }

    private SceneState sceneState = SceneState.NONE;

    private final AppCompatActivity activity;
    private final RequestListConfiguration config;

    private OnItemClick itemClickListener = null;
    private OnClickListener retryClickListener = null;
    private boolean isLoading = false;
    private boolean isStopped = true;

    private final Fade fade = new Fade();
    private final Scene listScene;
    private final Scene emptyScene;

    @Nullable
    @VisibleForTesting //because espresso
            Snackbar snackbar;


    public RequestListView(@NonNull AppCompatActivity activity,
                           @NonNull RequestListConfiguration config,
                           @NonNull Picasso picasso) {
        super(activity);
        this.activity = activity;
        this.config = config;
        setId(R.id.request_list_view);
        inflate(activity, R.layout.zs_activity_request_list, this);
        sceneRoot = findViewById(R.id.request_list_scene_root);

        LayoutInflater inflater = LayoutInflater.from(activity);
        listSceneView = inflater.inflate(R.layout.zs_activity_request_list_scene_data, sceneRoot, false);
        View emptySceneView = inflater.inflate(R.layout.zs_activity_request_list_scene_empty, sceneRoot, false);

        listScene = new Scene(sceneRoot, listSceneView);
        emptyScene = new Scene(sceneRoot, emptySceneView);

        progressBar = findViewById(R.id.request_list_progressBar);
        toolbar = findViewById(R.id.request_list_toolbar);
        rootLayout = findViewById(R.id.request_list_coordinator_layout);
        createTicketFab = findViewById(R.id.request_list_create_new_ticket_fab);

        logoImage = listSceneView.findViewById(R.id.request_list_zendesk_logo);
        recyclerView = listSceneView.findViewById(R.id.request_list_recycler);
        swipeRefreshLayout = listSceneView.findViewById(R.id.request_list_swipe_refresh_layout);

        startConversationButton = emptySceneView.findViewById(R.id.request_list_empty_start_conversation);
        swipeRefreshLayoutEmpty = emptySceneView.findViewById(R.id.request_list_swipe_refresh_layout_empty);
        logoImageEmpty = emptySceneView.findViewById(R.id.request_list_zendesk_logo_empty);

        OnItemClick onItemClick = new OnItemClick() {
            @Override
            public void onClick(RequestListItem requestListItem) {
                if (itemClickListener != null) {
                    itemClickListener.onClick(requestListItem);
                }
            }
        };
        adapter = new RequestListAdapter(onItemClick, picasso);
        recyclerView.setAdapter(adapter);
        recyclerView.setNestedScrollingEnabled(false);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false));
        recyclerView.addItemDecoration(new DividerItemDecoration(activity, DividerItemDecoration.VERTICAL));
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        createTicketFab.hide();

        View toolbarShadow = findViewById(R.id.request_list_compat_shadow);
        ((ViewGroup) toolbarShadow.getParent()).removeView(toolbarShadow);

        int colorAccent = UiUtils.themeAttributeToColor(R.attr.colorAccent, getContext(), R.color.zs_color_black);
        swipeRefreshLayout.setColorSchemeColors(colorAccent);
        swipeRefreshLayoutEmpty.setColorSchemeColors(colorAccent);

        applyWindowInsets();
    }

    private void applyWindowInsets() {
        AppBarLayout appBarLayout = findViewById(R.id.appbar_request_list);
        SystemWindowInsets.applyWindowInsets(appBarLayout, InsetType.TOP);
        SystemWindowInsets.applyWindowInsets(toolbar, InsetType.HORIZONTAL);
        SystemWindowInsets.applyWindowInsets(sceneRoot, InsetType.BOTTOM);
    }

    public Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable(REQUEST_LIST_VIEW_SUPERSTATE_KEY, super.onSaveInstanceState());
        bundle.putBoolean(IS_SHOWING_SNACKBAR_KEY, isShowingSnackBar());
        return bundle;
    }

    @Override
    public void onRestoreInstanceState(Parcelable state) {
        if (state instanceof Bundle) {
            final Bundle bundle = (Bundle) state;
            final boolean isShowingSnackBar = bundle.getBoolean(IS_SHOWING_SNACKBAR_KEY);
            state = bundle.getParcelable(REQUEST_LIST_VIEW_SUPERSTATE_KEY);

            if (isShowingSnackBar) {
                showErrorMessage();
            }
        }
        super.onRestoreInstanceState(state);
    }

    //if we had a snack bar from before show it
    public void onStart() {
        isStopped = false;
    }

    //hide the snack bar in on stop to prevent issues
    public void onStop() {
        isStopped = true;
        dismissSnackbar();
    }

    public void setItemClickListener(OnItemClick itemClickListener) {
        this.itemClickListener = itemClickListener;
    }

    public void setSwipeRefreshListener(SwipeRefreshLayout.OnRefreshListener swipeRefresh) {
        swipeRefreshLayout.setOnRefreshListener(swipeRefresh);
        swipeRefreshLayoutEmpty.setOnRefreshListener(swipeRefresh);
    }

    public void setBackClickListener(OnClickListener onClickListener) {
        toolbar.setNavigationOnClickListener(onClickListener);
    }

    public void setRetryClickListener(OnClickListener onClickListener) {
        retryClickListener = onClickListener;
    }

    public void setCreateRequestListener(OnClickListener onClickListener) {
        createTicketFab.setOnClickListener(onClickListener);
        startConversationButton.setOnClickListener(onClickListener);
    }

    public void setLogoClickListener(boolean visible, OnClickListener onClickListener) {
        final int visibility;
        final View.OnClickListener clickListener;

        if (visible) {
            visibility = View.VISIBLE;
            clickListener = onClickListener;
        } else {
            visibility = View.INVISIBLE;
            clickListener = null;
        }

        logoImage.setVisibility(visibility);
        logoImageEmpty.setVisibility(visibility);
        logoImage.setOnClickListener(clickListener);
        logoImageEmpty.setOnClickListener(clickListener);
    }

    public void showErrorMessage() {
        if (!isStopped && !isShowingSnackBar()) {
            announceAccessibility(R.string.zs_request_list_content_load_failed_accessibility);
            snackbar = Snackbar.make(rootLayout, R.string.request_list_error_message, Snackbar.LENGTH_INDEFINITE)
                    .setAction(R.string.zendesk_retry_button_label, retryClickListener);
            snackbar.show();
        }
    }

    public void setLoading(boolean loading) {
        //prevent playing animation many times
        dismissSnackbar();
        if (this.isLoading != loading) {
            if (loading) {
                if (!swipeRefreshLayout.isRefreshing() && !swipeRefreshLayoutEmpty.isRefreshing()) {
                    announceAccessibility(R.string.zs_request_list_content_loading_accessibility);
                    progressBar.start(ViewAlmostRealProgressBar.DONT_STOP_MOVING);
                }
            } else {
                if (swipeRefreshLayout.isRefreshing() || swipeRefreshLayoutEmpty.isRefreshing()) {
                    swipeRefreshLayout.setRefreshing(false);
                    swipeRefreshLayoutEmpty.setRefreshing(false);
                } else {
                    progressBar.stop(ViewAlmostRealProgressBar.STOP_ANIMATION_DURATION);
                }
            }
        }
        this.isLoading = loading;
    }

    private boolean isShowingSnackBar() {
        return snackbar != null && snackbar.isShownOrQueued();
    }

    private void dismissSnackbar() {
        if (snackbar != null) {
            snackbar.dismiss();
        }
        snackbar = null;
    }

    public void finish(@Nullable String message) {
        if (StringUtils.hasLength(message)) {
            Logger.d(RequestListActivity.LOG_TAG, message);
        }
        finish();
    }

    public void finish() {
        if (!activity.isFinishing()) {
            activity.finish();
        }
    }

    public void startReferrerPage(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        activity.startActivity(intent);
    }

    public void startRequestActivity(RequestConfiguration.Builder requestUiConfigBuilder) {
        requestUiConfigBuilder.show(activity, config.getConfigurations());
    }

    public void showRequestList(List<RequestListItem> result) {
        dismissSnackbar();
        progressBar.stop(ViewAlmostRealProgressBar.STOP_ANIMATION_DURATION);

        if (CollectionUtils.isEmpty(result)) {
            //show empty
            if (sceneState != SceneState.EMPTY) {
                createTicketFab.hide();
                TransitionManager.go(emptyScene, fade);
                announceAccessibility(R.string.zs_request_list_content_loaded_empty_accessibility);
                sceneState = SceneState.EMPTY;
            }
        } else {
            //show the list
            adapter.swapRequests(result);
            progressBar.stop(ViewAlmostRealProgressBar.STOP_ANIMATION_DURATION);
            if (sceneState != SceneState.LIST) {
                if (config.isContactUsButtonVisible()) {
                    createTicketFab.show();
                } else {
                    createTicketFab.hide();
                }
                if (listSceneView.getParent() == null) {
                    TransitionManager.go(listScene, fade);
                }
                announceAccessibility(R.string.zs_request_list_content_loaded_accessibility);
                sceneState = SceneState.LIST;
            }
        }
    }

    public void announceAccessibility(@StringRes int stringRes) {
        announceForAccessibility(getResources().getString(stringRes));
    }
}
