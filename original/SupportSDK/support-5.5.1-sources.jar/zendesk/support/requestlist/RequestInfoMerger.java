package zendesk.support.requestlist;

import androidx.annotation.NonNull;

import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class RequestInfoMerger {

    private static final Comparator<RequestInfo> REQUEST_INFO_COMPARATOR
            = new RequestInfo.LastUpdatedComparator();

    List<RequestInfo> merge(@NonNull List<RequestInfo> localItems, @NonNull List<RequestInfo> remoteItems) {
        Map<String, RequestInfo> idRequestInfoMap = new HashMap<>();
        List<RequestInfo> localOnlyItems = new ArrayList<>();

        for (RequestInfo requestInfo : localItems) {
            String remoteId = requestInfo.getRemoteId();
            if (StringUtils.hasLength(remoteId)) {
                idRequestInfoMap.put(remoteId, requestInfo);
            } else {
                localOnlyItems.add(requestInfo);
            }
        }

        List<RequestInfo> mergedItems = new ArrayList<>(localOnlyItems);
        for (RequestInfo remoteItem : remoteItems) {
            String remoteId = remoteItem.getRemoteId();
            if (idRequestInfoMap.containsKey(remoteId)) {
                mergedItems.add(merge(idRequestInfoMap.get(remoteId), remoteItem));
                idRequestInfoMap.remove(remoteId);
            } else {
                mergedItems.add(remoteItem);
            }
        }

        Collections.sort(mergedItems, REQUEST_INFO_COMPARATOR);
        return mergedItems;
    }

    private RequestInfo merge(RequestInfo localItem, RequestInfo remoteItem) {
        Date localItemDate = localItem.getLastUpdated();
        Date remoteItemDate = remoteItem.getLastUpdated();
        Date lastUpdated;
        if (localItemDate == null) {
            lastUpdated = remoteItemDate;
        } else if (remoteItemDate == null) {
            lastUpdated = localItemDate;
        } else {
            lastUpdated = localItemDate.after(remoteItemDate) ? localItemDate : remoteItemDate;
        }
        RequestInfo.MessageInfo lastLocalMessageInfo = localItem.getLastMessageInfo();
        RequestInfo.MessageInfo lastRemoteMessageInfo = remoteItem.getLastMessageInfo();
        RequestInfo.MessageInfo lastMessageInfo = lastLocalMessageInfo.getDate().after(lastRemoteMessageInfo.getDate())
                ? lastLocalMessageInfo
                : lastRemoteMessageInfo;

        return new RequestInfo(localItem.getLocalId(), remoteItem.getRemoteId(), remoteItem.getRequestStatus(),
                remoteItem.isUnread(), lastUpdated, remoteItem.getAgentInfos(), remoteItem.getFirstMessageInfo(),
                lastMessageInfo, localItem.getFailedMessageIds()
        );
    }
}
