package zendesk.support.requestlist;

import com.zendesk.service.SafeZendeskCallback;

import java.util.HashSet;
import java.util.Set;

@SuppressWarnings("ForLoopReplaceableByForEach")
class CancelableCompositeCallback {

    private Set<SafeZendeskCallback> zendeskCallbacks = new HashSet<>();

    /**
     * Add a callback to the group
     */
    public void add(SafeZendeskCallback... callbacks) {
        for (int i = 0; i < callbacks.length; i++) {
            add(callbacks[i]);
        }
    }

    /**
     * Add a callback to the group
     */
    public void add(SafeZendeskCallback callback) {
        zendeskCallbacks.add(callback);
    }

    /**
     * Cancel and remove all the callbacks
     */
    public void cancel() {
        for (SafeZendeskCallback zendeskCallback : zendeskCallbacks) {
            zendeskCallback.cancel();
        }
        zendeskCallbacks.clear();
    }
}
