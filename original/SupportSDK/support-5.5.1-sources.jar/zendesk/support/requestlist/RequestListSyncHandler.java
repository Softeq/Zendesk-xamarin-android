package zendesk.support.requestlist;

import android.content.Context;
import androidx.annotation.MainThread;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.JsonElement;

import java.util.Map;

import zendesk.core.ActionDescription;
import zendesk.core.ActionHandler;
import zendesk.support.Constants;


class RequestListSyncHandler implements ActionHandler {
    private final RequestListPresenter presenter;
    private boolean running = false;
    private boolean outdated = false;

    RequestListSyncHandler(@NonNull RequestListPresenter presenter) {
        this.presenter = presenter;
    }

    @Override
    public boolean canHandle(String s) {
        return Constants.ACTION_REFRESH_REQUEST_LIST.equals(s);
    }

    @MainThread
    @Override
    public void handle(@Nullable Map<String, Object> map, @NonNull Context context) {
        if (running) {
            presenter.refresh();
            outdated = false;
        } else {
            outdated = true;
        }
    }

    @Override
    public int getPriority() {
        return 0;
    }

    void setRunning(boolean isRunning) {
        this.running = isRunning;
        if (outdated) {
            presenter.refresh();
            outdated = false;
        }
    }

    @Override
    public ActionDescription getActionDescription() {
        return null;
    }

    @Override
    public void updateSettings(Map<String, JsonElement> settings) {
        // Intentionally empty
    }
}
