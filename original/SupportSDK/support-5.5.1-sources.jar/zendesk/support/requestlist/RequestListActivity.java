package zendesk.support.requestlist;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.zendesk.logger.Logger;


import javax.inject.Inject;

import zendesk.configurations.ConfigurationUtil;
import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.support.Constants;
import zendesk.support.R;
import zendesk.support.SdkDependencyProvider;

/**
 * This Activity is for showing a list of an end-user's requests
 * <p>
 * This Activity is designed to be started with the {@link #builder()}
 * </p>
 */
public class RequestListActivity extends AppCompatActivity {

    static final String LOG_TAG = "RequestListActivity";

    /**
     * Create a new builder for RequestListActivity.
     */
    public static RequestListConfiguration.Builder builder() {
        return new RequestListConfiguration.Builder();
    }

    /**
     * Refresh this screen
     */
    public static void refresh(Context context, ActionHandlerRegistry actionHandlerRegistry) {
        ActionHandler actionHandler = actionHandlerRegistry.handlerByAction(Constants.ACTION_REFRESH_REQUEST_LIST);
        if (actionHandler != null) {
            actionHandler.handle(null, context);
        }
    }

    @Inject
    RequestListPresenter presenter;

    @Inject
    RequestListView view;

    @Inject
    RequestListModel model;

    @Inject
    ActionHandlerRegistry actionHandlerRegistry;

    @Inject
    RequestListSyncHandler syncHandler;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getTheme().applyStyle(R.style.ZendeskActivityDefaultTheme, true);

        if (!SdkDependencyProvider.INSTANCE.isInitialized()) {
            Logger.e(LOG_TAG, SdkDependencyProvider.NOT_INITIALIZED_LOG);
            finish();
            return;
        }

        @SuppressLint("RestrictedApi")
        final RequestListConfiguration config =
                ConfigurationUtil.fromBundle(getIntent().getExtras(), RequestListConfiguration.class);

        if (config == null) {
            Logger.e(LOG_TAG, "No configuration found. Please use RequestListActivity.builder()");
            finish();
            return;
        }

        SdkDependencyProvider.INSTANCE.provideRequestListComponent(this, config)
                .inject(this);

        setContentView(view);
        presenter.onCreate(savedInstanceState == null, view);
        actionHandlerRegistry.add(syncHandler);
    }

    @Override
    protected void onStart() {
        super.onStart();
        view.onStart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        syncHandler.setRunning(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        syncHandler.setRunning(false);
    }

    @Override
    protected void onStop() {
        super.onStop();
        view.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (actionHandlerRegistry != null) {
            actionHandlerRegistry.remove(syncHandler);
        }
        if (presenter != null) {
            presenter.onDestroy(isChangingConfigurations());
        }
    }
}