package zendesk.support.requestlist;

import androidx.annotation.RestrictTo;

import com.squareup.picasso.Picasso;

import zendesk.support.ActivityScope;

import dagger.Module;
import dagger.Provides;

@Module
@RestrictTo(RestrictTo.Scope.LIBRARY)
public class RequestListViewModule {

    private final RequestListActivity activity;
    private final RequestListConfiguration config;

    public RequestListViewModule(RequestListActivity activity, RequestListConfiguration config) {
        this.activity = activity;
        this.config = config;
    }

    @Provides
    @ActivityScope
    RequestListView view(Picasso picasso) {
        return new RequestListView(activity, config, picasso);
    }
}
