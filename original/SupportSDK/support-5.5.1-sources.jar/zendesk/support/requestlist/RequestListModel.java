package zendesk.support.requestlist;

import androidx.annotation.Nullable;

import com.zendesk.func.ZFunc1;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;

import java.util.List;

import zendesk.core.MemoryCache;
import zendesk.support.AggregatedCallback;
import zendesk.support.SupportBlipsProvider;
import zendesk.support.SupportSdkSettings;
import zendesk.support.SupportSettingsProvider;

class RequestListModel {

    static final String SETTINGS_CACHE_KEY = "request_list_settings";
    static final String REQUEST_LIST_ITEMS_CACHE_KEY = "request_list_items";

    private final RequestInfoDataSource requestInfoDataSource;
    private final MemoryCache cache;
    private final SupportBlipsProvider blipsProvider;
    private final SupportSettingsProvider settingsProvider;
    private final AggregatedCallback<SupportSdkSettings> settingsAggregatedCallback = new AggregatedCallback<>();


    RequestListModel(RequestInfoDataSource requestInfoDataSource, MemoryCache cache,
                     SupportBlipsProvider blipsProvider, SupportSettingsProvider settingsProvider) {
        this.requestInfoDataSource = requestInfoDataSource;
        this.cache = cache;
        this.blipsProvider = blipsProvider;
        this.settingsProvider = settingsProvider;
    }

    @Nullable
    SupportSdkSettings getCachedSettings() {
        return cache.get(SETTINGS_CACHE_KEY);
    }

    void cacheSupportSdkSettings(SupportSdkSettings supportSdkSettings) {
        cache.put(SETTINGS_CACHE_KEY, supportSdkSettings);
    }

    void cleanup() {
        cache.remove(SETTINGS_CACHE_KEY);
        cache.remove(REQUEST_LIST_ITEMS_CACHE_KEY);
    }

    void trackRequestListViewed() {
        blipsProvider.requestListViewed();
    }

    void loadSettings(final ZendeskCallback<SupportSdkSettings> callback) {
        //group callbacks together to prevent double loading
        if (settingsAggregatedCallback.add(callback)) {
            settingsProvider.getSettings(settingsAggregatedCallback);
        }
    }

    @Nullable
    List<RequestListItem> getCachedRequestInfos() {
        return cache.get(REQUEST_LIST_ITEMS_CACHE_KEY);
    }

    void loadItems(boolean fresh,
                   final SupportSdkSettings supportSdkSettings,
                   final ZendeskCallback<List<RequestListItem>> callback) {
        if (fresh || getCachedRequestInfos() == null) {
            requestInfoDataSource.load(new ZendeskCallback<List<RequestInfo>>() {
                @Override
                public void onSuccess(List<RequestInfo> requestInfos) {
                    final List<RequestInfo> filteredInfos = filterClosedRequests(requestInfos, supportSdkSettings
                            .isShowClosedRequests());
                    final List<RequestListItem> requestListItems = CollectionUtils.map(filteredInfos, mapper);
                    cache.put(REQUEST_LIST_ITEMS_CACHE_KEY, requestListItems);
                    callback.onSuccess(requestListItems);
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    callback.onError(errorResponse);
                }
            });
        } else {
            callback.onSuccess(getCachedRequestInfos());
        }
    }

    private final ZFunc1<RequestInfo, RequestListItem> mapper = new ZFunc1<RequestInfo, RequestListItem>() {
        @Override
        public RequestListItem apply(RequestInfo requestInfo) {
            return new RequestListItem(requestInfo);
        }
    };

    private List<RequestInfo> filterClosedRequests(List<RequestInfo> requestInfos, boolean showClosed) {
        if (showClosed) {
            return requestInfos;
        } else {
            return CollectionUtils.filter(requestInfos, new ZFunc1<RequestInfo, Boolean>() {
                @Override
                public Boolean apply(RequestInfo requestInfo) {
                    return !requestInfo.isClosed();
                }
            });
        }
    }
}