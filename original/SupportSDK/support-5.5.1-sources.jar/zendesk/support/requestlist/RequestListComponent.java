package zendesk.support.requestlist;

import androidx.annotation.RestrictTo;

import zendesk.support.ActivityScope;

import dagger.Subcomponent;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@ActivityScope
@Subcomponent(modules = {RequestListModule.class, RequestListViewModule.class})
@RestrictTo(LIBRARY)
public interface RequestListComponent {

    void inject(RequestListActivity requestListActivity);

}
