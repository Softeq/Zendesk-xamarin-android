package zendesk.support.requestlist;

import androidx.recyclerview.widget.RecyclerView;
import android.view.ViewGroup;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


class RequestListAdapter extends RecyclerView.Adapter<RequestListViewHolder> {

    private final List<RequestListItem> requestListItems = new ArrayList<>(0);
    private final RequestListView.OnItemClick itemClickListener;
    private final Picasso picasso;

    RequestListAdapter(RequestListView.OnItemClick itemClickListener, Picasso picasso) {
        this.itemClickListener = itemClickListener;
        this.picasso = picasso;
        setHasStableIds(true);
    }

    @Override
    public RequestListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return RequestListViewHolder.create(parent.getContext(), parent, itemClickListener, picasso);
    }

    @Override
    public void onBindViewHolder(RequestListViewHolder holder, int position) {
        holder.bind(requestListItems.get(position));
    }

    @Override
    public int getItemCount() {
        return requestListItems.size();
    }

    @Override
    public long getItemId(int position) {
        return requestListItems.get(position).getItemId();
    }

    void swapRequests(List<RequestListItem> tickets) {
        this.requestListItems.clear();
        this.requestListItems.addAll(tickets);
        notifyDataSetChanged();
    }
}
