package zendesk.support.requestlist;

import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Set;

import zendesk.support.RequestStatus;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class RequestInfo {

    private final String localId;
    private final String remoteId;
    private final RequestStatus requestStatus;
    private final boolean unread;
    @Nullable
    private final Date lastUpdated;
    private final List<AgentInfo> agentInfos;
    private final MessageInfo firstMessageInfo;
    private final MessageInfo lastMessageInfo;
    private final Set<String> failedMessageIds;


    public RequestInfo(String localId, String remoteId, RequestStatus requestStatus,
                       boolean unread, @Nullable Date lastUpdated, List<AgentInfo> agentInfos,
                       MessageInfo firstMessageInfo, MessageInfo lastMessageInfo,
                       Set<String> failedMessageIds) {
        this.localId = localId;
        this.remoteId = remoteId;
        this.requestStatus = requestStatus;
        this.unread = unread;
        this.lastUpdated = lastUpdated;
        this.agentInfos = agentInfos;
        this.firstMessageInfo = firstMessageInfo;
        this.lastMessageInfo = lastMessageInfo;
        this.failedMessageIds = failedMessageIds;
    }

    public String getLocalId() {
        return localId;
    }

    public String getRemoteId() {
        return remoteId;
    }

    public RequestStatus getRequestStatus() {
        return requestStatus;
    }

    public List<AgentInfo> getAgentInfos() {
        return agentInfos;
    }

    boolean isUnread() {
        return unread;
    }

    @Nullable
    Date getLastUpdated() {
        return lastUpdated;
    }

    MessageInfo getFirstMessageInfo() {
        return firstMessageInfo;
    }

    MessageInfo getLastMessageInfo() {
        return lastMessageInfo;
    }

    Set<String> getFailedMessageIds() {
        return failedMessageIds;
    }

    boolean isClosed() {
        return RequestStatus.Closed.equals(requestStatus);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        RequestInfo that = (RequestInfo) o;

        if (unread != that.unread) {
            return false;
        }
        if (localId != null ? !localId.equals(that.localId) : that.localId != null) {
            return false;
        }
        if (remoteId != null ? !remoteId.equals(that.remoteId) : that.remoteId != null) {
            return false;
        }
        if (requestStatus != that.requestStatus) {
            return false;
        }
        if (lastUpdated != null ? !lastUpdated.equals(that.lastUpdated) : that.lastUpdated != null) {
            return false;
        }
        if (agentInfos != null ? !agentInfos.equals(that.agentInfos) : that.agentInfos != null) {
            return false;
        }
        if (firstMessageInfo != null ? !firstMessageInfo.equals(that.firstMessageInfo)
                : that.firstMessageInfo != null) {
            return false;
        }
        if (lastMessageInfo != null ? !lastMessageInfo.equals(that.lastMessageInfo) : that.lastMessageInfo != null) {
            return false;
        }
        return failedMessageIds != null ? failedMessageIds.equals(that.failedMessageIds)
                : that.failedMessageIds == null;
    }

    @Override
    public int hashCode() {
        int result = localId != null ? localId.hashCode() : 0;
        result = 31 * result + (remoteId != null ? remoteId.hashCode() : 0);
        result = 31 * result + (requestStatus != null ? requestStatus.hashCode() : 0);
        result = 31 * result + (unread ? 1 : 0);
        result = 31 * result + (lastUpdated != null ? lastUpdated.hashCode() : 0);
        result = 31 * result + (agentInfos != null ? agentInfos.hashCode() : 0);
        result = 31 * result + (firstMessageInfo != null ? firstMessageInfo.hashCode() : 0);
        result = 31 * result + (lastMessageInfo != null ? lastMessageInfo.hashCode() : 0);
        result = 31 * result + (failedMessageIds != null ? failedMessageIds.hashCode() : 0);
        return result;
    }

    public static class AgentInfo {
        private final String id;
        private final String name;
        private final String avatar;

        public AgentInfo(String id, String name, String avatar) {
            this.id = id;
            this.name = name;
            this.avatar = avatar;
        }

        String getId() {
            return id;
        }

        String getName() {
            return name;
        }

        String getAvatar() {
            return avatar;
        }

        @SuppressWarnings("SimplifiableIfStatement")
        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            AgentInfo agentInfo = (AgentInfo) o;

            if (id != null ? !id.equals(agentInfo.id) : agentInfo.id != null) {
                return false;
            }
            if (name != null ? !name.equals(agentInfo.name) : agentInfo.name != null) {
                return false;
            }
            return avatar != null ? avatar.equals(agentInfo.avatar) : agentInfo.avatar == null;
        }

        @Override
        public int hashCode() {
            int result = id != null ? id.hashCode() : 0;
            result = 31 * result + (name != null ? name.hashCode() : 0);
            result = 31 * result + (avatar != null ? avatar.hashCode() : 0);
            return result;
        }
    }

    public static class MessageInfo {
        private final String id;
        private final Date date;
        private final String body;

        public MessageInfo(String id, Date date, String body) {
            this.id = id;
            this.date = date;
            this.body = body;
        }

        String getId() {
            return id;
        }

        Date getDate() {
            return date;
        }

        String getBody() {
            return body;
        }

        @SuppressWarnings("SimplifiableIfStatement")
        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            MessageInfo that = (MessageInfo) o;

            if (id != null ? !id.equals(that.id) : that.id != null) {
                return false;
            }
            if (date != null ? !date.equals(that.date) : that.date != null) {
                return false;
            }
            return body != null ? body.equals(that.body) : that.body == null;
        }

        @Override
        public int hashCode() {
            int result = id != null ? id.hashCode() : 0;
            result = 31 * result + (date != null ? date.hashCode() : 0);
            result = 31 * result + (body != null ? body.hashCode() : 0);
            return result;
        }
    }

    static class LastUpdatedComparator implements Comparator<RequestInfo> {
        @Override
        public int compare(RequestInfo first, RequestInfo second) {
            if (second == null) {
                return 1;
            }
            if (first.getLastUpdated() == null) {
                return second.getLastUpdated() == null ? 0 : -1;
            }
            if (second.getLastUpdated() == null) {
                return 1;
            }
            return second.getLastUpdated().compareTo(first.getLastUpdated());
        }
    }
}
