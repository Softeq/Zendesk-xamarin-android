package zendesk.support;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.atomic.AtomicBoolean;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import zendesk.classic.messaging.components.ActionListener;
import zendesk.classic.messaging.components.bot.BotMessageDispatcher;
import zendesk.classic.messaging.components.CompositeActionListener;
import zendesk.classic.messaging.components.Timer;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.AuthenticationProvider;
import zendesk.core.Zendesk;
import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.Update;

@Module
class SupportEngineModule {

    @Provides
    SupportEngine supportEngine(
            Context context,
            SupportEngineModel supportEngineModel,
            CompositeActionListener<BotMessageDispatcher.ConversationState<MessagingItem>> stateViewObserver,
            CompositeActionListener<Update> updateViewObserver) {
        return new SupportEngine(context, supportEngineModel, stateViewObserver, updateViewObserver);
    }

    @Provides
    @Singleton
    CompositeActionListener<BotMessageDispatcher.ConversationState<MessagingItem>> stateCompositeActionListener() {
        return CompositeActionListener.create();
    }

    @Provides
    @Singleton
    CompositeActionListener<Update> updateViewObserver() {
        return CompositeActionListener.create();
    }

    @Provides
    ActionListener<BotMessageDispatcher.ConversationState<MessagingItem>> stateActionListener(
            final CompositeActionListener<BotMessageDispatcher.ConversationState<MessagingItem>> observer) {
        return new ActionListener<BotMessageDispatcher.ConversationState<MessagingItem>>() {
            @Override
            public void onAction(BotMessageDispatcher.ConversationState<MessagingItem> data) {
                observer.onAction(data);
            }
        };
    }

    @Provides
    ActionListener<Update> updateActionListener(final CompositeActionListener<Update> observer) {
        return new ActionListener<Update>() {
            @Override
            public void onAction(Update data) {
                observer.onAction(data);
            }
        };
    }

    @Provides
    @Singleton
    BotMessageDispatcher.MessageIdentifier<MessagingItem> interactionIdentifier() {
        return new BotMessageDispatcher.MessageIdentifier<MessagingItem>() {
            @Override
            public String getId(MessagingItem messagingItem) {
                return messagingItem.getId();
            }
        };
    }

    @Provides
    SupportEngineModel supportEngineModel(SupportSettingsProvider settingsProvider,
                                          RequestCreator requestCreator,
                                          AuthenticationProvider authenticationProvider,
                                          ConfigurationHelper configurationHelper,
                                          EmailValidator emailValidator,
                                          BotMessageDispatcher<MessagingItem> botMessageDispatcher) {
        AtomicBoolean engineStarted = new AtomicBoolean(false);
        return new SupportEngineModel(settingsProvider, requestCreator, Zendesk.INSTANCE,
                authenticationProvider, emailValidator, configurationHelper, engineStarted,
                botMessageDispatcher);
    }

    @Provides
    BotMessageDispatcher<MessagingItem> botMessageDispatcher(
            BotMessageDispatcher.MessageIdentifier<MessagingItem> messageIdentifier,
            ActionListener<BotMessageDispatcher.ConversationState<MessagingItem>> stateActionListener,
            ActionListener<Update> updateActionListener,
            Timer.Factory timerFactory) {
        return new BotMessageDispatcher<>(messageIdentifier, stateActionListener, updateActionListener, timerFactory);
    }

    @Provides
    RequestCreator requestCreator(RequestProvider requestProvider, UploadProvider uploadProvider) {
        return new RequestCreator(requestProvider, uploadProvider);
    }

    @Provides
    ConfigurationHelper configurationHelper() {
        return new ConfigurationHelper();
    }

    @Provides
    EmailValidator emailValidator() {
        return new EmailValidator();
    }

    @Provides
    Timer.Factory timerFactory(Handler handler) {
        return new Timer.Factory(handler);
    }

    @Provides
    Handler provideHandler() {
        return new Handler(Looper.getMainLooper());
    }
}
