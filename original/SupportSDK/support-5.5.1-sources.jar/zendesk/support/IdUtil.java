package zendesk.support;

import androidx.annotation.RestrictTo;

import java.util.UUID;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Helper class for generating new IDs. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class IdUtil {

    public static long newLongId() {
        return generateUniqueId().getMostSignificantBits() & Long.MAX_VALUE;
    }

    public static String newStringId() {
        return generateUniqueId().toString();
    }

    private static UUID generateUniqueId() {
        return UUID.randomUUID();
    }

}
