package zendesk.support;

import android.annotation.SuppressLint;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;

import java.util.List;
import java.util.UUID;

import javax.inject.Inject;

import zendesk.core.ActionHandler;
import zendesk.core.ActionHandlerRegistry;
import zendesk.core.Zendesk;
import zendesk.support.requestlist.RequestListActivity;
import zendesk.support.requestlist.RequestListComponent;
import zendesk.support.requestlist.RequestListConfiguration;
import zendesk.support.requestlist.RequestListModule;
import zendesk.support.requestlist.RequestListViewModule;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public enum SdkDependencyProvider {

    INSTANCE;

    public static final String NOT_INITIALIZED_LOG = "Zendesk is not initialized or no identity was set. Make sure"
            + " Zendesk.INSTANCE.init(...), Zendesk.INSTANCE.setIdentity(...), Support.INSTANCE.init(...)"
            + " was called ";

    SdkDependencyProvider() {
        // Intentionally empty.
    }

    @Inject
    ActionHandlerRegistry registry;
    @Inject
    List<ActionHandler> actionHandlers;

    private SupportSdkComponent supportSdkComponent;
    private UUID id;
    private RequestListModule requestListModule;

    @SuppressLint("RestrictedApi")
    public SupportSdkComponent provideSupportSdkComponent() {
        final SupportModule supportModule = Support.INSTANCE.getSupportModule();
        final UUID id = supportModule.getId();

        if (supportSdkComponent == null || !id.equals(this.id)) {

            final SupportSdkModule supportSdkModule = new SupportSdkModule();
            supportSdkComponent = DaggerSupportSdkComponent.builder()
                    .coreModule(Zendesk.INSTANCE.coreModule())
                    .supportModule(supportModule)
                    .supportSdkModule(supportSdkModule)
                    .build();

            this.id = supportModule.getId();

            supportSdkComponent.inject(this);
            registerActionHandlers();
        }

        return supportSdkComponent;
    }

    public RequestListComponent provideRequestListComponent(RequestListActivity activity,
                                                            RequestListConfiguration config) {
        // RequestListModule will be null unless we're running Espresso tests and injecting a test version,
        // or when this is called after a config change.
        if (requestListModule == null) {
            requestListModule = new RequestListModule();
        }

        return provideSupportSdkComponent()
                .plus(requestListModule, new RequestListViewModule(activity, config));
    }

    /**
     * Initialise the Support SDK Ui module with a component built for testing
     */
    @VisibleForTesting
    void initForTesting(SupportSdkComponent sdkComponent, UUID coreId) {
        this.supportSdkComponent = sdkComponent;
        this.id = coreId;
    }

    /**
     * Initialise the Support SDK Ui module with a component built for testing
     */
    @VisibleForTesting
    void initForTesting(SupportSdkComponent sdkComponent, UUID coreId, RequestListModule requestListModule) {
        initForTesting(sdkComponent, coreId);
        this.requestListModule = requestListModule;
    }

    public boolean isInitialized() {
        return Zendesk.INSTANCE.isInitialized()
                && Support.INSTANCE.isInitialized()
                && Support.INSTANCE.isAuthenticated();
    }

    private void registerActionHandlers() {
        for (ActionHandler actionHandler : actionHandlers) {
            registry.add(actionHandler);
        }
    }
}
