package zendesk.support;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.TaskStackBuilder;

import com.google.gson.JsonElement;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import zendesk.core.ActionDescription;
import zendesk.core.ActionHandler;
import zendesk.support.requestlist.RequestListActivity;

class DeepLinkToRequestActionHandler implements ActionHandler {

    static final String REQUEST_VIEW_CONVERSATION = "request_view_conversation";

    private static final String REQUEST_INTENT = "request_ui_config";
    private static final String BACK_STACK_ACTIVITIES = "back_stack_activities";

    static Map<String, Object> data(Intent requestIntent, List<Intent> backStackActivities) {

        final Map<String, Object> data = new HashMap<>();
        data.put(REQUEST_INTENT, requestIntent);
        data.put(BACK_STACK_ACTIVITIES, backStackActivities);

        return data;
    }

    @Override
    public boolean canHandle(String s) {
        return s.equals(REQUEST_VIEW_CONVERSATION);
    }

    @Override
    public void handle(@Nullable Map<String, Object> map, @NonNull Context context) {
        // Create the back stack
        final TaskStackBuilder taskStackBuilder = TaskStackBuilder.create(context);

        if (map != null) {
            // noinspection unchecked
            List<Intent> backStackActivities = (List<Intent>) map.get(BACK_STACK_ACTIVITIES);
            for (Intent i : backStackActivities) {
                taskStackBuilder.addNextIntentWithParentStack(i);
            }
        }

        // Add request list to the back stack
        Intent requestListIntent = RequestListActivity.builder().intent(context);
        taskStackBuilder.addNextIntentWithParentStack(requestListIntent);

        // Add the request conversation to the back stack
        if (map != null) {
            Intent requestIntent = (Intent) map.get(REQUEST_INTENT);
            taskStackBuilder.addNextIntentWithParentStack(requestIntent);
        }

        taskStackBuilder.startActivities();
    }

    @Override
    public int getPriority() {
        return 0;
    }

    @Override
    public ActionDescription getActionDescription() {
        return null;
    }

    @Override
    public void updateSettings(Map<String, JsonElement> settings) {
        // Intentionally empty
    }
}
