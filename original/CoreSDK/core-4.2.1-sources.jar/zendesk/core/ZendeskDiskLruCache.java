package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.jakewharton.disklrucache.DiskLruCache;
import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.DigestUtils;
import com.zendesk.util.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.ResponseBody;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import okio.Sink;
import okio.Source;

class ZendeskDiskLruCache implements BaseStorage {

    private static final String LOG_TAG = "DiskLruStorage";

    private final File directory;
    private final long maxSize;

    private DiskLruCache storage;
    private final Serializer serializer;

    /*
        We are only storing one item per key, so the index is always zero
     */
    private static final int CACHE_INDEX = 0;

    /*
        There will only be one item per key, the image itself.
     */
    private static final int ITEMS_PER_KEY = 1;

    /*
        For an image cache we don't need to handle version changes, so this can be hardcoded to 1
     */
    private static final int VERSION_ONE = 1;

    ZendeskDiskLruCache(File file, Serializer serializer, int size) {
        this.directory = file;
        this.maxSize = size;
        this.storage = openCache(directory, maxSize);
        this.serializer = serializer;
    }

    @VisibleForTesting
    ZendeskDiskLruCache(File directory, long maxSize, DiskLruCache diskLruCache, Serializer serializer) {
        this.directory = directory;
        this.maxSize = maxSize;
        this.storage = diskLruCache;
        this.serializer = serializer;
    }

    @Override
    public void put(@NonNull String key, @Nullable String value) {

        if (storage == null || StringUtils.isEmpty(value)) {
            return;
        }

        putString(key, CACHE_INDEX, value);
    }

    @Override
    public void put(@NonNull String key, @Nullable Object object) {

        if (storage == null) {
            return;
        }

        if (object instanceof ResponseBody) {

            final ResponseBody responseBody = (ResponseBody) object;

            write(key, CACHE_INDEX, responseBody.source());
            putString(keyMediaType(key), CACHE_INDEX, responseBody.contentType().toString());

        } else {
            String json = null;
            if (object != null) {
                json = serializer.serialize(object);
            }
            put(key, json);
        }
    }

    @Nullable
    @Override
    public String get(@NonNull String key) {

        if (storage == null) {
            return null;
        }

        return getString(key, CACHE_INDEX);
    }

    @Nullable
    @Override
    public <E> E get(@NonNull String key, @NonNull Class<E> clazz) {

        if (storage == null) {
            return null;
        }

        E data = null;

        if (clazz.equals(ResponseBody.class)) {
            try {
                final DiskLruCache.Snapshot snapshot = storage.get(key(key));

                if (snapshot != null) {

                    final Source body = Okio.source(snapshot.getInputStream(CACHE_INDEX));
                    final long length = snapshot.getLength(CACHE_INDEX);
                    final String contentType = getString(keyMediaType(key), CACHE_INDEX);
                    final MediaType mediaType;

                    if (StringUtils.hasLength(contentType)) {
                        mediaType = MediaType.parse(contentType);
                    } else {
                        mediaType = null;
                    }

                    //noinspection unchecked
                    data = (E) ResponseBody.create(mediaType, length, Okio.buffer(body));
                }

            } catch (IOException e) {
                Logger.w(LOG_TAG, "Unable to read from cache", e);
            }

        } else {
            final String dataDump = getString(key, CACHE_INDEX);
            data = serializer.deserialize(dataDump, clazz);
        }

        return data;
    }

    @Override
    public void remove(@NonNull String key) {
        // intentionally empty
    }

    @Override
    public void clear() {

        if (storage == null) {
            return;
        }

        try {
            if (storage.getDirectory() != null && storage.getDirectory().exists()
                    && CollectionUtils.isNotEmpty(storage.getDirectory().listFiles())) {
                storage.delete();
            } else {
                storage.close();
            }

        } catch (IOException e) {
            Logger.d(LOG_TAG, "Error clearing cache. Error: %s", e.getMessage());

        } finally {
            storage = openCache(directory, maxSize);

        }
    }

    private DiskLruCache openCache(File directory, long maxSize) {
        DiskLruCache cache;

        try {
            cache = DiskLruCache.open(directory, VERSION_ONE, ITEMS_PER_KEY, maxSize);
        } catch (IOException e) {
            cache = null;
            Logger.w(LOG_TAG, "Unable to open cache");
        }

        return cache;
    }

    private String key(String k) {
        return DigestUtils.sha1(k);
    }

    private String keyMediaType(String url) {
        return key(String.format(Locale.US, "%s_content_type", url));
    }

    private String getString(String key, int index) {
        Source source = null;
        BufferedSource buffer = null;
        String result = null;

        try {
            final DiskLruCache.Snapshot snapshot = storage.get(key(key));

            if (snapshot != null) {
                source = Okio.source(snapshot.getInputStream(index));
                buffer = Okio.buffer(source);
                result = buffer.readUtf8();
            }

        } catch (IOException e) {
            Logger.w(LOG_TAG, "Unable to read from cache", e);

        } finally {
            close(source);
            close(buffer);
        }

        return result;
    }

    private void putString(String key, int index, String data) {
        try {
            final byte[] bytes = data.getBytes("UTF-8");
            final Source source = Okio.source(new ByteArrayInputStream(bytes));
            write(key, index, source);

        } catch (UnsupportedEncodingException e) {
            Logger.w(LOG_TAG, "Unable to encode string", e);
        }

    }

    private void write(String key, int index, Source source) {
        Sink sink = null;
        BufferedSink buffer = null;
        try {
            final DiskLruCache.Editor edit;
            synchronized (directory) {
                edit = storage.edit(key(key));
            }

            if (edit != null) {
                sink = Okio.sink(edit.newOutputStream(index));

                buffer = Okio.buffer(sink);
                buffer.writeAll(source);
                buffer.flush();

                edit.commit();
            }

        } catch (IOException e) {
            Logger.w(LOG_TAG, "Unable to cache data", e);

        } finally {
            close(buffer);
            close(sink);
            close(source);
        }
    }

    private void close(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                // intentionally empty
            }
        }
    }
}
