package zendesk.core;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;

import com.zendesk.logger.Logger;
import com.zendesk.util.LocaleUtil;
import com.zendesk.util.StringUtils;

import java.io.File;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Provides meta information about the device
 */
class DeviceInfo {

    public static Locale getCurrentLocale(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return context.getResources().getConfiguration().getLocales().get(0);
        } else {
            return context.getResources().getConfiguration().locale;
        }
    }

    private static final String LOG_TAG = "DeviceInfo";

    private static final int EXPECTED_TOKEN_COUNT = 3;
    private static final long BYTES_MULTIPLIER = 1024L;
    private static final int BAD_VALUE = -1;
    private static final String PLATFORM_ANDROID = "Android";

    private final Context context;
    private final ActivityManager activityManager;

    DeviceInfo(Context context) {
        this.context = context;
        this.activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
    }

    Map<String, String> getInfo() {
        Map<String, String> deviceInfo = new HashMap<>();
        String os = getOS();
        String model = getModel();
        long usedMemory = getUsedMemory();
        long totalMemory = getTotalMemory();
        long diskSize = getDiskSize();
        long usedDiskSpace = getUsedDiskSpace();
        int batteryLevel = getBatteryLevel();
        String locale = getLocale();
        String manufacturer = getManufacturer();

        if (!StringUtils.isEmpty(os)) {
            deviceInfo.put("os", os);
        }
        if (!StringUtils.isEmpty(model)) {
            deviceInfo.put("model", model);
        }
        if (usedMemory != BAD_VALUE) {
            deviceInfo.put("memory_used", getBytesInMb(usedMemory));
        }
        if (totalMemory != BAD_VALUE) {
            deviceInfo.put("memory_total", getBytesInMb(totalMemory));
        }
        if (diskSize != BAD_VALUE) {
            deviceInfo.put("disk_total", getBytesInMb(diskSize));
        }
        if (usedDiskSpace != BAD_VALUE) {
            deviceInfo.put("disk_used", getBytesInMb(usedDiskSpace));
        }
        if (batteryLevel != BAD_VALUE) {
            deviceInfo.put("battery_level", String.valueOf(batteryLevel));
        }
        if (!StringUtils.isEmpty(locale)) {
            deviceInfo.put("sys_locale", locale);
        }
        if (!StringUtils.isEmpty(manufacturer)) {
            deviceInfo.put("manufacturer", manufacturer);
        }

        deviceInfo.put("platform", PLATFORM_ANDROID);

        return deviceInfo;
    }

    private String getBytesInMb(long bytes) {
        return String.valueOf(bytes / (BYTES_MULTIPLIER * BYTES_MULTIPLIER));
    }

    /**
     * Returns locale of the device. This will always be just the device locale and not the SDK locale.
     *
     * @return device's locale
     * @see Locale#getDefault()
     */
    String getLocale() {
        return LocaleUtil.toLanguageTag(Locale.getDefault());
    }

    /**
     * Returns OS information as combination of the release version and API level
     * <p>
     * If the values are unknown an empty string is returned
     * </p>
     *
     * @return OS info
     * @see Build.VERSION#RELEASE
     * @see Build.VERSION#SDK_INT
     */
    private String getOS() {
        boolean noReleaseInfo =
                Build.UNKNOWN.equals(Build.VERSION.RELEASE) || StringUtils.isEmpty(Build.VERSION.RELEASE);
        boolean noSdkLevelInfo = Build.VERSION.SDK_INT == 0;
        if (noReleaseInfo && noSdkLevelInfo) {
            return StringUtils.EMPTY_STRING;
        }

        return String.format(Locale.US, "%s/%s", Build.VERSION.RELEASE, Build.VERSION.SDK_INT);
    }

    /**
     * Returns model and device name concatenated together
     * <p>
     * If the values are unknown an empty string is returned
     * </p>
     *
     * @return concatenated model and device name
     * @see Build#MODEL
     * @see Build#DEVICE
     */
    String getModel() {
        boolean noModelInfo = Build.UNKNOWN.equals(Build.MODEL) || StringUtils.isEmpty(Build.MODEL);
        boolean noDeviceInfo = Build.UNKNOWN.equals(Build.DEVICE) || StringUtils.isEmpty(Build.DEVICE);
        if (noModelInfo && noDeviceInfo) {
            return StringUtils.EMPTY_STRING;
        }
        if (Build.MODEL.equals(Build.DEVICE)) {
            return Build.MODEL;
        } else {
            return String.format(Locale.US, "%s/%s", Build.MODEL, Build.DEVICE);
        }
    }

    /**
     * Returns the manufacturer of the device
     * <p>
     * If the values are unknown an empty string is returned
     * </p>
     *
     * @return device manufacturer
     * @see Build#MANUFACTURER
     */
    private String getManufacturer() {
        boolean noManufacturerInfo =
                Build.UNKNOWN.equals(Build.MANUFACTURER) || StringUtils.isEmpty(Build.MANUFACTURER);
        if (noManufacturerInfo) {
            return StringUtils.EMPTY_STRING;
        }

        return Build.MANUFACTURER;
    }

    /**
     * Returns current battery level
     *
     * @return percentage of battery charge remaining
     */
    private int getBatteryLevel() {
        IntentFilter batteryChangedFilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent batteryStatus = context.getApplicationContext().registerReceiver(null, batteryChangedFilter);

        return (batteryStatus != null)
                ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, BAD_VALUE)
                : BAD_VALUE;
    }

    /**
     * Returns the used memory in bytes
     *
     * @return the used memory in bytes
     */
    private long getUsedMemory() {
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);

        return getTotalMemory() - memoryInfo.availMem;
    }

    /**
     * Gets the total memory in megabytes that this device has.
     * <p>
     * This version will automatically pick the best way of determining the total amount of
     * memory depending on what Android API level the device is running on. If the API level
     * is 17 or later the memory is read directly from the
     * {@link android.app.ActivityManager.MemoryInfo MemoryInfo API}.
     * </p>
     * <p>
     * If the API level is lower than 17 then the memory will be determined by examining the
     * /proc/meminfo file.
     * </p>
     *
     * @return The total memory in bytes
     */
    private long getTotalMemory() {

        long totalMemoryMegabytes;

        Logger.d(LOG_TAG, "Using getTotalMemoryApi() to determine memory");
        totalMemoryMegabytes = getTotalMemoryApi();

        return totalMemoryMegabytes;
    }

    /**
     * Gets the total memory that this device has from the Android APIs directly.
     * <p>
     * Prefer the use of {@link #getTotalMemory() getTotalMemory()} because this will select
     * the best method of determining the total amount of memory.
     * </p>
     *
     * @return the total memory in bytes
     */
    private long getTotalMemoryApi() {
        ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);

        return memoryInfo.totalMem;
    }

    /**
     * Returns internal disk size which is used by applications
     *
     * @return disk size in bytes
     */
    private long getDiskSize() {
        return getTotalInternalDiskSize();
    }

    /**
     * Returns disk space used up by applications
     *
     * @return used disk space in bytes
     */
    private long getUsedDiskSpace() {
        return getDiskSize() - getAvailableInternalDiskMemory();
    }

    /**
     * Returns available disk space on internal storage
     *
     * @return available disk space in bytes
     */
    private long getAvailableInternalDiskMemory() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());

        long blockSize = stat.getBlockSizeLong();
        long availableBlocks = stat.getAvailableBlocksLong();
        return availableBlocks * blockSize;
    }

    /**
     * Returns total disk space on internal storage
     *
     * @return total disk space in bytes
     */
    private long getTotalInternalDiskSize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());

        long blockSize = stat.getBlockSizeLong();
        long totalBlocks = stat.getBlockCountLong();
        return totalBlocks * blockSize;
    }
}
