package zendesk.core;

import androidx.annotation.NonNull;

import com.zendesk.logger.Logger;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Response;

/**
 * This interceptor is used to check for a pending {@link PushRegistrationRequest} in storage and
 * send it to the {@link PushRegistrationProviderInternal} if one is found.
 *
 * This interceptor should be executed only when an {@link AccessToken} has already been acquired
 * and stored on the device. This is achieved by making sure it is after the
 * {@link ZendeskAccessInterceptor} in the request chain.
 *
 * It is added to the {@code STANDARD_RETROFIT} instance created in
 * {@link ZendeskNetworkModule}. This means it will be invoked on all requests made through the
 * STANDARD_RETROFIT, which includes Help Center, Support, and Answer Bot requests. In the case where
 * there is no stored {@link PushRegistrationRequest} it will check for one, not find one, and
 * proceed with the chain (without hitting the push registration endpoint). This has the unwanted
 * consequence of this interceptor being invoked more often than necessary. A side effect of this is
 * we will attempt to retry any failed push registration requests on the next network call.
 *
 * {@link PushRegistrationProviderInternal} is used rather than {@link PushRegistrationProvider}
 * because it provides a synchronous method for push registration. An {@link Interceptor} is unsuited
 * to asynchronous callback-based methods, since the {@link #intercept(Chain)} method needs to return
 * something.
 */
class ZendeskPushInterceptor implements Interceptor {

    private final PushRegistrationProviderInternal pushProvider;
    private final PushDeviceIdStorage pushDeviceIdStorage;
    private final IdentityStorage identityStorage;

    private static final String LOG_TAG = "ZendeskPushInterceptor";

    ZendeskPushInterceptor(PushRegistrationProviderInternal pushProvider,
                           PushDeviceIdStorage pushDeviceIdStorage, IdentityStorage identityStorage) {
        this.pushProvider = pushProvider;
        this.pushDeviceIdStorage = pushDeviceIdStorage;
        this.identityStorage = identityStorage;
    }

    @NonNull
    @Override
    public Response intercept(@NonNull final Chain chain) throws IOException {

        PushRegistrationRequest pushRequest = pushDeviceIdStorage.getPushRegistrationRequest();

        if (pushRequest != null && identityStorage.getStoredAccessToken() != null) {
            Logger.d(LOG_TAG, "Sending stored push registration request");
            pushProvider.sendPushRegistrationRequest(pushRequest);
        }

        return chain.proceed(chain.request());
    }
}
