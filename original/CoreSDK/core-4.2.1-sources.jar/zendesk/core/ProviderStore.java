package zendesk.core;

/**
 * Interface used to expose Providers through {@link Zendesk}.
 */
@SuppressWarnings("unused")
public interface ProviderStore {

    /**
     * Returns an implementation of {@link UserProvider}
     *
     * @return an instance of {@link UserProvider}
     */
    UserProvider userProvider();

    /**
     * Returns an implementation of {@link PushRegistrationProvider}
     *
     * @return an instance of {@link PushRegistrationProvider}
     */
    PushRegistrationProvider pushRegistrationProvider();

}