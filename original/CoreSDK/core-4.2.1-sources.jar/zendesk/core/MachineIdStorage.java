package zendesk.core;

import java.util.UUID;

/**
 * Provides access to the machine id storage that will be generate only once the host app installed.
 */
public interface MachineIdStorage {

    /**
     * Generates, stores and returns a {@link UUID} string to uniquely identify the host app install. Note: This
     * identifier lives until the host app is deleted. It is generated and returned on first call of this API and then
     * just returned on future calls.
     *
     * @return The machine id that already stored and identified the install.
     */
    String getMachineId();

}
