package zendesk.core;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * Defines the API calls for obtaining access tokens which will be used to access resources in a
 * Zendesk instance.
 * <p>
 * Currently this is defined using retrofit annotations but this could be changed in the
 * future as long as these signatures remain.
 * </p>
 */
interface AccessService {

    /**
     * Gets OAuth access token for JWT access
     *
     * @param authentication An object that wraps an {@link JwtIdentity}
     * @return a call which will be enqueued or executed by the provider
     */
    @POST("/access/sdk/jwt")
    Call<AuthenticationResponse> getAuthTokenForJwt(@Body AuthenticationRequestWrapper authentication);

    /**
     * Gets OAuth access token for JWT access
     *
     * @param authentication An object that wraps an {@link AnonymousIdentity}
     * @return a call which will be enqueued or executed by the provider
     */
    @POST("/access/sdk/anonymous")
    Call<AuthenticationResponse> getAuthTokenForAnonymous(@Body AuthenticationRequestWrapper authentication);
}
