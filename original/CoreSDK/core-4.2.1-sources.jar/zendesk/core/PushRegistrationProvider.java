package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

/**
 * <p>
 * A provider which will offer a higher level of abstraction compared to the {@link PushRegistrationService}
 * <br>
 * You can create an instance of PushRegistrationProvider like this:
 * <br>
 * <pre>
 *      import zendesk.core.PushRegistrationProvider;
 *      import zendesk.core.Zendesk;
 *      ...
 *      PushRegistrationProvider provider = Zendesk.INSTANCE.provider().pushRegistrationProvider();
 *      ...
 * </pre>
 * <br>
 * <p>
 * Once you have an instance of the provider you can call methods on it and handle the results
 * in callbacks. A success callback will give you the resource(s) that you are requesting, like
 * the result of registering for and un-registering from push. The error callback will be called
 * if there was some issue with the method call and it will define details about the error in an
 * {@link ErrorResponse}
 * </p>
 * <p>
 * For example you can register the device for push notifications like this:
 * </p>
 * <pre>
 *   provider.registerWithDeviceIdentifier("push-token", Locale.getDefault(), {@literal new
 *   ZendeskCallback<PushRegistrationResponse>}() {
 *       {@literal @Override}
 *       public void onSuccess(String pushRegistrationIdentifier) {
 *           // Handle success
 *       }
 *
 *       {@literal @Override}
 *       public void onError(ErrorResponse errorResponse) {
 *           // Handle error
 *       }
 *  });
 * </pre>
 */
@SuppressWarnings("unused")
public interface PushRegistrationProvider {

    /**
     * Calls a push registration service to register a given identifier to receive push notifications.
     *
     * @param identifier The device identifier
     * @param callback   Callback that will deliver a newly created device configuration
     *                   pushRegistrationIdentifier or {@link ErrorResponse}
     */
    void registerWithDeviceIdentifier(@NonNull String identifier, @Nullable ZendeskCallback<String> callback);

    /**
     * Calls a push registration service to register a given Urban Airship channel id to receive push notifications.
     *
     * @param urbanAirshipChannelId The UrbanAirship channel identifier
     * @param callback              Callback that will deliver a newly created device configuration
     *                              pushRegistrationIdentifier or {@link ErrorResponse}
     */
    @SuppressWarnings("checkstyle:abbreviationaswordinname")
    void registerWithUAChannelId(@NonNull String urbanAirshipChannelId, @Nullable ZendeskCallback<String> callback);

    /**
     * Calls a push registration service to unregister a device to receive push notifications.
     *
     * @param callback Callback that will deliver a {@link Void}
     *                 or {@link ErrorResponse}
     */
    void unregisterDevice(@Nullable ZendeskCallback<Void> callback);

    /**
     * Returns whether or not the device is currently registered for push notifications.
     *
     * @return true if this device is currently registered for push notifications, false if not.
     */
    boolean isRegisteredForPush();

}
