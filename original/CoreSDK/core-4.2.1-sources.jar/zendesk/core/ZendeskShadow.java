package zendesk.core;

import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

/**
 * For reference, see the Confluence page on <a href="https://zendesk.atlassian.net/wiki/display/MSDK/Core+init">Core
 * init</a>
 * and <a href="https://zendesk.atlassian.net/wiki/pages/viewpage.action?pageId=260800639">When to send an init
 * blip</a>.
 * <p>
 * Replaces the old ZendeskShadow & InitActions with a simple init and setIdentity method. Also I wanted to keep the
 * arbiter ascii art.
 */
final class ZendeskShadow {

    private static final String LOG_TAG = "ZendeskShadow";

    private final Storage storage;
    private final LegacyIdentityMigrator legacyIdentityMigrator;
    private final IdentityManager identityManager;
    private final BlipsCoreProvider blipsCoreProvider;
    private final PushRegistrationProvider pushRegistrationProvider;
    private final CoreModule coreModule;
    private final ProviderStore providerStore;

    ZendeskShadow(Storage storage, LegacyIdentityMigrator legacyIdentityMigrator, IdentityManager identityManager,
                  BlipsCoreProvider blipsCoreProvider, PushRegistrationProvider pushRegistrationProvider,
                  CoreModule coreModule, ProviderStore providerStore) {

        this.storage = storage;
        this.legacyIdentityMigrator = legacyIdentityMigrator;
        this.identityManager = identityManager;
        this.blipsCoreProvider = blipsCoreProvider;
        this.pushRegistrationProvider = pushRegistrationProvider;
        this.coreModule = coreModule;
        this.providerStore = providerStore;
    }

    void init(ApplicationConfiguration configuration, boolean initialized) {

        if (storage.hasSdkConfigChanged(configuration)) {
            Logger.d(LOG_TAG, "SDK app config details have changed, cleaning up old config storage.");
            storage.clear();
            storage.storeSdkHash(configuration);
        } else if (initialized) {
            Logger.i(LOG_TAG, "Zendesk is already initialized with these details, skipping.");
            return;
        }

        blipsCoreProvider.coreInitialized();
    }

    void cleanupIfNewConfig(ApplicationConfiguration configuration) {
        if (storage.hasSdkConfigChanged(configuration)) {
            pushRegistrationProvider.unregisterDevice(null);
        }
    }

    /**
     * Set the identity which the SDK uses to access and create resources.
     *
     * @param identity Identity that the SDK will identify as
     */
    public void setIdentity(Identity identity) {
        if (!checkIdentityValid(identity)) {
            return;
        }

        //migrate any identity that is hanging around from 1.x
        legacyIdentityMigrator.checkAndMigrateIdentity();

        //check if identity has changed
        if (identityManager.identityIsDifferent(identity)) {
            //new identity, nuke everything to do with users
            pushRegistrationProvider.unregisterDevice(null);
            storage.getSessionStorage().clear();
            identityManager.updateAndPersistIdentity(identity);
        } else {
            Logger.i(LOG_TAG, "Zendesk is already initialized with this identity, skipping.");
        }
    }

    @Nullable
    public Identity getIdentity() {
        return identityManager.getIdentity();
    }

    /**
     * For internal use.
     * <br />
     * <b>Here be dragons</b>
     */
    public CoreModule coreModule() {
        return coreModule;
    }

    /**
     * Gets a {@link ProviderStore} for accessing all available
     * SDK Providers.
     *
     * @return an instance of {@link ProviderStore}
     */
    public ProviderStore providers() {
        return providerStore;
    }

    @SuppressWarnings("RedundantIfStatement")
    private static boolean checkIdentityValid(Identity identity) {
        String message = "setIdentity(): The provided Identity object must be "
                + "an Anonymous Identity or a JwtIdentity with a non-empty JWT identifier. Returning.";

        if (identity == null) {
            Logger.w(LOG_TAG, message);
            return false;
        }

        if (!(identity instanceof AnonymousIdentity || identity instanceof JwtIdentity)) {
            Logger.w(LOG_TAG, message);
            return false;
        }

        if (identity instanceof JwtIdentity && StringUtils.isEmpty(((JwtIdentity) identity).getJwtUserIdentifier())) {
            Logger.w(LOG_TAG, message);
            return false;
        }
        return true;
    }

    void reset() {
        pushRegistrationProvider.unregisterDevice(null);
        storage.getSessionStorage().clear();
        storage.clear();
    }
}
