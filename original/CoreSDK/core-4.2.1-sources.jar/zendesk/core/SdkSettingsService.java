package zendesk.core;

import com.google.gson.JsonElement;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Path;

import static zendesk.core.Constants.ACCEPT_LANGUAGE;

/**
 * Defines the operations that can be carried out on the Zendesk mobile SDK settings APIs.
 * <p>
 * These APIs are used to retrieve settings that control features of the SDK.
 * This interface will be implemented by the {@link SdkSettingsService}
 * </p>
 */
interface SdkSettingsService {

    /**
     * Gets the settings for this application from a Zendesk instance.
     *
     * @param deviceLocale  The string representation of the device's locale in the format of
     *                      [language]-[COUNTRY]. This will influence the language of content that
     *                      is retrieved by some services like Help Center
     * @param applicationId The id of your application as defined in the sdk application's page on
     *                      the Lotus web UI.
     * @return a call which will be enqueued or executed by the provider
     */
    @GET("/api/private/mobile_sdk/settings/{applicationId}.json")
    Call<Map<String, JsonElement>> getSettings(
            @Header(ACCEPT_LANGUAGE) String deviceLocale,
            @Path("applicationId") String applicationId);
}