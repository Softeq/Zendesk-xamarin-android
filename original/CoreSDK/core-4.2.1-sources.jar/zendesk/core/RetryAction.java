package zendesk.core;

/**
 * RetryAction specifies behavior of things that can be retried
 */
public interface RetryAction {

    /**
     * Called when actions should be retried
     */
    void onRetry();
}
