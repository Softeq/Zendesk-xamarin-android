package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

interface PushDeviceIdStorage {

    void storeRegisteredDeviceId(@NonNull String deviceId);

    @Nullable
    String getRegisteredDeviceId();

    boolean hasRegisteredDeviceId();

    void removeRegisteredDeviceId();

    void storePushRegistrationRequest(@NonNull PushRegistrationRequest request);

    @Nullable
    PushRegistrationRequest getPushRegistrationRequest();

    void removePushRegistrationRequest();
}
