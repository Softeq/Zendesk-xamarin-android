package zendesk.core;

import com.google.gson.annotations.SerializedName;

/**
 * Models the api request which is formed when registering a device for push notifications
 */
@SuppressWarnings({"unused", "FieldCanBeLocal"})
class PushRegistrationRequestWrapper {

    @SerializedName("push_notification_device")
    private PushRegistrationRequest pushRegistrationRequest;

    public PushRegistrationRequestWrapper(PushRegistrationRequest pushRegistrationRequest) {
        this.pushRegistrationRequest = pushRegistrationRequest;
    }

    public PushRegistrationRequest getPushRegistrationRequest() {
        return pushRegistrationRequest;
    }
}
