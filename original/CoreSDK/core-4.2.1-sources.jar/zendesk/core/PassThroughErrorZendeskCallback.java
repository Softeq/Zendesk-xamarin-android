package zendesk.core;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

abstract class PassThroughErrorZendeskCallback<E> extends ZendeskCallback<E> {

    private final ZendeskCallback callback;

    PassThroughErrorZendeskCallback(ZendeskCallback callback) {
        this.callback = callback;
    }

    @Override
    public abstract void onSuccess(final E e);

    @Override
    public void onError(final ErrorResponse errorResponse) {
        if (callback != null) {
            callback.onError(errorResponse);
        }
    }
}
