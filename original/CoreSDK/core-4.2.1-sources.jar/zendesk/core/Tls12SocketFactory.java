package zendesk.core;

import com.zendesk.logger.Logger;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Collections;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import okhttp3.ConnectionSpec;
import okhttp3.OkHttpClient;
import okhttp3.TlsVersion;

/**
 * <p>
 * Applies the correct ConnectionSpecs for different versions of android. On api versions from 16-20 (Jelly Bean and
 * Kitkat)
 * a patch is applied to the SSLSocketFactory to enable TLSv1.2 and disable older TLS and SSL versions.
 * </p>
 * <p>
 * On Api versions >= 21 (Lollipop and above) TLSv1.2 is supported by default and the default SSLSocketFactory is used.
 * The Connection spec is set to disable older fallback versions of TLS and SSL.
 * </p>
 * <p>
 * more info <a href="https://github.com/square/okhttp/issues/2372">OkHttp Github Issue</a>
 * </p>
 */
@SuppressWarnings("WeakerAccess")
class Tls12SocketFactory extends SSLSocketFactory {

    /**
     * @param client the client to configure
     * @return the configured client
     */
    public static OkHttpClient.Builder enableTls12(OkHttpClient.Builder client) {

        //only patch android versions that need to be patched
        Logger.d("Tls12SocketFactory", "Skipping TLS 1.2 patch");
        //only use modern tls 1.2 & 1.3 on newer devices
        client.connectionSpecs(Collections.singletonList(new ConnectionSpec.Builder(ConnectionSpec.MODERN_TLS)
                .tlsVersions(TlsVersion.TLS_1_2, TlsVersion.TLS_1_3)
                .build()));
        return client;
    }

    private static final String[] TLS_V12_ONLY = {TlsVersion.TLS_1_2.javaName()};

    //Do not rename, needed for okhttp to overwrite with reflection
    final SSLSocketFactory delegate;

    public Tls12SocketFactory(SSLSocketFactory base) {
        this.delegate = base;
    }

    @Override
    public String[] getDefaultCipherSuites() {
        return delegate.getDefaultCipherSuites();
    }

    @Override
    public String[] getSupportedCipherSuites() {
        return delegate.getSupportedCipherSuites();
    }

    @Override
    public Socket createSocket(Socket s, String host, int port, boolean autoClose) throws IOException {
        return patch(delegate.createSocket(s, host, port, autoClose));
    }

    @Override
    public Socket createSocket(String host, int port) throws IOException {
        return patch(delegate.createSocket(host, port));
    }

    @Override
    public Socket createSocket(String host, int port, InetAddress localHost, int localPort) throws IOException {
        return patch(delegate.createSocket(host, port, localHost, localPort));
    }

    @Override
    public Socket createSocket(InetAddress host, int port) throws IOException {
        return patch(delegate.createSocket(host, port));
    }

    @Override
    public Socket createSocket(InetAddress address, int port, InetAddress localAddress, int localPort) throws
            IOException {
        return patch(delegate.createSocket(address, port, localAddress, localPort));
    }

    private static Socket patch(Socket s) {
        if (s instanceof SSLSocket) {
            ((SSLSocket) s).setEnabledProtocols(TLS_V12_ONLY);
        }
        return s;
    }
}