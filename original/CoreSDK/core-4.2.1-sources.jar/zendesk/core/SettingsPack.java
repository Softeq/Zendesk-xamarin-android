package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;

/**
 * Object for holding core settings and SDK specific settings. Returned by
 * {@link SettingsProvider#getSettingsForSdk(String, Class, ZendeskCallback)}
 *
 * @param <E> type of the SDK specific settings
 */
public class SettingsPack<E extends Settings> {

    private CoreSettings coreSettings;
    private E settings;

    /**
     * Create an instance of SettingsPack
     */
    SettingsPack(@NonNull CoreSettings coreSettings, @Nullable E settings) {
        this.coreSettings = coreSettings;
        this.settings = settings;
    }

    /**
     * Gets core settings
     *
     * @return a core settings object
     */
    @NonNull
    public CoreSettings getCoreSettings() {
        return coreSettings;
    }

    /**
     * Gets settings of the specified type.
     *
     * @return settings object of type {@code E}
     */
    @Nullable
    public E getSettings() {
        return settings;
    }
}
