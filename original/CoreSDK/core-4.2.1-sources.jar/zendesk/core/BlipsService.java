package zendesk.core;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Defines the API calls for sending Blips to Zendesk.
 */
interface BlipsService {

    /**
     * Transmit a blip using the new processor
     *
     * @param blipData A BlipRequest that has been converted to JSON, Base64 encoded, and then URLEncoded, in that order
     * @return a call which will be enqueued or executed by the provider
     */
    @GET("/embeddable_blip")
    Call<Void> send(@Query("data") String blipData);
}
