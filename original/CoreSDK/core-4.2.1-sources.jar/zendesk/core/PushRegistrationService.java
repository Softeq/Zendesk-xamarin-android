package zendesk.core;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Defines the operations that can be carried out on the Zendesk mobile SDK push notification
 * <p>
 * These APIs are used to register/unregister a device for push notifications.
 * This interface will be implemented by the {@link PushRegistrationService}
 * </p>
 */
interface PushRegistrationService {

    /**
     * Register an device to receive push notifications
     *
     * @param request A wrapper object which holds the device's push notification configuration
     * @return a call which will be enqueued or executed by the provider
     */
    @POST("/api/mobile/push_notification_devices.json")
    Call<PushRegistrationResponseWrapper> registerDevice(
            @Body PushRegistrationRequestWrapper request);


    /**
     * Unregister a device to receive push notifications
     *
     * @param identifier The device identifier
     * @return a call which will be enqueued or executed by the provider
     */
    @DELETE("/api/mobile/push_notification_devices/{id}.json")
    Call<Void> unregisterDevice(
            @Path("id") String identifier);

}
