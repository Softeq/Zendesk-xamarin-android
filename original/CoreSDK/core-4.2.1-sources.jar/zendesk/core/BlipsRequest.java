package zendesk.core;

import androidx.annotation.VisibleForTesting;

import com.google.gson.annotations.SerializedName;

import java.util.Map;

/**
 * Model class representing the abstract base of a Blips request.
 */
class BlipsRequest {

    private String uuid;
    private String version;
    private String timestamp;

    private String channel;

    @SerializedName("userId")
    private Long userId;

    @SerializedName("schemaVersion")
    private String schemaVersion = "1";

    @SerializedName("appId")
    private String appId;

    // UserAction specific
    @SerializedName("userAction")
    private ApiUserAction userAction;

    // PageView specific
    @SerializedName("pageView")
    private ApiPageView pageView;

    private String url;

    static BlipsRequest buildUserAction(String uuid, String timestamp, Long userId, String appId, String version,
                                        String channel, String category, String action,
                                        String label, Map<String, Object> value) {
        BlipsRequest request = new BlipsRequest();
        request.uuid = uuid;
        request.timestamp = timestamp;
        request.userId = userId;
        request.appId = appId;
        request.version = version;
        request.channel = channel;
        request.userAction = new ApiUserAction(category, action, label, value);
        return request;
    }

    static BlipsRequest buildPageView(String uuid, String timestamp, Long userId, String appId, String version,
                                      String channel, String url, String navigatorLanguage, String pageTitle,
                                      Long pageId, String pageLocale, Map<String, Object> value) {
        BlipsRequest request = new BlipsRequest();
        request.uuid = uuid;
        request.timestamp = timestamp;
        request.userId = userId;
        request.appId = appId;
        request.version = version;
        request.channel = channel;
        request.url = url;
        request.pageView = new ApiPageView(navigatorLanguage, pageTitle, pageId, pageLocale, value);
        return request;
    }

    /**
     * Create an instance of BlipsRequest.
     */
    private BlipsRequest() {
        // Intentionally private and empty.
    }

    static class ApiUserAction {

        /**
         * The category that will be sent in the user action for the blip.
         */
        private String category;

        /**
         * The action that will be sent in the user action for the blip.
         */
        private String action;

        /**
         * The label that will be sent in the user action for the blip.
         */
        private String label;

        /**
         * The value that will be sent in the user action for the blip.
         */
        private Map<String, Object> value;

        ApiUserAction(String category, String action, String label, Map<String, Object> value) {
            this.category = category;
            this.action = action;
            this.label = label;
            this.value = value;
        }

        String getCategory() {
            return category;
        }

        String getAction() {
            return action;
        }

        String getLabel() {
            return label;
        }

        Map<String, Object> getValue() {
            return value;
        }
    }

    static class ApiPageView {
        /**
         * The navigator language that will be sent in the page view for the blip.
         */
        @SerializedName("navigatorLanguage")
        private String navigatorLanguage;

        /**
         * The page title that will be sent in the page view for the blip.
         */
        @SerializedName("pageTitle")
        private String pageTitle;

        /**
         * The page id that will be sent in the page view for the blip.
         */
        @SerializedName("pageId")
        private Long pageId;

        /**
         * The page locale that will be sent in the page view for the blip.
         * Note: this ought to be the locale that the page is displaying in, not the locale
         * of the device etc.
         */
        @SerializedName("pageLocale")
        private String pageLocale;

        /**
         * The value that will be sent in the user action for the blip.
         */
        private Map<String, Object> value;

        ApiPageView(String navigatorLanguage, String pageTitle, Long pageId, String pageLocale,
                    Map<String, Object> value) {
            this.navigatorLanguage = navigatorLanguage;
            this.pageTitle = pageTitle;
            this.value = value;
            this.pageId = pageId;
            this.pageLocale = pageLocale;
        }

        @VisibleForTesting
        String getNavigatorLanguage() {
            return navigatorLanguage;
        }

        @VisibleForTesting
        String getPageTitle() {
            return pageTitle;
        }

        @VisibleForTesting
        Map<String, Object> getValue() {
            return value;
        }

        @VisibleForTesting
        Long getPageId() {
            return pageId;
        }

        @VisibleForTesting
        String getPageLocale() {
            return pageLocale;
        }
    }

    /**
     * Gets the BUID
     *
     * @return the BUID
     */
    String getUuid() {
        return uuid;
    }

    /**
     * Gets the version string
     *
     * @return the version string
     */
    String getVersion() {
        return version;
    }

    /**
     * Gets the timestamp
     *
     * @return gets the timestamp ISO8601 formatted
     */
    String getTimestamp() {
        return timestamp;
    }

    /**
     * Gets the schema version
     *
     * @return the schema version
     */
    String getSchemaVersion() {
        return schemaVersion;
    }

    /**
     * Gets the channel
     *
     * @return the channel
     */
    String getChannel() {
        return channel;
    }

    /**
     * Gets the user_id
     *
     * @return the user_id
     */
    Long getUserId() {
        return userId;
    }

    /**
     * Gets the appId
     *
     * @return the appId
     */
    String getAppId() {
        return appId;
    }

    ApiUserAction getUserAction() {
        return userAction;
    }

    ApiPageView getPageView() {
        return pageView;
    }

    String getUrl() {
        return url;
    }
}
