package zendesk.core;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;

/**
 * This class is a collection of utility methods for determining network state.
 */
@SuppressWarnings("unused")
class NetworkUtils {

    private static final String LOG_TAG = "NetworkUtils";

    private NetworkUtils() {
        // Intentionally empty
    }

    /**
     * Determines whether we have a usable connection or not.
     * <p>
     * Specifically this calls {@link NetworkInfo#isConnected()} which determines
     * that a <b>usable</b> connection is present.
     * </p>
     *
     * @param context The context which will be used to obtain an instance of {@link ConnectivityManager}
     * @return true if a usable connection is present, false otherwise.
     */
    static boolean isConnected(Context context) {

        boolean isConnected = false;

        NetworkInfo networkInfo = getActiveNetworkInfo(context);

        if (networkInfo != null) {
            isConnected = networkInfo.isConnected();
        }

        return isConnected;
    }

    /**
     * Determines whether we are on a mobile network or not.
     * <p>
     * This checks if the type of the current active network is {@link ConnectivityManager#TYPE_MOBILE},
     * as reported by {@link NetworkInfo#getType()}
     * </p>
     *
     * @param context The context which will be used to obtain an instance of {@link ConnectivityManager}
     * @return true if the current active connection is a mobile one, false otherwise.
     */
    static boolean isMobile(Context context) {

        boolean isMobile = false;

        NetworkInfo networkInfo = getActiveNetworkInfo(context);

        if (networkInfo != null) {
            isMobile = ConnectivityManager.TYPE_MOBILE == networkInfo.getType();
        }

        return isMobile;
    }

    /**
     * Obtains an instance of the {@link ConnectivityManager}
     * <p>
     * This is simply a convenience method for obtaining a {@link ConnectivityManager}
     * without having to call {@link Context#getSystemService(String)}
     * </p>
     *
     * @param context The context which will be used to obtain an instance of {@link ConnectivityManager}
     * @return An instance of {@link ConnectivityManager} or null if it was not found.
     */
    @Nullable
    static ConnectivityManager getConnectivityManager(Context context) {

        if (context == null) {
            Logger.w(LOG_TAG, "Context is null. Cannot get ConnectivityManager");
            return null;
        }

        ConnectivityManager connectivityManager =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivityManager == null) {
            Logger.w(LOG_TAG, "Connectivity manager is null");
        }

        return connectivityManager;
    }

    /**
     * Gets the currently active {@link NetworkInfo}.
     * <p>
     * Please note that your application must have the {@code Manifest.permission#ACCESS_NETWORK_STATE}
     * permission in order for this method to return actual data.
     * </p>
     *
     * @param context The context which will be used to obtain an instance of {@link NetworkInfo}
     * @return The {@link NetworkInfo} representing the active network connection or
     * null if there was an issue looking this up.
     */
    @Nullable
    static NetworkInfo getActiveNetworkInfo(Context context) {

        NetworkInfo networkInfo = null;

        ConnectivityManager connectivityManager = getConnectivityManager(context);

        if (connectivityManager != null && context != null) {

            if (PackageManager.PERMISSION_GRANTED == context
                    .checkCallingOrSelfPermission(Manifest.permission.ACCESS_NETWORK_STATE)) {
                Logger.i(LOG_TAG, "Getting active network information");
                networkInfo = connectivityManager.getActiveNetworkInfo();
            } else {
                Logger.w(LOG_TAG,
                        "Will not return if network is available because we do not have the permission to do so: "
                                + "ACCESS_NETWORK_STATE");
            }
        }

        return networkInfo;
    }
}
