package zendesk.core;

import android.os.Build;
import androidx.annotation.NonNull;

import java.io.IOException;
import java.util.Locale;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * This interceptor will add three headers to the outgoing request: User-Agent, X-Zendesk-Client,
 * and X-Zendesk-Client-Version. Any headers with the same names from earlier interceptors will be
 * overwritten.
 * <p>
 * The values for all three headers are computed from two values: the version and variant of the SDK
 * making the request. In most cases, this means the SDK that contains the provider that makes the
 * request. For example, settings calls, access calls, and push registration calls will all have
 * Core's variant and version number, while calls to Help Center or tickets will all have Support's
 * variant and version number.
 * <p>
 * The formats of the three headers are as follows:
 *
 * <p>
 * User-Agent Zendesk-SDK/{{version}} Android/{{API level}} Variant/{{variant, in Pascal case}}
 * X-Zendesk-Client mobile/android/sdk/{{variant, in lower case}}
 * X-Zendesk-Client-Version {{version}}
 * </p>
 * <p>
 * Full examples:
 *
 * <p>
 * User-Agent Zendesk-SDK/1.0.0 Android/23 Variant/Core
 * X-Zendesk-Client mobile/android/sdk/core
 * X-Zendesk-Client-Version 1.0.0
 * </p>
 */
class UserAgentAndClientHeadersInterceptor implements Interceptor {

    private final String userAgent;
    private final String zendeskClient;
    private final String version;

    public UserAgentAndClientHeadersInterceptor(String version, String variant) {
        this.userAgent =
                String.format(Locale.US, Constants.USER_AGENT_HEADER_TEMPLATE, version, Build.VERSION.SDK_INT, variant);
        this.zendeskClient =
                String.format(Locale.US, Constants.X_ZENDESK_CLIENT_HEADER_VALUE_FORMAT, variant.toLowerCase());
        this.version = version;
    }

    @NonNull
    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        Request request = chain.request();
        Request.Builder requestHeadersBuilder = request.newBuilder();

        requestHeadersBuilder.removeHeader(Constants.USER_AGENT_HEADER_KEY);
        requestHeadersBuilder.addHeader(Constants.USER_AGENT_HEADER_KEY, userAgent);

        requestHeadersBuilder.removeHeader(Constants.X_ZENDESK_CLIENT_HEADER_NAME);
        requestHeadersBuilder.addHeader(Constants.X_ZENDESK_CLIENT_HEADER_NAME, zendeskClient);

        requestHeadersBuilder.removeHeader(Constants.X_ZENDESK_CLIENT_VERSION_HEADER_NAME);
        requestHeadersBuilder.addHeader(Constants.X_ZENDESK_CLIENT_VERSION_HEADER_NAME, version);

        return chain.proceed(requestHeadersBuilder.build());
    }
}
