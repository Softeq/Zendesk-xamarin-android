package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;

/**
 * <p>
 * A provider which will offer a higher level of abstraction compared to the {@link SdkSettingsService}
 * <br>
 * This provider is used internally by the SDK and does not need to be called explicitly. If you do
 * need to call it, create an instance of SettingsProvider like this:
 *
 * <pre>
 *      import zendesk.core.SettingsProvider;
 *      import zendesk.core.Zendesk;
 *      ...
 *      SettingsProvider provider = Zendesk.INSTANCE.provider().sdkSettingsProvider();
 *      ...
 * </pre>
 *
 * <p>
 * Once you have an instance of the provider you can call methods on it and handle the results
 * in callbacks. A success callback will give you the resource(s) that you are requesting. The
 * error callback will be called if there was some issue with the method call and it will define
 * details about the error in an {@link com.zendesk.service.ErrorResponse}
 * </p>
 * <p>
 * For example you can get the SDK Settings like this:
 *
 * <pre>
 *   provider.getCoreSettings(new ZendeskCallback{@literal <CoreSettings>}() {
 *       {@literal @Override}
 *       public void onSuccess(CoreSettings settings) {
 *           // Handle the success
 *       }
 *
 *       {@literal @Override}
 *       public void onError(ErrorResponse errorResponse) {
 *           // Handle the error
 *       }
 *   });
 * </pre>
 * <p>
 * When you request SDK settings in this way the settings will be saved to the device also.
 */
public interface SettingsProvider {

    /**
     * Retrieves core settings from storage if they are valid or network if they are not.
     */
    void getCoreSettings(@Nullable ZendeskCallback<CoreSettings> callback);

    /**
     * Retrieves SDK-specific settings and Core settings in a SettingsPack object. Checks storage
     * first to see if it contains valid storage. If so, these are returned. Otherwise, they are
     * retrieved from the network.
     *
     * @param key              the request storage key
     * @param sdkSettingsClass a class instance describing the expected settings
     * @param <E>              the expected type of the settings object
     */
    <E extends Settings> void getSettingsForSdk(@NonNull String key,
                                                @NonNull Class<E> sdkSettingsClass,
                                                @Nullable ZendeskCallback<SettingsPack<E>> callback);
}
