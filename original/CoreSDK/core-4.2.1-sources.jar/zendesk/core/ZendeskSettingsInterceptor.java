package zendesk.core;

import com.zendesk.logger.Logger;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.Protocol;
import okhttp3.Response;

class ZendeskSettingsInterceptor implements Interceptor {

    private static final String LOG_TAG = "SettingsInterceptor";

    private final SdkSettingsProviderInternal provider;
    private SettingsStorage settingsStorage;

    ZendeskSettingsInterceptor(SdkSettingsProviderInternal provider,
                               SettingsStorage settingsStorage) {
        this.provider = provider;
        this.settingsStorage = settingsStorage;
    }

    @Override
    public Response intercept(final Chain chain) throws IOException {
        if (!settingsStorage.areSettingsUpToDate(ZendeskSettingsProvider.SDK_SETTINGS_MAX_AGE_HOURS,
                TimeUnit.HOURS)) {
            Logger.d(LOG_TAG, "Requesting SDK settings.");
            CoreSettings settings = provider.getCoreSettings();

            if (settings == null) {

                Logger.d(LOG_TAG, "Retrieved settings are null. Returning 404.");

                return new Response.Builder()
                        .protocol(Protocol.HTTP_2)
                        .request(chain.request())
                        .message(chain.request().method())
                        .code(404)
                        .build();
            }
        }

        Logger.d(LOG_TAG, "Proceeding with chain.");
        return chain.proceed(chain.request());
    }

}
