package zendesk.core;

import com.zendesk.logger.Logger;

import java.io.IOException;
import java.net.HttpURLConnection;

import okhttp3.Interceptor;
import okhttp3.Response;

/**
 * This is the default 401 error {@link Interceptor} that will be used when configuring a {@link okhttp3.OkHttpClient}
 */
class ZendeskUnauthorizedInterceptor implements Interceptor {

    private final SessionStorage sessionStorage;
    private final IdentityManager identityManager;

    private static final String LOG_TAG = "ZendeskUnauthorizedInterceptor";

    ZendeskUnauthorizedInterceptor(SessionStorage sessionStorage, IdentityManager identityManager) {
        this.sessionStorage = sessionStorage;
        this.identityManager = identityManager;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Response response = chain.proceed(chain.request());

        if (!response.isSuccessful() && HttpURLConnection.HTTP_UNAUTHORIZED == response.code()) {
            if (UrlHelper.isGuideRequest(chain.request().url().toString())
                    && identityManager.getIdentity() instanceof AnonymousIdentity) {
                Logger.d(LOG_TAG, "Unauthorized guide request");
            } else {
                onHttpUnauthorized();
            }
        }

        return response;
    }

    void onHttpUnauthorized() {
        sessionStorage.clear();
    }
}
