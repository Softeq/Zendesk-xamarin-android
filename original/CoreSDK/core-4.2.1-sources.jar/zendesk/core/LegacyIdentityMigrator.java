package zendesk.core;

import androidx.annotation.Nullable;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

/**
 * Migrates legacy (Support SDK 1.x) identity data from legacy storage to Core's storage. This is to
 * allow users upgrading from Support 1.x to Support 2.0 to keep their requests. Without the identity
 * data, SDK GUID, access token, they cannot do this, and the tickets would be lost irretrievably.
 * <p>
 * This class is an implementation of the innovative "Shitbox" pattern, explained elegantly by this
 * quote:
 * <p>
 * "Get your shit together. Get it all together and put it in a backpack. All your shit, so it's all together."
 * - Morty Smith, 2015
 * <p>
 * No one wants to do migration. It's lame. It's horrible. It's a bunch of weird hacky crap that
 * nobody wants to do, but we have to do it anyway. So as per the Shitbox pattern, we try to
 * encapsulate all that manky shit as much as we can in one place - the shitbox. The shit should not
 * be allowed to leak from the shitbox. With this implementation, the shitty details of migration
 * do not leak into {@link IdentityManager}. One detail has leaked into {@link IdentityStorage},
 * since we need to be able to set the stored SDK GUID directly, rather than the usual strategy of
 * generating them from random when required.
 * <p>
 * To avoid multiple "Legacy" classes such as "LegacyAnonymousIdentity" (which would be required to
 * live in the code forever to support migration), the implementation makes use of direct JSON
 * manipulation through GSON's classes. Direct manipulation of {@link IdentityStorage}, rather than
 * going through {@link IdentityManager}, is also done here, to prevent leaking of migration logic
 * into IdentityManager. Shitbox.
 * <p>
 * The only public method of the class, {@link #checkAndMigrateIdentity()}, should be invoked at
 * initialisation time, when migration is a logical possibility (ie, we do not have a stored
 * Core SDK configuration, since that would mean it is not the first run).
 * <p>
 * Following migration, the migrated data is removed from legacy storage, which should prevent any
 * accidental re-migration.
 */
class LegacyIdentityMigrator {

    private static final String LOG_TAG = "LegacyIdentityStorage";

    private static final String LEGACY_STORED_TOKEN_KEY = "stored_token";
    private static final String LEGACY_IDENTITY_KEY = "zendesk-identity";
    private static final String LEGACY_IDENTITY_TYPE_KEY = "zendesk-identity-type";
    private static final String LEGACY_SDK_GUID_KEY = "uuid";
    private static final String LEGACY_USER_ID_KEY = "user_id";
    private static final String ANONYMOUS_EMAIL_KEY = "email";
    private static final String ANONYMOUS_NAME_KEY = "name";
    private static final String JWT_TOKEN_KEY = "token";
    private static final String LEGACY_ACCESS_TOKEN_KEY = "access_token";
    private static final String LEGACY_ACCESS_TOKEN_USER_ID_KEY = "user_id";
    private static final String LEGACY_PUSH_RESPONSE_KEY = "pushRegResponseIdentifier";
    private static final String LEGACY_PUSH_DEVICE_ID_KEY = "identifier";

    private SharedPreferencesStorage legacyIdentityStorage;
    private SharedPreferencesStorage legacyPushStorage;
    private IdentityStorage identityStorage;
    private IdentityManager identityManager;
    private PushDeviceIdStorage pushDeviceIdStorage;

    LegacyIdentityMigrator(SharedPreferencesStorage legacyIdentityStorage,
                           SharedPreferencesStorage legacyPushStorage,
                           IdentityStorage identityStorage,
                           IdentityManager identityManager,
                           PushDeviceIdStorage pushDeviceIdStorage) {
        this.legacyIdentityStorage = legacyIdentityStorage;
        this.legacyPushStorage = legacyPushStorage;
        this.identityStorage = identityStorage;
        this.identityManager = identityManager;
        this.pushDeviceIdStorage = pushDeviceIdStorage;
    }

    void checkAndMigrateIdentity() {
        // If there's no legacy identity, don't migrate anything.
        Identity legacyIdentity = getLegacyIdentity();
        if (legacyIdentity == null) {
            return;
        }

        // Migrate the identity
        identityStorage.storeIdentity(legacyIdentity);

        // Migrate the userId
        long legacyUserId = getLegacyUserId();
        if (legacyUserId != 0L) {
            identityStorage.storeUserId(legacyUserId);
        }

        // Migrate the AccessToken
        AccessToken legacyToken = getLegacyAccessToken();
        if (legacyToken != null) {
            identityManager.storeAccessToken(legacyToken);
        }

        // If it's an AnonymousIdentity, migrate the sdkGuid
        if (getLegacyIdentityType() == AuthenticationType.ANONYMOUS) {
            String legacySdkGuid = getLegacySdkGuid();
            if (StringUtils.hasLength(legacySdkGuid)) {
                identityStorage.storeSdkGuid(legacySdkGuid);
            }
        }

        // Migrate the push device ID
        String pushDeviceId = getLegacyPushId();
        if (StringUtils.hasLength(pushDeviceId)) {
            pushDeviceIdStorage.storeRegisteredDeviceId(pushDeviceId);
        }

        // Wipe the old storage so we don't re-migrate
        clear();
    }

    @Nullable
    private Identity getLegacyIdentity() {
        // If we can't determine the legacy auth type, return null.
        AuthenticationType authType = getLegacyIdentityType();
        if (authType == null) {
            return null;
        }

        switch (authType) {
            case ANONYMOUS:
                return readLegacyAnonymousIdentity();
            case JWT:
                return readLegacyJwtIdentity();
        }

        return null;
    }

    @Nullable
    private AnonymousIdentity readLegacyAnonymousIdentity() {
        String legacyIdentityJson = legacyIdentityStorage.get(LEGACY_IDENTITY_KEY);
        if (StringUtils.isEmpty(legacyIdentityJson)) {
            return null;
        }

        try {
            JsonElement jsonElement = new JsonParser().parse(legacyIdentityJson);
            if (jsonElement == null || !jsonElement.isJsonObject()) {
                return null;
            }

            JsonObject json = jsonElement.getAsJsonObject();

            AnonymousIdentity.Builder builder = new AnonymousIdentity.Builder();

            JsonElement emailJson = json.get(ANONYMOUS_EMAIL_KEY);
            if (emailJson != null) {
                builder.withEmailIdentifier(emailJson.getAsString());
            }

            JsonElement nameJson = json.get(ANONYMOUS_NAME_KEY);
            if (nameJson != null) {
                builder.withNameIdentifier(nameJson.getAsString());
            }

            return (AnonymousIdentity) builder.build();
        } catch (JsonSyntaxException ex) {
            Logger.w(LOG_TAG, "Unable to read legacy AnonymousIdentity.", ex);
            return null;
        }
    }

    private JwtIdentity readLegacyJwtIdentity() {
        String legacyIdentityJson = legacyIdentityStorage.get(LEGACY_IDENTITY_KEY);
        if (StringUtils.isEmpty(legacyIdentityJson)) {
            return null;
        }

        try {
            JsonElement jsonElement = new JsonParser().parse(legacyIdentityJson);
            if (jsonElement == null) {
                return null;
            }

            JsonObject jsonObject = jsonElement.getAsJsonObject();
            if (jsonObject != null) {
                JsonElement jwtToken = jsonObject.get(JWT_TOKEN_KEY);
                return (jwtToken != null) ? new JwtIdentity(jwtToken.getAsString()) : null;
            } else {
                return null;
            }
        } catch (JsonSyntaxException ex) {
            Logger.w(LOG_TAG, "Unable to read legacy JwtIdentity.", ex);
            return null;
        }
    }

    @Nullable
    private AuthenticationType getLegacyIdentityType() {
        return AuthenticationType.getAuthType(legacyIdentityStorage.get(LEGACY_IDENTITY_TYPE_KEY));
    }

    @Nullable
    private AccessToken getLegacyAccessToken() {
        String legacyAccessTokenJson = legacyIdentityStorage.get(LEGACY_STORED_TOKEN_KEY);
        if (StringUtils.isEmpty(legacyAccessTokenJson)) {
            return null;
        }

        try {
            JsonElement jsonElement = new JsonParser().parse(legacyAccessTokenJson);
            if (jsonElement == null || !jsonElement.isJsonObject()) {
                return null;
            }

            JsonObject jsonObject = jsonElement.getAsJsonObject();
            JsonElement accessTokenJson = jsonObject.get(LEGACY_ACCESS_TOKEN_KEY);
            JsonElement userIdJson = jsonObject.get(LEGACY_ACCESS_TOKEN_USER_ID_KEY);

            if (accessTokenJson != null && userIdJson != null) {
                return new AccessToken(accessTokenJson.getAsString(), userIdJson.getAsString());
            } else {
                return null;
            }
        } catch (JsonSyntaxException ex) {
            Logger.w(LOG_TAG, "Unable to read legacy AccessToken.", ex);
            return null;
        }
    }

    @Nullable
    private String getLegacySdkGuid() {
        return legacyIdentityStorage.get(LEGACY_SDK_GUID_KEY);
    }

    private long getLegacyUserId() {
        return legacyIdentityStorage.getLong(LEGACY_USER_ID_KEY);
    }

    @Nullable
    private String getLegacyPushId() {
        String rawJson = legacyPushStorage.get(LEGACY_PUSH_RESPONSE_KEY);

        if (StringUtils.hasLength(rawJson)) {
            try {
                JsonElement jsonElement = new JsonParser().parse(rawJson);
                if (jsonElement == null || !jsonElement.isJsonObject()) {
                    return null;
                }

                JsonElement legacyId = jsonElement.getAsJsonObject()
                        .get(LEGACY_PUSH_DEVICE_ID_KEY);

                if (legacyId != null) {
                    return legacyId.getAsString();
                }
            } catch (JsonSyntaxException ex) {
                Logger.w(LOG_TAG, "Unable to read legacy push device ID.", ex);
            }
        }

        return null;
    }

    private void clear() {
        legacyIdentityStorage.remove(LEGACY_IDENTITY_TYPE_KEY);
        legacyIdentityStorage.remove(LEGACY_IDENTITY_KEY);
        legacyIdentityStorage.remove(LEGACY_STORED_TOKEN_KEY);
        legacyIdentityStorage.remove(LEGACY_SDK_GUID_KEY);
        legacyIdentityStorage.remove(LEGACY_USER_ID_KEY);
        legacyPushStorage.remove(LEGACY_PUSH_RESPONSE_KEY);
    }
}
