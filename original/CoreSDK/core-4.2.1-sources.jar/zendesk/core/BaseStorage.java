package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Low level storage description. Using a very basic key value concept.
 */
public interface BaseStorage {

    /**
     * Store the the given key value pair.
     * <br>
     * If there's already a value stored with the same key, it will be overridden
     * <br>
     * Passing in {@code null} as value removes the key from the storage.
     *
     * @param key   a unique key
     * @param value data as String
     */
    void put(@NonNull String key, @Nullable String value);

    /**
     * Store the the given key value pair.
     * <br>
     * The concrete implementation of the storage will take care of the deserialization of
     * the given object.
     * <br>
     * If there's already a value stored with the same key, it will be overridden
     * <br>
     * Passing in {@code null} as value removes the key from the storage.
     *
     * @param key    a unique key
     * @param object data
     */
    void put(@NonNull String key, @Nullable Object object);

    /**
     * Retrieve the stored value for the provided key.
     * <br>
     * It will return null, if the key isn't available.
     *
     * @param key the requested key
     * @return the requested value or {@code null}
     */
    @Nullable
    String get(@NonNull String key);

    /**
     * Retrieve the stored value for the provided key.
     * <br>
     * It will return null, if the key isn't available.
     *
     * @param key the requested key
     * @return the requested object or {@code null}
     */
    @Nullable
    <E> E get(@NonNull String key, @NonNull Class<E> clazz);

    /**
     * Remove the stored value for the provided key.
     *
     * @param key the requested key
     */
    void remove(@NonNull String key);

    /**
     * Clear everything from storage.
     */
    void clear();

}