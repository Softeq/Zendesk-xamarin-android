package zendesk.core;

import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.Gson;
import com.zendesk.util.StringUtils;

/**
 * Implementation of {@link BaseStorage} using Android's {@link SharedPreferences} as
 * layer of persistence and {@link Gson} for serializing/deserializing objects.
 */
class SharedPreferencesStorage implements BaseStorage {

    private final SharedPreferences sharedPreferences;
    private final Serializer serializer;

    SharedPreferencesStorage(SharedPreferences sharedPreferences, Serializer serializer) {
        this.sharedPreferences = sharedPreferences;
        this.serializer = serializer;
    }

    @Override
    public void put(@NonNull String key, @Nullable String value) {
        if (StringUtils.hasLength(key)) {
            sharedPreferences
                    .edit()
                    .putString(key, value)
                    .apply();
        }
    }

    @Override
    public void put(@NonNull String key, @Nullable Object object) {
        if (StringUtils.hasLength(key)) {
            String json = null;
            if (object != null) {
                json = serializer.serialize(object);
            }
            put(key, json);
        }
    }

    @Override
    @Nullable
    public String get(@NonNull String key) {
        return sharedPreferences.getString(key, null);
    }


    @Override
    @Nullable
    public <E> E get(@NonNull String key, @NonNull Class<E> clazz) {
        return serializer.deserialize(get(key), clazz);
    }
    
    long getLong(@NonNull String key) {
        return sharedPreferences.getLong(key, 0L);
    }

    @Override
    public void remove(@NonNull String key) {
        if (StringUtils.hasLength(key)) {
            sharedPreferences.edit().remove(key).apply();
        }
    }

    @Override
    public void clear() {
        sharedPreferences.edit().clear().apply();
    }
}
