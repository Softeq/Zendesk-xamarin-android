package zendesk.core;

import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

import java.util.Locale;

import static zendesk.core.Constants.AUTHORIZATION_BEARER_FORMAT;


class ZendeskIdentityManager implements IdentityManager {

    private static final String LOG_TAG = "ZendeskIdentityManager";
    private final IdentityStorage identityStorage;

    /**
     * Create an instance of {@link IdentityManager}
     *
     * @param identityStorage an instance of {@link IdentityStorage}
     */
    ZendeskIdentityManager(IdentityStorage identityStorage) {
        this.identityStorage = identityStorage;
    }

    @Override
    public boolean identityIsDifferent(Identity identity) {
        final Identity currentIdentity = identityStorage.getIdentity();
        return currentIdentity == null || identity == null || !currentIdentity.equals(identity);
    }

    @Override
    public Identity updateAndPersistIdentity(Identity newIdentity) {

        final Identity currentIdentity = identityStorage.getIdentity();

        if (currentIdentity == null) {
            Logger.d(LOG_TAG, "No previous identity set, storing identity");
            identityStorage.storeIdentity(newIdentity);
            return newIdentity;
        }

        if (newIdentity != null && identityIsDifferent(newIdentity)) {
            Logger.d(LOG_TAG, "Identity has changed, storing new identity");

            identityStorage.storeIdentity(newIdentity);
            return newIdentity;
        }
        return currentIdentity;
    }

    @Override
    public String getSdkGuid() {
        String uuid = identityStorage.getUuid();
        if (StringUtils.isEmpty(uuid)) {
            return identityStorage.updateSdkGuid();
        } else {
            return uuid;
        }
    }

    @Override
    public String getStoredAccessTokenAsBearerToken() {
        AccessToken accessToken = identityStorage.getStoredAccessToken();

        if (accessToken != null) {
            return String.format(Locale.US, AUTHORIZATION_BEARER_FORMAT, accessToken.getAccessToken());
        } else {
            Logger.w(LOG_TAG,
                    "There is no stored access token, have you initialised an identity and requested an access token?");
            return null;
        }
    }

    @Override
    @Nullable
    public Identity getIdentity() {
        Identity storedIdentity = identityStorage.getIdentity();
        Identity exposedIdentity;
        if (storedIdentity instanceof AnonymousIdentity) {
            AnonymousIdentity anonIdentity = (AnonymousIdentity) storedIdentity;
            anonIdentity.setSdkGuid(getSdkGuid());
            exposedIdentity = anonIdentity;
        } else {
            exposedIdentity = storedIdentity;
        }
        return exposedIdentity;
    }


    @Override
    public String getBlipsUuid() {
        String blipsUuid = identityStorage.getBlipsUuid();
        if (StringUtils.isEmpty(blipsUuid)) {
            return identityStorage.updateBlipsUuid();
        } else {
            return blipsUuid;
        }
    }

    @Override
    public void storeAccessToken(AccessToken accessToken) {
        if (accessToken == null) {
            Logger.w(LOG_TAG, "Access Token object was null, cannot store.");
            return;
        }

        if (!StringUtils.isEmpty(accessToken.getAccessToken())) {
            identityStorage.storeAccessToken(accessToken);
        } else {
            Logger.w(LOG_TAG, "Access token String was null or empty, cannot store.");
        }

        String userId = accessToken.getUserId();
        if (StringUtils.isNumeric(userId)) {
            identityStorage.storeUserId(Long.valueOf(userId));
        } else {
            Logger.w(LOG_TAG, "User ID String was null or empty, cannot store.");
        }
    }

    @Override
    public Long getUserId() {
        return identityStorage.getUserId();
    }
}
