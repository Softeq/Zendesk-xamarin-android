package zendesk.core;

/**
 * Defines the different groups of blips which can be sent. Intended for use as a parameter in
 * methods of {@link BlipsProvider}, for determining whether or not the blip should be sent or its
 * group has been disabled.
 */
public enum BlipsGroup {

    /**
     * These blips are required to make something in Zendesk function, or they provide critical information.
     */
    REQUIRED,

    /**
     * These blips represent actions or behaviours exhibited by the user.
     */
    BEHAVIOURAL,

    /**
     * These blips are required for the Pathfinder app to function.
     */
    PATHFINDER

}
