package zendesk.core;

import com.google.gson.annotations.SerializedName;

import java.util.Date;

/**
 * This model contains the server-driven core SDK specific configurations
 * that can affect how the SDK behaves.
 */
public class CoreSettings implements Settings {

    private AuthenticationType authentication;
    @SerializedName("updated_at")
    private Date updatedAt;

    private String identifier;
    @SerializedName("brand_id")
    private String brandId;

    CoreSettings(Date updatedAt, AuthenticationType authentication) {
        this.updatedAt = updatedAt;
        this.authentication = authentication;
    }

    /**
     * Returns the authentication type enabled for the App configuration
     * <p>
     * Can be one of the following two values:
     * <ul>
     * <li>jwt</li>
     * <li>anonymous</li>
     * </ul>
     *
     * @return the authentication type for the app configuration
     */
    public AuthenticationType getAuthentication() {
        return authentication;
    }

    /**
     * Returns when the configuration was last updated
     * <p>
     * This date is deserialised from a UTC timestamp but the returned Date will be in the
     * device's local time.
     * </p>
     *
     * @return when the configuration was last updated
     */
    Date getUpdatedAt() {
        if (updatedAt != null) {
            return new Date(updatedAt.getTime());
        } else {
            return new Date(0);
        }
    }

}
