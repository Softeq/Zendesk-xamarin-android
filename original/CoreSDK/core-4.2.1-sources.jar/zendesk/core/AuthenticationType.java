package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;


/**
 * Enum to track the authentication type for a given app configuration
 */
public enum AuthenticationType {

    @SerializedName("jwt")
    JWT("jwt"),

    @SerializedName("anonymous")
    ANONYMOUS("anonymous");

    private final String authenticationType;

    AuthenticationType(String authenticationType) {
        this.authenticationType = authenticationType;
    }

    /**
     * Get an authentication type based on a String value passed
     *
     * @param authenticationType String of the authentication type
     * @return type of authentication enum based on value passed
     */
    @Nullable
    static AuthenticationType getAuthType(String authenticationType) {

        if (JWT.authenticationType.equals(authenticationType)) {
            return JWT;
        } else if (ANONYMOUS.authenticationType.equals(authenticationType)) {
            return ANONYMOUS;
        }

        return null;
    }

    /**
     * Gets the authentication type as a lowercase String
     *
     * @return the authentication type as a lowercase String
     */
    @NonNull
    String getAuthenticationType() {
        return this.authenticationType;
    }

}
