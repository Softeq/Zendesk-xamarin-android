package zendesk.core;

/**
 * Interface to indicate that an implementer is aware of changes to network state
 */
public interface NetworkAware {

    /**
     * Called when network connectivity is available
     */
    void onNetworkAvailable();

    /**
     * Called when network connectivity is unavailable.
     */
    void onNetworkUnavailable();
}
