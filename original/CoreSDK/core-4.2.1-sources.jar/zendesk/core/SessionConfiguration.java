package zendesk.core;

import java.util.Locale;

class SessionConfiguration {

    private Identity identity;
    private Locale locale;

    private SessionConfiguration(Builder builder) {
        this.identity = builder.identity;
        this.locale = builder.locale;
    }

    Identity getIdentity() {
        return identity;
    }

    Builder newBuilder() {
        return new Builder(this);
    }

    Locale getLocale() {
        return locale;
    }

    static class Builder {
        private Identity identity = new Identity() {
        }; //new AnonymousIdentity.Builder().build();
        private Locale locale = Locale.getDefault();

        private Builder(SessionConfiguration configuration) {
            this.identity = configuration.getIdentity();
        }

        Builder() {
        }

        Builder setIdentity(Identity identity) {
            this.identity = identity;
            return this;
        }

        Builder setLocale(Locale locale) {
            this.locale = locale;
            return this;
        }

        public SessionConfiguration build() {
            return new SessionConfiguration(this);
        }
    }

}
