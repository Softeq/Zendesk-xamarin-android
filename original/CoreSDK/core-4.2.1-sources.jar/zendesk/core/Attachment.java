package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * This is a model class for an Attachment object.
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/core/attachments">Attachments</a>
 */
@SuppressWarnings({"unused"})
class Attachment {

    private Long id;
    private String url;
    private String fileName;
    private String contentUrl;
    private String mappedContentUrl;
    private String contentType;
    private Long size;
    private List<Attachment> thumbnails;

    /**
     * Gets the API URL of the attachment
     *
     * @return the API URL of the attachment
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the ID of the attachment
     *
     * @return the ID of the attachment
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the file name of the attachment
     *
     * @return the file name of the attachment
     */
    @Nullable
    public String getFileName() {
        return fileName;
    }

    /**
     * Gets the URL at which the attachment can be downloaded
     *
     * @return the URL at which the attachment can be downloaded
     */
    @Nullable
    public String getContentUrl() {
        return contentUrl;
    }

    /**
     * Gets the content type of the attachment, e.g. image/png
     *
     * @return the content type of the attachment, e.g. image/png
     */
    @Nullable
    public String getContentType() {
        return contentType;
    }

    /**
     * Gets the size of the attachment in bytes
     *
     * @return the size of the attachment in bytes
     */
    public Long getSize() {
        return size;
    }

    /**
     * Gets the thumbnails of the attachment
     *
     * @return the thumbnails of the attachment
     */
    @NonNull
    public List<Attachment> getThumbnails() {
        return CollectionUtils.copyOf(thumbnails);
    }
}