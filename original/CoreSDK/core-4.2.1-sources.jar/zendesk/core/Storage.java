package zendesk.core;

/**
 * Interface for accessing various forms of storage.
 */
interface Storage {

    /**
     * Retrieves the current instance of {@link SessionStorage}.
     *
     * @return the session storage.
     */
    SessionStorage getSessionStorage();

    /**
     * Clears {@link SessionStorage} and {@link SettingsStorage}, but not {@link CoreSettingsStorage}.
     */
    void clear();

    /**
     * Tells whether the given Zendesk instance and SDK app details are different to the stored
     * configuration. This is required when initialising the SDK to know whether it's a
     * re-initialisation of an existing, stored configuration, or initialising a new configuration,
     * which requires that the old one be wiped from storage.
     *
     * @return true if any of the given parameters differ from the stored configuration, false if
     * the configurations are the same.
     */
    boolean hasSdkConfigChanged(ApplicationConfiguration appConfig);

    /**
     * Generates and stores a hash from the given Zendesk instance and SDK app details.
     *
     * @param appConfig the URL,AppId and OAuth Client for the Zendesk instance.
     */
    void storeSdkHash(ApplicationConfiguration appConfig);

}
