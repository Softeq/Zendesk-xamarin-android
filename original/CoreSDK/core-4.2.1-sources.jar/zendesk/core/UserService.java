package zendesk.core;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;

/**
 * Defines the operations that can be carried out on the User.
 */
interface UserService {

    /**
     * Add tags to the current user.
     *
     * @param userTagRequest An object, containing a list of tags
     * @return a call which will be enqueued or executed by the provider
     */
    @POST("/api/mobile/user_tags.json")
    Call<UserResponse> addTags(
            @Body UserTagRequest userTagRequest
    );

    /**
     * Delete tags from the current user.
     *
     * @param tags List of tags as a comma separated string
     * @return a call which will be enqueued or executed by the provider
     */
    @DELETE("/api/mobile/user_tags/destroy_many.json")
    Call<UserResponse> deleteTags(
            @Query("tags") String tags
    );

    /**
     * Get user field definitions.
     *
     * @return a call which will be enqueued or executed by the provider
     */
    @GET("/api/mobile/user_fields.json")
    Call<UserFieldResponse> getUserFields();

    /**
     * Set user fields.
     *
     * @param userFieldRequest Model that represents fields that should be set
     * @return a call which will be enqueued or executed by the provider
     */
    @PUT("/api/mobile/users/me.json")
    Call<UserResponse> setUserFields(
            @Body UserFieldRequest userFieldRequest
    );

    /**
     * Get information about the logged in user.
     *
     * @return a call which will be enqueued or executed by the provider
     */
    @GET("/api/mobile/users/me.json")
    Call<UserResponse> getUser();

}