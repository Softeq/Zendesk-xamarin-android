package zendesk.core;

import androidx.annotation.Nullable;

/**
 * This is a class model for a response for adding tags to an user. This object
 * will be created by {@link UserProvider}
 */
@SuppressWarnings("unused")
class UserResponse {

    private User user;

    /**
     * Get the updated user.
     *
     * @return The updated user
     */
    @Nullable
    User getUser() {
        return user;
    }
}
