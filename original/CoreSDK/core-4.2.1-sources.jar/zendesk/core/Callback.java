package zendesk.core;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Simple Callback used to deliver results asynchronously.
 *
 * @param <E> The result type.
 */
public abstract class Callback<E> {

    private final AtomicBoolean canceled = new AtomicBoolean(false);

    public Callback(){
        // Intentionally empty
    }

    /**
     * Cancel this callback. {@link #success(Object)} won't be called.
     */
    public void cancel(){
        this.canceled.set(true);
    }

    public void internalSuccess(final E result){
        if(!canceled.get()){
            new Handler(Looper.getMainLooper()).post(() -> Callback.this.success(result));
        }
    }

    /**
     * Method used to deliver results.
     * <p>
     *     Will be invoked on the main thread.
     * </p>
     *
     * @param result The result.
     */
    public abstract void success(E result);
}
