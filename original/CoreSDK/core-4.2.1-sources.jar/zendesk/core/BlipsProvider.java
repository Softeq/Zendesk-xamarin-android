package zendesk.core;

import androidx.annotation.NonNull;

/**
 * A Provider for tracking user actions.
 */
public interface BlipsProvider {

    /**
     * Track a user action
     *
     * @param userAction the userAction which is to be tracked in the Blip
     * @param blipsGroup the group (or type) of the blip
     */
    void sendBlip(@NonNull UserAction userAction, @NonNull BlipsGroup blipsGroup);

    /**
     * Track a page view.
     *
     * @param pageView   the pageView which is to be tracked in the Blip
     * @param blipsGroup the group (or type) of the blip
     */
    void sendBlip(@NonNull PageView pageView, @NonNull BlipsGroup blipsGroup);
}
