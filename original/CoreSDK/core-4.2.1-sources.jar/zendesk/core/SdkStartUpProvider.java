package zendesk.core;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import androidx.annotation.RestrictTo;

import com.zendesk.util.StringUtils;

/**
 * Hidden ContentProvider superclass that can be extended by SDKs to perform actions that
 * are needed at app startup.
 * <p>
 * Any subclasses needs to be registered as a content provider in the manifest of any SDK's that use it.
 * <p><b>THE AUTHORITIES MUST BE UNIQUE FOR EVERY APP THAT USES THE SDK. IT MUST START WITH ${applicationId} TO
 * PREVENT CONFLICTS</b></p>
 * <p>
 * <provider
 * android:name="zendesk.support.SupportSDKStartUpProvider"
 * android:authorities="${applicationId}.zendesk.support.SupportSDKStartUpProvider"
 * android:enabled="true"
 * android:exported="false"/>
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public abstract class SdkStartUpProvider extends ContentProvider {

    @Override
    public final int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public final String getType(Uri uri) {
        return StringUtils.EMPTY_STRING;
    }

    @Override
    public final Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public final boolean onCreate() {
        onStartUp(getContext());
        return true;
    }

    @Override
    public final Cursor query(Uri uri, String[] projection, String selection,
                              String[] selectionArgs, String sortOrder) {
        return new MatrixCursor(new String[0], 0);
    }

    @Override
    public final int update(Uri uri, ContentValues values, String selection,
                            String[] selectionArgs) {
        return 0;
    }

    /**
     * Perform any SDK startup actions here. DO NOT PERFORM ANY LONG OPERATIONS HERE (DISK ACCESS, NETWORK), this wil
     * slow down
     * the integrator app startup time.
     *
     * @param context the content provider context.
     */
    protected abstract void onStartUp(Context context);
}
