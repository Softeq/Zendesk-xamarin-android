package zendesk.core;

public class UrlHelper {

    public static boolean isGuideRequest(String url) {
        return (url.contains("/api/v2/help_center")
                || url.contains("/hc/api")
                || url.contains("/api/mobile/help_center"));
    }

    // Vote related call are treated differently for them to work - they need to be intercepted
    public static boolean isVoteRequest(String url) {
        return (url.contains("/up.json")
                || url.contains("/down.json")
                || url.contains("/api/v2/help_center/votes/"));
    }
}
