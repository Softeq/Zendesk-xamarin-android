package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Map;

public class UserAction {

    /**
     * The name and version of the SDK sending the Blip
     */
    private String version;

    /**
     * The channel of the SDK/module sending the blip
     */
    private String channel;

    /**
     * The category that will be sent in the user action for the blip.
     */
    private String category;

    /**
     * The action that will be sent in the user action for the blip.
     */
    private String action;

    /**
     * The label that will be sent in the user action for the blip.
     */
    private String label;

    /**
     * The value that will be sent in the user action for the blip.
     */
    private Map<String, Object> value;

    public UserAction(@NonNull String version, @NonNull String channel, @NonNull String category,
                      @NonNull String action) {
        this.version = version;
        this.channel = channel;
        this.category = category;
        this.action = action;
    }

    public UserAction(@NonNull String version, @NonNull String channel, @NonNull String category,
                      @NonNull String action, @Nullable String label, @Nullable Map<String, Object> value) {
        this.version = version;
        this.channel = channel;
        this.category = category;
        this.action = action;
        this.label = label;
        this.value = value;
    }

    public String getVersion() {
        return version;
    }

    public String getChannel() {
        return channel;
    }

    public String getCategory() {
        return category;
    }

    public String getAction() {
        return action;
    }

    public String getLabel() {
        return label;
    }

    public Map<String, Object> getValue() {
        return value;
    }
}
