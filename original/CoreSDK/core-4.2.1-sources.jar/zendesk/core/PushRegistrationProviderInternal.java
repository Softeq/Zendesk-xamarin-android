package zendesk.core;

/**
 * Interface providing a synchronous method for registering for push notifications. This is used
 * only by the {@link ZendeskPushInterceptor} for executing a pending {@link PushRegistrationRequest}.
 * There is no known reason at this time to make this method publicly accessible, so it has been
 * split from the public-facing {@link PushRegistrationProvider}.
 *
 * It shares a concrete implementation {@link ZendeskPushRegistrationProvider} with the public
 * interface {@link PushRegistrationProvider}.
 */
interface PushRegistrationProviderInternal {

    /**
     * Synchronous method to register the given {@link PushRegistrationRequest} with the Zendesk back-end.
     *
     * @param request the {@link PushRegistrationRequest} to register with Zendesk.
     * @return the registered push device identifier.
     */
    String sendPushRegistrationRequest(PushRegistrationRequest request);
}
