package zendesk.core;

import android.content.Context;

import com.zendesk.util.LocaleUtil;
import com.zendesk.util.StringUtils;

import java.io.IOException;
import java.util.Locale;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * This interceptor will add an accept language header if one hasn't been added already
 */
class AcceptLanguageHeaderInterceptor implements Interceptor {

    private Context context;

    /**
     * Creates an instance of the interceptor
     *
     * @param context The locale to use for the accept language header
     */
    public AcceptLanguageHeaderInterceptor(Context context) {
        this.context = context;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request request = chain.request();
        Locale locale = DeviceInfo.getCurrentLocale(context);
        if (StringUtils.isEmpty(request.header(Constants.ACCEPT_LANGUAGE)) && locale != null) {
            Request acceptLanguageHeaders = request
                    .newBuilder()
                    .addHeader(Constants.ACCEPT_LANGUAGE, LocaleUtil.toLanguageTag(locale))
                    .build();

            return chain.proceed(acceptLanguageHeaders);
        } else {
            return chain.proceed(request);
        }
    }
}
