package zendesk.core;

import com.zendesk.util.StringUtils;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

/**
 * This request interceptor will add oauthId header to all requests that are made through the means
 * of a {@link retrofit2.Retrofit}
 * <p>
 * <ul>
 * <li>Adds an oauthId header with value of the oauthId to all requests</li>
 * </ul>
 */
class ZendeskOauthIdHeaderInterceptor implements Interceptor {

    private final String oauthId;

    public ZendeskOauthIdHeaderInterceptor(String oauthId) {
        this.oauthId = oauthId;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request.Builder requestHeadersBuilder = chain.request().newBuilder();

        if (StringUtils.hasLength(oauthId)) {
            requestHeadersBuilder.addHeader(Constants.CLIENT_IDENTIFIER_HEADER, oauthId);
        }

        return chain.proceed(requestHeadersBuilder.build());
    }
}
