package zendesk.core;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.google.gson.JsonElement;
import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.RetrofitZendeskCallbackAdapter;
import com.zendesk.service.ZendeskCallback;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import retrofit2.Response;

/**
 * This provider will allow you to download {@link SdkSettings}
 * from your Zendesk.
 * <p>
 * This provider requires that you have
 * {@link Zendesk#init(Context, String, String, String)}  correctly initialised Zendesk}.
 * </p>
 * <p>
 * After calls to {@link } the provider will attempt to persist the {@link SdkSettings}
 * using a {@link SettingsStorage}.
 * </p>
 */
class ZendeskSettingsProvider implements SettingsProvider, SdkSettingsProviderInternal {

    private static final String LOG_TAG = "ZendeskSdkSettingsProvi";
    static final int SDK_SETTINGS_MAX_AGE_HOURS = 1;

    private final SdkSettingsService settingsService;
    private final SettingsStorage settingsStorage;
    private final CoreSettingsStorage coreSettingsStorage;
    private final ActionHandlerRegistry actionHandlerRegistry;
    private final Serializer serializer;
    private final ZendeskLocaleConverter zendeskLocaleConverter;
    private final String applicationId;
    private final Context context;

    /**
     * Creates an instance of this provider.
     */
    ZendeskSettingsProvider(
            SdkSettingsService settingsService,
            SettingsStorage settingsStorage,
            CoreSettingsStorage coreSettingsStorage,
            ActionHandlerRegistry actionHandlerRegistry,
            Serializer serializer,
            ZendeskLocaleConverter zendeskLocaleConverter,
            String applicationId,
            Context context) {
        this.settingsService = settingsService;
        this.settingsStorage = settingsStorage;
        this.coreSettingsStorage = coreSettingsStorage;
        this.actionHandlerRegistry = actionHandlerRegistry;
        this.serializer = serializer;
        this.zendeskLocaleConverter = zendeskLocaleConverter;
        this.applicationId = applicationId;
        this.context = context;
    }

    @Override
    public void getCoreSettings(@Nullable final ZendeskCallback<CoreSettings> callback) {
        if (settingsStorage.areSettingsUpToDate(SDK_SETTINGS_MAX_AGE_HOURS, TimeUnit.HOURS)) {
            if (callback != null) {
                callback.onSuccess(coreSettingsStorage.getCoreSettings());
            }
        } else {
            Locale locale = DeviceInfo.getCurrentLocale(context);
            getSettingsInternal(locale, new ZendeskCallback<Map<String, JsonElement>>() {
                @Override
                public void onSuccess(Map<String, JsonElement> settings) {
                    actionHandlerRegistry.updateSettings(settings);
                    settingsStorage.storeRawSettings(settings);
                    if (callback != null) {
                        CoreSettings coreSettings = extractCoreSettings(settings);
                        callback.onSuccess(coreSettings);
                    }
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    if (callback != null) {
                        callback.onSuccess(coreSettingsStorage.getCoreSettings());
                    }
                }
            });
        }
    }

    /**
     * This method is not exposed to consumers of Core SDK, as {@link SdkSettingsProviderInternal},
     * which defines this method, {@link SdkSettingsProviderInternal#getCoreSettings()}, is
     * package-private.
     * <p>
     * The method is used only by {@link ZendeskSettingsInterceptor}, to request Zendesk settings
     * in a synchronous way.
     *
     * @return the CoreSettings object.
     */
    @Override
    public CoreSettings getCoreSettings() {
        if (settingsStorage.areSettingsUpToDate(SDK_SETTINGS_MAX_AGE_HOURS, TimeUnit.HOURS)) {
            return coreSettingsStorage.getCoreSettings();
        } else {
            Map<String, JsonElement> settings = getSettingsInternal(DeviceInfo.getCurrentLocale(context));
            if (settings.isEmpty()) {
                return new CoreSettings(new Date(0), null);
            }
            actionHandlerRegistry.updateSettings(settings);
            settingsStorage.storeRawSettings(settings);
            return extractCoreSettings(settings);
        }
    }

    @Override
    public <E extends Settings> void getSettingsForSdk(@NonNull final String key,
                                                       @NonNull final Class<E> sdkSettingsClass,
                                                       final ZendeskCallback<SettingsPack<E>> callback) {
        if (settingsStorage.areSettingsUpToDate(SDK_SETTINGS_MAX_AGE_HOURS, TimeUnit.HOURS)) {
            if (callback != null) {
                SettingsPack<E> settingsPack = new SettingsPack<>(
                        coreSettingsStorage.getCoreSettings(),
                        settingsStorage.getSettings(key, sdkSettingsClass));

                callback.onSuccess(settingsPack);
                actionHandlerRegistry.updateSettings(settingsStorage.getRawSettings());
            }
        } else {
            getSettingsInternal(DeviceInfo.getCurrentLocale(context), new ZendeskCallback<Map<String, JsonElement>>() {
                @Override
                public void onSuccess(Map<String, JsonElement> settings) {

                    actionHandlerRegistry.updateSettings(settings);
                    settingsStorage.storeRawSettings(settings);

                    if (callback != null) {
                        SettingsPack<E> settingsPack = new SettingsPack<>(
                                extractCoreSettings(settings),
                                serializer.deserialize(settings.get(key), sdkSettingsClass));
                        callback.onSuccess(settingsPack);
                    }
                }

                @Override
                public void onError(ErrorResponse errorResponse) {
                    if (callback == null) {
                        return;
                    }
                    if (settingsStorage.hasStoredSettings()) {
                        SettingsPack<E> settingsPack = new SettingsPack<>(
                                coreSettingsStorage.getCoreSettings(),
                                settingsStorage.getSettings(key, sdkSettingsClass));
                        callback.onSuccess(settingsPack);
                    } else {
                        callback.onError(errorResponse);
                    }
                }
            });
        }
    }

    private void getSettingsInternal(Locale locale, ZendeskCallback<Map<String, JsonElement>> callback) {
        final RetrofitZendeskCallbackAdapter<Map<String, JsonElement>, Map<String, JsonElement>> callbackAdapter
                = new RetrofitZendeskCallbackAdapter<>(callback);

        String localeString = zendeskLocaleConverter.toHelpCenterLocaleString(locale);
        settingsService
                .getSettings(localeString, applicationId)
                .enqueue(callbackAdapter);
    }

    @NonNull
    private Map<String, JsonElement> getSettingsInternal(@Nullable Locale locale) {
        try {
            final Response<Map<String, JsonElement>> execute =
                    settingsService.getSettings(
                            zendeskLocaleConverter.toHelpCenterLocaleString(locale),
                            applicationId)
                        .execute();

            if (execute.body() != null) {
                return new HashMap<>(execute.body());
            } else {
                return new HashMap<>(0);
            }

        } catch (IOException ex) {
            Logger.e(LOG_TAG, "Settings retrieval failed, returning empty map.");
            return new HashMap<>(0);
        }
    }

    @VisibleForTesting
    @NonNull
    @SuppressWarnings("ConstantConditions")
    CoreSettings extractCoreSettings(@Nullable Map<String, JsonElement> rawSettings) {
        JsonElement jsonElement = (rawSettings == null) ? null
                : rawSettings.get(ZendeskCoreSettingsStorage.CORE_KEY);

        CoreSettings coreSettings = serializer.deserialize(jsonElement, CoreSettings.class);

        if (coreSettings != null) {
            return coreSettings;
        } else {
            return ZendeskCoreSettingsStorage.DEFAULT_CORE_SETTINGS;
        }
    }

    @Override
    public BlipsSettings getBlipsSettings() {
        return coreSettingsStorage.getBlipsSettings();
    }
}
