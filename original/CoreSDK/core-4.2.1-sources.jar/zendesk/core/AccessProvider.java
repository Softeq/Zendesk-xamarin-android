package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import retrofit2.Response;

/**
 * A Provider which is used to download access tokens and user IDs.
 *
 * The provider does not perform any storage of the retrieved tokens.
 *
 * <p>
 * This provider shouldn't be exposed.
 * </p>
 */
interface AccessProvider {

    /**
     * Calls an {@link AccessService} and loads an authentication token for a {@link AnonymousIdentity}.
     *
     * @param identity A {@link AnonymousIdentity}
     * @return a {@link Response<AuthenticationResponse>} containing the {@link AccessToken} for the authenticated
     * user.
     */
    @Nullable
    Response<AuthenticationResponse> getAuthTokenViaAnonymous(@NonNull AnonymousIdentity identity);

    String NO_JWT_ERROR_MESSAGE = "The jwt user identifier is null or empty. We cannot proceed to get an access token";

    /**
     * Calls an {@link AccessService} and loads a authentication token for a {@link JwtIdentity}.
     *
     * @param jwtIdentity A {@link JwtIdentity}
     * @return a {@link Response<AuthenticationResponse>} containing the {@link AccessToken} for the authenticated
     * user.
     */
    @Nullable
    Response<AuthenticationResponse> getAuthTokenViaJwt(@NonNull JwtIdentity jwtIdentity);

}
