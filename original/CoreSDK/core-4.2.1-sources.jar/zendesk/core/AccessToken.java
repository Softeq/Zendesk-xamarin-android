package zendesk.core;

import com.google.gson.annotations.SerializedName;

/**
 * Access token representing a token that authorizes the user in Zendesk service API.
 */
@SuppressWarnings("unused")
class AccessToken {

    private String accessToken;

    @SerializedName("user_id")
    private String userId;

    AccessToken() {
        // Intentionally empty.
    }

    AccessToken(String accessToken, String userId) {
        this.accessToken = accessToken;
        this.userId = userId;
    }

    /**
     * OAuth access token returned as a response to the authentication requests
     *
     * @return String OAuth access token
     */
    String getAccessToken() {
        return accessToken;
    }

    /**
     * Gets the user ID used to identify a user in Zendesk. This should be sent as "user_id" in
     * every blip.
     *
     * @return the user ID
     */
    public String getUserId() {
        return userId;
    }

    @Override
    @SuppressWarnings("SimplifiableIfStatement")
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AccessToken that = (AccessToken) o;

        if (accessToken != null ? !accessToken.equals(that.accessToken) : that.accessToken != null) {
            return false;
        }
        return userId != null ? userId.equals(that.userId) : that.userId == null;

    }

    @Override
    public int hashCode() {
        int result = accessToken != null ? accessToken.hashCode() : 0;
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        return result;
    }
}
