package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Map;

/**
 * Model class for BlipsPageView used in {@link BlipsProvider#sendBlip(PageView, BlipsGroup)}.
 */
public class PageView {

    /**
     * The name and version of the SDK sending the Blip
     */
    private String version;

    /**
     * The channel of the SDK/module sending the blip
     */
    private String channel;

    /**
     * The URL for the page that was viewed
     */
    private String url;

    /**
     * The navigator language that will be sent in the page view for the blip.
     */
    private String navigatorLanguage;

    /**
     * The page title that will be sent in the page view for the blip.
     */
    private String pageTitle;

    /**
     * The page id that will be send in the page view for the blip
     */
    private Long pageId;

    /**
     * The actual locale of the page, as determined from the locale property of an Article
     * object.
     */
    private String pageLocale;

    /**
     * The value that will be sent in the user action for the blip.
     */
    private Map<String, Object> value;

    public PageView(@NonNull String version, @NonNull String channel, @NonNull String url,
                    @NonNull String navigatorLanguage, @NonNull String pageTitle,
                    @NonNull Long pageId, @NonNull String pageLocale) {
        this.version = version;
        this.channel = channel;
        this.url = url;
        this.navigatorLanguage = navigatorLanguage;
        this.pageTitle = pageTitle;
        this.pageId = pageId;
        this.pageLocale = pageLocale;
    }

    public PageView(@NonNull String version, @NonNull String channel, @NonNull String url,
                    @NonNull String navigatorLanguage, @NonNull String pageTitle,
                    @NonNull Long pageId, @NonNull String pageLocale,
                    @Nullable Map<String, Object> value) {
        this(version, channel, url, navigatorLanguage, pageTitle, pageId, pageLocale);
        this.value = value;
    }

    public String getVersion() {
        return version;
    }

    public String getChannel() {
        return channel;
    }

    public String getUrl() {
        return url;
    }

    public String getNavigatorLanguage() {
        return navigatorLanguage;
    }

    public String getPageTitle() {
        return pageTitle;
    }

    public Long getPageId() {
        return pageId;
    }

    public String getPageLocale() {
        return pageLocale;
    }

    public Map<String, Object> getValue() {
        return value;
    }
}
