package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

import java.util.UUID;

import static zendesk.core.AuthenticationType.ANONYMOUS;

/**
 * Provides storage of an Access token. Default implementation of {@link IdentityStorage}
 * using {@link BaseStorage} for persistence.
 */
class ZendeskIdentityStorage implements IdentityStorage {

    static final String LOG_TAG = "ZendeskIdentityStorage";

    static final String TOKEN_KEY = "stored_token";
    static final String IDENTITY_KEY = "zendesk-identity";
    static final String IDENTITY_TYPE_KEY = "zendesk-identity-type";
    static final String UUID_KEY = "uuid";
    static final String USER_ID_KEY = "user_id";

    static final String BLIPS_UUID_KEY = "blips_buid";


    private final BaseStorage identityStorage;

    /**
     * Initialises the ZendeskIdentityStorage.
     *
     * @param identityStorage an instance of BaseStorage
     */
    ZendeskIdentityStorage(BaseStorage identityStorage) {
        this.identityStorage = identityStorage;
    }

    @Override
    public void storeAccessToken(AccessToken accessToken) {
        if (accessToken != null) {
            identityStorage.put(TOKEN_KEY, accessToken);
        }
    }

    @Override
    public AccessToken getStoredAccessToken() {
        return identityStorage.get(TOKEN_KEY, AccessToken.class);
    }

    @Override
    public void storeUserId(Long userId) {
        if (userId != null) {
            identityStorage.put(USER_ID_KEY, userId);
        }
    }

    @Override
    public Long getUserId() {
        return identityStorage.get(USER_ID_KEY, Long.class);
    }

    @NonNull
    @Override
    public String getUuid() {
        Logger.d(LOG_TAG, "Fetching UUID from preferences store");

        final String guid = identityStorage.get(UUID_KEY);

        return (StringUtils.isEmpty(guid)) ? StringUtils.EMPTY_STRING : guid;
    }

    @Override
    public void storeIdentity(Identity identity) {

        if (identity == null) {
            Logger.e(LOG_TAG, "identity is null, will not store the identity");
            return;
        }

        String authenticationType = null;
        if (identity instanceof AnonymousIdentity) {
            Logger.d(LOG_TAG, "Storing anonymous identity");
            authenticationType = ANONYMOUS.getAuthenticationType();

        } else if (identity instanceof JwtIdentity) {
            Logger.d(LOG_TAG, "Storing jwt identity");
            authenticationType = AuthenticationType.JWT.getAuthenticationType();

        } else {
            Logger.e(LOG_TAG, "Unknown authentication type, identity will not be stored");
        }

        //noinspection ConstantConditions
        if (identity != null && authenticationType != null) {
            identityStorage.put(IDENTITY_KEY, identity);
            identityStorage.put(IDENTITY_TYPE_KEY, authenticationType);
        }
    }

    @Nullable
    @Override
    public Identity getIdentity() {
        Identity identity = null;
        String authType = identityStorage.get(IDENTITY_TYPE_KEY);

        if (StringUtils.hasLength(authType)) {
            AuthenticationType authenticationType = AuthenticationType.getAuthType(authType);

            if (authenticationType != null) {

                switch (authenticationType) {
                    case JWT: {
                        Logger.d(LOG_TAG, "Loading Jwt identity");
                        identity = identityStorage.get(IDENTITY_KEY, JwtIdentity.class);
                        break;
                    }
                    case ANONYMOUS: {
                        Logger.d(LOG_TAG, "Loading Anonymous identity");
                        identity = identityStorage.get(IDENTITY_KEY, AnonymousIdentity.class);
                        break;
                    }
                }

            }
        }

        return identity;
    }

    @Override
    public String updateBlipsUuid() {
        final String uuid = UUID.randomUUID().toString();
        Logger.d(LOG_TAG, "Generate new Blips BUID");
        identityStorage.put(BLIPS_UUID_KEY, uuid);
        return uuid;
    }

    @Override
    public String getBlipsUuid() {
        return identityStorage.get(BLIPS_UUID_KEY);
    }

    @Override
    public void clear() {
        identityStorage.clear();
    }

    @NonNull
    @Override
    public String updateSdkGuid() {
        //Generate the UUID, store and return
        String id = UUID.randomUUID().toString();

        storeSdkGuid(id);

        return id;
    }

    @Override
    public void storeSdkGuid(String sdkGuid) {
        Logger.d(LOG_TAG, "Storing new UUID in preference store");
        identityStorage.put(UUID_KEY, sdkGuid);
    }
}
