package zendesk.core;

/**
 * Wraps an authentication request which will contain an {@link Identity}
 * <p>
 * Created by Zendesk on 07/11/2014.
 */
@SuppressWarnings({"unused", "FieldCanBeLocal"})
class AuthenticationRequestWrapper {

    private Identity user;

    AuthenticationRequestWrapper(Identity user) {
        this.user = user;
    }
}
