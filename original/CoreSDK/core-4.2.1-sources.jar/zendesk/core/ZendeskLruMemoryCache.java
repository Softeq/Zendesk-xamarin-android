package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;
import android.util.LruCache;

class ZendeskLruMemoryCache implements MemoryCache {

    public final LruCache<String, Object> cache;

    public ZendeskLruMemoryCache() {
        this(new LruCache<String, Object>(50));
    }

    @VisibleForTesting
    ZendeskLruMemoryCache(LruCache<String, Object> cache) {
        this.cache = cache;
    }

    @Override
    @Nullable
    @SuppressWarnings("unchecked")
    public <T> T get(@NonNull String key) {
        synchronized (this) {
            return (T) cache.get(key);
        }
    }

    @Override
    @NonNull
    public <T> T getOrDefault(@NonNull String key, @NonNull T defaultData) {
        T data = get(key);
        if (data != null) {
            return data;
        } else {
            return defaultData;
        }
    }

    @Override
    public boolean contains(@NonNull String key) {
        synchronized (this) {
            return cache.get(key) != null;
        }
    }

    @Override
    public void put(@NonNull String key, @NonNull Object data) {
        synchronized (this) {
            this.cache.put(key, data);
        }
    }

    @Override
    public void remove(@NonNull String key) {
        synchronized (this) {
            this.cache.remove(key);
        }
    }

    @Override
    public void clear() {
        cache.evictAll();
    }

}
