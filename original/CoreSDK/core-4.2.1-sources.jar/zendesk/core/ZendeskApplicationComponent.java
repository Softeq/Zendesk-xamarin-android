package zendesk.core;

import javax.inject.Singleton;

import dagger.Component;

/**
 * This application component shall only contain modules which do not change for the lifecycle of
 * the application.
 * <p>
 * Created by Zendesk on 09/09/2016.
 */
@Singleton
@Component(modules = {ZendeskApplicationModule.class, ZendeskStorageModule.class, ZendeskProvidersModule.class,
        ZendeskNetworkModule.class})
interface ZendeskApplicationComponent {

    ZendeskShadow zendeskShadow();
}