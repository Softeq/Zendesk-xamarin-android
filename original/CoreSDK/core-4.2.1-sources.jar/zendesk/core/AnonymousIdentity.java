package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * <p>
 * This class models an identity which is used to identify an End User within a Zendesk instance.
 * <br>
 * Please use the {@link AnonymousIdentity.Builder} to
 * create an instance of this class. A UUID will be created if necessary and associated with
 * the identity.
 * </p>
 * <p>
 * If you don't know anything about your user please create an Identity like this:
 *
 * <pre>
 *          Identity identity = new AnonymousIdentity();
 *      </pre>
 * <p>
 * If you do know something about the user then you can use the <i>optional</i> methods in the
 * {@link AnonymousIdentity.Builder} to specify them.
 * </p>
 *
 * @see <a href="https://developer.zendesk.com/embeddables/docs/android/authentication#anonymous-access">Anonymous
 * access docs on developer.zendesk.com</a>
 */
public final class AnonymousIdentity implements Identity {

    private String sdkGuid;
    private String email;
    private String name;

    /**
     * Creates a new, empty instance of an AnonymousIdentity.
     * <p>
     * This constructor provides the most basic authentication identity, and should be used when no
     * additional information about the user is desired. To include values for name, or email address,
     * use the {@link AnonymousIdentity.Builder}.
     */
    public AnonymousIdentity() {
        // Intentionally empty.
    }

    private AnonymousIdentity(Builder builder) {
        email = builder.email;
        name = builder.name;
    }

    @SuppressWarnings("RedundantIfStatement")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        AnonymousIdentity that = (AnonymousIdentity) o;

        if (email != null ? !email.equals(that.email) : that.email != null) {
            return false;
        }

        if (name != null ? !name.equals(that.name) : that.name != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        int result = email != null ? email.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }

    /**
     * Gets the email address associated with this anonymous identity
     *
     * @return The email address or null if it was not set
     */
    @Nullable
    public String getEmail() {
        return email;
    }

    /**
     * Gets the name associated with this anonymous identity
     *
     * @return The name or null if it was not set
     */
    @Nullable
    public String getName() {
        return name;
    }

    /**
     * Gets the sdk guid associated with this anonymous identity
     *
     * @return The sdk guid
     */
    @NonNull
    public String getSdkGuid() {
        return sdkGuid;
    }

    void setSdkGuid(String sdkGuid) {
        this.sdkGuid = sdkGuid;
    }

    /**
     * This is a builder class which is used to generate a {@link Identity}
     */
    public static class Builder {

        private String email;
        private String name;

        /**
         * Creates a builder which can be used to create an anonymous identity
         */
        public Builder() {
            // Intentionally empty.
        }

        /**
         * Specify the Name to be used as part of the identity when using Anonymous Access.
         * <p>
         * This field is optional
         * </p>
         *
         * @param name String name which will be included as part of the End User profile
         * @return The Builder
         */
        public Builder withNameIdentifier(String name) {
            this.name = name;
            return this;
        }

        /**
         * Specify the Email to be used as part of the identity when using Anonymous Access
         * <p>
         * This field is optional
         * </p>
         *
         * @param email String email which will be included as part of the End User profile
         * @return The Builder
         */
        public Builder withEmailIdentifier(String email) {
            this.email = email;
            return this;
        }

        /**
         * Builds a {@link Identity} object with the
         * specified parameters.
         *
         * @return the {@link Identity}
         */
        public Identity build() {
            return new AnonymousIdentity(this);
        }
    }
}
