package zendesk.core;

/**
 * Constants required for network operations
 */
interface Constants {

    /**
     * User-Agent header key
     */
    String USER_AGENT_HEADER_KEY = "User-Agent";

    /**
     * User-Agent header value
     */
    String USER_AGENT_HEADER_TEMPLATE = "Zendesk-SDK/%s Android/%d Variant/%s";

    /**
     * Used in Use-Agent header
     */
    String VARIANT = "Core";

    /**
     * Accept header name
     */
    String ACCEPT_HEADER = "Accept";

    /**
     * Accept language header
     */
    String ACCEPT_LANGUAGE = "Accept-Language";

    /**
     * Accept header value
     */
    String APPLICATION_JSON = "application/json";

    /**
     * Text/Json Media Type
     */
    String TEXT_JSON = "txt/json";

    /**
     * Client-Identifier header name, used to identify oauth client id.
     */
    String CLIENT_IDENTIFIER_HEADER = "Client-Identifier";

    /**
     * Authorization header name
     */
    String AUTHORIZATION_HEADER = "Authorization";

    /**
     * Authorization header name value format string
     */
    String AUTHORIZATION_BEARER_FORMAT = "Bearer %s";

    /**
     * Storage key for the push device identifier.
     */
    String PUSH_DEVICE_IDENTIFIER = "pushDeviceIdentifier";

    /**
     * Storage key for the pending push registration request.
     */
    String PUSH_REGISTRATION_REQUEST = "pushRegistrationRequest";

    /**
     * Custom header name, used in traffic and performance monitoring.
     * <p>
     * The value of this header should be {@link Constants#X_ZENDESK_CLIENT_HEADER_VALUE_FORMAT}.
     */
    String X_ZENDESK_CLIENT_HEADER_NAME = "X-Zendesk-Client";

    /**
     * Format for custom header value, used in traffic and performance monitoring.
     * <p>
     * The name of the SDK sending the request (ie, the "variant", or SDK which contains the provider
     * sending the request) should be used, in lower case,
     * as the parameter in this string. For example, "mobile/android/sdk/core" or
     * "mobile/android/sdk/support".
     * <p>
     * The name of this header should be {@link Constants#X_ZENDESK_CLIENT_HEADER_NAME}.
     */
    String X_ZENDESK_CLIENT_HEADER_VALUE_FORMAT = "mobile/android/sdk/%s";

    /**
     * Custom header name, used in traffic and performance monitoring.
     * <p>
     * The value of this header should be the version name of the artifact, ie {@link BuildConfig#VERSION_NAME}.
     */
    String X_ZENDESK_CLIENT_VERSION_HEADER_NAME = "X-Zendesk-Client-Version";
}
