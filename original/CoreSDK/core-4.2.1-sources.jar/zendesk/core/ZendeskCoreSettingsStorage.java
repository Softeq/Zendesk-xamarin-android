package zendesk.core;

import androidx.annotation.NonNull;

import com.zendesk.logger.Logger;

import java.util.Date;

/**
 * Implementation of {@link CoreSettingsStorage}
 */
class ZendeskCoreSettingsStorage implements CoreSettingsStorage {

    private static final String LOG_TAG = "ZendeskCoreSettingsStorage";

    static final String CORE_KEY = "core";
    static final String BLIPS_KEY = "blips";

    static final CoreSettings DEFAULT_CORE_SETTINGS = new CoreSettings(new Date(0), null);
    static final BlipsSettings DEFAULT_BLIPS_SETTINGS = new BlipsSettings(new BlipsPermissions());

    private final SettingsStorage settingsStorage;

    /**
     * Create an instance of ZendeskCoreSettingsStorage
     *
     * @param settingsStorage an instance of {@link SettingsStorage}
     */
    ZendeskCoreSettingsStorage(SettingsStorage settingsStorage) {
        this.settingsStorage = settingsStorage;
    }

    @NonNull
    @Override
    public CoreSettings getCoreSettings() {
        CoreSettings coreSettings = settingsStorage.getSettings(CORE_KEY, CoreSettings.class);

        if (coreSettings != null) {
            return coreSettings;
        } else {
            Logger.d(LOG_TAG, "Unable to load Core SDK Settings, returning default settings.");
            return DEFAULT_CORE_SETTINGS;
        }
    }

    @NonNull
    @Override
    public BlipsSettings getBlipsSettings() {
        BlipsSettings blipsSettings = settingsStorage.getSettings(BLIPS_KEY, BlipsSettings.class);

        if (blipsSettings != null) {
            return blipsSettings;
        } else {
            Logger.d(LOG_TAG, "Unable to load blips settings, returning defaults.");
            return DEFAULT_BLIPS_SETTINGS;
        }
    }
}
