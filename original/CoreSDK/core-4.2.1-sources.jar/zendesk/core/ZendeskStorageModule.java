package zendesk.core;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import dagger.Module;
import dagger.Provides;
import java.io.File;
import java.util.Locale;
import javax.inject.Named;
import javax.inject.Singleton;
import okhttp3.Cache;

/**
 * Defines a module which provides injections for storage
 */
@Module
class ZendeskStorageModule {

    private static final int MAX_CACHE_SIZE = 20 * 1024 * 1024;

    private static final String BASE_STORAGE_SDK = "base_storage_sdk";
    private static final String BASE_STORAGE_IDENTITY = "base_storage_identity";
    private static final String BASE_STORAGE_LEGACY_IDENTITY = "base_storage_legacy_identity";
    private static final String BASE_STORAGE_LEGACY_PUSH = "base_storage_legacy_push";
    private static final String BASE_STORAGE_SETTINGS = "base_storage_settings";
    static final String BASE_STORAGE_DISK_LRU = "base_storage_disk_lru";

    private static final String CACHE_DIR = "cache_dir";
    private static final String DATA_DIR = "data_dir";
    private static final String BELVEDERE_DIR = "belvedere_dir";
    private static final String ZENDESK_DIR_NAME = "zendesk";
    private static final String STORAGE_BELVEDERE_CACHE =
            "belvedere-data-v2" + File.separator + "user" + File.separator + ZENDESK_DIR_NAME;

    private static final String STORAGE_NAME_IDENTITY = "identity";
    private static final String STORAGE_NAME_SETTINGS = "settings";
    private static final String STORAGE_NAME_ADDITIONAL_SDK = "additional_sdk";
    private static final String STORAGE_NAME_CORE_SDK = "sdk";
    private static final String STORAGE_NAME_RESPONSE_CACHE = "response_cache";
    private static final String STORAGE_NAME_MEDIA_CACHE = "media_cache";

    private static final String BASE_STORAGE_ADDITIONAL_SDK = "base_storage_additional_sdk";
    static final String GSON_SERIALIZER = "gson_serializer";

    /**
     * Used to access IdentityStorage from Support 1.x, to migrate data to 2.0.
     */
    private static final String LEGACY_IDENTITY_STORAGE_FILE_NAME = "zendesk-token";
    private static final String LEGACY_PUSH_ID_STORAGE_FILE_NAME = "zendesk-push-token";

    @Provides
    @Singleton
    @Named(CACHE_DIR)
    static File providesCacheDir(@Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context) {
        return new File(context.getCacheDir(), ZENDESK_DIR_NAME);
    }

    @Provides
    @Singleton
    @Named(DATA_DIR)
    static File providesDataDir(@Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context) {
        return new File(context.getFilesDir(), ZENDESK_DIR_NAME);
    }

    @Provides
    @Singleton
    @Named(BELVEDERE_DIR)
    static File providesBelvedereDir(@Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context) {
        return new File(context.getCacheDir(), STORAGE_BELVEDERE_CACHE);
    }

    @Provides
    @Singleton
    @Named(GSON_SERIALIZER)
    static Serializer provideSerializer(Gson gson) {
        return new GsonSerializer(gson);
    }

    @Provides
    @Singleton
    static Cache provideCache(@Named(CACHE_DIR) File file) {
        return new Cache(new File(file, storageName(STORAGE_NAME_RESPONSE_CACHE)), MAX_CACHE_SIZE);
    }

    @Provides
    @Singleton
    static MemoryCache provideMemoryCache() {
        return new ZendeskLruMemoryCache();
    }

    @Provides
    @Singleton
    @Named(BASE_STORAGE_IDENTITY)
    static BaseStorage provideIdentityBaseStorage(@Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context,
            @Named(GSON_SERIALIZER) Serializer serializer) {
        SharedPreferences identity = getSharedPrefs(context, storageName(STORAGE_NAME_IDENTITY));
        return new SharedPreferencesStorage(identity, serializer);
    }

    @Provides
    @Singleton
    @Named(BASE_STORAGE_LEGACY_IDENTITY)
    static SharedPreferencesStorage provideLegacyIdentityBaseStorage(@Named(ZendeskApplicationModule
            .APPLICATION_CONTEXT) Context context, @Named(GSON_SERIALIZER) Serializer serializer) {
        SharedPreferences legacyIdentity = getSharedPrefs(context, LEGACY_IDENTITY_STORAGE_FILE_NAME);
        return new SharedPreferencesStorage(legacyIdentity, serializer);
    }

    @Provides
    @Singleton
    @Named(BASE_STORAGE_LEGACY_PUSH)
    static SharedPreferencesStorage provideLegacyPushBaseStorage(@Named(ZendeskApplicationModule.APPLICATION_CONTEXT)
            Context context, @Named(GSON_SERIALIZER) Serializer serializer) {
        SharedPreferences legacyPush = getSharedPrefs(context, LEGACY_PUSH_ID_STORAGE_FILE_NAME);
        return new SharedPreferencesStorage(legacyPush, serializer);
    }

    @Provides
    @Singleton
    @Named(BASE_STORAGE_SETTINGS)
    static BaseStorage provideSettingsBaseStorage(@Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context,
            @Named(GSON_SERIALIZER) Serializer serializer) {
        SharedPreferences sharedPreferences = getSharedPrefs(context, storageName(STORAGE_NAME_SETTINGS));

        return new SharedPreferencesStorage(sharedPreferences, serializer);
    }

    @Provides
    @Singleton
    @Named(BASE_STORAGE_ADDITIONAL_SDK)
    static BaseStorage provideAdditionalSdkBaseStorage(@Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context
            context, @Named(GSON_SERIALIZER) Serializer serializer) {
        SharedPreferences sharedPreferences = getSharedPrefs(context, storageName(STORAGE_NAME_ADDITIONAL_SDK));

        return new SharedPreferencesStorage(sharedPreferences, serializer);
    }

    @Provides
    @Singleton
    @Named(BASE_STORAGE_SDK)
    static BaseStorage provideSdkBaseStorage(@Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context,
            @Named(GSON_SERIALIZER) Serializer serializer) {
        SharedPreferences sharedPreferences = getSharedPrefs(context, storageName(STORAGE_NAME_CORE_SDK));

        return new SharedPreferencesStorage(sharedPreferences, serializer);
    }

    @Provides
    @Singleton
    @Named(BASE_STORAGE_DISK_LRU)
    static BaseStorage providesDiskLruStorage(@Named(CACHE_DIR) File file,
            @Named(GSON_SERIALIZER) Serializer serializer) {
        return new ZendeskDiskLruCache(new File(file, storageName(STORAGE_NAME_MEDIA_CACHE)),
                serializer,
                MAX_CACHE_SIZE);
    }

    @Provides
    @Singleton
    static SettingsStorage provideSettingsStorage(@Named(BASE_STORAGE_SETTINGS) BaseStorage baseStorage) {
        return new ZendeskSettingsStorage(baseStorage);
    }

    @Provides
    @Singleton
    static IdentityStorage provideIdentityStorage(@Named(BASE_STORAGE_IDENTITY) BaseStorage baseStorage) {
        return new ZendeskIdentityStorage(baseStorage);
    }

    @Provides
    @Singleton
    static AuthenticationProvider provideAuthProvider(IdentityManager identityManager) {
        return new ZendeskAuthenticationProvider(identityManager);
    }

    @Provides
    @Singleton
    static CoreSettingsStorage provideCoreSettingsStorage(SettingsStorage settingsStorage) {
        return new ZendeskCoreSettingsStorage(settingsStorage);
    }


    @Provides
    @Singleton
    static LegacyIdentityMigrator provideLegacyIdentityStorage(
            @Named(BASE_STORAGE_LEGACY_IDENTITY) SharedPreferencesStorage legacyIdentityBaseStorage,
            @Named(BASE_STORAGE_LEGACY_PUSH) SharedPreferencesStorage legacyPushBaseStorage,
            IdentityStorage identityStorage,
            IdentityManager identityManager,
            PushDeviceIdStorage pushDeviceIdStorage) {
        return new LegacyIdentityMigrator(legacyIdentityBaseStorage, legacyPushBaseStorage,
                identityStorage, identityManager, pushDeviceIdStorage);
    }

    @Provides
    @Singleton
    static IdentityManager provideIdentityManager(IdentityStorage identityStorage) {
        return new ZendeskIdentityManager(identityStorage);
    }

    @Provides
    @Singleton
    static SessionStorage provideSessionStorage(IdentityStorage identityStorage,
            @Named(BASE_STORAGE_ADDITIONAL_SDK) BaseStorage additionalSdkStorage,
            @Named(BASE_STORAGE_DISK_LRU) BaseStorage mediaCache,
            Cache cache,
            @Named(CACHE_DIR) File cacheDir,
            @Named(DATA_DIR) File dataDir,
            @Named(BELVEDERE_DIR) File belvedereDir) {
        return new ZendeskSessionStorage(identityStorage,
                additionalSdkStorage,
                cache,
                mediaCache,
                cacheDir,
                dataDir,
                belvedereDir);
    }

    @Provides
    @Singleton
    static PushDeviceIdStorage providePushDeviceIdStorage(@Named(BASE_STORAGE_ADDITIONAL_SDK) BaseStorage
            additionalSdkStorage) {
        return new ZendeskPushDeviceIdStorage(additionalSdkStorage);
    }

    @Provides
    @Singleton
    static Storage provideSdkStorage(SettingsStorage settingsStorage, SessionStorage sessionStorage,
            @Named(BASE_STORAGE_SDK) BaseStorage sdkBaseStorage, MemoryCache memoryCache) {
        return new ZendeskStorage(sessionStorage, settingsStorage, sdkBaseStorage, memoryCache);
    }

    @Provides
    @Singleton
    static MachineIdStorage provideMachineIdStorage(
            @Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context
    ) {
        SharedPreferences sharedPreferences = getSharedPrefs(context, storageName(STORAGE_NAME_CORE_SDK));
        return new ZendeskMachineIdStorage(sharedPreferences);
    }

    private static String storageName(String name) {
        return String.format(Locale.US, "zendesk_%s", name);
    }

    private static SharedPreferences getSharedPrefs(Context context, String name) {
        return context.getSharedPreferences(name, Context.MODE_PRIVATE);
    }
}
