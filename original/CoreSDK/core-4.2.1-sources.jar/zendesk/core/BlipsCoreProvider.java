package zendesk.core;

/**
 * Core SDK specific Blips Provider
 */
interface BlipsCoreProvider {
    /**
     * Track initialisation of Core SDK.
     */
    void coreInitialized();

    /**
     * Track that push was enabled.
     */
    void corePushEnabled();

    /**
     * Track that push was disabled.
     */
    void corePushDisabled(Long userId);
}
