package zendesk.core;

/**
 * Marker interface for SDK-specific Settings objects.
 */
public interface Settings {
    // Intentionally empty. Marker interface only.
}
