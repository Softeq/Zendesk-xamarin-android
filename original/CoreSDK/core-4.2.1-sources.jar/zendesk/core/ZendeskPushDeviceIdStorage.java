package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

class ZendeskPushDeviceIdStorage implements PushDeviceIdStorage {

    private final BaseStorage deviceIdStorage;

    ZendeskPushDeviceIdStorage(@NonNull BaseStorage deviceIdStorage) {
        this.deviceIdStorage = deviceIdStorage;
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void storeRegisteredDeviceId(@NonNull String deviceId) {
        if (deviceId != null) {
            deviceIdStorage.put(Constants.PUSH_DEVICE_IDENTIFIER, deviceId);
        }
    }

    @Nullable
    @Override
    public String getRegisteredDeviceId() {
        return deviceIdStorage.get(Constants.PUSH_DEVICE_IDENTIFIER);
    }

    @Override
    public boolean hasRegisteredDeviceId() {
        return deviceIdStorage.get(Constants.PUSH_DEVICE_IDENTIFIER) != null;
    }

    @Override
    public void removeRegisteredDeviceId() {
        deviceIdStorage.remove(Constants.PUSH_DEVICE_IDENTIFIER);
    }

    @Override
    public void storePushRegistrationRequest(@NonNull PushRegistrationRequest request) {
        deviceIdStorage.put(Constants.PUSH_REGISTRATION_REQUEST, request);
    }

    @Nullable
    @Override
    public PushRegistrationRequest getPushRegistrationRequest() {
        return deviceIdStorage.get(Constants.PUSH_REGISTRATION_REQUEST, PushRegistrationRequest.class);
    }

    @Override
    public void removePushRegistrationRequest() {
        deviceIdStorage.remove(Constants.PUSH_REGISTRATION_REQUEST);
    }
}
