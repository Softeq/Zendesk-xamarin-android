package zendesk.core;

import androidx.annotation.VisibleForTesting;

import java.util.Iterator;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Implementation of {@link RestServiceProvider}. Uses {@link Retrofit} for creating services.
 */
class ZendeskRestServiceProvider implements RestServiceProvider {

    @VisibleForTesting
    final Retrofit retrofit;
    @VisibleForTesting
    final OkHttpClient standardOkHttpClient;

    private final OkHttpClient mediaHttpClient;
    private final OkHttpClient coreOkHttpClient;

    /**
     * Creates an {@link ZendeskRestServiceProvider}
     */
    ZendeskRestServiceProvider(Retrofit retrofit, OkHttpClient mediaHttpClient,
                               OkHttpClient standardOkHttpClient, OkHttpClient coreOkHttpClient) {
        this.retrofit = retrofit;
        this.mediaHttpClient = mediaHttpClient;
        this.standardOkHttpClient = standardOkHttpClient;
        this.coreOkHttpClient = coreOkHttpClient;
    }

    @Override
    public <E> E createRestService(Class<E> clazz, String sdkVersion, String sdkVariant) {
        Retrofit newRetrofit = retrofit.newBuilder()
                .client(standardOkHttpClient.newBuilder()
                        .addInterceptor(new UserAgentAndClientHeadersInterceptor(sdkVersion, sdkVariant))
                        .build())
                .build();

        return newRetrofit.create(clazz);
    }

    @Override
    public <E> E createRestService(Class<E> clazz,
                                   String sdkVersion,
                                   String sdkVariant,
                                   CustomNetworkConfig customNetworkConfig) {
        OkHttpClient.Builder okHttpClientBuilder = standardOkHttpClient.newBuilder();
        customNetworkConfig.configureOkHttpClient(okHttpClientBuilder);
        okHttpClientBuilder.addInterceptor(new UserAgentAndClientHeadersInterceptor(sdkVersion, sdkVariant));

        Retrofit.Builder retrofitBuilder = retrofit.newBuilder();

        customNetworkConfig.configureRetrofit(retrofitBuilder);

        return retrofitBuilder
                .client(okHttpClientBuilder.build())
                .build()
                .create(clazz);
    }

    @Override
    public <E> E createUnauthenticatedRestService(Class<E> clazz,
                                                   String sdkVersion,
                                                   String sdkVariant,
                                                   CustomNetworkConfig customNetworkConfig) {
        OkHttpClient.Builder okHttpClientBuilder = createNonAuthenticatedOkHttpClient();
        customNetworkConfig.configureOkHttpClient(okHttpClientBuilder);
        okHttpClientBuilder.addInterceptor(new UserAgentAndClientHeadersInterceptor(sdkVersion, sdkVariant));

        Retrofit.Builder retrofitBuilder = retrofit.newBuilder();

        customNetworkConfig.configureRetrofit(retrofitBuilder);

        return retrofitBuilder
                .client(okHttpClientBuilder.build())
                .build()
                .create(clazz);
    }

    @Override
    public OkHttpClient getMediaOkHttpClient() {
        return mediaHttpClient;
    }

    @Override
    public OkHttpClient getCoreOkHttpClient() {
        return coreOkHttpClient;
    }

    private OkHttpClient.Builder createNonAuthenticatedOkHttpClient() {
        OkHttpClient.Builder builder = standardOkHttpClient.newBuilder();
        Iterator<Interceptor> iterator = builder.interceptors().iterator();

        while (iterator.hasNext()) {
            Interceptor interceptor = iterator.next();
            if (interceptor instanceof ZendeskAuthHeaderInterceptor) {
                iterator.remove();
            }
        }
        return builder;
    }
}
