package zendesk.core;

/**
 * This is a model class for a user field option that will be created by the {@link UserProvider} as part
 * of {@link UserField}.
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/core/user_fields">User fields</a>
 */
@SuppressWarnings("unused")
public class UserFieldOption {

    private Long id;
    private String name;
    private String rawName;
    private String value;

    /**
     * Get the id of the user field option.
     *
     * @return the id of the user field option
     */
    public Long getId() {
        return id;
    }

    /**
     * Get the name of the user field option.
     *
     * @return the name of the user field option
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the raw name of the user field option
     *
     * @return the raw name of the user field option
     */
    public String getRawName() {
        return rawName;
    }

    /**
     * Get the value of the user field options.
     *
     * @return the value of the user field option
     */
    public String getValue() {
        return value;
    }
}
