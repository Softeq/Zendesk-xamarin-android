package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.util.Base64;

import com.zendesk.logger.Logger;

import java.nio.charset.Charset;

/**
 * This is an implementation of {@link Serializer} that serializes to json using our {@link GsonSerializer}
 * and encodes in base64 using {@link android.util.Base64}
 * If the object passed to the deserialize method is not of type String then the method returns null.
 */

class ZendeskBase64Serializer implements Serializer {

    private static final String LOG_TAG = "ZendeskBase64Serializer";

    private Serializer jsonSerializer;

    ZendeskBase64Serializer(Serializer jsonSerializer) {
        this.jsonSerializer = jsonSerializer;
    }

    @Nullable
    @Override
    public <E> E deserialize(@Nullable Object data, @NonNull Class<E> clazz) {
        if (data instanceof String) {
            String dataString = (String) data;
            String decodedString = new String(Base64.decode(dataString, Base64.NO_WRAP));
            return jsonSerializer.deserialize(decodedString, clazz);
        } else {
            Logger.w(LOG_TAG, "Data was not of type string. Cannot deserialize. Returning null.");
            return null;
        }
    }

    @Nullable
    @Override
    public String serialize(@Nullable Object object) {
        String jsonString = jsonSerializer.serialize(object);
        if (jsonString != null) {
            return Base64.encodeToString(jsonString.getBytes(Charset.defaultCharset()), Base64.NO_WRAP);
        } else {
            return null;
        }
    }
}
