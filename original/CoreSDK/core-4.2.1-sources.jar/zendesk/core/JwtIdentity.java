package zendesk.core;

import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

/**
 * This class models a JWT identity which is used to identify an End User within a Zendesk instance.
 */
public final class JwtIdentity implements Identity {


    private static final String LOG_TAG = "JwtIdentity";

    private final String token;

    /**
     * Creates a JWT identity that will be used during identification of a user.  The user identifier
     * will typically be used by the remote system to identify the user there and pass back a token
     * which will be used to identify that user in the Zendesk instance.
     *
     * @param jwtUserIdentifier The jwt user identifier that corresponds to a user on your system
     */
    public JwtIdentity(String jwtUserIdentifier) {

        if (StringUtils.isEmpty(jwtUserIdentifier)) {
            Logger.e(LOG_TAG,
                    "A null or empty JWT was specified. This will not work. Please check your initialisation of "
                            + "JwtIdentity!");
        }

        this.token = jwtUserIdentifier;
    }

    /**
     * Gets the JWT User Identifier
     *
     * @return the JWT Identifier, or null if it is not set
     */
    @Nullable
    public String getJwtUserIdentifier() {
        return this.token;
    }

    @SuppressWarnings("RedundantIfStatement")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        JwtIdentity that = (JwtIdentity) o;

        if (token != null ? !token.equals(that.token) : that.token != null) {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode() {
        return token != null ? token.hashCode() : 0;
    }
}
