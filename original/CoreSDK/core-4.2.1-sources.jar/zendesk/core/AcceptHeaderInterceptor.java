package zendesk.core;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;


class AcceptHeaderInterceptor implements Interceptor {
    @Override
    public Response intercept(Chain chain) throws IOException {
        final Request request = chain.request()
                .newBuilder()
                .addHeader(Constants.ACCEPT_HEADER, Constants.APPLICATION_JSON)
                .build();

        return chain.proceed(request);
    }
}
