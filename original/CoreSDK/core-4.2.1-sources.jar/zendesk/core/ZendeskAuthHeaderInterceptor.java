package zendesk.core;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

class ZendeskAuthHeaderInterceptor implements Interceptor {

    private IdentityManager identityManager;

    ZendeskAuthHeaderInterceptor(IdentityManager identityManager) {
        this.identityManager = identityManager;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request.Builder requestHeadersBuilder = chain.request().newBuilder();

        Identity identity = identityManager.getIdentity();
        String bearerToken = identityManager.getStoredAccessTokenAsBearerToken();

        if (UrlHelper.isGuideRequest(chain.request().url().toString())
                && !UrlHelper.isVoteRequest(chain.request().url().toString())
                && identity instanceof  AnonymousIdentity) {
            return chain.proceed(requestHeadersBuilder.build());
        }
        if (bearerToken != null) {
            requestHeadersBuilder.addHeader(Constants.AUTHORIZATION_HEADER, bearerToken);
        }

        return chain.proceed(requestHeadersBuilder.build());
    }
}
