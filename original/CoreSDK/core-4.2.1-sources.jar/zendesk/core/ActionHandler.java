package zendesk.core;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.JsonElement;

import java.util.Map;

/**
 * Defines a handler for an inter-SDK action, such as one SDK starting another one, without either
 * SDK having a dependency on the other. An example of this would be a hypothetical Help Center
 * SDK starting the "create ticket" screen of the Support SDK.
 * <p>
 * In order to properly separate SDKs from each other, handlers will work on "action Strings".
 * Similar to Android's Intent system, multiple SDKs can be capable of handling the same action
 * String. For example, a "contact us" action can be handled by Support, Chat, Voice, Message, etc.
 * In the event that more than one ActionHandler has been registered for the same actionString,
 * the {@code getPriority()} method can be used to determine which one to call {@code handle} on.
 */
public interface ActionHandler {

    /**
     * Determines whether or not the ActionHandler object can handle the given action String.
     *
     * @param actionName the action String to check against.
     * @return true if the action String can be handled, false if it can't.
     */
    boolean canHandle(@NonNull String actionName);

    /**
     * Invokes an action on the given action String. This is expected to be the starting of an
     * Activity, hence the {@link Context} parameter.
     * <p>
     * This method can be called before init for a given SDK is performed so you need to
     * check if any SDK's called here are initialised before any action takes place.
     *
     * @param data    an optional map of key-value pairs for the {@code ActionHandler} to use in handling the action.
     * @param context the {@link Context} to use in invoking the action, such as starting an Activity.
     */
    void handle(@Nullable Map<String, Object> data, @NonNull Context context);

    /**
     * Returns the priority of the ActionHandler. The higher the number, the higher the priority.
     *
     * @return the priority of the ActionHandler.
     */
    int getPriority();

    /**
     * @return a description for this action.
     */
    @Nullable
    ActionDescription getActionDescription();

    /**
     * Notifies the ActionHandler of an update to settings. These settings allows the ActionHandler to determine
     * whether they should be enabled. This will contain settings for each of the SDKs enabled for this account.
     * Each ActionHandler should extract the settings object relating to its specific SDK and only store that.
     *
     * @param settings a map representing the SDK settings for the current instance.
     */
    void updateSettings(Map<String, JsonElement> settings);
}
