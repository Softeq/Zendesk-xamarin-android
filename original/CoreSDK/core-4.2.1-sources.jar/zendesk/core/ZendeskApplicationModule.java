package zendesk.core;

import android.content.Context;
import android.os.Process;
import androidx.annotation.NonNull;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.zendesk.logger.Logger;
import com.zendesk.service.ZendeskDateTypeAdapter;

import java.lang.reflect.Modifier;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.Reusable;
import okhttp3.logging.HttpLoggingInterceptor;

import static zendesk.core.ZendeskStorageModule.GSON_SERIALIZER;

/**
 * This module shall only contain dependency providers for dependencies that will not change
 * during the lifecycle of an application. Note that provide* methods are not intended to be
 * called directly.
 * <p>
 * Created by Zendesk on 06/09/2016.
 */
@Module
class ZendeskApplicationModule {

    static final String APPLICATION_CONTEXT = "application_context";
    static final String BASE_64_SERIALIZER = "base_64_serializer";
    private static final int THREAD_POOL_SIZE = 5;

    private Context context;
    private ApplicationConfiguration applicationConfiguration;

    /**
     * Creates an instance of the module
     *
     * @param context                  A valid context. The application context will be capured.
     * @param applicationConfiguration The application configuration
     */
    ZendeskApplicationModule(
            @NonNull Context context, @NonNull ApplicationConfiguration applicationConfiguration) {
        this.context = context.getApplicationContext();
        this.applicationConfiguration = applicationConfiguration;
    }

    /**
     * Provides an instance of Base64Encoder for use in the SDK
     *
     * @return An instance of Base64Encoder for use in the SDK
     */
    @Provides
    @Reusable
    @Named(BASE_64_SERIALIZER)
    Serializer provideBase64Serializer(@Named(GSON_SERIALIZER) Serializer gsonSerializer) {
        return new ZendeskBase64Serializer(gsonSerializer);
    }

    /**
     * Provides the application context
     *
     * @return the application context
     */
    @Provides
    @Singleton
    @Named(APPLICATION_CONTEXT)
    Context provideApplicationContext() {
        return this.context;
    }

    /**
     * Provides the application configuration
     *
     * @return the application configuration
     */
    @Provides
    @Singleton
    ApplicationConfiguration provideApplicationConfiguration() {
        return this.applicationConfiguration;
    }

    @Provides
    @Singleton
    ZendeskLocaleConverter provideZendeskLocaleConverter() {
        return new ZendeskLocaleConverter();
    }

    /**
     * Provides an instance of Gson configured for use in the SDK.
     *
     * @return An instance of Gson configured for use in the Zendesk SDK
     */
    @Provides
    @Reusable
    static Gson provideGson() {
        return new GsonBuilder()
                .setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
                .excludeFieldsWithModifiers(Modifier.TRANSIENT, Modifier.STATIC)
                .registerTypeAdapter(Date.class, new ZendeskDateTypeAdapter())
                .create();
    }

    @Provides
    @Singleton
    static DeviceInfo provideDeviceInfo(@Named(APPLICATION_CONTEXT) Context context) {
        return new DeviceInfo(context);
    }

    /**
     * Provides an instance of a HTTP logging request interceptor
     *
     * @return instance of a HTTP logging request interceptor
     */
    @Provides
    @Reusable
    static HttpLoggingInterceptor provideHttpLoggingInterceptor() {
        final HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.setLevel(
                (Logger.isLoggable() ? HttpLoggingInterceptor.Level.BASIC : HttpLoggingInterceptor.Level.NONE));
        return loggingInterceptor;
    }

    @Provides
    @Singleton
    static ZendeskShadow provideZendesk(Storage storage,
                                        LegacyIdentityMigrator legacyIdentityMigrator,
                                        IdentityManager identityManager,
                                        BlipsCoreProvider blipsCoreProvider,
                                        PushRegistrationProvider pushRegistrationProvider,
                                        CoreModule coreModule,
                                        ProviderStore providerStore) {
        return new ZendeskShadow(storage, legacyIdentityMigrator, identityManager, blipsCoreProvider,
                pushRegistrationProvider, coreModule, providerStore);
    }

    /**
     * Threads are named for easy identifying in logs and tools.
     */
    @Provides
    @Singleton
    static ScheduledExecutorService provideExecutor() {
        return Executors.newScheduledThreadPool(THREAD_POOL_SIZE, new ThreadFactory() {

            final AtomicInteger atomicInteger = new AtomicInteger(0);

            @Override
            public Thread newThread(@NonNull Runnable runnable) {
                Thread thread = new Thread(runnable,
                        String.format(Locale.ENGLISH, "ZendeskThread-%d", atomicInteger.getAndIncrement()));
                thread.setPriority(Process.THREAD_PRIORITY_BACKGROUND);
                return thread;
            }
        });
    }

    @Provides
    @Singleton
    static ExecutorService provideExecutorService(ScheduledExecutorService scheduledExecutorService) {
        return scheduledExecutorService;
    }
}
