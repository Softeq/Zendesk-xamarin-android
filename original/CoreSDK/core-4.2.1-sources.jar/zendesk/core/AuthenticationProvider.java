package zendesk.core;

/**
 * SDK access to Identity. Read only to prevent setting of data by integrators.
 */
public interface AuthenticationProvider {

    /**
     * @return the current identity or null if no identity exists
     */
    Identity getIdentity();
}
