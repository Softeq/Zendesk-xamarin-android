package zendesk.core;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

/**
 * Abstract class for customising network configuration, to be used by Zendesk SDKs in conjunction
 * with {@link RestServiceProvider#createRestService(Class, CustomNetworkConfig)}.
 * <p>
 * It provides a way to add custom configuration to the {@link OkHttpClient} and {@link Retrofit}
 * objects used to power a generated Retrofit service API class, through implementing the
 * configuration methods. Both are empty by default.
 * <p>
 * This class should not be used directly by integrators.
 */
public abstract class CustomNetworkConfig {

    /**
     * Add custom configuration to the {@link OkHttpClient.Builder} which will be used by the object
     * returned by {@link RestServiceProvider#createRestService(Class, CustomNetworkConfig)}.
     *
     * @param builder a {@link OkHttpClient.Builder} with starting configuration from the Zendesk
     *                Core SDK.
     */
    public void configureOkHttpClient(OkHttpClient.Builder builder) {
        // Intentionally empty by default.
    }

    /**
     * Add custom configuration to the {@link Retrofit.Builder} which will be used by the object
     * returned by {@link RestServiceProvider#createRestService(Class, CustomNetworkConfig)}.
     *
     * @param builder a {@link Retrofit.Builder} with starting configuration from the Zendesk
     *                Core SDK.
     */
    public void configureRetrofit(Retrofit.Builder builder) {
        // Intentionally empty by default.
    }

}
