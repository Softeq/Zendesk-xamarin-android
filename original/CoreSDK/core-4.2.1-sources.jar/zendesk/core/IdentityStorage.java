package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Provides storage of an Access token
 */
@SuppressWarnings("unused")
interface IdentityStorage {

    /**
     * Stores an {@link AccessToken} on the device
     *
     * @param accessToken The access token to store
     */
    void storeAccessToken(AccessToken accessToken);

    /**
     * Gets a stored {@link AccessToken} from the device.
     *
     * @return The stored {@link AccessToken} or null if one
     * is not stored or if the storage is unavailable.
     */
    AccessToken getStoredAccessToken();

    /**
     * Stores a user ID for use in blips. The value should come from
     * {@link AccessToken#getUserId()}, parsed to a {@link Long} using {@link Long#valueOf(String)}.
     *
     * @param userId The user ID to store.
     */
    void storeUserId(Long userId);

    /**
     * Gets a stored user ID from the device. This should be sent in every blip to identify the
     * authenticated user.
     *
     * @return the user ID
     */
    @Nullable
    Long getUserId();

    /**
     * Gets the stored UUID of the current user or creates one if required.
     *
     * @return the UUID of the current user
     */
    @NonNull
    String getUuid();

    /**
     * Stores an identity.
     *
     * @param identity The identity to store.
     */
    void storeIdentity(Identity identity);

    /**
     * Gets the stored identity.
     *
     * @return The stored identity if it is available or null if none was found.
     */
    @Nullable
    Identity getIdentity();

    /**
     * Clears the identity storage
     */
    void clear();

    /**
     * Generate a new Blips UUID.
     *
     * @return the newly generated id
     */
    String updateBlipsUuid();

    /**
     * Gets the stored Blips UUID from storage.
     *
     * @return the stored UUID
     */
    String getBlipsUuid();

    /**
     * Generate a new SDK GUID.
     *
     * @return the newly generated id
     */
    String updateSdkGuid();

    /**
     * Set a particular SDK GUID. This should only be used when migrating from Support SDK v1.x.
     *
     * @param sdkGuid the SDK GUID from a legacy version of Support SDK (1.x).
     */
    void storeSdkGuid(String sdkGuid);
}
