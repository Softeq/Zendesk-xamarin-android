package zendesk.core;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Contains methods used to format strings for Blips operations
 */
@SuppressWarnings("unused")
class BlipsFormatHelper {

    private static final String VERSION_NAME_FORMAT = "%s:%s";
    static final String BLIPS_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final String UTC_TIMEZONE = "UTC";

    /**
     * Gets the ISO8601 timestamp of now, in UTC, with milliseconds.
     *
     * @return the ISO8601 timestamp of now, in UTC, with milliseconds.
     */
    static String nowAsString(Date now) {
        Date date = now == null ? new Date() : new Date(now.getTime());
        SimpleDateFormat dateFormat = new SimpleDateFormat(BLIPS_DATE_FORMAT, Locale.US);
        dateFormat.setTimeZone(TimeZone.getTimeZone(UTC_TIMEZONE));
        return dateFormat.format(date);
    }
}