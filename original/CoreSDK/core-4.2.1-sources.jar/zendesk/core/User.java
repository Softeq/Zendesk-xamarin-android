package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * This is a model class for a User
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/core/users">Users API documentation</a>
 */
public class User {

    private final Long id;
    private final String name;
    private final Attachment photo;
    private final boolean agent;
    private final List<String> tags;
    private final Map<String, String> userFields;

    /**
     * Initialises a user with default values.
     */
    public User() {
        this.id = -1L;
        this.name = "";
        this.photo = null;
        this.agent = false;
        this.tags = new ArrayList<>();
        this.userFields = new HashMap<>();
    }

    /**
     * Get the id of the user.
     *
     * @return the user's Id
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Get the name of the user.
     *
     * @return the user's name
     */
    @Nullable
    public String getName() {
        return name;
    }

    /**
     * Get the URL for the avatar of the user.
     *
     * @return the URL for the user's avatar, or null if none is present
     */
    @Nullable
    public String getPhoto() {
        if (photo == null) {
            return null;
        }
        return photo.getContentUrl();
    }

    /**
     * Is the user an agent.
     *
     * @return true if the user is an agent
     */
    public boolean isAgent() {
        return agent;
    }

    /**
     * Gets the list of tags associated with the user
     *
     * @return the list of tags associated with the user
     */
    @NonNull
    public List<String> getTags() {
        return CollectionUtils.copyOf(tags);
    }

    /**
     * Get a map of user fields, associated with the user.
     * <p>
     * The map returned by this method is a map of the field's key to the field's value. For
     * example, if you have a user field with the key 'custom_field_1' and the value 'some value',
     * then the map would be 'custom_field_1' -> 'some value'
     * </p>
     *
     * @return A map containing user fields.
     */
    @NonNull
    public Map<String, String> getUserFields() {
        return CollectionUtils.copyOf(userFields);
    }
}