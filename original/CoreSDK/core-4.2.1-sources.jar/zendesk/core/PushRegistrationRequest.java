package zendesk.core;


/**
 * Models the api request which is formed when registering a device for push notifications.
 */
@SuppressWarnings("unused")
class PushRegistrationRequest {

    private final String deviceType = "android";

    private String identifier;
    private String locale;
    private String tokenType;
    private String sdkGuid;

    /**
     * Sets the device locale
     *
     * @param locale The locale of the device in the format of ll-cc. en-us, en-ca. The country
     */
    void setLocale(String locale) {
        this.locale = locale;
    }

    /**
     * Sets an identifier
     *
     * @param identifier The identifier
     */
    void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    /**
     * Sets a token type
     *
     * @param tokenType The token type
     */
    void setTokenType(final String tokenType) {
        this.tokenType = tokenType;
    }

    /**
     * Gets the push registration identifier
     *
     * @return the push identifier
     */
    String getIdentifier() {
        return identifier;
    }

    /**
     * Gets the locale
     *
     * @return the locale
     */
    String getLocale() {
        return locale;
    }

    /**
     * Gets the type of the token
     *
     * @return the token type
     */
    String getTokenType() {
        return tokenType;
    }

    /**
     * Set the users sdk guid {@link IdentityManager#getSdkGuid()}
     *
     * @param sdkGuid The sdk guid
     */
    void setSdkGuid(String sdkGuid) {
        this.sdkGuid = sdkGuid;
    }

    /**
     * Gets the users sdk guid
     *
     * @return the sdk guid
     */
    String getSdkGuid() {
        return sdkGuid;
    }
}
