package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponseAdapter;
import com.zendesk.service.RetrofitZendeskCallbackAdapter;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.LocaleUtil;
import com.zendesk.util.StringUtils;

import java.io.IOException;
import java.util.Locale;

import retrofit2.Response;

/**
 * Provider to register and unregister a device for push notifications.
 */
class ZendeskPushRegistrationProvider implements PushRegistrationProvider,
        PushRegistrationProviderInternal {

    private static final String LOG_TAG = "PushRegistrationProvider";
    private final PushRegistrationService pushService;
    private final IdentityManager identityManager;
    private final SettingsProvider settingsProvider;

    private final BlipsCoreProvider blipsProvider;
    private final PushDeviceIdStorage pushIdStorage;
    private final Locale locale;

    /**
     * Default constructor for instantiating an implementation of {@link PushRegistrationProvider}
     */
    ZendeskPushRegistrationProvider(PushRegistrationService pushService,
                                    IdentityManager identityManager,
                                    SettingsProvider settingsProvider,
                                    BlipsCoreProvider blipsProvider,
                                    PushDeviceIdStorage pushIdStorage,
                                    Locale locale) {
        this.pushService = pushService;
        this.identityManager = identityManager;
        this.settingsProvider = settingsProvider;
        this.blipsProvider = blipsProvider;
        this.pushIdStorage = pushIdStorage;
        this.locale = locale;
    }

    @Override
    public void registerWithDeviceIdentifier(@NonNull final String identifier,
                                             @Nullable final ZendeskCallback<String> callback) {
        getAuthTypeAndRequest(identifier, TokenType.Identifier, callback);
    }

    @Override
    public void registerWithUAChannelId(@NonNull final String urbanAirshipChannelId,
                                        @Nullable final ZendeskCallback<String> callback) {
        getAuthTypeAndRequest(urbanAirshipChannelId, TokenType.UrbanAirshipChannelId, callback);
    }

    private void getAuthTypeAndRequest(@NonNull final String identifier, final TokenType tokenType,
                                       final ZendeskCallback<String> callback) {
        if (checkForStoredPushRegistration(identifier, callback)) {
            return;
        }

        settingsProvider.getCoreSettings(new PassThroughErrorZendeskCallback<CoreSettings>(callback) {
            @Override
            public void onSuccess(CoreSettings coreSettings) {
                final AuthenticationType authenticationType = coreSettings.getAuthentication();

                if (authenticationType == null) {
                    if (callback != null) {
                        callback.onError(new ErrorResponseAdapter("Authentication type is null."));
                    }
                    return;
                }

                PushRegistrationRequest request = getPushRegistrationRequest(identifier, locale,
                        authenticationType, tokenType);

                if (hasNoStoredAccessToken()) {
                    storePendingPushRegistrationRequest(request, callback);
                } else {
                    sendPushRegistrationRequest(request, callback);
                }
            }
        });
    }

    private boolean hasNoStoredAccessToken() {
        return identityManager.getStoredAccessTokenAsBearerToken() == null;
    }

    private void storePendingPushRegistrationRequest(PushRegistrationRequest request,
                                                     ZendeskCallback<String> callback) {
        pushIdStorage.storePushRegistrationRequest(request);
        if (callback != null) {
            callback.onSuccess(request.getIdentifier());
        }
    }

    @Override
    public void unregisterDevice(@Nullable final ZendeskCallback<Void> callback) {

        String identifier = pushIdStorage.getRegisteredDeviceId();
        final Long userId = identityManager.getUserId();

        if (identifier != null) {
            pushService.unregisterDevice(identifier).enqueue(
                    new RetrofitZendeskCallbackAdapter<Void, Void>(
                            new PassThroughErrorZendeskCallback<Void>(callback) {
                                @Override
                                public void onSuccess(Void isVoid) {
                                    pushIdStorage.removeRegisteredDeviceId();
                                    blipsProvider.corePushDisabled(userId);
                                    if (callback != null) {
                                        callback.onSuccess(isVoid);
                                    }
                                }
                            }
                    )
            );
        }
    }

    @Override
    public boolean isRegisteredForPush() {
        return pushIdStorage.hasRegisteredDeviceId();
    }

    private void sendPushRegistrationRequest(@NonNull final PushRegistrationRequest request,
                                     @Nullable final ZendeskCallback<String> callback) {
        pushService.registerDevice(new PushRegistrationRequestWrapper(request)).enqueue(
                new RetrofitZendeskCallbackAdapter<>(
                        new PassThroughErrorZendeskCallback<String>(callback) {
                            @Override
                            public void onSuccess(String identifier) {
                                onSuccessfulRegistration(identifier);

                                if (callback != null) {
                                    callback.onSuccess(identifier);
                                }
                            }
                        }, PUSH_RESPONSE_EXTRACTOR
                )
        );
    }

    @Override
    public String sendPushRegistrationRequest(PushRegistrationRequest request) {
        try {
            Response<PushRegistrationResponseWrapper> execute = pushService.registerDevice(
                    new PushRegistrationRequestWrapper(request)).execute();

            if (execute.body() != null && execute.body().getRegistrationResponse() != null) {
                String identifier = execute.body().getRegistrationResponse().getIdentifier();

                onSuccessfulRegistration(identifier);

                return identifier;
            }
        } catch (IOException ex) {
            Logger.e(LOG_TAG, "Push registration request failed.", ex);
        }
        return StringUtils.EMPTY_STRING;
    }

    private void onSuccessfulRegistration(String identifier) {
        pushIdStorage.storeRegisteredDeviceId(identifier);
        pushIdStorage.removePushRegistrationRequest();
        blipsProvider.corePushEnabled();
    }

    @NonNull
    private PushRegistrationRequest getPushRegistrationRequest(@NonNull String identifier,
                                                       @NonNull Locale locale,
                                                       @NonNull AuthenticationType authenticationType,
                                                       @NonNull TokenType tokenType) {
        PushRegistrationRequest request = new PushRegistrationRequest();
        request.setIdentifier(identifier);

        request.setLocale(LocaleUtil.toLanguageTag(locale));

        if (tokenType == TokenType.UrbanAirshipChannelId) {
            request.setTokenType(tokenType.name);
        }

        if (AuthenticationType.ANONYMOUS == authenticationType) {
            request.setSdkGuid(identityManager.getSdkGuid());
        }

        return request;
    }

    private boolean checkForStoredPushRegistration(@NonNull final String identifier,
                                                   @Nullable final ZendeskCallback<String> callback) {
        if (!StringUtils.hasLength(identifier)) {
            final String log = "Invalid identifier provided.";
            if (callback != null) {
                callback.onError(new ErrorResponseAdapter(log));
            }
            Logger.w(LOG_TAG, log);
            return true;

        } else if (pushIdStorage.hasRegisteredDeviceId() && identifier.equals(pushIdStorage.getRegisteredDeviceId())) {

            if (callback != null) {
                callback.onSuccess(identifier);
            }

            Logger.d(LOG_TAG, "Skipping registration because device is already registered with this ID.");
            return true;

        } else if (pushIdStorage.hasRegisteredDeviceId()) {
            pushIdStorage.removeRegisteredDeviceId();
            Logger.d(LOG_TAG, "Removing stored push registration response because a new one has been provided.");
            return false;

        } else {
            return false;
        }
    }

    enum TokenType {
        Identifier(null),
        UrbanAirshipChannelId("urban_airship_channel_id");

        final String name;

        TokenType(String name) {
            this.name = name;
        }

        String getName() {
            return name;
        }
    }

    private static final RetrofitZendeskCallbackAdapter.RequestExtractor<PushRegistrationResponseWrapper, String>
            PUSH_RESPONSE_EXTRACTOR =
            new RetrofitZendeskCallbackAdapter.RequestExtractor<PushRegistrationResponseWrapper, String>() {
                @Override
                public String extract(PushRegistrationResponseWrapper responseWrapper) {

                    if (responseWrapper != null
                            && responseWrapper.getRegistrationResponse() != null
                            && StringUtils.hasLength(responseWrapper.getRegistrationResponse().getIdentifier())) {
                        return responseWrapper.getRegistrationResponse().getIdentifier();
                    }

                    return StringUtils.EMPTY_STRING;
                }
            };
}
