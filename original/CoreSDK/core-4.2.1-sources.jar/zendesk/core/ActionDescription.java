package zendesk.core;

import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;

public final class ActionDescription {

    private final String localizedLabel;
    private final String localizedAccessibilityLabel;
    private final int icon;

    public ActionDescription(@Nullable String localizedLabel,
                             @Nullable String localizedAccessibilityLabel,
                             @DrawableRes int icon) {
        this.localizedLabel = localizedLabel;
        this.localizedAccessibilityLabel = localizedAccessibilityLabel;
        this.icon = icon;
    }

    @Nullable
    public String getLocalizedLabel() {
        return localizedLabel;
    }

    @Nullable
    public String getLocalizedAccessibilityLabel() {
        return localizedAccessibilityLabel;
    }

    @DrawableRes
    public int getIcon() {
        return icon;
    }
}
