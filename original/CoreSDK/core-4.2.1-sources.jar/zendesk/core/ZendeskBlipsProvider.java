package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.RetrofitZendeskCallbackAdapter;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;

/**
 * This is a reference implementation of {@link BlipsProvider}.
 */
class ZendeskBlipsProvider implements BlipsProvider, BlipsCoreProvider {

    private static final String LOG_TAG = "ZendeskBlipsProvider";

    static final String BLIPS_CORE_CATEGORY = "CoreSDK";
    private static final String CORE_VERSION_STRING = BuildConfig.VERSION_NAME;
    private static final String DEVICE_INFO_FIELD_STRING = "device";
    private static final String BLIP_VALUE_STRING = "payload";
    private static final String CODE_FIELD_NAME_STRING = "code";
    private static final String CODE_VALUE_JAVA_STRING = "java";
    private static final String CHANNEL_CORE_SDK = "core_sdk";

    static final String ACTION_CORE_INIT = "init";
    static final String ACTION_CORE_PUSH_ON = "PushOn";
    static final String ACTION_CORE_PUSH_OFF = "PushOff";

    private final BlipsService blipsService;
    private final DeviceInfo deviceInfo;
    private final Serializer serializer;
    private final IdentityManager identityManager;
    private final String appId;
    private final CoreSettingsStorage coreSettingsStorage;
    private final Executor executor;

    /**
     * Create an instance of ZendeskBlipsProvider.
     */
    ZendeskBlipsProvider(BlipsService blipsService, DeviceInfo deviceInfo,
                         Serializer serializer, IdentityManager identityManager, String appId,
                         CoreSettingsStorage coreSettingsStorage, Executor executor) {
        this.blipsService = blipsService;
        this.deviceInfo = deviceInfo;
        this.serializer = serializer;
        this.identityManager = identityManager;
        this.appId = appId;
        this.coreSettingsStorage = coreSettingsStorage;
        this.executor = executor;
    }

    @Override
    public void sendBlip(@NonNull UserAction userAction, @NonNull BlipsGroup blipsGroup) {
        sendBlip(blipsGroup, userAction, identityManager.getUserId());
    }

    /**
     * This overloaded sendBlip method is used below in {@link #corePushDisabled(Long)} which is
     * required to pass in a userId other than the one returned by {@link IdentityManager#getUserId()},
     * because the value {@link IdentityManager} may have changed by the time {@link #corePushDisabled(Long)}
     * has been called, though we still want to send the blip with the userId value that was sent at
     * the time of push unregistration.
     *
     * @param blipsGroup the permissions group the blip is in
     * @param userAction the details of the action to track
     * @param userId     the id of the user
     */
    @VisibleForTesting
    void sendBlip(@NonNull BlipsGroup blipsGroup, @NonNull UserAction userAction, Long userId) {
        BlipsSettings blipsSettings = coreSettingsStorage.getBlipsSettings();

        if (blipsSettings.getBlipsPermissions().isEnabled(blipsGroup)
                && StringUtils.hasLength(userAction.getChannel())) {
            dispatchBlip(createBlipsRequest(userAction, identityManager.getBlipsUuid(), appId, userId));
        }
    }

    @Override
    public void sendBlip(@NonNull PageView pageView, @NonNull BlipsGroup blipsGroup) {
        BlipsSettings blipsSettings = coreSettingsStorage.getBlipsSettings();

        if (blipsSettings.getBlipsPermissions().isEnabled(blipsGroup)
                && StringUtils.hasLength(pageView.getChannel())) {
            dispatchBlip(createBlipsRequest(pageView,
                    identityManager.getBlipsUuid(),
                    appId,
                    identityManager.getUserId()));
        }
    }

    @Override
    public void coreInitialized() {
        Map<String, Object> value = new HashMap<>();
        value.put(CODE_FIELD_NAME_STRING, CODE_VALUE_JAVA_STRING);

        sendBlip(new UserAction(CORE_VERSION_STRING, CHANNEL_CORE_SDK,
                BLIPS_CORE_CATEGORY, ACTION_CORE_INIT, null, value), BlipsGroup.REQUIRED);
    }

    @Override
    public void corePushEnabled() {
        sendBlip(new UserAction(CORE_VERSION_STRING, CHANNEL_CORE_SDK,
                BLIPS_CORE_CATEGORY, ACTION_CORE_PUSH_ON), BlipsGroup.REQUIRED);
    }

    /**
     * The "push off" blip is sent after the push unregistration completes, which can happen when
     * identities are changed, which means the userId from IdentityManager has changed, which means
     * we'd be sending a "push off" blip with the wrong user ID. So instead, we pass it in to this
     * method at the time of unregistration.
     *
     * @param userId the userId of the user who has unregistered for push.
     */
    @Override
    public void corePushDisabled(Long userId) {
        sendBlip(BlipsGroup.REQUIRED, new UserAction(CORE_VERSION_STRING, CHANNEL_CORE_SDK,
                        BLIPS_CORE_CATEGORY, ACTION_CORE_PUSH_OFF),
                userId);
    }

    @VisibleForTesting
    void dispatchBlip(final BlipsRequest blipsRequest) {
        executor.execute(new Runnable() {
            @Override
            public void run() {
                String encodedJson = serializer.serialize(blipsRequest);

                blipsService
                        .send(encodedJson)
                        .enqueue(new RetrofitZendeskCallbackAdapter<Void, Void>(new ZendeskCallback<Void>() {
                            @Override
                            public void onSuccess(Void isVoid) {
                                // Intentionally empty.
                            }

                            @Override
                            public void onError(ErrorResponse errorResponse) {
                                Logger.d(LOG_TAG, "Unable to send Blip | Error: %s", errorResponse.getReason());
                            }
                        }));
            }
        });
    }

    BlipsRequest createBlipsRequest(UserAction userAction, String uuid, String appId, Long userId) {
        String timestamp = BlipsFormatHelper.nowAsString(new Date());

        return BlipsRequest.buildUserAction(uuid, timestamp, userId, appId, userAction.getVersion(),
                userAction.getChannel(), userAction.getCategory(), userAction.getAction(),
                userAction.getLabel(), addDeviceInfoToValue(userAction.getValue()));
    }

    BlipsRequest createBlipsRequest(PageView pageView, String uuid, String appId, Long userId) {
        String timestamp = BlipsFormatHelper.nowAsString(new Date());

        return BlipsRequest.buildPageView(uuid, timestamp, userId, appId, pageView.getVersion(),
                pageView.getChannel(), pageView.getUrl(), pageView.getNavigatorLanguage(),
                pageView.getPageTitle(), pageView.getPageId(), pageView.getPageLocale(),
                addDeviceInfoToValue(pageView.getValue()));
    }

    private Map<String, Object> addDeviceInfoToValue(Map<String, Object> value) {
        Map<String, Object> mergedValue = new HashMap<>();

        mergedValue.put(DEVICE_INFO_FIELD_STRING, deviceInfo.getInfo());
        if (value != null && !value.isEmpty()) {
            mergedValue.put(BLIP_VALUE_STRING, value);
        }

        return mergedValue;
    }

}
