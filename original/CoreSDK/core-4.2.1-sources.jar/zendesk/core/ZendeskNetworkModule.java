package zendesk.core;

import android.content.Context;

import com.google.gson.Gson;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.Reusable;
import okhttp3.Cache;
import okhttp3.Dispatcher;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Module
class ZendeskNetworkModule {

    static final String CORE_RETROFIT = "CoreRetrofit";
    static final String STANDARD_RETROFIT = "Retrofit";
    static final String PUSH_PROVIDER_RETROFIT = "PushProviderRetrofit";

    private static final String CORE_OK_HTTP = "CoreOkHttp";
    private static final String BASE_OK_HTTP = "BaseOkHttp";
    private static final String STANDARD_OK_HTTP = "StandardOkHttp";

    private static final String MEDIA_OK_HTTP = "MediaOkHttp";

    /**
     * Provides an instance of a request interceptor to decorate http requests with Zendesk specific
     * headers
     *
     * @param configuration The application configuration
     * @return an instance of a request interceptor to decorate http requests with Zendesk specific
     * headers
     */
    @Provides
    @Reusable
    ZendeskOauthIdHeaderInterceptor provideZendeskBasicHeadersInterceptor(ApplicationConfiguration configuration) {
        return new ZendeskOauthIdHeaderInterceptor(configuration.getOauthClientId());
    }

    @Provides
    @Reusable
    UserAgentAndClientHeadersInterceptor providesUserAgentHeaderInterceptor() {
        return new UserAgentAndClientHeadersInterceptor(BuildConfig.VERSION_NAME, Constants.VARIANT);
    }

    @Provides
    @Reusable
    static AcceptHeaderInterceptor providesAcceptHeaderInterceptor() {
        return new AcceptHeaderInterceptor();
    }

    /**
     * Provides an instance of a request interceptor used to clear identity storage if a login
     *
     * @param sessionStorage The identity storage
     * @return An instance of a request interceptor used to clear identity storage if a login
     * failure occurs
     */
    @Provides
    @Reusable
    static ZendeskUnauthorizedInterceptor provideZendeskUnauthorizedInterceptor(SessionStorage sessionStorage,
                                                                                IdentityManager identityManager) {
        return new ZendeskUnauthorizedInterceptor(sessionStorage, identityManager);
    }

    @Provides
    @Reusable
    static ZendeskSettingsInterceptor provideSettingsInterceptor(SdkSettingsProviderInternal sdkSettingsProvider,
                                                                 SettingsStorage settingsStorage) {
        return new ZendeskSettingsInterceptor(sdkSettingsProvider, settingsStorage);
    }

    @Provides
    @Reusable
    static AcceptLanguageHeaderInterceptor provideAcceptLanguageHeaderInterceptor(@Named(ZendeskApplicationModule
            .APPLICATION_CONTEXT) Context context) {
        return new AcceptLanguageHeaderInterceptor(context);
    }

    @Provides
    @Reusable
    static ZendeskAuthHeaderInterceptor provideAuthHeaderInterceptor(IdentityManager identityManager) {
        return new ZendeskAuthHeaderInterceptor(identityManager);
    }

    @Provides
    @Reusable
    static ZendeskAccessInterceptor provideAccessInterceptor(IdentityManager identityManager,
                                                             AccessProvider accessProvider, Storage storage,
                                                             CoreSettingsStorage coreSettingsStorage) {
        return new ZendeskAccessInterceptor(identityManager, accessProvider, storage,
                coreSettingsStorage);
    }

    @Provides
    @Reusable
    static CachingInterceptor provideCachingInterceptor(@Named(ZendeskStorageModule.BASE_STORAGE_DISK_LRU)
                                                                    BaseStorage mediaCache) {
        return new CachingInterceptor(mediaCache);
    }

    @Provides
    @Reusable
    static ZendeskPushInterceptor providePushInterceptor(PushRegistrationProviderInternal pushProvider,
                                                         PushDeviceIdStorage pushDeviceIdStorage,
                                                         IdentityStorage identityStorage) {
        return new ZendeskPushInterceptor(pushProvider, pushDeviceIdStorage, identityStorage);
    }

    @Provides
    @Singleton
    @Named(BASE_OK_HTTP)
    OkHttpClient provideBaseOkHttpClient(HttpLoggingInterceptor loggingInterceptor,
                                         ZendeskOauthIdHeaderInterceptor oauthIdHeaderInterceptor,
                                         UserAgentAndClientHeadersInterceptor userAgentAndClientHeadersInterceptor,
                                         ExecutorService executorService) {

        return Tls12SocketFactory.enableTls12(new OkHttpClient.Builder())
                .addInterceptor(oauthIdHeaderInterceptor)
                .addInterceptor(loggingInterceptor)
                .addInterceptor(userAgentAndClientHeadersInterceptor)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .dispatcher(new Dispatcher(executorService))
                .build();
    }

    @Provides
    @Singleton
    @Named(CORE_OK_HTTP)
    OkHttpClient provideCoreOkHttpClient(@Named(BASE_OK_HTTP) OkHttpClient okHttpClient,
                                                AcceptLanguageHeaderInterceptor acceptLanguageHeaderInterceptor,
                                                AcceptHeaderInterceptor acceptHeaderInterceptor) {
        return okHttpClient.newBuilder()
                .addInterceptor(acceptLanguageHeaderInterceptor)
                .addInterceptor(acceptHeaderInterceptor)
                .build();
    }

    @Provides
    @Singleton
    @Named(MEDIA_OK_HTTP)
    OkHttpClient provideMediaOkHttpClient(@Named(BASE_OK_HTTP) OkHttpClient okHttpClient,
                                                 ZendeskAccessInterceptor accessInterceptor,
                                                 ZendeskAuthHeaderInterceptor authHeaderInterceptor,
                                                 ZendeskSettingsInterceptor settingsInterceptor,
                                                 CachingInterceptor cachingInterceptor,
                                                 ZendeskUnauthorizedInterceptor unauthorizedInterceptor) {
        return okHttpClient.newBuilder()
                .addInterceptor(settingsInterceptor)
                .addInterceptor(cachingInterceptor)
                .addInterceptor(accessInterceptor)
                .addInterceptor(authHeaderInterceptor)
                .addInterceptor(unauthorizedInterceptor)
                .build();
    }

    /**
     * Provides an instance of an OkHttp client
     *
     * @return An instance of an OkHttp client
     */
    @Provides
    @Singleton
    @Named(STANDARD_OK_HTTP)
    OkHttpClient provideOkHttpClient(@Named(BASE_OK_HTTP) OkHttpClient okHttpClient,
                                            ZendeskAccessInterceptor accessInterceptor,
                                            ZendeskUnauthorizedInterceptor unauthorizedInterceptor,
                                            ZendeskAuthHeaderInterceptor authHeaderInterceptor,
                                            ZendeskSettingsInterceptor settingsInterceptor,
                                            AcceptHeaderInterceptor acceptHeaderInterceptor,
                                            ZendeskPushInterceptor pushInterceptor,
                                            Cache cache) {
        return okHttpClient.newBuilder()
                .addInterceptor(settingsInterceptor)
                .addInterceptor(accessInterceptor)
                .addInterceptor(authHeaderInterceptor)
                .addInterceptor(unauthorizedInterceptor)
                .addInterceptor(acceptHeaderInterceptor)
                .addInterceptor(pushInterceptor)
                .cache(cache)
                .build();
    }

    /**
     * Provides an instance of Retrofit
     *
     * @param configuration The application configuration
     * @param gson          The gson used for deserialising and serialising
     * @param okHttpClient  The OkHttpClient to use
     * @return An instance of Retrofit
     */
    @Provides
    @Singleton
    @Named(STANDARD_RETROFIT)
    static Retrofit provideRetrofit(ApplicationConfiguration configuration, Gson gson,
                                    @Named(STANDARD_OK_HTTP) OkHttpClient okHttpClient) {
        return new Retrofit.Builder()
                .baseUrl(configuration.getZendeskUrl())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(okHttpClient)
                .build();
    }

    @Provides
    @Singleton
    @Named(CORE_RETROFIT)
    static Retrofit provideCoreRetrofit(ApplicationConfiguration configuration, Gson gson,
                                        @Named(CORE_OK_HTTP) OkHttpClient okHttpClient) {
        return new Retrofit.Builder()
                .baseUrl(configuration.getZendeskUrl())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(okHttpClient)
                .build();
    }

    @Provides
    @Singleton
    @Named(PUSH_PROVIDER_RETROFIT)
    static Retrofit providePushProviderRetrofit(ApplicationConfiguration configuration, Gson gson,
                                                @Named(CORE_OK_HTTP) OkHttpClient okHttpClient,
                                                ZendeskAuthHeaderInterceptor authHeaderInterceptor) {
        return new Retrofit.Builder()
                .baseUrl(configuration.getZendeskUrl())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(okHttpClient.newBuilder()
                        .addInterceptor(authHeaderInterceptor)
                        .build())
                .build();
    }

    @Provides
    @Singleton
    RestServiceProvider provideRestServiceProvider(@Named(ZendeskNetworkModule.STANDARD_RETROFIT) Retrofit
                                                                      retrofit,
                                                          @Named(ZendeskNetworkModule.MEDIA_OK_HTTP) OkHttpClient
                                                                  mediaOkHttpClient,
                                                          @Named(ZendeskNetworkModule.STANDARD_OK_HTTP) OkHttpClient
                                                                      standardOkHttpClient,
                                                          @Named(ZendeskNetworkModule.CORE_OK_HTTP) OkHttpClient
                                                                      coreOkHttpClient) {
        return new ZendeskRestServiceProvider(retrofit, mediaOkHttpClient, standardOkHttpClient, coreOkHttpClient);
    }
}
