package zendesk.core;

import com.zendesk.logger.Logger;
import com.zendesk.service.HttpConstants;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

class CachingInterceptor implements Interceptor {

    private static final String LOG_TAG = "CachingInterceptor";

    private final Map<String, Lock> locks = new HashMap<>();
    private final BaseStorage cache;

    CachingInterceptor(BaseStorage cache) {
        this.cache = cache;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {

        final String url = chain.request().url().toString();
        final Lock lock;

        synchronized (locks) {
            if (locks.containsKey(url)) {
                lock = locks.get(url);
            } else {
                lock = new ReentrantLock();
                locks.put(url, lock);
            }
        }

        Response response;
        try {
            lock.lock();
            response = loadData(url, chain);
        } finally {
            lock.unlock();
        }

        return response;
    }

    private Response loadData(String url, Chain chain) throws IOException {
        int responseCode = HttpConstants.HTTP_OK;
        ResponseBody responseBody = cache.get(url, ResponseBody.class);

        if (responseBody == null) {
            Logger.d(LOG_TAG, "Response not cached, loading it from the network. | %s", url);
            final Response response = chain.proceed(chain.request());

            if (response.isSuccessful()) {
                final MediaType contentType = response.body().contentType();
                final byte[] body = response.body().bytes();
                cache.put(url, ResponseBody.create(contentType, body));
                responseBody = ResponseBody.create(contentType, body);

            } else {
                Logger.d(LOG_TAG, "Unable to load data from network. | %s", url);
                responseBody = response.body();
            }

            responseCode = response.code();
        }

        return createResponse(responseCode, chain.request(), responseBody);
    }

    private Response createResponse(int statusCode, Request request, ResponseBody responseBody) {
        final Response.Builder builder = new Response.Builder();

        if (responseBody != null) {
            builder.body(responseBody);
        } else {
            Logger.w(LOG_TAG, "Response body is null");
        }

        return builder
                .code(statusCode)
                .message(request.method())
                .request(request)
                .protocol(Protocol.HTTP_1_1)
                .build();
    }
}
