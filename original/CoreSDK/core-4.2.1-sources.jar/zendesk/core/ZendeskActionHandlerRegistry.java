package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.JsonElement;
import com.zendesk.func.ZFunc1;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

class ZendeskActionHandlerRegistry implements ActionHandlerRegistry {

    private List<ActionHandler> registry = new ArrayList<>();

    @Override
    @SuppressWarnings("ConstantConditions")
    public void add(@NonNull ActionHandler actionHandler) {
        if (actionHandler == null) {
            return;
        }

        registry.add(actionHandler);
    }

    @Override
    @SuppressWarnings("ConstantConditions")
    public void remove(@NonNull ActionHandler actionHandler) {
        if (actionHandler == null) {
            return;
        }

        registry.remove(actionHandler);
    }

    @Override
    public void clear() {
        registry.clear();
    }

    @Nullable
    @Override
    @SuppressWarnings("ConstantConditions")
    public ActionHandler handlerByAction(@NonNull String actionName) {
        if (StringUtils.isEmpty(actionName)) {
            return null;
        }
        List<ActionHandler> operatingRegistry = new ArrayList<>(registry);

        Collections.sort(operatingRegistry, PRIORITY_ACTION_HANDLER_COMPARATOR);

        for (ActionHandler actionHandler : operatingRegistry) {
            if (actionHandler.canHandle(actionName)) {
                return actionHandler;
            }
        }

        return null;
    }

    @NonNull
    @Override
    @SuppressWarnings("ConstantConditions")
    public List<ActionHandler> handlersByAction(@NonNull final String actionName) {
        if (StringUtils.isEmpty(actionName)) {
            return Collections.emptyList();
        }
        final List<ActionHandler> filtered = CollectionUtils.filter(registry, new ZFunc1<ActionHandler, Boolean>() {
            @Override
            public Boolean apply(ActionHandler actionHandler) {
                return actionHandler.canHandle(actionName);
            }
        });
        Collections.sort(filtered, PRIORITY_ACTION_HANDLER_COMPARATOR);
        return filtered;
    }

    @Override
    public void updateSettings(Map<String, JsonElement> settings) {
        for (ActionHandler actionHandler : registry) {
            if (actionHandler != null) {
                actionHandler.updateSettings(settings);
            }
        }
    }

    private static final Comparator<ActionHandler> PRIORITY_ACTION_HANDLER_COMPARATOR =
            new Comparator<ActionHandler>() {
                @Override
                public int compare(ActionHandler o1, ActionHandler o2) {
                    return o2.getPriority() - o1.getPriority();
                }
            };
}
