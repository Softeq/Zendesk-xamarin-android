package zendesk.core;

import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

/**
 * Models the api response which is formed when registering a device for push notification
 */
@SuppressWarnings({"unused"})
class PushRegistrationResponseWrapper {

    @SerializedName("push_notification_device")
    private PushRegistrationResponse registrationResponse;

    /**
     * Gets the push registration response
     *
     * @return the push registration response
     */
    @Nullable
    PushRegistrationResponse getRegistrationResponse() {
        return registrationResponse;
    }
}
