package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.RetrofitZendeskCallbackAdapter;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ZendeskUserProvider implements UserProvider {

    private final UserService userService;

    ZendeskUserProvider(UserService userService) {
        this.userService = userService;
    }

    @Override
    public void addTags(@NonNull final List<String> tags, @Nullable final ZendeskCallback<List<String>> callback) {
        final UserTagRequest userTagRequest = new UserTagRequest(CollectionUtils.ensureEmpty(tags));

        userService.addTags(userTagRequest).enqueue(
                new RetrofitZendeskCallbackAdapter<>(
                        new PassThroughErrorZendeskCallback<List<String>>(callback) {
                            @Override
                            public void onSuccess(List<String> strings) {
                                if (callback != null) {
                                    callback.onSuccess(strings);
                                }
                            }
                        }, TAGS_EXTRACTOR
                ));
    }

    @Override
    public void deleteTags(@NonNull final List<String> tags, @Nullable final ZendeskCallback<List<String>> callback) {
        final String tagsCsv = StringUtils.toCsvString(CollectionUtils.ensureEmpty(tags));

        userService.deleteTags(tagsCsv).enqueue(
                new RetrofitZendeskCallbackAdapter<>(
                        new PassThroughErrorZendeskCallback<List<String>>(callback) {

                            @Override
                            public void onSuccess(List<String> strings) {
                                if (callback != null) {
                                    callback.onSuccess(strings);
                                }
                            }
                        }, TAGS_EXTRACTOR
                ));
    }

    @Override
    public void getUserFields(@Nullable final ZendeskCallback<List<UserField>> callback) {
        userService.getUserFields().enqueue(
                new RetrofitZendeskCallbackAdapter<>(
                        new PassThroughErrorZendeskCallback<List<UserField>>(callback) {
                            @Override
                            public void onSuccess(List<UserField> userFields) {
                                if (callback != null) {
                                    callback.onSuccess(userFields);
                                }
                            }
                        }, FIELDS_EXTRACTOR
                ));
    }

    @Override
    public void setUserFields(@NonNull final Map<String, String> userFields,
                              @Nullable final ZendeskCallback<Map<String, String>> callback) {
        final UserFieldRequest userFieldRequest = new UserFieldRequest(userFields);

        userService.setUserFields(userFieldRequest).enqueue(
                new RetrofitZendeskCallbackAdapter<>(
                        new PassThroughErrorZendeskCallback<Map<String, String>>(callback) {
                            @Override
                            public void onSuccess(Map<String, String> stringStringMap) {
                                if (callback != null) {
                                    callback.onSuccess(stringStringMap);
                                }
                            }
                        }, FIELDS_MAP_EXTRACTOR
                )
        );
    }

    @Override
    public void getUser(@Nullable final ZendeskCallback<User> callback) {
        userService.getUser().enqueue(
                new RetrofitZendeskCallbackAdapter<>(
                        new PassThroughErrorZendeskCallback<User>(callback) {
                            @Override
                            public void onSuccess(User user) {
                                if (callback != null) {
                                    callback.onSuccess(user);
                                }
                            }
                        }, USER_EXTRACTOR
                )

        );
    }

    private static final RetrofitZendeskCallbackAdapter.RequestExtractor<UserResponse, User> USER_EXTRACTOR =
            new RetrofitZendeskCallbackAdapter.RequestExtractor<UserResponse, User>() {
                @Override
                public User extract(UserResponse userResponse) {
                    return userResponse.getUser();
                }
            };

    private static final RetrofitZendeskCallbackAdapter.RequestExtractor<UserFieldResponse, List<UserField>>
            FIELDS_EXTRACTOR =
            new RetrofitZendeskCallbackAdapter.RequestExtractor<UserFieldResponse, List<UserField>>() {
                @Override
                public List<UserField> extract(UserFieldResponse userFieldResponse) {
                    return userFieldResponse.getUserFields();
                }
            };

    private static final RetrofitZendeskCallbackAdapter.RequestExtractor<UserResponse, Map<String, String>>
            FIELDS_MAP_EXTRACTOR =
            new RetrofitZendeskCallbackAdapter.RequestExtractor<UserResponse, Map<String, String>>() {
                @Override
                public Map<String, String> extract(UserResponse userResponse) {
                    if (userResponse == null || userResponse.getUser() == null) {
                        return CollectionUtils.copyOf(new HashMap<String, String>());
                    } else {
                        return userResponse.getUser().getUserFields();
                    }
                }
            };

    private static final RetrofitZendeskCallbackAdapter.RequestExtractor<UserResponse, List<String>> TAGS_EXTRACTOR =
            new RetrofitZendeskCallbackAdapter.RequestExtractor<UserResponse, List<String>>() {
                @Override
                public List<String> extract(UserResponse userResponse) {
                    if (userResponse == null || userResponse.getUser() == null) {
                        return CollectionUtils.copyOf(new ArrayList<String>());
                    } else {
                        return userResponse.getUser().getTags();
                    }
                }
            };
}
