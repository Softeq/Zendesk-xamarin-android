package zendesk.core;

import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;

import java.io.IOException;
import java.net.HttpURLConnection;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Response;
import okhttp3.ResponseBody;

/**
 * Interceptor which handles just-in-time authentication with the Zendesk back-end, using an {@link AccessProvider} and
 * an {@link IdentityManager}.
 *
 * The Interceptor is added to the request chain for requests made through a certain OkHttpClient
 * (see {@link ZendeskNetworkModule#provideOkHttpClient(OkHttpClient, ZendeskAccessInterceptor,
 * ZendeskUnauthorizedInterceptor, ZendeskAuthHeaderInterceptor, ZendeskSettingsInterceptor, AcceptHeaderInterceptor,
 * ZendeskPushInterceptor, Cache)}).
 *
 * The Interceptor first checks storage (using {@link IdentityManager#getStoredAccessTokenAsBearerToken()} for an
 * existing auth token for a user. If one is found, the Interceptor proceeds with the request chain. If no auth
 * token is found, the Interceptor checks the stored Identity (using {@link IdentityManager#getIdentity()}) and the
 * authentication type in SDK settings. If there is a match, the appropriate method on {@link AccessProvider} is
 * called to authenticate the user with the Zendesk back-end. The retrieved access token is then saved into the SDK's
 * storage using {@link IdentityManager#storeAccessToken(AccessToken)}, and the Interceptor returns. The stored access
 * token is then used by the {@link ZendeskAuthHeaderInterceptor} to decorate the outgoing request.
 *
 * If the local identity and the auth type in settings do not match, this Interceptor clears storage and returns an
 * error.
 *
 * In the event of multiple simultaneous requests which all trigger the {@link ZendeskAccessInterceptor} at the same
 * time, all except one of the calls to {@link ZendeskAccessProvider} will return a 409 status code error. In this case,
 * the {@link ZendeskAccessInterceptor} will invoke its {@link #intercept(Chain)} method again, which should now
 * retrieve an access token from storage, and allow the chain to proceed. If a token is still not found, the Interceptor
 * will make a new call to {@link AccessProvider}. To prevent an infinite loop if the {@link AccessProvider} continues
 * to return 409, the Interceptor will retry a maximum of 3 times.
 */
class ZendeskAccessInterceptor implements Interceptor {

    private static final String LOG_TAG = "ZendeskAccessInterceptor";
    private static final String EMPTY_JSON = "{}";
    private static final int RETRY_LIMIT = 3;

    private IdentityManager identityManager;
    private AccessProvider accessProvider;
    private Storage storage;
    private CoreSettingsStorage coreSettingsStorage;

    private int retryCounter;

    ZendeskAccessInterceptor(IdentityManager identityManager, AccessProvider accessProvider,
                             Storage storage, CoreSettingsStorage coreSettingsStorage) {
        this.identityManager = identityManager;
        this.accessProvider = accessProvider;
        this.storage = storage;
        this.coreSettingsStorage = coreSettingsStorage;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {

        Identity identity = identityManager.getIdentity();

        AuthenticationType authenticationType = coreSettingsStorage.getCoreSettings().getAuthentication();

        if (identityManager.getStoredAccessTokenAsBearerToken() != null) {
            Logger.d(LOG_TAG, "Access token present, no need to intercept.");
            return chain.proceed(chain.request());
        } else {
            Logger.d(LOG_TAG, "Access token is required, intercepting.");
            retrofit2.Response<AuthenticationResponse> response;
            if (AuthenticationType.ANONYMOUS == authenticationType && identity instanceof AnonymousIdentity) {
                Logger.d(LOG_TAG, "Anonymous Identity found. Requesting and storing auth token.");
                response = accessProvider.getAuthTokenViaAnonymous((AnonymousIdentity) identity);
            } else if (AuthenticationType.JWT == authenticationType && identity instanceof JwtIdentity) {
                Logger.d(LOG_TAG, "JWT Identity found. Requesting and storing auth token.");
                response = accessProvider.getAuthTokenViaJwt((JwtIdentity) identity);
            } else {
                /*
                  This can happen when auth types are switched, so let's delete stored settings
                  and any session storage because it will force the download of new settings on
                  next launch. The current settings are invalid anyway.
                 */
                storage.clear();

                final String error = getErrorLogMessage(authenticationType, identity);
                Logger.e(LOG_TAG, error);

                return errorResponse(chain, error);
            }

            if (response == null) {
                return errorResponse(chain, "Response was null, failed to auth user.");
            } else if (response.code() == 409) {
                if (retryCounter < RETRY_LIMIT) {
                    retryCounter++;
                    return intercept(chain);
                } else {
                    return errorResponse(chain, "Response was 409, failed to auth user.");
                }
            } else if (response.body() != null) {
                AccessToken accessToken = response.body().getAuthentication();
                if (accessToken != null) {
                    identityManager.storeAccessToken(accessToken);
                }
                retryCounter = 0;
                return chain.proceed(chain.request());
            } else {
                return errorResponse(chain, "Response body was null, failed to auth user.");
            }
        }
    }

    @VisibleForTesting
    static String getErrorLogMessage(AuthenticationType expectedAuthenticationType, Identity storedIdentity) {
        StringBuilder stringBuilder = new StringBuilder(160);

        stringBuilder.append("The expected type of authentication is ");

        if (expectedAuthenticationType == null) {
            stringBuilder.append("null. Check that settings have been downloaded.");
        } else if (expectedAuthenticationType == AuthenticationType.ANONYMOUS) {
            stringBuilder.append("anonymous.");
        } else if (expectedAuthenticationType == AuthenticationType.JWT) {
            stringBuilder.append("jwt.");
        }

        stringBuilder.append('\n');

        stringBuilder.append("The local identity is");

        if (storedIdentity == null) {
            stringBuilder.append(" not");
        }

        stringBuilder.append(" present.\n");

        if (storedIdentity != null) {
            stringBuilder.append("The local identity is ");

            if (storedIdentity instanceof AnonymousIdentity) {
                stringBuilder.append("anonymous.");
            } else if (storedIdentity instanceof JwtIdentity) {
                stringBuilder.append("jwt.");
            } else {
                stringBuilder.append("unknown.");
            }
        }

        return stringBuilder.toString();
    }

    private Response errorResponse(Chain chain, String errorMessage) {
        return new Response.Builder()
                .request(chain.request())
                .protocol(Protocol.HTTP_2)
                .code(HttpURLConnection.HTTP_BAD_REQUEST)
                .message(errorMessage)
                .body(ResponseBody.create(MediaType.parse(Constants.TEXT_JSON), EMPTY_JSON))
                .build();
    }
}
