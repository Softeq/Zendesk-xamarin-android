package zendesk.core;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonSyntaxException;
import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

/**
 * Implementation of {@link Serializer} using {@link Gson} for the
 * heavy lifting.
 */
class GsonSerializer implements Serializer {

    private static final String LOG_TAG = "GsonSerializer";

    private final Gson gson;

    /**
     * Create an instance of {@link GsonSerializer}
     */
    GsonSerializer(Gson gson) {
        this.gson = gson;
    }

    /**
     * Deserialize the provided dump of data into the provided type {@code E}.
     * <br>
     * Typically the provided object representing data is type of {@link String}.
     * <br>
     * The provide {@code object} should by of type {@link String} or {@link JsonElement}
     * everything else will be ignored.
     *
     * @param object data for deserialization
     * @param clazz  the class representing the stored settings
     * @return the requested object of type {@code E} or {@code null}
     */
    @Override
    public <E> E deserialize(Object object, @NonNull Class<E> clazz) {
        if (object instanceof String) {
            String json = (String) object;
            if (StringUtils.hasLength(json)) {
                try {
                    return gson.fromJson(json, clazz);
                } catch (JsonSyntaxException exception) {
                    Logger.d(LOG_TAG, "Unable to deserialize String into object of type %s",
                            clazz.getSimpleName());
                }
            }
        } else if (object instanceof JsonElement) {
            JsonElement json = (JsonElement) object;
            try {
                return gson.fromJson(json, clazz);
            } catch (JsonSyntaxException exception) {
                Logger.d(LOG_TAG, "Unable to deserialize JsonElement into object of type %s",
                        clazz.getSimpleName(), exception);
            }

        } else {
            Logger.d(LOG_TAG, "Unable to deserialize the provided object into %s",
                    clazz.getSimpleName());
        }

        return null;
    }

    @Override
    public String serialize(Object object) {
        return gson.toJson(object);
    }

}
