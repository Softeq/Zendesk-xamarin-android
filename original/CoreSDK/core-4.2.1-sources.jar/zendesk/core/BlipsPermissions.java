package zendesk.core;

import androidx.annotation.VisibleForTesting;

/**
 * This model represents all of the settings that can be retrieved from the server for the permissions
 * of blip events, for features such as Pathfinder.
 */
@SuppressWarnings("unused")
class BlipsPermissions {

    private boolean required;

    private boolean behavioural;

    private boolean pathfinder;

    /**
     * Creates a new instance of {@link BlipsPermissions} with the supplied enabled/disabled values.
     * <p>
     * This method should not be used except for testing purposes. An instance of the class will be
     * created when the settings network response is deserialised, or the object is read from storage.
     * There should be no need to instantiate this class directly.
     *
     * @param required    true if {@link BlipsGroup#REQUIRED} blips are enabled, false if not.
     * @param behavioural true if {@link BlipsGroup#BEHAVIOURAL} blips are enabled, false if not.
     * @param pathfinder  true if {@link BlipsGroup#PATHFINDER} blips are enabled, false if not.
     */
    @VisibleForTesting
    BlipsPermissions(boolean required, boolean behavioural, boolean pathfinder) {
        this.required = required;
        this.behavioural = behavioural;
        this.pathfinder = pathfinder;
    }

    /**
     * Creates a new, default instance of {@link BlipsPermissions} with everything disabled.
     */
    BlipsPermissions() {
        this(false, false, false);
    }

    /**
     * Checks if the supplied {@link BlipsGroup} is enabled or not in the supplied {@link BlipsPermissions}.
     * Blips of the supplied type will be sent if this method returns true, otherwise they will not be sent.
     *
     * @param group the {@link BlipsGroup} to check the enabled/disabled status of.
     * @return true if the supplied {@link BlipsGroup} is enabled, false if not.
     */
    boolean isEnabled(BlipsGroup group) {
        switch (group) {
            case REQUIRED:
                return required;
            case BEHAVIOURAL:
                return behavioural;
            case PATHFINDER:
                return pathfinder;
            default:
                return false;
        }
    }

}
