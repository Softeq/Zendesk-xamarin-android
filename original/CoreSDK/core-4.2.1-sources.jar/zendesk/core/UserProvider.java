package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

import java.util.List;
import java.util.Map;

/**
 * <p>
 * <b>Setting tags and fields on a user are features. Your plan must support these features in order to
 * work with them.</b>
 * </p>
 *
 * <p>
 * A provider which will offer a higher level of abstraction compared to the {@link UserService}
 * <br>
 * You can create an instance of UserProvider like this:
 *
 * <pre>
 *      import zendesk.core.UserProvider;
 *      import zendesk.core.Zendesk;
 *      ...
 *      UserProvider provider = Zendesk.INSTANCE.provider().userProvider();
 *      ...
 * </pre>
 *
 * <p>
 * Once you have an instance of the provider you can call methods on it and handle the results
 * in callbacks. A success callback will give you the resource(s) that you are requesting. The error
 * callback will be called if there was some issue with the method call and it will define details
 * about the error in an {@link ErrorResponse}
 * </p>
 * <p>
 * For example you can upload a file like this:
 * <pre>
 *
 *   provider.addTags(Arrays.asList("tag", "foo", "bar"), new ZendeskCallback&lt;User&gt;() {
 *      {@literal @Override}
 *      public void onSuccess(final User user) {
 *          // Handle success
 *      }
 *
 *      {@literal @Override}
 *      public void onError(final ErrorResponse errorResponse) {
 *          // Handle error
 *      }
 *   });
 *
 * </pre>
 */
@SuppressWarnings("unused")
public interface UserProvider {

    /**
     * Calls a user service to add tags to a user on behalf of the end-user.
     *
     * @param tags     A list of tags.
     * @param callback Callback that will deliver the list of the user's tags after the call or an {@link ErrorResponse}
     * @since 1.4.0.1
     */
    void addTags(@NonNull List<String> tags, @Nullable ZendeskCallback<List<String>> callback);


    /**
     * Calls a user service to remove tags from a user on behalf of the end-user.
     *
     * @param tags     A list of tags
     * @param callback Callback that will deliver the list of the user's tags after the call or an {@link ErrorResponse}
     */
    void deleteTags(@NonNull List<String> tags, @Nullable ZendeskCallback<List<String>> callback);


    /**
     * Gets a list of user field definitions that are available in your account.
     * <p>
     * Note that this retrieves the definitions, and not the values of the user fields for the
     * current user. To retrieve the values you should call {@link #getUser(ZendeskCallback)},
     * and then call {@link User#getUserFields()} on the returned {@code User} object.
     * </p>
     *
     * @param callback Callback that will deliver a newly created list containing
     *                 {@link UserField} or {@link ErrorResponse}
     * @since 1.4.0.1
     */
    void getUserFields(@Nullable ZendeskCallback<List<UserField>> callback);

    /**
     * Sets the user fields for the current user.
     * <p>
     * User fields must have been created in your Zendesk account before they can be set by this
     * method. The userFields map is a map from the key of your user field to the value of your
     * user field.
     * </p>
     *
     * <pre>{@code
     *      Map<String, String> userFields = new HashMap<>();
     *      userFields.put("sdk_phone_number", "12345");
     *
     *      userProvider.setUserFields(userFields, new ZendeskCallback<Map<String, String>>() {
     *          // handle callbacks
     *      });
     * }</pre>
     *
     * @param userFields A map containing the fields to be set. The map is from a field's key to its value
     * @param callback   Callback that will deliver the map of the user's fields and their values after the call or
     *                   an {@link ErrorResponse}
     * @see <a href="https://support.zendesk.com/hc/en-us/articles/203662066-Adding-custom-fields-to-users">Adding
     * custom fields to users</a>
     * @since 1.4.0.1
     */

    void setUserFields(@NonNull Map<String, String> userFields, @Nullable ZendeskCallback<Map<String, String>>
            callback);

    /**
     * Calls a user service to get information about the current logged in user.
     * <p>
     * The {@link User} object which is returned from this method's callback only contains
     * the user's tags and fields at this time.
     * </p>
     *
     * @param callback Callback that will deliver a newly created request of type
     *                 {@link User} or {@link ErrorResponse}
     * @since 1.4.0.1
     */
    void getUser(@Nullable ZendeskCallback<User> callback);
}
