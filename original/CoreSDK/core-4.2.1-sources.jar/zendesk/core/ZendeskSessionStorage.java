package zendesk.core;

import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import okhttp3.Cache;

class ZendeskSessionStorage implements SessionStorage {

    private static final String LOG_TAG = "SessionStorage";

    private final IdentityStorage identityStorage;
    private final BaseStorage additionalSdkStorage;
    private final BaseStorage mediaCache;
    private final Cache responseCache;

    private final List<File> registeredFolders;
    private final File zendeskCacheDir;
    private final File zendeskDataDir;

    /**
     * Create an instance of SessionStorage.
     *
     * @param identityStorage      reference to identity storage
     * @param additionalSdkStorage reference to additional sdk storage
     * @param mediaCache           reference to the media cache
     */
    ZendeskSessionStorage(IdentityStorage identityStorage,
                          BaseStorage additionalSdkStorage,
                          Cache responseCache,
                          BaseStorage mediaCache,
                          File cacheDir, File dataDir, File belvedereDir) {
        this.identityStorage = identityStorage;
        this.additionalSdkStorage = additionalSdkStorage;
        this.responseCache = responseCache;
        this.zendeskCacheDir = cacheDir;
        this.zendeskDataDir = dataDir;
        this.mediaCache = mediaCache;
        this.registeredFolders = new ArrayList<>(Arrays.asList(zendeskCacheDir, zendeskDataDir, belvedereDir));
    }

    /**
     * Gets a reference to additional sdk storage
     *
     * @return reference to the additional sdk storage
     */
    @Override
    public BaseStorage getAdditionalSdkStorage() {
        return additionalSdkStorage;
    }

    @Override
    public File getZendeskCacheDir() {
        return createDirIfNotExists(zendeskCacheDir);
    }

    @Override
    public File getZendeskDataDir() {
        return createDirIfNotExists(zendeskDataDir);
    }

    /**
     * Clear all information tied to a session.
     */
    @Override
    public void clear() {
        identityStorage.clear();
        additionalSdkStorage.clear();
        mediaCache.clear();

        try {
            responseCache.evictAll();
        } catch (IOException e) {
            // intentionally empty
        }

        for (File file : registeredFolders) {
            clearDirectory(file);
        }
    }

    private File createDirIfNotExists(File file) {
        if (file.exists()) {
            final boolean success = file.mkdirs();
            Logger.d(LOG_TAG, "Created dir %s, success: %s", file.getAbsolutePath(), success);
        }

        return file;
    }

    private static void clearDirectory(File file) {
        if (file != null && file.exists()) {
            //only get the array once, fix subtle concurrency bug
            final File[] files = file.listFiles();
            if (files != null && file.isDirectory() && CollectionUtils.isNotEmpty(files)) {
                for (File child : files) {
                    clearDirectory(child);
                }
            }
            //noinspection ResultOfMethodCallIgnored
            file.delete();
        }
    }
}