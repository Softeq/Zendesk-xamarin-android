package zendesk.core;

import androidx.annotation.NonNull;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * Models the api response from the api call to get a list of {@link UserField} in Zendesk
 */
@SuppressWarnings("unused")
class UserFieldResponse {

    private List<UserField> userFields;

    /**
     * Get the list of user fields associated with the user.
     *
     * @return A list of user fields
     */
    @NonNull
    List<UserField> getUserFields() {
        return CollectionUtils.copyOf(userFields);
    }
}
