package zendesk.core;

import androidx.annotation.NonNull;

/**
 * Core specific settings storage.
 */
interface CoreSettingsStorage {

    /**
     * Load Core SDK Settings from storage.
     * <br>
     * Returns default {@link CoreSettings} if the storage is empty.
     *
     * @return core SDK setting.
     */
    @NonNull
    CoreSettings getCoreSettings();

    /**
     * Load {@link BlipsSettings} from storage
     * <br>
     * Returns default {@link BlipsSettings} if the storage is empty.
     *
     * @return blips settings
     */
    @NonNull
    BlipsSettings getBlipsSettings();

}
