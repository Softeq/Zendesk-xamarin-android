package zendesk.core;

/**
 * This is a marker interface for handling different identity types which are used to resolve
 * end users within a Zendesk instance.
 */
public interface Identity {
    // Marker interface only
}
