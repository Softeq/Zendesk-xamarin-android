package zendesk.core;

import androidx.annotation.Nullable;

/**
 * Class responsible for managing SDK identities.
 * <br>
 * Containing the logic of updating/changing/setting identities.
 */
interface IdentityManager {

    boolean identityIsDifferent(Identity identity);

    /**
     * Sets or updates the SDK to use the provided identity.
     *
     * <p>
     * The method returns the actually set identity. We might have to
     * modify the provided identity.
     * </p>
     *
     * @param newIdentity the new identity.
     * @return
     */
    Identity updateAndPersistIdentity(Identity newIdentity);

    /**
     * Gets the SDK GUID for the current anonymous identity.
     *
     * @return the SDK GUID for the current anonymous identity.
     */
    String getSdkGuid();


    /**
     * Gets the stored access token as a bearer value for an authorization header.
     *
     * @return A bearer token for use in an Authorization header or null.  If the token is present this will
     * be like "Bearer {token}". If the token is missing it will be null
     */
    String getStoredAccessTokenAsBearerToken();

    /**
     * Gets the active {@link Identity}
     *
     * @return the active {@link Identity} or {@code null}
     */
    @Nullable
    Identity getIdentity();

    /**
     * Gets the Blips UUID for the current identity
     *
     * @return the UUID for the current identity
     */
    String getBlipsUuid();

    /**
     * Stores an {@link AccessToken} and its user ID.
     *
     * @param accessToken the Access Token to store
     */
    void storeAccessToken(AccessToken accessToken);

    /**
     * Gets a stored user ID from the device. This should be sent in every blip to identify the
     * authenticated user.
     *
     * @return the user ID
     */
    @Nullable
    Long getUserId();
}
