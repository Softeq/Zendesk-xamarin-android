package zendesk.core;

import androidx.annotation.NonNull;

import com.zendesk.util.DigestUtils;

import java.util.Locale;

/**
 * Provides access to various forms of storage. Implementation of {@link Storage}.
 */
class ZendeskStorage implements Storage {

    private static final String SDK_HASH_KEY = "sdk_hash";
    private static final String SDK_HASH_FORMAT = "%s_%s_%s";

    private final SessionStorage sessionStorage;
    private final SettingsStorage settingsStorage;
    private final BaseStorage sdkDetailsStorage;
    private final MemoryCache memoryCache;

    /**
     * Create an instance of {@link Storage}
     */
    ZendeskStorage(SessionStorage sessionStorage, SettingsStorage settingsStorage,
                   BaseStorage sdkDetailsStorage, MemoryCache memoryCache) {
        this.sessionStorage = sessionStorage;
        this.settingsStorage = settingsStorage;
        this.sdkDetailsStorage = sdkDetailsStorage;
        this.memoryCache = memoryCache;
    }

    @Override
    public SessionStorage getSessionStorage() {
        return sessionStorage;
    }

    @Override
    public void clear() {
        sessionStorage.clear();
        settingsStorage.clear();
        memoryCache.clear();
    }

    @Override
    public boolean hasSdkConfigChanged(ApplicationConfiguration config) {
        String sdkHash = generateSdkHash(config);
        String storedSdkHash = sdkDetailsStorage.get(SDK_HASH_KEY);
        return !sdkHash.equals(storedSdkHash);
    }

    @Override
    public void storeSdkHash(ApplicationConfiguration config) {
        sdkDetailsStorage.put(SDK_HASH_KEY, generateSdkHash(config));
    }

    @NonNull
    private String generateSdkHash(ApplicationConfiguration config) {
        String rawHash = String.format(Locale.US, SDK_HASH_FORMAT, config.getZendeskUrl().toLowerCase(Locale.US),
                config.getApplicationId().toLowerCase(Locale.US), config.getOauthClientId().toLowerCase(Locale.US));
        return DigestUtils.sha1(rawHash);
    }

}
