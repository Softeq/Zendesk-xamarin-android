package zendesk.core;

/**
 * This model represents all of the settings that can be retrieved from the server for the sending
 * of blip events.
 */
@SuppressWarnings("unused")
class BlipsSettings {

    private BlipsPermissions permissions;

    /**
     * Instantiates a new BlipsSettings object with the supplied {@link BlipsPermissions}
     *
     * @param permissions the {@link BlipsPermissions} for this BlipsSettings object.
     */
    BlipsSettings(BlipsPermissions permissions) {
        this.permissions = permissions;
    }

    /**
     * Returns the permissions settings governing the sending of blips
     *
     * @return the blips permissions settings
     */
    BlipsPermissions getBlipsPermissions() {
        return permissions;
    }
}