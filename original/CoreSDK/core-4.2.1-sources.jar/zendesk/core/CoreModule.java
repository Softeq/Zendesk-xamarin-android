package zendesk.core;

import android.content.Context;
import androidx.annotation.RestrictTo;
import dagger.Module;
import dagger.Provides;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;

/**
 * Module holding references to internal dependencies.
 */
@Module
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class CoreModule {

    private final SettingsProvider settingsProvider;
    private final RestServiceProvider restServiceProvider;
    private final BlipsProvider blipsProvider;
    private final SessionStorage sessionStorage;
    private final NetworkInfoProvider networkInfoProvider;
    private final Context applicationContext;
    private final ActionHandlerRegistry actionHandlerRegistry;
    private final MemoryCache memoryCache;
    private final ScheduledExecutorService executor;
    private final AuthenticationProvider authenticationProvider;
    private final ApplicationConfiguration applicationConfiguration;
    private final PushRegistrationProvider pushRegistrationProvider;
    private final MachineIdStorage machineIdStorage;

    CoreModule(SettingsProvider settingsProvider,
            RestServiceProvider restServiceProvider,
            BlipsProvider blipsProvider,
            SessionStorage sessionStorage,
            NetworkInfoProvider networkInfoProvider,
            Context applicationContext,
            ActionHandlerRegistry actionHandlerRegistry,
            MemoryCache memoryCache,
            ScheduledExecutorService executor,
            AuthenticationProvider authenticationProvider,
            ApplicationConfiguration applicationConfiguration,
            PushRegistrationProvider pushRegistrationProvider,
            MachineIdStorage machineIdStorage) {
        this.settingsProvider = settingsProvider;
        this.restServiceProvider = restServiceProvider;
        this.blipsProvider = blipsProvider;
        this.sessionStorage = sessionStorage;
        this.networkInfoProvider = networkInfoProvider;
        this.applicationContext = applicationContext;
        this.actionHandlerRegistry = actionHandlerRegistry;
        this.memoryCache = memoryCache;
        this.executor = executor;
        this.authenticationProvider = authenticationProvider;
        this.applicationConfiguration = applicationConfiguration;
        this.pushRegistrationProvider = pushRegistrationProvider;
        this.machineIdStorage = machineIdStorage;
    }

    @Provides
    SettingsProvider getSettingsProvider() {
        return settingsProvider;
    }

    @Provides
    RestServiceProvider getRestServiceProvider() {
        return restServiceProvider;
    }

    @Provides
    BlipsProvider getBlipsProvider() {
        return blipsProvider;
    }

    @Provides
    SessionStorage getSessionStorage() {
        return sessionStorage;
    }

    @Provides
    AuthenticationProvider getAuthenticationProvider() {
        return authenticationProvider;
    }

    @Provides
    NetworkInfoProvider getNetworkInfoProvider() {
        return networkInfoProvider;
    }

    @Provides
    ActionHandlerRegistry actionHandlerRegistry() {
        return actionHandlerRegistry;
    }

    @Provides
    MemoryCache getMemoryCache() {
        return memoryCache;
    }

    @Provides
    Context getApplicationContext() {
        return applicationContext;
    }

    @Provides
    ExecutorService getExecutorService() {
        return executor;
    }

    @Provides
    ScheduledExecutorService getScheduledExecutorService() {
        return executor;
    }

    @Provides
    Executor getExecutor() {
        return executor;
    }

    @Provides
    ApplicationConfiguration getApplicationConfiguration() {
        return applicationConfiguration;
    }

    @Provides
    PushRegistrationProvider getPushRegistrationProvider() {
        return pushRegistrationProvider;
    }

    @Provides
    MachineIdStorage getMachineIdStorage() {
        return machineIdStorage;
    }
}
