package zendesk.core;

import android.content.SharedPreferences;
import java.util.UUID;

/**
 * Implementation of {@link MachineIdStorage}
 */
public class ZendeskMachineIdStorage implements MachineIdStorage {

    private static final String MACHINE_ID_KEY = "machine_id_key";

    private final SharedPreferences sharedPreferences;

    public ZendeskMachineIdStorage(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
    }

    /**
     * Generates, stores and returns a {@link UUID} string to uniquely identify the host app install.
     * Note: This identifier lives until the host app is deleted. It is generated and returned on first call of
     * this API and then just returned on future calls.
     *
     * @return The machine id that already stored and identified the install.
     */
    @Override
    public String getMachineId() {
        String machineId = sharedPreferences.getString(MACHINE_ID_KEY, null);
        if (machineId != null && !machineId.isEmpty()) {
            return machineId;
        }
        return generateMachineId();
    }

    /**
     * Generate and stores a {@link UUID} string to uniquely identify the host app install.
     *
     * @return The generated {@link UUID}.
     */
    private String generateMachineId() {
        String generateMachineId = UUID.randomUUID().toString();
        sharedPreferences.edit().putString(MACHINE_ID_KEY, generateMachineId).apply();
        return generateMachineId;
    }
}
