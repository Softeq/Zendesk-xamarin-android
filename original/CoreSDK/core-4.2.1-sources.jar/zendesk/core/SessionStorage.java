package zendesk.core;

import java.io.File;

/**
 * Class holding storage that is tied to a user. Likely to be cleared after an user logs out or
 * the identity changes.
 */
public interface SessionStorage {

    /**
     * Gets a reference to additional sdk storage
     *
     * @return reference to the additional sdk storage
     */
    BaseStorage getAdditionalSdkStorage();

    /**
     * Gets the absolute path to Core SDK specific cache directory.
     */
    File getZendeskCacheDir();

    /**
     * Gets the absolute path to Core SDK specific data directory.
     */
    File getZendeskDataDir();

    /**
     * Clear all session related data.
     */
    void clear();

}
