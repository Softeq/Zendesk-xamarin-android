package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Cache for storing data at the application level to survive config changes,
 * prevents pollution of the parcelable buffers when handing larger objects.
 * <p>
 * Entries here might removed for any reason so don't use for passing objects
 * required objects across components
 * <p>
 * Implementations should have a max size to prevent runaway caching size.
 * <p>
 * Should only be used for caching data objects, DON'T PUT BITMAPS HERE
 */
public interface MemoryCache {

    @Nullable
    @SuppressWarnings("unchecked")
    <T> T get(@NonNull String key);

    @NonNull
    <T> T getOrDefault(@NonNull String key, T defaultData);

    boolean contains(@NonNull String key);

    void put(@NonNull String key, Object data);

    void remove(@NonNull String key);

    void clear();
}
