package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.JsonElement;

import java.util.List;
import java.util.Map;

/**
 * Defines an interface for a registry of {@link ActionHandler} objects to be used for inter-SDK
 * actions, such as starting an {@link android.app.Activity} from one SDK, in another SDK, without
 * any dependency between them.
 * <p>
 * {@link ActionHandler} objects can be added and removed from the registry using
 * {@link ActionHandlerRegistry#add(ActionHandler)} and
 * {@link ActionHandlerRegistry#remove(ActionHandler)}, respectively. A query method,
 * {@link ActionHandlerRegistry#handlerByAction(String)}, returns the highest priority
 * {@link ActionHandler} whose {@link ActionHandler#canHandle(String)} returned true.
 */
public interface ActionHandlerRegistry {

    /**
     * Adds an {@link ActionHandler} to the registry.
     *
     * @param actionHandler the ActionHandler to add to the registry.
     */
    void add(@NonNull ActionHandler actionHandler);

    /**
     * Removes an {@link ActionHandler} from the registry.
     *
     * @param actionHandler the ActionHandler to remove from the registry.
     */
    void remove(@NonNull ActionHandler actionHandler);

    /**
     * Removes all {@link ActionHandler}s from the registry.
     */
    void clear();

    /**
     * Finds and returns the highest priority {@link ActionHandler} whose
     * {@link ActionHandler#canHandle(String)} method returned true for the given action String, or
     * null if no {@link ActionHandler}s returned true.
     *
     * @param actionName the action String with which to query the {@link ActionHandler}s in the
     *                   registry.
     * @return the highest priority {@link ActionHandler} whose
     * {@link ActionHandler#canHandle(String)} method returned true, or null if no {@link ActionHandler}s
     * returned true.
     */
    @Nullable
    ActionHandler handlerByAction(@NonNull String actionName);

    /**
     * Finds and returns a priority ordered list of {@link ActionHandler} whose
     * {@link ActionHandler#canHandle(String)} method returned true for the given action String,
     * or an empty list if no {@link ActionHandler}s returned true.
     *
     * @param actionName the action String with which to query the {@link ActionHandler}s in the
     *                   registry.
     * @return A priority ordered list of {@link ActionHandler} whose
     * {@link ActionHandler#canHandle(String)} method returned true, or an empty list if no {@link ActionHandler}s
     * returned true.
     */
    @NonNull
    List<ActionHandler> handlersByAction(@NonNull String actionName);

    /**
     * Notifies the Registry of an update to settings. These will be passed to each of the ActionHandlers via the
     * {@link ActionHandler#updateSettings(Map)} method. These settings allows the ActionHandlers to determine
     * whether they should be enabled.
     *
     * @param settings a map representing the SDK settings for the current instance. This will contain settings for
     *                 each of the SDKs enabled for this account.
     */
    void updateSettings(Map<String, JsonElement> settings);
}
