package zendesk.core;

import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.zendesk.util.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Implementation of {@link SettingsStorage} using Android's {@link SharedPreferences} as
 * layer of persistence and {@link Gson} for serializing/deserializing objects.
 */
class ZendeskSettingsStorage implements SettingsStorage {

    private static final String LAST_UPDATE = "last_settings_update";
    private static final String RAWSETTTINGS_KEYSET = "rawsettings_keyset";

    private final BaseStorage settingsStorage;

    ZendeskSettingsStorage(BaseStorage settingsStorage) {
        this.settingsStorage = settingsStorage;
    }

    @Override
    public <E> E getSettings(@NonNull String key, @NonNull Class<E> clazz) {
        synchronized (settingsStorage) {
            return settingsStorage.get(key, clazz);
        }
    }

    @Override
    public void clear() {
        synchronized (settingsStorage) {
            settingsStorage.clear();
        }
    }

    @Override
    public void storeRawSettings(@NonNull Map<String, JsonElement> rawSettings) {
        synchronized (settingsStorage) {
            settingsStorage.put(LAST_UPDATE, System.currentTimeMillis());

            for (Map.Entry<String, JsonElement> entry : rawSettings.entrySet()) {
                settingsStorage.put(entry.getKey(), entry.getValue());
            }

            settingsStorage.put(RAWSETTTINGS_KEYSET, rawSettings.keySet());
        }
    }

    @Override
    public Map<String, JsonElement> getRawSettings() {
        synchronized (settingsStorage) {

            Map<String, JsonElement> rawSettings = new HashMap<>();

            @SuppressWarnings("unchecked")
            Set<String> keySet = settingsStorage.get(RAWSETTTINGS_KEYSET, Set.class);

            if (keySet != null) {
                for (String key: keySet) {
                    if (key != null) {
                        rawSettings.put(key, settingsStorage.get(key, JsonElement.class));
                    }
                }
            }

            return rawSettings;
        }
    }

    @Override
    public boolean hasStoredSettings() {
        synchronized (settingsStorage) {
            return StringUtils.hasLength(settingsStorage.get(LAST_UPDATE));
        }
    }

    @Override
    public boolean areSettingsUpToDate(long duration, @NonNull TimeUnit timeUnit) {
        final Long lastDownloaded;
        synchronized (settingsStorage) {
            lastDownloaded = settingsStorage.get(LAST_UPDATE, Long.class);
        }

        //noinspection SimplifiableIfStatement
        if (lastDownloaded == null || lastDownloaded == -1L) {
            return false;
        }

        final long durationAsMillis = TimeUnit.MILLISECONDS.convert(duration, timeUnit);
        return (System.currentTimeMillis() - lastDownloaded) < durationAsMillis;
    }

}
