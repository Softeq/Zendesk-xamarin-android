package zendesk.core;

import java.util.HashMap;
import java.util.Map;

/**
 * This model class is used to update user fields of the logged in user.
 */
@SuppressWarnings({"unused", "FieldCanBeLocal"})
class UserFieldRequest {

    private final Map<String, Map<String, String>> user;

    /**
     * Creates an instance with the specified mapping from field names to field values.
     *
     * @param user The fields to set
     */
    UserFieldRequest(final Map<String, String> user) {
        final Map<String, Map<String, String>> maps = new HashMap<>();
        maps.put("user_fields", user);

        this.user = maps;
    }
}
