package zendesk.core;

import java.util.List;

/**
 * Models the api request which is formed when adding tags to a user.
 */
@SuppressWarnings({"unused", "FieldCanBeLocal"})
class UserTagRequest {

    private List<String> tags;

    UserTagRequest(List<String> tags) {
        this.tags = tags;
    }
}
