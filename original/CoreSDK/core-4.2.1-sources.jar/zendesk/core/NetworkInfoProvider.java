package zendesk.core;

import androidx.annotation.NonNull;

/**
 * A provider which will provide information about network connectivity.
 * <p>
 * It must be registered (using the {@link NetworkInfoProvider#register()} method) to begin listening
 * for network changes, and unregistering (using the {@link NetworkInfoProvider#unregister()} method)
 * will stop it from receiving any more network changes.
 * <p>
 * No changes will be received before the {@link NetworkInfoProvider#register()} method has been called,
 * or after the {@link NetworkInfoProvider#unregister()} method has been called.
 * <p>
 * It provides a simple synchronous method, isNetworkAvailable, which returns a boolean, as well as
 * an interface for adding {@link NetworkAware} listeners to be notified when the network state
 * changes.
 * <p>
 * It also allows for adding {@link RetryAction} objects, which will be next time a network becomes
 * available.
 */
public interface NetworkInfoProvider {

    /**
     * Begin listening for network change events.
     */
    void register();

    /**
     * Stop listening for network change events.
     */
    void unregister();

    /**
     * Returns whether or not the network is currently available.
     *
     * @return true if the network is currently available, false if not.
     */
    boolean isNetworkAvailable();

    /**
     * Add a {@link NetworkAware} listener object, which will receive updates to the network state
     * via {@link NetworkAware#onNetworkAvailable()} and {@link NetworkAware#onNetworkUnavailable()}
     * as long as the {@link NetworkInfoProvider} is currently in a registered state.
     * The {@link NetworkAware} will continue to receive updates as the network availability changes until either
     * it is removed, or the {@link NetworkInfoProvider#unregister()} method is called.
     *
     * @param id       the ID to use for this listener. The same ID should be used when removing the listener in
     *                 {@link NetworkInfoProvider#removeNetworkAwareListener(Integer)}
     * @param listener the {@link NetworkAware} listener object to be notified of network change events.
     */
    void addNetworkAwareListener(@NonNull Integer id, @NonNull NetworkAware listener);

    /**
     * Remove a {@link NetworkAware} listener object so that it will no longer receive updates to
     * network state.
     *
     * @param id the ID for the {@link NetworkAware} listener object to stop notifying.
     */
    void removeNetworkAwareListener(@NonNull Integer id);

    /**
     * Clear all added {@link NetworkAware} listener objects. Any {@link NetworkAware} listeners
     * previously added will no longer receive updates after this method is called, unless they are
     * added again via {@link NetworkInfoProvider#addNetworkAwareListener(Integer, NetworkAware)}.
     */
    void clearNetworkAwareListeners();

    /**
     * Add a {@link RetryAction}, whose {@link RetryAction#onRetry()} method will be called the next
     * time the provider is notified with network availability. After being invoked, the
     * {@link RetryAction} is removed from the list and will not be invoked again.
     * The {@link RetryAction} will only be invoked if the provider is currently in a registered
     * state.
     *
     * @param id          the ID to use for this {@link RetryAction}. The same ID should be used when removing
     *                    the {@link RetryAction} in {@link NetworkInfoProvider#removeRetryAction(Integer)}
     * @param retryAction the {@link RetryAction} to invoke and remove, the next time the provider
     *                    receives a positive network availability update.
     */
    void addRetryAction(@NonNull Integer id, @NonNull RetryAction retryAction);

    /**
     * Remove a {@link RetryAction} so that it will not be invoked next time the provider is notified
     * with network availability.
     *
     * @param id the ID for the {@link RetryAction} to remove.
     */
    void removeRetryAction(@NonNull Integer id);

    /**
     * Clear all added {@link RetryAction} objects. Any {@link RetryAction} listeners previously added
     * will no longer be invoked after this method has been called, unless they are added again via
     */
    void clearRetryActions();
}
