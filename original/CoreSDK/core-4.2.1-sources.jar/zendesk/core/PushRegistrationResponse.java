package zendesk.core;

import androidx.annotation.Nullable;

/**
 * This is a class model for a response for registering a device for push notifications. This object
 * will be created by {@link zendesk.core.ZendeskPushRegistrationProvider}
 */
@SuppressWarnings({"unused"})
class PushRegistrationResponse {

    private String identifier;

    /**
     * Get the device-specific identifier
     *
     * @return The device-specific identifier
     */
    @Nullable
    String getIdentifier() {
        return identifier;
    }
}
