package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.StringUtils;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * This class is responsible for mapping between Java locales and the representations
 * of locales that Help Center expects.
 * <p>
 * There are two large classes of remappings that need to be done:
 *
 * <ol>
 * <li>Mapping of legacy Java locales (iw, in, ji) to their modern counterparts (he, id, yi)</li>
 * <li>Mapping of locales in Help Center that are different to Java (nb -> no)</li>
 * </ol>
 * </p>
 * <p>
 * Created by Zendesk on 12/05/2016.
 *
 * @see <a href="http://developer.android.com/reference/java/util/Locale.html"></a>
 */
public class ZendeskLocaleConverter {

    private static final Map<String, String> forwardLookupMap;

    static {
        forwardLookupMap = new HashMap<>();

        forwardLookupMap.put("iw", "he");   // Hebrew
        forwardLookupMap.put("nb", "no");   // Norwegian
        forwardLookupMap.put("in", "id");   // Indonesian
        forwardLookupMap.put("ji", "yi");   // Yiddish
    }

    /**
     * Converts the specified locale into a string version which Help Center expects.
     *
     * @param locale The locale to convert. If it is null, or if its language is null, then the
     *               default locale will be used
     * @return The string representation of the Locale.
     */
    @NonNull
    public String toHelpCenterLocaleString(@Nullable Locale locale) {

        boolean isUsableLocale = locale != null && StringUtils.hasLength(locale.getLanguage());

        Locale deviceLocale = isUsableLocale ? locale : Locale.getDefault();

        String remappedLanguage = forwardLookupMap.get(deviceLocale.getLanguage());

        StringBuilder localeBuilder = new StringBuilder(
                StringUtils.hasLength(remappedLanguage)
                        ? remappedLanguage
                        : deviceLocale.getLanguage()
        );

        if (StringUtils.hasLength(deviceLocale.getCountry())) {
            localeBuilder
                    .append("-")
                    .append(deviceLocale.getCountry());
        }

        return localeBuilder.toString().toLowerCase();
    }
}
