package zendesk.core;

import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.Date;

/**
 * Models the SDK settings.
 */
@SuppressWarnings("unused")
class SdkSettings implements Serializable {

    private String authentication;

    private Date updatedAt;

    /**
     * Returns when the configuration was last updated
     * <p>
     * This date is deserialised from a UTC timestamp but the returned Date will be in the
     * device's local time.
     * </p>
     *
     * @return when the configuration was last updated
     */
    @Nullable
    Date getUpdatedAt() {
        return updatedAt == null ? null : new Date(updatedAt.getTime());
    }

    /**
     * Returns the authentication type enabled for the App configuration
     * <p>
     * Can be one of the following two values:
     * <ul>
     * <li>jwt</li>
     * <li>anonymous</li>
     * </ul>
     *
     * @return the authentication type for the app configuration
     */
    @Nullable
    AuthenticationType getAuthentication() {
        return AuthenticationType.getAuthType(authentication);
    }
}