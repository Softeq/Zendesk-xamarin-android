package zendesk.core;

import androidx.annotation.RestrictTo;

/**
 * Class holding the minimum SDK configuration.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ApplicationConfiguration {

    private String applicationId;
    private String zendeskUrl;
    private String oauthClientId;

    /**
     * Create an instance of {@code ApplicationConfiguration}
     *
     * @param applicationId an app id
     * @param zendeskUrl    a valid zendesk url
     * @param oauthClientId an oAuth token
     */
    public ApplicationConfiguration(String applicationId, String zendeskUrl, String oauthClientId) {
        this.applicationId = applicationId;
        this.zendeskUrl = zendeskUrl;
        this.oauthClientId = oauthClientId;
    }

    /**
     * Gets the App ID
     *
     * @return an app id
     */
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * Gets the configured zendesk url
     *
     * @return a zendesk url
     */
    public String getZendeskUrl() {
        return zendeskUrl;
    }

    /**
     * Gets an Oauth client id
     *
     * @return a client id
     */
    public String getOauthClientId() {
        return oauthClientId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ApplicationConfiguration that = (ApplicationConfiguration) o;

        if (applicationId != null ? !applicationId.equals(that.applicationId) : that.applicationId != null) {
            return false;
        }
        if (zendeskUrl != null ? !zendeskUrl.equals(that.zendeskUrl) : that.zendeskUrl != null) {
            return false;
        }
        return oauthClientId != null ? oauthClientId.equals(that.oauthClientId) : that.oauthClientId == null;

    }

    @Override
    public int hashCode() {
        int result = applicationId != null ? applicationId.hashCode() : 0;
        result = 31 * result + (zendeskUrl != null ? zendeskUrl.hashCode() : 0);
        result = 31 * result + (oauthClientId != null ? oauthClientId.hashCode() : 0);
        return result;
    }
}
