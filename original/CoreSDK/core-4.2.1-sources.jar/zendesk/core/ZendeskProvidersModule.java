package zendesk.core;

import android.content.Context;
import android.net.ConnectivityManager;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;
import dagger.Reusable;
import retrofit2.Retrofit;

import static zendesk.core.ZendeskApplicationModule.BASE_64_SERIALIZER;
import static zendesk.core.ZendeskStorageModule.GSON_SERIALIZER;

/**
 * A module defining the dependency providers for API providers. Note that the provide* methods in the module are not
 * intended to be called directly.
 * <p>
 * Created by Zendesk on 06/09/2016.
 */
@Module
class ZendeskProvidersModule {

    /**
     * Provides an instance of the user service
     *
     * @param retrofit The instance of retrofit used to create the service
     * @return An instance of the user service
     */
    @Provides
    @Reusable
    static UserService provideUserService(@Named(ZendeskNetworkModule.STANDARD_RETROFIT) Retrofit retrofit) {
        return retrofit.create(UserService.class);
    }

    /**
     * Provides an instance of the sdk settings service
     *
     * @param retrofit The instance of retrofit used to create the service
     * @return An instance of the sdk settings service
     */
    @Provides
    @Reusable
    static SdkSettingsService provideSdkSettingsService(@Named(ZendeskNetworkModule.CORE_RETROFIT) Retrofit retrofit) {
        return retrofit.create(SdkSettingsService.class);
    }

    /**
     * Provides an instance of the access service
     *
     * @param retrofit The instance of retrofit used to create the service
     * @return An instance of the access service
     */
    @Provides
    @Reusable
    static AccessService provideAccessService(@Named(ZendeskNetworkModule.CORE_RETROFIT) Retrofit retrofit) {
        return retrofit.create(AccessService.class);
    }

    /**
     * Provides an instance of the push registration service
     *
     * @param retrofit The instance of retrofit used to create the service
     * @return An instance of the push registration service
     */
    @Provides
    @Reusable
    static PushRegistrationService providePushRegistrationService(@Named(ZendeskNetworkModule.PUSH_PROVIDER_RETROFIT)
            Retrofit retrofit) {
        return retrofit.create(PushRegistrationService.class);
    }

    /**
     * Provides an instance of the user provider `
     *
     * @param userService An instance of the user service
     * @return An instance of the user provider
     */
    @Provides
    @Singleton
    static UserProvider provideUserProvider(UserService userService) {
        return new ZendeskUserProvider(userService);
    }

    @Provides
    @Singleton
    static BlipsService provideBlipsService(@Named(ZendeskNetworkModule.CORE_RETROFIT) Retrofit retrofit) {
        return retrofit.create(BlipsService.class);
    }


    /**
     * Provides an instance of the sdk settings provider
     *
     * @param sdkSettingsService An instance of the sdk settings service
     * @param settingsStorage    An instance of the sdk settings storage
     * @param configuration      An instance of the application configuration
     * @return An instance of the sdk settings provider
     */
    @Provides
    @Singleton
    static ZendeskSettingsProvider provideZendeskSdkSettingsProvider(
            SdkSettingsService sdkSettingsService,
            SettingsStorage settingsStorage,
            CoreSettingsStorage coreSettingsStorage,
            ActionHandlerRegistry actionHandlerRegistry,
            @Named(GSON_SERIALIZER) Serializer serializer,
            ZendeskLocaleConverter zendeskLocaleConverter,
            ApplicationConfiguration configuration,
            @Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context) {
        return new ZendeskSettingsProvider(
                sdkSettingsService,
                settingsStorage,
                coreSettingsStorage,
                actionHandlerRegistry,
                serializer,
                zendeskLocaleConverter,
                configuration.getApplicationId(),
                context);
    }

    @Provides
    @Singleton
    static SettingsProvider provideSdkSettingsProvider(ZendeskSettingsProvider sdkSettingsProvider) {
        return sdkSettingsProvider;
    }

    @Provides
    @Singleton
    static SdkSettingsProviderInternal provideSdkSettingsProviderInternal(ZendeskSettingsProvider sdkSettingsProvider) {
        return sdkSettingsProvider;
    }

    /**
     * Provides an instance of the access provider
     *
     * @param identityManager An instance of identity manager
     * @param accessService   An instance of the access service
     * @return An instance of the access provider
     */
    @Provides
    @Singleton
    static AccessProvider provideAccessProvider(IdentityManager identityManager,
            AccessService accessService) {
        return new ZendeskAccessProvider(identityManager, accessService);
    }

    /**
     * Provides an instance of the push registration provider
     *
     * @param pushRegistrationService An instance of the push registration service
     * @param identityManager         An identity manager
     * @return An instance of the push registration provider
     */
    @Provides
    @Singleton
    static PushRegistrationProvider providePushRegistrationProvider(
            PushRegistrationService pushRegistrationService,
            IdentityManager identityManager,
            SettingsProvider settingsProvider,
            BlipsCoreProvider blipsProvider,
            PushDeviceIdStorage pushDeviceIdStorage,
            @Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context) {
        return new ZendeskPushRegistrationProvider(pushRegistrationService, identityManager,
                settingsProvider, blipsProvider, pushDeviceIdStorage, DeviceInfo.getCurrentLocale(context));
    }

    @Provides
    @Singleton
    static PushRegistrationProviderInternal providePushRegistrationProviderInternal(
            PushRegistrationProvider pushRegistrationProvider) {
        return (ZendeskPushRegistrationProvider) pushRegistrationProvider;
    }

    /**
     * Provides an instance of the network information provider
     *
     * @return An instance of the network information provider
     */
    @Provides
    @Singleton
    static NetworkInfoProvider providerNetworkInfoProvider(
            ConnectivityManager connectivityManager) {
        return new ZendeskNetworkInfoProvider(connectivityManager);
    }

    @Provides
    @Singleton
    static ConnectivityManager providerConnectivityManager(
            @Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context) {
        return (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
    }

    @Provides
    @Singleton
    static ZendeskBlipsProvider providerZendeskBlipsProvider(BlipsService blipsService,
            DeviceInfo deviceInfo,
            @Named(BASE_64_SERIALIZER) Serializer serializer,
            IdentityManager identityManager,
            ApplicationConfiguration applicationConfiguration,
            CoreSettingsStorage coreSettingsStorage,
            ExecutorService executor) {
        return new ZendeskBlipsProvider(blipsService, deviceInfo, serializer,
                identityManager, applicationConfiguration.getApplicationId(), coreSettingsStorage, executor);
    }

    @Provides
    @Singleton
    static BlipsCoreProvider providerBlipsCoreProvider(ZendeskBlipsProvider zendeskBlipsProvider) {
        return zendeskBlipsProvider;
    }

    @Provides
    @Singleton
    static BlipsProvider providerBlipsProvider(ZendeskBlipsProvider zendeskBlipsProvider) {
        return zendeskBlipsProvider;
    }

    /**
     * Provides an instance of the provider store, which contains all of the providers available to implementers of the
     * SDK
     *
     * @param userProvider             An instance of the user provider
     * @param pushRegistrationProvider An instance of the push registration provider
     * @return An instance of the provider store, which contains all of the providers available to implementers of the
     *         SDK
     */
    @Provides
    @Singleton
    static ProviderStore provideProviderStore(UserProvider userProvider,
            PushRegistrationProvider pushRegistrationProvider) {
        return new ZendeskProviderStore(userProvider, pushRegistrationProvider);
    }

    @Provides
    @Singleton
    static ActionHandlerRegistry actionHandlerRegistry() {
        return Zendesk.INSTANCE.actionHandlerRegistry();
    }

    @Provides
    @Reusable
    static CoreModule provideCoreSdkModule(SettingsProvider settingsProvider,
            RestServiceProvider restServiceProvider,
            BlipsProvider blipsProvider,
            SessionStorage sessionStorage,
            NetworkInfoProvider networkInfoProvider,
            MemoryCache memoryCache,
            ActionHandlerRegistry actionHandlerRegistry,
            ScheduledExecutorService executor,
            @Named(ZendeskApplicationModule.APPLICATION_CONTEXT) Context context,
            AuthenticationProvider authenticationProvider,
            ApplicationConfiguration zendeskConfiguration,
            PushRegistrationProvider pushRegistrationProvider,
            MachineIdStorage machineIdStorage) {
        return new CoreModule(settingsProvider, restServiceProvider, blipsProvider,
                sessionStorage, networkInfoProvider,
                context, actionHandlerRegistry, memoryCache, executor, authenticationProvider, zendeskConfiguration,
                pushRegistrationProvider, machineIdStorage);
    }

}
