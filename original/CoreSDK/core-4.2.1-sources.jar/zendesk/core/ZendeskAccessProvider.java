package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

import java.io.IOException;

import retrofit2.Response;

class ZendeskAccessProvider implements AccessProvider {

    private static final String LOG_TAG = "ZendeskAccessProvider";

    private final AccessService accessService;
    private final IdentityManager identityManager;

    ZendeskAccessProvider(
            @NonNull final IdentityManager identityManager,
            @NonNull final AccessService accessService) {
        this.identityManager = identityManager;
        this.accessService = accessService;
    }

    @Override
    public Response<AuthenticationResponse> getAuthTokenViaAnonymous(@NonNull AnonymousIdentity identity) {
        Logger.d(LOG_TAG, "Requesting an access token for anonymous identity.");

        try {
            final AuthenticationRequestWrapper wrapper = new AuthenticationRequestWrapper(
                    new ApiAnonymousIdentity(identity, identityManager.getSdkGuid()));
            return accessService.getAuthTokenForAnonymous(wrapper).execute();
        } catch (IOException e) {
            Logger.e(LOG_TAG, e.getMessage(), e);
            return null;
        }
    }

    @Nullable
    @Override
    public Response<AuthenticationResponse> getAuthTokenViaJwt(@NonNull JwtIdentity jwtIdentity) {
        Logger.d(LOG_TAG, "Requesting an access token for jwt identity.");

        /*
          If we don't have a valid JWT identity at this point we shouldn't bother reaching
          out to the server as there is no way it will work and this is a lot more obvious
          than getting a HTTP status code back which doesn't explain anything.
         */
        if (StringUtils.isEmpty(jwtIdentity.getJwtUserIdentifier())) {

            // Do not change this error
            Logger.e(LOG_TAG, NO_JWT_ERROR_MESSAGE);

            return null;
        }

        try {
            AuthenticationRequestWrapper wrapper = new AuthenticationRequestWrapper(jwtIdentity);
            return accessService.getAuthTokenForJwt(wrapper).execute();
        } catch (IOException e) {
            Logger.e(LOG_TAG, e.getMessage(), e);
            return null;
        }

    }

}
