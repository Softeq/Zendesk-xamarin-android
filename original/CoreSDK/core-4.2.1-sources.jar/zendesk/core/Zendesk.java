package zendesk.core;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

/**
 * Configuration class for Zendesk Core SDK initialization. Call this first to configure Zendesk
 * to use the correct credentials and Zendesk URL.
 */
public enum Zendesk {

    /**
     * The instance of zendesk configured using {@link #init(Context, String, String, String)}. If init was not
     * called first then all other operations will fail.
     */
    INSTANCE;

    private static final String LOG_TAG = "Zendesk";

    private ActionHandlerRegistry actionHandlerRegistry = new ZendeskActionHandlerRegistry();
    private ZendeskShadow zendeskShadow;

    /**
     * Initialises the Zendesk Core SDK with your Zendesk subdomain settings and an {@link Identity}.
     * <p>
     * <p>
     * This requires some authentication settings. Your zendeskUrl must be your full Zendesk URL in the form
     * of <b>https://{subdomain.zendesk.com</b>
     * You should replace {subdomain} with your own subdomain.
     * </p>
     * <p>
     * This method is idempotent; calling it more than once with the same values will have no
     * effect. If called with any changed values, it will result in fresh instances of all
     * providers being created. Any references to providers previously obtained from the
     * {@link ProviderStore} via {@link Zendesk#provider()} should be discarded and re-obtained.
     * </p>
     * <p>
     * Before the SDK can used a valid {@link Identity} ust be set using the {@link #setIdentity(Identity)} method.
     * </p>
     *
     * @param context       A context, used for initialising stored settings
     * @param zendeskUrl    The full URL of your Zendesk instance, https://{subdomain}.zendesk.com
     * @param applicationId The application id of your SDK app, as found in the web interface
     * @param oauthClientId The oauth client id that was supplied when you set up oauth in the
     *                      web interface
     */
    public void init(@NonNull Context context,
                     @NonNull String zendeskUrl,
                     @NonNull String applicationId,
                     String oauthClientId) {
        checkConfig(context, zendeskUrl, applicationId, oauthClientId);

        ApplicationConfiguration configuration = new ApplicationConfiguration(applicationId, zendeskUrl, oauthClientId);

        // initialize dependency graph
        ZendeskApplicationComponent component = DaggerZendeskApplicationComponent.builder()
                .zendeskApplicationModule(new ZendeskApplicationModule(context, configuration))
                .build();

        init(component, configuration);
    }

    /**
     * Used in testing for mocking out parts of the dagger component.
     */
    @VisibleForTesting
    void init(ZendeskApplicationComponent component, ApplicationConfiguration configuration) {

        boolean initialised = zendeskShadow != null;

        if (initialised) {
            zendeskShadow.cleanupIfNewConfig(configuration);
        }

        ZendeskShadow zendeskShadow = component.zendeskShadow();
        zendeskShadow.init(configuration, initialised);
        this.zendeskShadow = zendeskShadow;
    }

    /**
     * Not public intentionally. This method allows us to teardown the object and must only
     * be used for testing. If you make this public this kitten will die. Do you want that on
     * your conscience?
     * 　 ／l、
     * ﾞ（ﾟ､ ｡ ７
     * 　l、ﾞ ~ヽ
     * 　じしf_, )ノ
     */
    @VisibleForTesting
    void reset() {
        if (isInitialized()) {
            zendeskShadow.reset();
            zendeskShadow = null;
            Logger.i(LOG_TAG, "Tearing down Zendesk");
        } else {
            Logger.i(LOG_TAG, "Cant reset, Zendesk is uninitialized");
        }
    }

    /**
     * Gets whether {@link #init(Context, String, String, String)} was called with valid
     * values or not.
     *
     * @return true if init was successfully called, false otherwise.
     */
    public boolean isInitialized() {
        return zendeskShadow != null;
    }

    @VisibleForTesting
    static boolean checkConfig(Context context, String zendeskUrl, String applicationId, String oauthClientId) {
        if (context == null || !StringUtils.hasLengthMany(zendeskUrl, applicationId, oauthClientId)) {
            String message = String.format(
                    "Invalid zendesk configuration provided | Context: %b | Url: %b | Application Id: %b | "
                            + "OauthClientId: %b",
                    context,
                    StringUtils.hasLength(zendeskUrl),
                    StringUtils.hasLength(applicationId),
                    StringUtils.hasLength(oauthClientId));
            Logger.e(LOG_TAG, message);
            return false;
        } else {
            return true;
        }
    }

    /**
     * For internal use only. Gets the {@link ActionHandlerRegistry}. This is always available regardless of the init
     * state of Core so SDKs can register action handlers at start up.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public ActionHandlerRegistry actionHandlerRegistry() {
        return actionHandlerRegistry;
    }

    /**
     * For internal use only.
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    @Nullable
    public CoreModule coreModule() {
        if (!isInitialized()) {
            Logger.e(LOG_TAG, "Cannot get CoreModule before SDK has been initialized. init() must be " +
                    "called before coreModule().");
            return null;
        }
        return zendeskShadow.coreModule();
    }

    /**
     * Set the {@link Identity} for the SDK. If there is a previously stored Identity and this sets different
     * Identity any user data will be wiped
     * from the SDK.
     * <p>identity
     * This can be set multiple times with different valid identities
     * </p>
     */
    public void setIdentity(@NonNull Identity identity) {

        if (!isInitialized()) {
            Logger.e(LOG_TAG, "Cannot get set identity before SDK has been initialized. init() must be " +
                    "called before setIdentity(...).");
            return;
        }

        zendeskShadow.setIdentity(identity);
    }

    /**
     * Return the current {@link Identity} for the SDK, or null if none has been set.
     *
     * @return the current {@link Identity}, or null if none has been set.
     */
    @Nullable
    public Identity getIdentity() {
        if (!isInitialized()) {
            return null;
        }
        return zendeskShadow.getIdentity();
    }

    /**
     * Gets a {@link ProviderStore} for accessing all available
     * SDK Providers.
     *
     * @return an instance of {@link ProviderStore}, or {@code null} if Zendesk wasn't initialized.
     */
    @Nullable
    public ProviderStore provider() {

        if (!isInitialized()) {
            Logger.e(LOG_TAG, "Cannot get ProviderStore before SDK has been initialized. init() must be " +
                    "called before provider().");
            return null;
        }

        if (getIdentity() == null) {
            Logger.e(LOG_TAG, "Cannot get ProviderStore before an identity has been set. " +
                    "Zendesk.INSTANCE.setIdentity() must be called before provider().");
            return null;
        }

        return zendeskShadow.providers();
    }
}
