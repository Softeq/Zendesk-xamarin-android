package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * This is a model class for a user field that will be created by the {@link UserProvider} as part
 * of {@link UserFieldResponse}.
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/core/user_fields">User fields</a>
 */
@SuppressWarnings({"unused"})
public class UserField {

    private Long id;
    private String url;
    private String key;
    private String title;
    private String description;
    private String rawTitle;
    private String rawDescription;
    private Long position;
    private Boolean active;
    private Boolean system;
    private String regexpForValidation;
    private Date createdAt;
    private Date updatedAt;
    private List<UserFieldOption> customFieldOptions;

    @SerializedName("type")
    private UserFieldType userFieldType;


    /**
     * Get the id of the user field.
     *
     * @return the id of the field
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the API URL of the user field
     *
     * @return the API URL of the user field
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Get the type of the user field.
     *
     * @return the type of the field
     */
    @Nullable
    public UserFieldType getUserFieldType() {
        return userFieldType;
    }

    /**
     * Get the unique key of the user field.
     *
     * <p>
     * Use this property for updating the user field by calling {@link UserProvider#setUserFields(Map, ZendeskCallback)}
     * </p>
     *
     * @return the unique key of the field
     */
    @Nullable
    public String getKey() {
        return key;
    }

    /**
     * Get the title of the user field.
     *
     * @return the title of the field
     */
    @Nullable
    public String getTitle() {
        return title;
    }

    /**
     * Get the description of the user field.
     *
     * @return the description of the field
     */
    @Nullable
    public String getDescription() {
        return description;
    }

    /**
     * Get the raw description of the user field.
     *
     * @return the raw description of the field
     */
    @Nullable
    public String getRawDescription() {
        return rawDescription;
    }

    /**
     * Gets the raw title of the user field
     *
     * @return the raw title of the user field
     */
    @Nullable
    public String getRawTitle() {
        return rawTitle;
    }

    /**
     * Gets the position of the user field
     *
     * @return the position of the user field
     */
    @Nullable
    public Long getPosition() {
        return position;
    }

    /**
     * Checks if the user field is active or not
     *
     * @return true if it is active, false otherwise
     */
    public boolean isActive() {
        return active != null && active;
    }

    /**
     * Checks if the user field is a system field or not
     *
     * @return @return true if it is system, false otherwise
     */
    public boolean isSystem() {
        return system != null && system;
    }

    /**
     * Gets the regexp which is used to validate the user field
     *
     * @return the regexp which is used to validate the user field
     */
    @Nullable
    public String getRegexpForValidation() {
        return regexpForValidation;
    }

    /**
     * Gets the date that the user field was created at
     *
     * @return the date that the user field was created at
     */
    @Nullable
    public Date getCreatedAt() {
        return createdAt == null ? null : new Date(createdAt.getTime());
    }

    /**
     * Gets the date that the user field was updated at
     *
     * @return the date that the user field was updated at
     */
    @Nullable
    public Date getUpdatedAt() {
        return updatedAt == null ? null : new Date(updatedAt.getTime());
    }

    /**
     * Get a list of {@link UserFieldOption}.
     *
     * <p>
     * Options for the custom user field. Only for Dropdown type of user fields.
     * </p>
     *
     * @return the list of user field options
     */
    @NonNull
    public List<UserFieldOption> getUserFieldOptions() {
        return CollectionUtils.copyOf(customFieldOptions);
    }

    /**
     * Enum for describing the type of a user field.
     */
    public enum UserFieldType {

        @SerializedName("integer")
        Integer,

        @SerializedName("decimal")
        Decimal,

        @SerializedName("checkbox")
        Checkbox,

        @SerializedName("date")
        Date,

        @SerializedName("text")
        Text,

        @SerializedName("textarea")
        Textarea,

        @SerializedName("dropdown")
        Dropdown,

        @SerializedName("regexp")
        Regexp
    }

}
