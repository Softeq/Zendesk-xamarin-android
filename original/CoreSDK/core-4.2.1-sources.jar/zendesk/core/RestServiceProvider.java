package zendesk.core;

import okhttp3.OkHttpClient;

/**
 * A Provider which is used to create RestApis for sub-SDKs. This is used internally by the Zendesk
 * SDKs and should not be used directly by integrators.
 */
public interface RestServiceProvider {

    /**
     * Create a RestApi from the provided class.
     * <br>
     * Uses the internal {@link retrofit2.Retrofit} instance to create
     * requested API.
     * <br>
     * This should not be used directly by integrators of the Zendesk SDKs.
     *
     * @param clazz the Retrofit service interface to create an implementation of
     * @param <E>   type of the returned api
     */
    <E> E createRestService(Class<E> clazz, String sdkVersion, String sdkVariant);

    /**
     * Create a RestApi from the provided class, with a configuration class for
     * custom network needs.
     * <br>
     * Uses the internal link {@link retrofit2.Retrofit} instance to create the requested API.
     * <br>
     * This should not be used directly by integrators of the Zendesdk SDKs.
     *
     * @param clazz               the Retrofit service interface to create an implementation of
     * @param customNetworkConfig a function object which can be used to add custom configuration to
     *                            the OkHttpClient and Retrofit instances used for the returned API.
     * @param <E>                 type of the returned API
     * @return an instance of a Retrofit service, with the provided customisation applied to its
     * underlying OkHttpClient and Retrofit instances.
     */
    <E> E createRestService(Class<E> clazz,
                            String sdkVersion,
                            String sdkVariant,
                            CustomNetworkConfig customNetworkConfig);

    /**
     * Create a RestApi from the provided class to send unauthenticated requests, with a configuration class for
     * custom network needs.
     * <br>
     * Uses the internal link {@link retrofit2.Retrofit} instance to create the requested API.
     * <br>
     * This should not be used directly by integrators of the Zendesdk SDKs.
     *
     * @param clazz               the Retrofit service interface to create an implementation of
     * @param sdkVersion          the version of SDK
     * @param sdkVariant          the variant of SDK
     * @param customNetworkConfig a function object which can be used to add custom configuration to
     *                            the OkHttpClient and Retrofit instances used for the returned API.
     * @param <E>                 type of the returned API
     * @return an instance of a Retrofit service, with the provided customisation applied to its
     * * underlying OkHttpClient and Retrofit instances.
     */
    <E> E createUnauthenticatedRestService(Class<E> clazz,
                                            String sdkVersion,
                                            String sdkVariant,
                                            CustomNetworkConfig customNetworkConfig);

    /**
     * Gets an {@link OkHttpClient} that's doing zendesk auth and is heavily caching responses.
     */
    OkHttpClient getMediaOkHttpClient();

    /**
     * Gets an {@link OkHttpClient} that's not doing zendesk auth and is not caching responses.
     */
    OkHttpClient getCoreOkHttpClient();

}
