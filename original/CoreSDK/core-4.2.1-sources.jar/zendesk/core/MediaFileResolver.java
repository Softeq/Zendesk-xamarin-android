package zendesk.core;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import android.webkit.MimeTypeMap;

import androidx.annotation.NonNull;

import com.zendesk.logger.Logger;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.inject.Inject;

/**
 * MediaFileUtility provides a set of utility methods to store, retrieve,
 * and create cache files for managing user media attachments.
 */
public class MediaFileResolver {

    private final Context context;

    private final static String MEDIA_FILE_PROVIDER_AUTHORITY_SUFFIX = ".zendesk.sdk.user.attachments";
    private final static String FILE_DIR_USER_MEDIA = "zendesk-user-media-data";
    private final static String FILE_DIR_MEDIA = "media";
    private final static String FILE_DIR_USER = "user";
    private final static String ATTACHMENT_NAME = "attachment_%s";
    private final static String CAMERA_DATETIME_STRING_FORMAT = "yyyyMMddHHmmssSSS";
    private final static String CAMERA_IMG_NAME = "camera_image_%s";
    private final static String CAMERA_IMG_SUFFIX = ".jpg";
    private final static String LOG_TAG = "MediaFileUtility";
    private static final String PATH_PLACEHOLDER = "%s%s%s";
    private static final String MEDIA_FORMATTED_BASE_PATH =
            String.format(Locale.US, PATH_PLACEHOLDER, "zendesk", File.separator, "support");
    private static final String REQUEST_FORMATTED_MEDIA_PATH =
            String.format(Locale.US, PATH_PLACEHOLDER, MEDIA_FORMATTED_BASE_PATH, File.separator, "request");


    @Inject
    MediaFileResolver(Context context) {
        this.context = context;
    }

    /**
     * Get a {@link File} for media from the gallery.
     *
     * @param uri          {@link Uri} to the media from the gallery
     * @param subDirectory Name of the sub directory where to put the file or {@code null} if not needed
     * @return The {@link File}
     */
    public File getFileForUri(Uri uri, String subDirectory) {
        final String path;
        if (!TextUtils.isEmpty(subDirectory)) {
            path = FILE_DIR_USER + File.separator + subDirectory;
        } else {
            path = FILE_DIR_MEDIA;
        }

        final File cacheDir = getAttachmentDir(path);

        if (cacheDir == null) {
            Log.w(LOG_TAG, "Error creating cache directory");
            return null;
        }

        String fileName = getFileNameFromUri(uri);
        String suffix = null;

        if (TextUtils.isEmpty(fileName)) {
            final SimpleDateFormat sdf = new SimpleDateFormat(CAMERA_DATETIME_STRING_FORMAT, Locale.US);
            fileName = String.format(Locale.US, ATTACHMENT_NAME, sdf.format(new Date(System.currentTimeMillis())));
            suffix = getExtension(uri, true);
        }

        return createTempFile(cacheDir, fileName, suffix);
    }

    /**
     * Try to get the file name of a {@link File} behind an {@link Uri}.
     * This method queries {@link ContentResolver} for the
     * {@link MediaStore.MediaColumns#DISPLAY_NAME} column the find the name of
     * the provided {@link Uri}.
     *
     * @param uri Link to the {@link Uri}
     * @return The name of the {@link File}, or an empty {@link String}
     */
    private String getFileNameFromUri(Uri uri) {
        final String schema = uri.getScheme();
        String path = "";

        if (ContentResolver.SCHEME_CONTENT.equals(schema)) {
            final String[] projection = {MediaStore.MediaColumns.DISPLAY_NAME};
            final ContentResolver contentResolver = context.getContentResolver();
            final Cursor cursor = contentResolver.query(uri, projection, null, null, null);

            if (cursor != null) {
                try {
                    if (cursor.moveToFirst()) {
                        path = cursor.getString(0);
                    }
                } finally {
                    cursor.close();
                }
            }

        } else if (ContentResolver.SCHEME_FILE.equals(schema)) {
            path = uri.getLastPathSegment();

        }

        return path;
    }


    /**
     * Get a {@link File} for storing misc data that should be
     * accessible for {@link MediaFileProvider}. If the cache dir doesn't
     * exist we try to create it.
     *
     * @param subDirectory Name of the sub directory where to put the file or {@code null} if not needed
     * @param fileName     The name of the file.
     * @return The File.
     */
    public File createCacheFile(String subDirectory, String fileName) {
        final String path;
        if (!TextUtils.isEmpty(subDirectory)) {
            path = FILE_DIR_USER + File.separator + subDirectory;
        } else {
            path = FILE_DIR_USER;
        }

        final File cacheDir = getAttachmentDir(path);

        if (cacheDir == null) {
            Log.w(LOG_TAG, "Error creating cache directory");
            return null;
        }

        return createTempFile(cacheDir, fileName, null);
    }

    String getTemporaryRequestCacheDir() {
        return String.format(Locale.US, PATH_PLACEHOLDER, REQUEST_FORMATTED_MEDIA_PATH, File.separator, UUID.randomUUID().toString());
    }

    /**
     * Generates a unique file name for a picture taken with the camera.
     *
     * @return A string representing the file name for the picture.
     */
    public String createTakenPictureFileName() {
        final SimpleDateFormat sdf = new SimpleDateFormat(CAMERA_DATETIME_STRING_FORMAT, Locale.US);
        final String fileName = String.format(Locale.US, CAMERA_IMG_NAME, sdf.format(new Date(System.currentTimeMillis())));
        return fileName + CAMERA_IMG_SUFFIX;
    }

    /**
     * Creates a URI to save a taken picture
     *
     * @return A URI representing the location where the picture will be saved.
     */
    public Uri createUriToSaveTakenPicture() {
        String fileName = createTakenPictureFileName();
        final File file = createCacheFile(getTemporaryRequestCacheDir(), fileName);
        return getFileProviderUri(context, file);
    }

    /**
     * Get the authority of , that is used to access files.
     * <br>
     * Defined in the AndroidManifest as android:authorities=".."
     *
     * @param context A valid application {@link Context}
     * @return The authority as a {@link String}
     */
    String getFileProviderAuthority(Context context) {
        return String.format(Locale.US, "%s%s", context.getPackageName(), MEDIA_FILE_PROVIDER_AUTHORITY_SUFFIX);
    }

    /**
     * Create an {@link Uri} that points to the specified {@link File}. The {@link File} must be
     * accessible through our
     *
     * @param context A valid application {@link Context}
     * @param file    A {@link File}, accessible through our
     * @return The {@link Uri} pointing to the provided File.
     */
    public Uri getFileProviderUri(Context context, File file) {
        final String authority = getFileProviderAuthority(context);

        try {
            return MediaFileProvider.getUriForFile(context, authority, file);

        } catch (IllegalArgumentException e) {
            Log.e(LOG_TAG, String.format(Locale.US, "The selected file can't be shared %s", file.toString()));
            return null;

        } catch (NullPointerException e) {

            final String msg = String.format(Locale.US,
                    "=====================\n" +
                            "FileProvider failed to retrieve file uri. There might be an issue with the FileProvider \n" +
                            "Please make sure that manifest-merger is working, and that you have defined the applicationId (package name) in the build.gradle\n" +
                            "Manifest merger: http://tools.android.com/tech-docs/new-build-system/user-guide/manifest-merger\n" +
                            "If your are not able to use gradle or the manifest merger, please add the following to your AndroidManifest.xml:\n" +
                            "        <provider\n" +
                            "            android:name=\".MediaFileProvider\"\n" +
                            "            android:authorities=\"${applicationId}%s\"\n" +
                            "            android:exported=\"false\"\n" +
                            "            android:grantUriPermissions=\"true\">\n" +
                            "            <meta-data\n" +
                            "                android:name=\"android.support.FILE_PROVIDER_PATHS\"\n" +
                            "                android:resource=\"@xml/zendesk_user_attachments\" />\n" +
                            "        </provider>\n" +
                            "=====================",
                    authority);

            Log.e(LOG_TAG, msg, e);
            Log.e(LOG_TAG, msg, e);

            throw new RuntimeException("Please specify your application id");
        }
    }

    /**
     * Get and create a sub directory in the Belvedere cache.
     * <p>
     * If the directory not exist the method tries to create it.
     * </p>
     *
     * @param subDirectory The name of the sub directory
     * @return A {@link File} pointing to the directory.
     */
    @SuppressWarnings("ResultOfMethodCallIgnored")
    private File getAttachmentDir(String subDirectory) {

        final String subDirectoryString;
        if (!TextUtils.isEmpty(subDirectory)) {
            subDirectoryString = subDirectory + File.separator;
        } else {
            subDirectoryString = "";
        }

        final File dir = new File(getRootDir(context) + File.separator + FILE_DIR_USER_MEDIA + File.separator + subDirectoryString);

        if (!dir.isDirectory()) {
            dir.mkdirs();
        }

        return dir.isDirectory() ? dir : null;
    }

    private String getRootDir(Context context) {
        return context.getCacheDir().getAbsolutePath();
    }


    /**
     * Create a {@link File} with the given parameters.
     * <p>
     * <p>
     * Suffix could be null. If a suffice is provided
     * it has to start with a '.'. E.g. '.gif'
     * </p>
     *
     * @param dir      The directory, where the {@link File} should live.
     * @param fileName The name of the {@link File}.
     * @param suffix   The suffix of the {@link File}.
     * @return The {@link File}
     */
    private File createTempFile(File dir, String fileName, String suffix) {
        return new File(dir, fileName + (!TextUtils.isEmpty(suffix) ? suffix : ""));
    }

    /**
     * Clear cache.
     */
    void clearStorage() {
        final File rootDir = new File(getRootDir(context) + File.separator + FILE_DIR_USER_MEDIA);
        if (rootDir.isDirectory()) {
            clearDirectory(rootDir);
        }
    }


    @SuppressWarnings("ResultOfMethodCallIgnored")
    private void clearDirectory(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory()) {
            for (File child : fileOrDirectory.listFiles()) {
                clearDirectory(child);
            }
        }
        fileOrDirectory.delete();
    }

    /**
     * Try to guess the mime type of the media {@link File} behind
     * the provided {@link Uri}.
     * <p>
     * The returned result will look like this '.gif' or '.jpg'.
     * <br>
     * If this method isn't able to figure out the mime type, it will
     * return '.tmp'
     * </p>
     *
     * @param uri            An {@link Uri}
     * @param withLeadingDot {@code true} if the method should add a '.' to the extension
     * @return The mime type as a {@link String}.
     */
    private String getExtension(Uri uri, boolean withLeadingDot) {
        final MimeTypeMap mime = MimeTypeMap.getSingleton();
        final String schema = uri.getScheme();
        String ext = "tmp";

        if (ContentResolver.SCHEME_CONTENT.equals(schema)) {
            final ContentResolver cr = context.getContentResolver();
            ext = mime.getExtensionFromMimeType(cr.getType(uri));

        } else if (ContentResolver.SCHEME_FILE.equals(schema)) {
            final String fullFileName = uri.getLastPathSegment();
            final int i = fullFileName.lastIndexOf(".");

            if (i != -1) {
                ext = fullFileName.substring(i + 1, fullFileName.length());
            }
        }

        if (withLeadingDot) {
            return String.format(Locale.US, ".%s", ext);

        } else {
            return ext;
        }
    }

    /**
     * Gets the dimension of an image file.
     *
     * @param file The image file
     * @return The width and the height of an image file.
     */
    @SuppressWarnings("WeakerAccess")
    public Pair<Integer, Integer> getImageDimensions(@NonNull File file) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), options); // I/O on the main thread but only takes ~0.5ms
        return Pair.create(options.outWidth, options.outHeight);
    }


    /**
     * Function to map a list of uris to file
     *
     * @param uris {@link List<Uri>}
     * @return the list of files {@link List<File>}
     */
    public List<File> fetchFilesFromUris(List<Uri> uris) {
        List<File> files = new ArrayList<>();
        final byte[] buf = new byte[1_048_576];
        InputStream inputStream = null;
        FileOutputStream fileOutputStream = null;

        for (Uri uri : uris) {
            try {
                inputStream = context.getContentResolver().openInputStream(uri);
                final File file = getFileForUri(uri, null);

                if (inputStream != null && file != null) {
                    Logger.d(LOG_TAG, String.format(Locale.US, "Copying media file into private cache - Uri: %s - Dest: %s", uri, file));
                    fileOutputStream = new FileOutputStream(file);

                    int len;
                    while ((len = inputStream.read(buf)) > 0) {
                        fileOutputStream.write(buf, 0, len);
                    }
                } else {
                    Logger.w(LOG_TAG, String.format(
                            Locale.US,
                            "Unable to resolve uri. InputStream null = %s, File null = %s",
                            (inputStream == null), (file == null)
                    ));
                }

                files.add(file);
            } catch (FileNotFoundException e) {
                Logger.e(LOG_TAG, String.format(Locale.US, "File not found error copying file, uri: %s", uri), e);

            } catch (IOException e) {
                Logger.e(LOG_TAG, String.format(Locale.US, "IO Error copying file, uri: %s", uri), e);

            } catch (IllegalStateException e) {
                Logger.e(LOG_TAG, String.format(Locale.US, "The file is either partially downloaded or corrupted, uri: %s", uri), e);

            } finally {
                try {
                    if (inputStream != null) {
                        inputStream.close();
                    }
                } catch (IOException e) {
                    Logger.e(LOG_TAG, "Error closing InputStream", e);
                }
                try {
                    if (fileOutputStream != null) {
                        fileOutputStream.close();
                    }
                } catch (IOException e) {
                    Logger.e(LOG_TAG, "Error closing FileOutputStream", e);
                }
            }
        }
        return files;
    }
}
