package zendesk.core;

/**
 * Default implementation of {@link ProviderStore}. Created as part of the dependency graph in
 * {@link ZendeskProvidersModule} to hold instances of all available storage classes.
 */
class ZendeskProviderStore implements ProviderStore {

    private final UserProvider userProvider;
    private final PushRegistrationProvider pushRegistrationProvider;

    ZendeskProviderStore(UserProvider userProvider, PushRegistrationProvider pushRegistrationProvider) {
        this.userProvider = userProvider;
        this.pushRegistrationProvider = pushRegistrationProvider;
    }

    @Override
    public UserProvider userProvider() {
        return userProvider;
    }

    @Override
    public PushRegistrationProvider pushRegistrationProvider() {
        return pushRegistrationProvider;
    }

}
