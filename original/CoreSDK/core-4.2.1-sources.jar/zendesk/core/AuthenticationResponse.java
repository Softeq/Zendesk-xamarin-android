package zendesk.core;

/**
 * Models the api response from an authentication call.
 */
@SuppressWarnings("unused")
class AuthenticationResponse {

    private AccessToken authentication;

    /**
     * Gets the {@link AccessToken} which represents an oauth token that is used to authenticate
     * a user in Zendesk.
     *
     * @return The access token
     */
    AccessToken getAuthentication() {
        return authentication;
    }
}