package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.JsonElement;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Interface for interacting with the stored settings.
 */
interface SettingsStorage {

    /**
     * Retrieve stored settings and deserialize them into an object of the provided type.
     *
     * @param key   the key where the settings can be found
     * @param clazz the class representing the stored settings
     * @param <E>   the type of the stored settings
     * @return the deserialized settings or {@code null} if not found
     */
    @Nullable
    <E> E getSettings(@NonNull String key, @NonNull Class<E> clazz);

    /**
     * Saves the supplied settings from the network to storage.
     *
     * @param rawSettings settings from the {@link SettingsProvider}.
     **/
    void storeRawSettings(@NonNull Map<String, JsonElement> rawSettings);

    /**
     * Gets the settings in a raw format, suitable for use in dispatching to ActionHandlers
     *
     * @return raw settings as a map of keys to JsonElement
     */
    Map<String, JsonElement> getRawSettings();

    /**
     * This method can check to see if there are any stored settings.
     * in storage.
     *
     * @return {@code true} if the storage has settings stored
     */
    boolean hasStoredSettings();

    /**
     * Determine if the stored settings older than the provided amount of time.
     *
     * @param duration the time duration in the given {@code timeUnit}
     * @param timeUnit the unit of the {@code duration} argument
     * @return {@code true} if the settings are loaded in the provided time range,
     * {@code false} if they are outdated.
     */
    boolean areSettingsUpToDate(long duration, @NonNull TimeUnit timeUnit);

    /**
     * Deletes any stored settings that may be present in the storage.
     */
    void clear();
}
