package zendesk.core;

import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;

import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import static com.zendesk.util.CollectionUtils.copyOf;

/**
 * This is a reference implementation of {@link NetworkInfoProvider}, which uses {@link NetworkUtils}
 * and a {@link ConnectivityManager} to report on the state of, and listen for changes to, network connectivity.
 * <p>
 * At construction time the {@link ConnectivityManager} is registered using the
 * {@link NetworkInfoProvider#register()} method, and unregistered using the
 * {@link NetworkInfoProvider#unregister()} method. As such, their use should respect the
 * {@link android.app.Activity}/{@link android.app.Fragment} lifecycle.
 * <p>
 * <p>
 * {@link java.lang.ref.WeakReference}s are used to reference any {@link NetworkAware} or
 * {@link RetryAction} objects added, to prevent leaks.
 */
class ZendeskNetworkInfoProvider implements NetworkInfoProvider, NetworkAware {

    private static final String LOG_TAG = "ZendeskNetworkInfoProvider";

    private ConnectivityManager.NetworkCallback networkCallback;

    private final ConnectivityManager connectivityManager;

    private final Map<Integer, WeakReference<NetworkAware>> listeners = new HashMap<>();
    private final Map<Integer, WeakReference<RetryAction>> retryActions = new HashMap<>();
    private CurrentState currentState = null;

    ZendeskNetworkInfoProvider(@NonNull ConnectivityManager connectivityManager) {
        this.connectivityManager = connectivityManager;
    }

    @Override
    public void register() {
        registerForNetworkCallbacks();
    }

    @Override
    public void unregister() {
        unregisterForNetworkCallbacks();
    }

    @Override
    public boolean isNetworkAvailable() {
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void addNetworkAwareListener(@NonNull Integer id, @NonNull NetworkAware listener) {
        if (id != null && listener != null) {
            listeners.put(id, new WeakReference<>(listener));
        }
    }

    @Override
    public void removeNetworkAwareListener(@NonNull Integer id) {
        listeners.remove(id);
    }

    @Override
    public void clearNetworkAwareListeners() {
        listeners.clear();
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void addRetryAction(@NonNull Integer id, @NonNull RetryAction retryAction) {
        if (id != null && retryAction != null) {
            retryActions.put(id, new WeakReference<>(retryAction));
        }
    }

    @Override
    public void removeRetryAction(@NonNull Integer id) {
        retryActions.remove(id);
    }

    @Override
    public void clearRetryActions() {
        retryActions.clear();
    }

    @Override
    public void onNetworkAvailable() {
        if (CurrentState.CONNECTED == currentState || !isConnectedOrConnecting(connectivityManager)) {
            return;
        }
        currentState = CurrentState.CONNECTED;

        Map<Integer, WeakReference<NetworkAware>> listenerReferences = CollectionUtils.copyOf(listeners);
        Map<Integer, WeakReference<RetryAction>> retryActionReferences = CollectionUtils.copyOf(retryActions);

        for (WeakReference<NetworkAware> listenerReference : listenerReferences.values()) {
            if (listenerReference.get() != null) {
                listenerReference.get().onNetworkAvailable();
            }
        }

        for (WeakReference<RetryAction> retryActionReference : retryActionReferences.values()) {
            if (retryActionReference.get() != null) {
                retryActionReference.get().onRetry();
            }
        }
        retryActions.clear();
    }

    @Override
    public void onNetworkUnavailable() {
        if (CurrentState.DISCONNECTED == currentState || isConnectedOrConnecting(connectivityManager)) {
            return;
        }
        currentState = CurrentState.DISCONNECTED;

        Map<Integer, WeakReference<NetworkAware>> listenerReferences = copyOf(listeners);

        for (WeakReference<NetworkAware> listenerReference : listenerReferences.values()) {
            if (listenerReference.get() != null) {
                listenerReference.get().onNetworkUnavailable();
            }
        }
    }

    private void registerForNetworkCallbacks() {
        if (networkCallback != null) {
            Logger.d(LOG_TAG, "Network callback already registered, skipping.");
            return;
        }

        Logger.d(LOG_TAG, "Adding Lollipop network callbacks...");

        final Handler handler = new Handler(Looper.getMainLooper());

        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(Network network) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        onNetworkAvailable();
                    }
                });
            }

            @Override
            public void onLost(Network network) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        onNetworkUnavailable();
                    }
                });
            }
        };

        connectivityManager.registerNetworkCallback(
                new NetworkRequest.Builder().build(), networkCallback);
    }

    private void unregisterForNetworkCallbacks() {
        if (networkCallback != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
            networkCallback = null;
        }
    }

    private static boolean isConnectedOrConnecting(ConnectivityManager connectivityManager) {
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnectedOrConnecting();
    }

    private enum CurrentState {
        CONNECTED, DISCONNECTED
    }
}
