package zendesk.core;

import androidx.annotation.NonNull;

import com.zendesk.logger.Logger;
import com.zendesk.util.StringUtils;

/**
 * This class models an anonymous identity for submission to the Zendesk API. It is intended to be
 * used only by {@link ZendeskAccessProvider}.
 * <p>
 * It includes an SDK GUID, which is required for the {@code /access/sdk/anonymous} call, but is
 * unsuitable for inclusion in the {@link AnonymousIdentity} class since we are storing it in its own key
 * (see {@link ZendeskIdentityStorage#updateSdkGuid()}.
 * As such, the GUID is no longer included as a field in the {@link AnonymousIdentity}.
 */
@SuppressWarnings({"unused", "FieldCanBeLocal"})
class ApiAnonymousIdentity implements Identity {

    private static final transient String LOG_TAG = "ApiAnonymousIdentity";

    private String sdkGuid;
    private String email;
    private String name;

    /**
     * Package-private constuctor which should only be used by {@link ZendeskAccessProvider} for
     * converting {@link AnonymousIdentity} objects into a Zendesk API-friendly form (ie, including
     * the SDK GUID).
     *
     * @param identity the anonymous identity for authorisation
     * @param sdkGuid  the SDK GUID for the anonymous identity
     */
    ApiAnonymousIdentity(@NonNull AnonymousIdentity identity, @NonNull String sdkGuid) {
        if (StringUtils.isEmpty(sdkGuid)) {
            this.sdkGuid = StringUtils.EMPTY_STRING;
            Logger.w(LOG_TAG, "SdkGuid cannot be null or empty.");
        } else {
            this.sdkGuid = sdkGuid;
        }

        //noinspection ConstantConditions
        if (identity == null) {
            Logger.w(LOG_TAG, "Identity is null.");
        } else {
            this.email = identity.getEmail();
            this.name = identity.getName();
        }
    }
}
