package zendesk.core;

/**
 * Interface providing a synchronous method for retrieving settings. This is used only by the
 * {@link ZendeskSettingsInterceptor} for ensuring that we have valid settings when making any
 * Zendesk call. There is no known reason (at this time) to make this method publicly accessible,
 * so it has been split from the public-facing {@link SettingsProvider}.
 * <p>
 * It shares a common concrete implementation ({@link ZendeskSettingsProvider}) with
 * {@link SettingsProvider}.
 */
interface SdkSettingsProviderInternal {

    /**
     * Retrieves core settings from storage, if present and valid, or from the network if not.
     *
     * @return Valid Core settings.
     */
    CoreSettings getCoreSettings();

    /**
     * Retrieves blips settings from storage, if present and valid, or from the network if not.
     *
     * @return Blips settings.
     */
    BlipsSettings getBlipsSettings();
}
