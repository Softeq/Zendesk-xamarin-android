package zendesk.core;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Basic serializer description. Used to define a concept of
 * serializing objects into {@link String} and vice-versa.
 */
interface Serializer {

    /**
     * Deserialize the provided dump of data into the provided type {@code E}.
     * <br>
     * Typically the provided object representing data is type of {@link String}.
     *
     * @param data  data for deserialization
     * @param clazz the class representing the stored settings
     * @return the requested object of type {@code E} or {@code null}
     */
    @Nullable
    <E> E deserialize(@Nullable Object data, @NonNull Class<E> clazz);

    /**
     * Serialize the given object into a {@link String}.
     *
     * @param object data for serialization
     * @return {@link String} representing the object
     */
    @Nullable
    String serialize(@Nullable Object object);

}
