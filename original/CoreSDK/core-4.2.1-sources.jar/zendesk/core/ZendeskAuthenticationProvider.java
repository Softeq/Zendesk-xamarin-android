package zendesk.core;

class ZendeskAuthenticationProvider implements AuthenticationProvider {

    private final IdentityManager identityManager;

    ZendeskAuthenticationProvider(IdentityManager identityManager) {
        this.identityManager = identityManager;
    }

    @Override
    public Identity getIdentity() {
        return identityManager.getIdentity();
    }
}
