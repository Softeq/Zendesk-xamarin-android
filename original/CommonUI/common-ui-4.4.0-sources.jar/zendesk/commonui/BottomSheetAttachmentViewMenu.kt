package zendesk.commonui

import android.content.Context
import android.net.Uri
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog

/**
 * BottomSheetAttachmentAction handles user's actions from a bottom sheet attachment menu
 * [BottomSheetAttachmentViewMenu].
 * Implement this interface to provide custom behavior for each action when it is
 * triggered from the bottom sheet attachment menu. These actions are related to taking photos,
 * selecting media from the gallery, and selecting documents from the file system.
 */
interface BottomSheetAttachmentAction {
    /**
     * Called when the user selects the option to take a photo.
     *
     * Implement this method to provide the behavior when the "Take Photo"
     * option is selected in the bottom sheet.
     */
    fun onTakePhotoClicked()

    /**
     * Called when the user selects the option to select media from the gallery.
     *
     * Implement this method to provide the behavior when the "Select Media"
     * option is selected in the bottom sheet.
     */
    fun onSelectMediaClicked()

    /**
     * Called when the user selects the option to select documents from the file system.
     *
     * Implement this method to provide the behavior when the "Select Document"
     * option is selected in the bottom sheet.
     */
    fun onSelectDocumentClicked()
}

/**
 * A custom BottomSheetDialog to display attachment menu options.
 *
 * @constructor Creates a bottom sheet dialog with the specified context and action callbacks.
 * @param context The context in which the bottom sheet dialog should be created.
 * @param titles A set of strings value for the menu item titles. The order needs to be checked.
 * @param action An instance of [BottomSheetAttachmentAction] to handle the menu actions.
 */
class BottomSheetAttachmentViewMenu(
    context: Context,
    titles: List<String>,
    action: BottomSheetAttachmentAction
) : BottomSheetDialog(context) {

    private val takePhotoTextView: TextView?
    private val mediaTextView: TextView?
    private val documentTextView: TextView?

    init {
        setContentView(R.layout.zui_view_attachment_menu)
        takePhotoTextView = findViewById(R.id.menu_item_camera)
        mediaTextView = findViewById(R.id.menu_item_media)
        documentTextView = findViewById(R.id.menu_item_document)
        setupMenuTitles(titles)
        setupActionClickListener(action)
        setCancelable(true)
    }

    private fun setupActionClickListener(action: BottomSheetAttachmentAction){
        takePhotoTextView?.setOnClickListener {
            action.onTakePhotoClicked()
            dismiss()
        }

        mediaTextView?.setOnClickListener {
            action.onSelectMediaClicked()
            dismiss()
        }

        documentTextView?.setOnClickListener {
            action.onSelectDocumentClicked()
            dismiss()
        }
    }

    private fun setupMenuTitles(menuTitles: List<String>) {
        menuTitles.getOrNull(CAMERA_MENU_ITEM_INDEX)?.let { camera ->
            takePhotoTextView?.text = camera
        }

        menuTitles.getOrNull(GALLERY_MENU_ITEM_INDEX)?.let { gallery ->
            mediaTextView?.text = gallery
        }

        menuTitles.getOrNull(DOCUMENT_MENU_ITEM_INDEX)?.let { document ->
            documentTextView?.text = document
        }
    }


    fun showMenu() {
        if (!isShowing) {
            this@BottomSheetAttachmentViewMenu.show()
        }
    }

    companion object {
        const val CAMERA_MENU_ITEM_INDEX = 0
        const val GALLERY_MENU_ITEM_INDEX = 1
        const val DOCUMENT_MENU_ITEM_INDEX = 2
    }

}