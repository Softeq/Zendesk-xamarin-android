package zendesk.commonui;

import android.os.Handler;
import android.os.Looper;
import androidx.annotation.NonNull;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.AbstractExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Executes all submitted tasks on the callback thread; Cannot be shutdown as its the callback thread
 */
public final class MainThreadExecutorService extends AbstractExecutorService {

    private static final Handler HANDLER = new Handler(Looper.getMainLooper());
    private static final MainThreadExecutorService INSTANCE = new MainThreadExecutorService();

    public static MainThreadExecutorService get() {
        return INSTANCE;
    }

    private MainThreadExecutorService() {
        // Intentionally empty. Singleton only
    }

    @Override
    public void shutdown() {
    }

    @Override
    public boolean isShutdown() {
        return false;
    }

    @Override
    public boolean isTerminated() {
        return false;
    }

    @Override
    public boolean awaitTermination(long theTimeout, @NonNull TimeUnit theUnit) throws InterruptedException {
        return false;
    }

    @Override
    @NonNull
    public List<Runnable> shutdownNow() {
        return Collections.emptyList();
    }

    @Override
    public void execute(@NonNull Runnable theCommand) {
        HANDLER.post(theCommand);
    }
}