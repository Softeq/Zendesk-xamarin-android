package zendesk.commonui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import java.util.HashMap;
import java.util.Map;

/**
 * Cache based on a fragment with {@link Fragment#setRetainInstance(boolean)} set to true to preserve data
 * across config changes.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class CacheFragment extends Fragment {

    private static final String TAG = "CacheFragment";

    private final Map<String, Object> cache = new HashMap<>();

    /**
     * Gets the cache fragment from the activity or creates/attaches a new one if a cache fragment is
     * not attached
     */
    public static CacheFragment from(FragmentActivity activity) {
        final FragmentManager fragmentManager = activity.getSupportFragmentManager();
        final Fragment fragment = fragmentManager.findFragmentByTag(TAG);
        if (fragment instanceof CacheFragment) {
            return (CacheFragment) fragment;
        } else {
            //no fragment or wrong instance, attach a new one
            CacheFragment cacheFragment = new CacheFragment();
            cacheFragment.setRetainInstance(true);
            fragmentManager.beginTransaction().add(cacheFragment, TAG).commit();
            return cacheFragment;
        }
    }

    /**
     * Gets a value from the cache for the given key
     *
     * @param key the entry to get
     * @return the entry if it exists, null if the key is missing
     */
    @SuppressWarnings("unchecked")
    @Nullable
    public <T> T get(@NonNull String key) {
        try {
            return (T) cache.get(key);
        } catch (Exception e) { //catch possible class cast error
            return null;
        }
    }

    /**
     * Gets a item from the cache. If the entry is missing the Supplier is called to create a new entry in
     * the cache which is then returned. Useful if the cache needs to store something computationally expensive to
     * create
     * compared to {@link #getOrDefault(String, Object)}
     *
     * @param key      the key to use
     * @param supplier the supplier returning a default value if cache is missing the value
     * @return the value from the cache or the returned value from the supplier
     */
    @NonNull
    public <T> T getOrDefault(@NonNull String key, @NonNull Supplier<T> supplier) {
        T data = get(key);
        if (data != null) {
            return data;
        } else {
            T defaultData = supplier.get();
            put(key, defaultData);
            return defaultData;
        }
    }

    /**
     * Gets a item from the cache. If the entry is missing the defaultData is returned
     *
     * @param key          the key to use
     * @param defaultValue a default value if cache is missing the value
     * @return the value from the cache or the defaultData
     */
    @NonNull
    public <T> T getOrDefault(@NonNull String key, @NonNull T defaultValue) {
        T data = get(key);
        if (data != null) {
            return data;
        } else {
            return defaultValue;
        }
    }

    /**
     * Puts a value into the cache
     *
     * @param key  the key to use
     * @param data the data to cache
     */
    public <T> void put(@NonNull String key, @NonNull T data) {
        cache.put(key, data);
    }

    /**
     * Check a value is in the cache
     *
     * @return true if a value exists for a given key
     */
    public boolean contains(@NonNull String key) {
        return cache.containsKey(key);
    }

    /**
     * Remove a value from the cache
     */
    public void remove(@NonNull String key) {
        cache.remove(key);
    }

    public interface Supplier<T> {

        @NonNull
        T get();
    }
}
