package zendesk.commonui

import android.net.Uri

/**
 * PhotoPickerSelectionCallback handles results from photo picker selection.
 */
interface PhotoPickerSelectionCallback {
    /**
     * Called when media items have been selected from the picker.
     *
     * This method is invoked when the user selects one or more media items
     * (such as photos, videos or documents) from the photo picker. The selected media
     * URIs are provided as a list.
     *
     * @param uris The list of URIs representing the selected media items.
     */
    fun onMediaSelected(uris: List<@JvmSuppressWildcards Uri>)

    /**
     * Called when a picture has been taken using the camera.
     *
     * This method is invoked when the user completes a picture-taking
     * operation with the camera.
     *
     * @param inputUriPhotoTaken The URI where the picture will be saved
     */
    fun onPhotoTaken(inputUriPhotoTaken: Uri)
}