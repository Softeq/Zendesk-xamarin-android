package zendesk.commonui

import android.net.Uri
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.ActivityResultRegistry
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

/**
 * A lifecycle-aware observer to manage media picking and picture-taking activities.
 *
 * This class is responsible for registering and managing the activity result launchers
 * required for picking multiple media items from the gallery, picking multiple documents,
 * and taking pictures using the camera. The results are handled via the [PhotoPickerSelectionCallback].
 *
 * @property registry The [ActivityResultRegistry] used to register activity result launchers.
 * @property selectionCallback Callback to handle the selected media URIs and picture-taking result.
 */
class PhotoPickerLifecycleObserver(
    private val registry: ActivityResultRegistry,
    private val selectionCallback: PhotoPickerSelectionCallback,
    private val restoredInputUriPhoto: () -> Uri
) : DefaultLifecycleObserver {

    private lateinit var galleryPicker: ActivityResultLauncher<PickVisualMediaRequest>
    private lateinit var documentPicker: ActivityResultLauncher<Array<String>>
    private lateinit var takePicture: ActivityResultLauncher<Uri>
    /**
     * The URI where the photo will be saved when a [takePicture] action is triggered
     */
    private lateinit var inputUriPhotoTaken: Uri

    override fun onCreate(owner: LifecycleOwner) {
        super.onCreate(owner)
        setupGalleryPicker(owner)
        setupDocumentPicker(owner)
        setupTakePicture(owner)
    }

    /**
     * Registers the activity result launcher for picking multiple media items (Photos/Videos) from the gallery.
     *
     * @param owner The [LifecycleOwner] associated with this observer.
     */
    private fun setupGalleryPicker(owner: LifecycleOwner) {
        galleryPicker = registry.register(
            GALLERY_PICKER_KEY, owner,
            ActivityResultContracts.PickMultipleVisualMedia()
        ) { uris ->
            selectionCallback.onMediaSelected(uris)
        }
    }

    /**
     * Registers the activity result launcher for picking multiple documents.
     *
     * @param owner The [LifecycleOwner] associated with this observer.
     */
    private fun setupDocumentPicker(owner: LifecycleOwner) {
        documentPicker = registry.register(
            DOCUMENT_PICKER_KEY, owner,
            ActivityResultContracts.OpenMultipleDocuments()
        ) { uris ->
            selectionCallback.onMediaSelected(uris)
        }
    }

    /**
     * Registers the activity result launcher for taking pictures using the camera.
     *
     * @param owner The [LifecycleOwner] associated with this observer.
     */
    private fun setupTakePicture(owner: LifecycleOwner) {
        takePicture = registry.register(
            TAKE_PICTURE_KEY, owner,
            ActivityResultContracts.TakePicture()
        ) { wasPictureTaken ->
            restoredInputUriPhoto().let {
                inputUriPhotoTaken = it
            }
            if (wasPictureTaken) {
                selectionCallback.onPhotoTaken(inputUriPhotoTaken)
            }
        }
    }

    /**
     * Launches the PhotoPicker to select multiple media items from the gallery.
     */
    fun selectMedia() {
        galleryPicker.launch(PickVisualMediaRequest())
    }

    /**
     * Launches the PhotoPicker to select multiple documents.
     *
     * @param input An array of MIME types for the types of documents to be selected.
     */
    fun selectDocument(input: Array<String>){
        documentPicker.launch(input)
    }

    /**
     * Launches the the PhotoPicker to take a picture and save it to the provided URI.
     *
     * @param input The URI where the picture will be saved
     */
    fun takePicture(input: Uri){
        inputUriPhotoTaken = input
        takePicture.launch(inputUriPhotoTaken)
    }

    companion object {
        private const val GALLERY_PICKER_KEY = "GALLERY_PICKER"
        private const val DOCUMENT_PICKER_KEY = "DOCUMENT_PICKER"
        private const val TAKE_PICTURE_KEY = "TAKE_PICTURE"
    }
}