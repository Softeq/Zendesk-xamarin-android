package zendesk.commonui;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * Adapts a {@link TextWatcher}
 * <p>
 * Implements {@link TextWatcher#beforeTextChanged(CharSequence, int, int, int) beforeTextChanged},
 * {@link TextWatcher#onTextChanged(CharSequence, int, int, int) onTextChanged}
 * and {@link TextWatcher#afterTextChanged(Editable) afterTextChanged}.
 * </p>
 *
 * @see <a href="http://developer.android.com/reference/android/text/TextWatcher.html">TextWatcher</a>
 */
public abstract class TextWatcherAdapter implements TextWatcher {

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        // Intentionally empty
    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        // Intentionally empty
    }

    @Override
    public void afterTextChanged(Editable s) {
        // Intentionally empty
    }
}