package zendesk.commonui;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import androidx.annotation.AttrRes;
import androidx.annotation.ColorInt;
import androidx.annotation.ColorRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import android.text.Html;
import android.util.TypedValue;
import android.view.View;

import com.zendesk.logger.Logger;

import java.util.Locale;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * Conversion utils for screen related items. For Zendesk internal use only.
 */
@RestrictTo(LIBRARY_GROUP)
public class UiUtils {

    private static final String LOG_TAG = "UiUtils";

    public enum ScreenSize {
        UNKNOWN, UNDEFINED, X_LARGE, LARGE, NORMAL, SMALL
    }

    private UiUtils() {
        // Intentionally empty
    }

    /**
     * Converts a attribute id in the current theme to the corresponding resolved color value.
     * <p>
     * This method will resolve a color that has been specified in a style XML file like this:
     * <br>
     * {@code <item name="colorPrimary">@color/my_primary_color</item>}
     * <br>
     * This will return the value of {@code @color/my_primary_color}.
     * </p>
     *
     * @param themeAttributeId The color attr id
     * @param context          Must be a UI context, must not be an application context. It must also be
     *                         using the theme the attribute is declared in.
     * @param fallbackColorId  Only used when there was an issue looking up the attribute color ID,
     *                         as a second choice. This should be a color reference directly, as in
     *                         {@code R.color} rather than {@code R.attr}
     * @return The resolved color value of themeAttributeId, if found, or fallbackColorId, if not.
     * If invalid IDs, or a null context is supplied, then {@link Color#BLACK} will be returned
     */
    @ColorInt
    public static int themeAttributeToColor(@AttrRes int themeAttributeId, @NonNull Context context,
                                            @ColorRes int fallbackColorId) {
        //noinspection ConstantConditions
        if (themeAttributeId == 0 || context == null || fallbackColorId == 0) {
            Logger.d(LOG_TAG, "themeAttributeId, context, and fallbackColorId are required.");
            return Color.BLACK;
        }

        TypedValue outValue = new TypedValue();
        Resources.Theme theme = context.getTheme();

        boolean wasResolved = theme.resolveAttribute(themeAttributeId, outValue, true);

        if (!wasResolved) {
            String errorMessage =
                    String.format(
                            Locale.US,
                            "Resource %d not found. Resource is either missing or you are using a non-ui context.",
                            themeAttributeId);
            Logger.e(LOG_TAG, errorMessage);

            return resolveColor(fallbackColorId, context);
        } else {

            /*
                Whoa Nelly! What's going on here. Well, it turns out that if you have an
                attribute pointing to a literal color as opposed to an @color/foo reference,
                then you get the actual color in outValue.data rather than getting a resourceId.
             */
            return outValue.resourceId == 0
                    ? outValue.data
                    : resolveColor(outValue.resourceId, context);
        }
    }

    /**
     * Resolves a color ID to a color resource.
     *
     * @param colorId The color ID.
     * @param context Must be a UI context, must not an application context.
     * @return The resolved color resource.
     */
    public static int resolveColor(@ColorRes int colorId, @NonNull Context context) {
        return ContextCompat.getColor(context, colorId);
    }

    /**
     * Sets a view's visibility to one of {@link View#VISIBLE}, {@link View#INVISIBLE} or
     * {@link View#GONE}.
     * <p>
     * If the supplied view is null then no action will be attempted.
     * </p>
     *
     * @param view            The view to change the visibility of
     * @param visibilityState The visibility to set
     */
    public static void setVisibility(View view, int visibilityState) {

        if (view == null) {

            Logger.w(LOG_TAG, "View is null and can't change visibility");

        } else {
            view.setVisibility(visibilityState);
        }
    }

    /**
     * Sets a tint on a drawable and updates the view displaying it.
     *
     * @param color    The tint color to be applied to a drawable.
     * @param drawable The drawable to be tinted.
     * @param view     The view to be invalidated.
     */
    public static void setTint(@ColorInt int color, @Nullable Drawable drawable, @Nullable View view) {
        if (drawable == null) {
            Logger.e(LOG_TAG, "Drawable is null, cannot apply a tint");
            return;
        }

        Drawable d = DrawableCompat.wrap(drawable);
        DrawableCompat.setTint(d.mutate(), color);

        if (view != null) {
            view.invalidate();
        }
    }

    public int themeAttributeToPixels(@AttrRes int themeAttributeId,
                                      Context context,
                                      int fallbackUnitType,
                                      float fallbackUnitValue) {
        TypedValue outValue = new TypedValue();

        Resources.Theme theme = context.getTheme();

        boolean wasFound = theme.resolveAttribute(themeAttributeId, outValue, true);

        if (!wasFound) {
            String errorMessage =
                    String.format(
                            Locale.US,
                            "Resource %d not found. Resource is either missing or you are using a non-ui context.",
                            themeAttributeId);

            Logger.e(LOG_TAG, errorMessage);
            return Math.round(TypedValue
                    .applyDimension(fallbackUnitType, fallbackUnitValue, context.getResources().getDisplayMetrics()));

        } else {
            return Math.round(outValue.getDimension(context.getResources().getDisplayMetrics()));
        }
    }

    public static CharSequence decodeHtmlEntities(String html) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            return Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY);
        } else {
            return Html.fromHtml(html);
        }
    }
}
