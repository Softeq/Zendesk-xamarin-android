@file:JvmName("SystemWindowInsets")

package zendesk.commonui

import android.os.Build
import android.view.View
import android.view.WindowInsets
import androidx.core.view.updatePadding

/**
 * Applies window insets to this `View` based on the provided `InsetType`, supporting edge-to-edge
 * reinforcement as introduced in Android 15.
 *
 * @param insetType Specifies which padding should be applied
 */

fun View.applyWindowInsets(vararg insetType: InsetType) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
        this.setOnApplyWindowInsetsListener { view, windowInsets ->
            val imeVisible = windowInsets.isVisible(WindowInsets.Type.ime())
            insetType.forEach { type ->
                when (type) {
                    InsetType.TOP ->
                        view.updatePadding(
                            top = windowInsets.getInsets(WindowInsets.Type.statusBars()).top,
                        )

                    InsetType.BOTTOM -> {
                        val padding = if (imeVisible) {
                            windowInsets.getInsets(WindowInsets.Type.ime())
                        } else {
                            windowInsets.getInsets(WindowInsets.Type.systemBars())
                        }
                        view.updatePadding(bottom = padding.bottom)
                    }

                    InsetType.HORIZONTAL -> {
                        val systemBarInsets = windowInsets.getInsets(WindowInsets.Type.systemBars())
                        val displayCutoutInsets = windowInsets.getInsets(WindowInsets.Type.displayCutout())
                        val maxInset = maxOf(
                            systemBarInsets.right,
                            displayCutoutInsets.right,
                            systemBarInsets.left,
                            displayCutoutInsets.left,
                        )
                        view.updatePadding(right = maxInset, left = maxInset)
                    }
                }
            }
            windowInsets
        }
    }
}


/**
 * Enum class representing different types of insets that can be applied to a `View`.
 * - `TOP`: Applies padding to the top of the view, typically used for status bar insets.
 * - `BOTTOM`: Applies padding to the bottom of the view, typically used for system bar or keyboard insets.
 * - 'HORIZONTAL': Applies padding to both left and right side of view, typically used for
 *                 3-button navigation bar insets.
 */
enum class InsetType {
    TOP, BOTTOM, HORIZONTAL
}
