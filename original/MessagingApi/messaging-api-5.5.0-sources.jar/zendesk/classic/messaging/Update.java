package zendesk.classic.messaging;

import android.app.Activity;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.text.InputType;

import com.zendesk.util.StringUtils;

import java.util.Collections;
import java.util.List;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;
import static java.util.Arrays.asList;

/**
 * Represents an update from the {@link Engine} to be processed by the Messaging SDK.
 * <br>
 * Messaging SDK receive updates by registering itself with {@link Engine#registerObserver(Engine.UpdateObserver)}
 */
@RestrictTo(LIBRARY_GROUP)
public abstract class Update {

    public static final String APPLY_MESSAGING_ITEMS = "apply_messaging_items";
    public static final String APPLY_MENU_ITEMS = "apply_menu_items";
    public static final String HIDE_TYPING = "hide_typing";
    public static final String SHOW_TYPING = "show_typing";
    public static final String UPDATE_CONNECTION_STATE = "update_connection_state";
    public static final String NAVIGATION = "navigation";
    public static final String UPDATE_INPUT_FIELD_STATE = "update_input_field_state";
    public static final String SHOW_DIALOG = "show_dialog";
    public static final String SHOW_BANNER = "show_banner";

    private final String type;

    public Update(@NonNull String type) {
        this.type = type;
    }

    /**
     * Gets the type. Used by the {@link Engine} to distinguish the events from one another.
     *
     * @return Unique {@link String} describing the type of {@link Event}.
     */
    @NonNull
    public String getType() {
        return type;
    }

    /**
     * Represents an Update which updates some part of the Messaging
     */
    @RestrictTo(LIBRARY_GROUP)
    public abstract static class State extends Update {

        public State(@NonNull String type) {
            super(type);
        }

        /**
         * Update carrying the a new list of {@link MessagingItem}s.
         */
        @RestrictTo(LIBRARY_GROUP)
        public static class ApplyMessagingItems extends State {

            private final List<MessagingItem> messagingItems;

            public ApplyMessagingItems(List<MessagingItem> messagingItems) {
                super(APPLY_MESSAGING_ITEMS);
                this.messagingItems = messagingItems;
            }

            /**
             * Gets current list of {@link MessagingItem}.
             *
             * @return List of {@link MessagingItem}.
             */
            @NonNull
            public List<MessagingItem> getMessagingItems() {
                return messagingItems;
            }
        }

        @RestrictTo(LIBRARY_GROUP)
        public static class HideTyping extends State {

            public HideTyping() {
                super(HIDE_TYPING);
            }
        }

        /**
         * Update carrying connectionState for a typing indicator
         */
        @RestrictTo(LIBRARY_GROUP)
        public static class ShowTyping extends State {

            private final AgentDetails agentDetails;

            public ShowTyping(@Nullable AgentDetails agentDetails) {
                super(SHOW_TYPING);
                this.agentDetails = agentDetails;
            }

            public AgentDetails getAgentDetails() {
                return agentDetails;
            }
        }

        /**
         * An {@link Update} carrying connectionState of the connection.
         */
        @RestrictTo(LIBRARY_GROUP)
        public static class UpdateConnectionState extends State {

            private final ConnectionState connectionState;

            public UpdateConnectionState(@NonNull ConnectionState connectionState) {
                super(UPDATE_CONNECTION_STATE);
                this.connectionState = connectionState;
            }

            @NonNull
            public ConnectionState getConnectionState() {
                return connectionState;
            }

        }

        /**
         * An {@link Update} carrying a state for an Input Field.
         * All fields are nullable, and a null value indicates the field should not be updated.
         */
        @RestrictTo(LIBRARY_GROUP)
        public static class UpdateInputFieldState extends State {

            // Value used to indicate the update the composer hint should be reset to the default.
            public static final String DEFAULT_HINT = StringUtils.EMPTY_STRING;

            @Nullable
            private final String hint;

            // Deliberate use of Boolean here rather than primitive boolean as a null value indicates no update
            @Nullable
            private final Boolean enabled;
            @Nullable
            private final AttachmentSettings attachmentSettings;
            @Nullable
            private final Integer inputType;

            public static UpdateInputFieldState resetHintToDefault() {
                return updateHint(DEFAULT_HINT);
            }

            public static UpdateInputFieldState updateInputType(int inputType) {
                return new UpdateInputFieldState(null, null, null, inputType);
            }

            public static UpdateInputFieldState resetInputType() {
                return updateInputType((InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE));
            }

            public static UpdateInputFieldState updateHint(@NonNull String hint) {
                return new UpdateInputFieldState(hint, null, null, null);
            }

            public static UpdateInputFieldState updateInputFieldEnabled(boolean enabled) {
                return new UpdateInputFieldState(null, enabled, null, null);
            }

            public static UpdateInputFieldState updateAttachmentSettings(
                    @NonNull AttachmentSettings attachmentSettings) {
                return new UpdateInputFieldState(null, null, attachmentSettings, null);
            }

            public UpdateInputFieldState(
                    @Nullable String hint,
                    @Nullable Boolean enabled,
                    @Nullable AttachmentSettings attachmentSettings,
                    @Nullable Integer inputType) {
                super(UPDATE_INPUT_FIELD_STATE);
                this.hint = hint;
                this.enabled = enabled;
                this.attachmentSettings = attachmentSettings;
                this.inputType = inputType;
            }

            @Nullable
            public String getHint() {
                return hint;
            }

            @Nullable
            public Boolean isEnabled() {
                return enabled;
            }

            @Nullable
            public AttachmentSettings getAttachmentSettings() {
                return attachmentSettings;
            }

            @Nullable
            public Integer getInputType() {
                return inputType;
            }
        }

    }

    /**
     * Represents an Update which triggers some kind of once-off action
     */
    @RestrictTo(LIBRARY_GROUP)
    public abstract static class Action extends Update {

        public Action(@NonNull String type) {
            super(type);
        }

        public abstract void navigate(Activity activity);

        /**
         * Update carrying a connectionState for the Toolbar
         */
        @RestrictTo(LIBRARY_GROUP)
        public static class Navigation extends Action {

            private static int NO_REQUEST_CODE = -1;

            private final int requestCode;
            private final Intent intent;

            public Navigation(Intent intent) {
                this(intent, NO_REQUEST_CODE);
            }

            public Navigation(Intent intent, int requestCode) {
                super(NAVIGATION);
                this.intent = intent;
                this.requestCode = requestCode;
            }

            /**
             * Executes the navigation action defined by the state of this Navigation
             *
             * @param activity the activity with which to execute this Navigation
             */
            @Override
            public void navigate(Activity activity) {
                if (requestCode == NO_REQUEST_CODE) {
                    activity.startActivity(intent);
                } else {
                    activity.startActivityForResult(intent, requestCode);
                }
            }
        }
    }

    /**
     * Update carrying the new list of {@link MenuItem}.
     */
    public static class ApplyMenuItems extends State {
        private final List<MenuItem> menuItems;

        public ApplyMenuItems(@NonNull MenuItem... menuItems) {
            super(APPLY_MENU_ITEMS);
            this.menuItems = menuItems == null
                    ? Collections.<MenuItem>emptyList()
                    : asList(menuItems);
        }

        public ApplyMenuItems(@NonNull List<MenuItem> menuItems) {
            super(APPLY_MENU_ITEMS);
            this.menuItems = menuItems;
        }

        @NonNull
        public List<MenuItem> getMenuItems() {
            return menuItems;
        }
    }

    /**
     * Update carrying a {@link Banner} object with data to be
     * displayed in the banner
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ShowBanner extends State {

        private final Banner banner;

        public ShowBanner(Banner banner) {
            super(SHOW_BANNER);
            this.banner = banner;
        }

        public Banner getBanner() {
            return banner;
        }
    }

    @RestrictTo(LIBRARY_GROUP)
    public static class ShowDialog extends State {

        private final DialogContent dialogContent;

        public ShowDialog(@NonNull DialogContent dialogContent) {
            super(SHOW_DIALOG);
            this.dialogContent = dialogContent;
        }

        public DialogContent getDialogContent() {
            return dialogContent;
        }
    }
}