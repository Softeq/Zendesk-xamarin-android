package zendesk.classic.messaging;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Data class that represents an informational update in the form of a banner
 * Use the {@link zendesk.classic.messaging.Banner.Builder} to create an instance
 */
public class Banner {

    private final String label;
    private final String buttonText;
    private final Position position;
    private final Duration duration;

    private Banner(@NonNull String label,
                   @Nullable String buttonText,
                   @Nullable Position position,
                   @Nullable Duration duration) {

        this.label = label;
        this.buttonText = buttonText;
        this.position = position;
        this.duration = duration;
    }

    public String getLabel() {
        return label;
    }

    public String getButtonText() {
        return buttonText;
    }

    public Duration getDuration() {
        return duration;
    }

    public Position getPosition() {
        return position;
    }

    public static class Builder {
        private final String label;
        private String buttonText = null;
        private Position position = Position.BOTTOM;
        private Duration duration = Duration.SHORT;

        public Builder(String label) {
            this.label = label;
        }

        /**
         * Adds text to the banner button. If no text is present the button is set to {View.GONE}.
         * Button text is null by default.
         *
         * @param buttonText the text to be displayed on the button.
         * @return Builder with the buttonText set
         */
        public Builder withButtonText(@Nullable String buttonText) {
            this.buttonText = buttonText;

            return this;
        }

        /**
         * Sets the duration of how long the banner should be displayed.
         * Banner is set to Short (4000ms) by default.
         * See {@link zendesk.classic.messaging.Banner.Duration} for values.
         *
         * @param duration of the banner
         * @return Builder with the duration set
         */
        public Builder setDuration(Duration duration) {
            this.duration = duration;

            return this;
        }

        /**
         * Constructs a new instance of {@link Banner}
         *
         * @return the constructed instance of {@link Banner}
         */
        public Banner build() {
            return new Banner(label,buttonText, position, duration);
        }
    }

    public enum Position {
        BOTTOM
    }

    public enum Duration {

        /**
         * 4000ms (4s) banner duration
         */
        SHORT,

        /**
         * Banners with indefinite duration will need to be manually dismissed
         */
        INDEFINITE;
    }
}

