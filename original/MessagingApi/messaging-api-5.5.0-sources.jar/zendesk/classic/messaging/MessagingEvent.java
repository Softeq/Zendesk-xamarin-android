package zendesk.classic.messaging;

import java.util.Date;

public interface MessagingEvent {

    Date getTimestamp();

}
