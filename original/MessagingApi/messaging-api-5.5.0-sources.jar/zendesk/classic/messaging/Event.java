package zendesk.classic.messaging;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import java.io.File;
import java.util.Date;
import java.util.List;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * Represents an event from Messaging SDK to be processed by the {@link Engine}.
 * <br>
 * Engine receive an event in the {@link Engine#onEvent(Event)} method.
 */
@RestrictTo(LIBRARY_GROUP)
public abstract class Event implements MessagingEvent {

    public static final String MESSAGE_SUBMITTED = "message_submitted";
    public static final String TYPING_STARTED = "typing_started";
    public static final String TYPING_STOPPED = "typing_stopped";
    public static final String TRANSFER_OPTION_CLICKED = "transfer_option_clicked";
    public static final String ACTION_OPTION_CLICKED = "action_option_clicked";
    public static final String ARTICLE_SUGGESTION_CLICKED = "article_suggestion_clicked";
    public static final String MESSAGE_DELETED = "message_deleted";
    public static final String MESSAGE_RESENT = "message_resent";
    public static final String MESSAGE_COPIED = "message_copied";
    public static final String RESPONSE_OPTION_CLICKED = "response_option_clicked";
    public static final String RECONNECT_BUTTON_CLICKED = "reconnect_button_clicked";
    public static final String FILE_SELECTED = "file_selected";
    public static final String RETRY_SEND_ATTACHMENT_CLICKED = "retry_send_attachment_clicked";
    public static final String ACTIVITY_RESULT_RECEIVED = "activity_result_received";
    public static final String MENU_ITEM_CLICKED = "menu_item_clicked";
    public static final String DIALOG_ITEM_CLICKED = "dialog_item_clicked";

    private final String type;
    private final Date timestamp;

    public Event(@NonNull String type, Date timestamp) {
        this.type = type;
        this.timestamp = timestamp;
    }

    /**
     * Gets the type. Used by the {@link Engine} to distinguish the events from one another.
     *
     * @return Unique {@link String} describing the type of {@link Event}.
     */
    @NonNull
    public String getType() {
        return type;
    }

    @Override
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * Event representing a text that was submitted by the user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class MessageSubmitted extends Event {

        private final String textInput;

        public MessageSubmitted(@NonNull String message, Date timestamp) {
            super(MESSAGE_SUBMITTED, timestamp);
            this.textInput = message;
        }

        /**
         * @return the text input that was submitted by the user.
         */
        @NonNull
        public String getTextInput() {
            return textInput;
        }
    }

    /**
     * Event representing an article clicked by the user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ArticleSuggestionClicked extends Event {

        private final MessagingItem.ArticlesResponse.ArticleSuggestion articleSuggestion;

        public ArticleSuggestionClicked(
                MessagingItem.ArticlesResponse.ArticleSuggestion articleSuggestion,
                Date timestamp) {
            super(ARTICLE_SUGGESTION_CLICKED, timestamp);
            this.articleSuggestion = articleSuggestion;
        }

        /**
         * @return a {@link MessagingItem.ArticlesResponse.ArticleSuggestion} that was selected by
         * the user.
         */
        @NonNull
        public MessagingItem.ArticlesResponse.ArticleSuggestion getArticleSuggestion() {
            return articleSuggestion;
        }
    }

    /**
     * Event representing a transfer option clicked by the user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class EngineSelection extends Event {

        private final Engine.TransferOptionDescription selectedEngine;

        public EngineSelection(@NonNull Engine.TransferOptionDescription selectedEngine, Date timestamp) {
            super(TRANSFER_OPTION_CLICKED, timestamp);
            this.selectedEngine = selectedEngine;
        }

        public Engine.TransferOptionDescription getSelectedEngine() {
            return selectedEngine;
        }
    }

    /**
     * Event representing an action option click by the user. The {@link ActionOptionClicked} object
     * will be passed to the current {@link Engine} for handling in its {@link Engine#onEvent(Event)}
     * method.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ActionOptionClicked extends Event {

        private final MessagingItem.Action action;

        public ActionOptionClicked(@NonNull MessagingItem.Action action, Date timestamp) {
            super(ACTION_OPTION_CLICKED, timestamp);
            this.action = action;
        }

        public MessagingItem.Action getAction() {
            return action;
        }
    }

    /**
     * Event representing that the user started typing
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class TypingStarted extends Event {

        public TypingStarted(Date timestamp) {
            super(TYPING_STARTED, timestamp);
        }
    }

    /**
     * Event representing that the user stopped typing.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class TypingStopped extends Event {

        public TypingStopped(Date timestamp) {
            super(TYPING_STOPPED, timestamp);
        }
    }

    /**
     * Event representing that delete option for a failed query was clicked by the user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class MessageDeleted extends Event {

        private final MessagingItem.Query message;

        public MessageDeleted(@NonNull MessagingItem.Query message, Date timestamp) {
            super(MESSAGE_DELETED, timestamp);
            this.message = message;
        }

        /**
         * Gets a failed query to be deleted.
         *
         * @return {@link MessagingItem.Query} with a failed status.
         */
        public MessagingItem.Query getMessage() {
            return message;
        }
    }

    /**
     * Event representing that retry option for a failed query was clicked by the user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class MessageResent extends Event {

        private final MessagingItem.Query query;

        public MessageResent(@NonNull MessagingItem.Query query, Date timestamp) {
            super(MESSAGE_RESENT, timestamp);
            this.query = query;
        }

        /**
         * Gets a failed query to be retried.
         *
         * @return {@link MessagingItem.Query} with a failed status.
         */
        public MessagingItem.Query getQuery() {
            return query;
        }
    }

    /**
     * Event representing that copy option for a query was clicked by the user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class CopyQueryClick extends Event {

        private final MessagingItem.Query query;

        public CopyQueryClick(@NonNull MessagingItem.Query query, Date timestamp) {
            super(MESSAGE_COPIED, timestamp);
            this.query = query;
        }

        /**
         * Gets a query to be copied.
         *
         * @return {@link MessagingItem.Query} with a failed status.
         */
        public MessagingItem.Query getQuery() {
            return query;
        }
    }

    /**
     * Event representing that an option from the form has been clicked.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ResponseOptionClicked extends Event {

        private final MessagingItem.OptionsResponse optionsResponse;
        private final MessagingItem.Option clickedOption;

        public ResponseOptionClicked(@NonNull MessagingItem.OptionsResponse optionsResponse,
                                     @NonNull MessagingItem.Option clickedOption,
                                     Date timestamp) {
            super(RESPONSE_OPTION_CLICKED, timestamp);
            this.optionsResponse = optionsResponse;
            this.clickedOption = clickedOption;
        }

        /**
         * @return a {@link MessagingItem.OptionsResponse} for which the option has been clicked.
         */
        public MessagingItem.OptionsResponse getOptionsResponse() {
            return optionsResponse;
        }

        /**
         * @return a {@link MessagingItem.Option} that has been clicked
         */
        public MessagingItem.Option getClickedOption() {
            return clickedOption;
        }
    }

    @RestrictTo(LIBRARY_GROUP)
    public static class ReconnectButtonClicked extends Event {

        public ReconnectButtonClicked(Date timestamp) {
            super(RECONNECT_BUTTON_CLICKED, timestamp);
        }
    }

    /**
     * Event representing an attachment that was submitted by the user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class FileSelected extends Event {

        private final List<File> attachments;

        public FileSelected(@NonNull List<File> attachments, Date timestamp) {
            super(FILE_SELECTED, timestamp);
            this.attachments = attachments;
        }

        /**
         * @return a list of {@link File}s that were attached by the user.
         */
        @NonNull
        public List<File> getAttachments() {
            return attachments;
        }
    }

    /**
     * Event representing that retry option for a failed attachment send was clicked by the user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class RetrySendAttachmentClick extends Event {

        private final MessagingItem.FileQuery failedFileQuery;

        public RetrySendAttachmentClick(MessagingItem.FileQuery failedFileQuery, Date timestamp) {
            super(RETRY_SEND_ATTACHMENT_CLICKED, timestamp);
            this.failedFileQuery = failedFileQuery;
        }

        /**
         * Gets a failed query to be retried.
         *
         * @return {@link MessagingItem.FileQuery} with a failed status.
         */
        public MessagingItem.FileQuery getFailedFileQuery() {
            return failedFileQuery;
        }
    }

    /**
     * Event representing the data involved in a navigation event which results in onActivityResult being called.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ActivityResult extends Event {

        private final int requestCode;
        private final int resultCode;
        private final Intent data;

        public ActivityResult(int requestCode, int resultCode, Intent data, Date timestamp) {
            super(ACTIVITY_RESULT_RECEIVED, timestamp);
            this.requestCode = requestCode;
            this.resultCode = resultCode;
            this.data = data;
        }

        /**
         * @return the Request Code for the Navigation event
         */
        public int getRequestCode() {
            return requestCode;
        }

        /**
         * @return the Result Code for the Navigation event
         */
        public int getResultCode() {
            return resultCode;
        }

        /**
         * @return the Data representing the payload from the Navigation event
         */
        public Intent getData() {
            return data;
        }
    }

    /**
     * Event representing that a menu item was clicked.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class MenuItemClicked extends Event {

        private final int menuItemId;

        public MenuItemClicked(Date timestamp, int menuItemId) {
            super(MENU_ITEM_CLICKED, timestamp);
            this.menuItemId = menuItemId;
        }

        /**
         * Gets the identifier of the clicked menu item.
         *
         * @return {@link MenuItem#getItemId()}
         */
        public int getMenuItemId() {
            return menuItemId;
        }
    }

    @RestrictTo(LIBRARY_GROUP)
    public static class DialogItemClicked extends Event {
        private final DialogContent.Config config;
        private final boolean isPositive;
        private final String payload;
        private final DialogContent.Config previousConfig;


        private DialogItemClicked(Date timestamp,
                                 DialogContent.Config config,
                                 boolean isPositive,
                                 @Nullable String payload,
                                 @Nullable DialogContent.Config previousConfig) {
            super(DIALOG_ITEM_CLICKED, timestamp);
            this.config = config;
            this.isPositive = isPositive;
            this.payload = payload;
            this.previousConfig = previousConfig;
        }

        public DialogContent.Config getConfig() {
            return config;
        }

        public boolean isPositive() {
            return isPositive;
        }

        public String getPayload() {
            return payload;
        }

        public DialogContent.Config getPreviousConfig() {
            return previousConfig;
        }

        @RestrictTo(LIBRARY_GROUP)
        public static class Builder {

            private final Date timestamp;
            private final DialogContent.Config config;
            private final boolean isPositive;
            private String payload = null;
            private DialogContent.Config previousConfig = null;

            public Builder(Date timestamp, DialogContent.Config config, boolean isPositive) {
                this.timestamp = timestamp;
                this.config = config;
                this.isPositive = isPositive;
            }

            /**
             * Sets the payload returned from the dialog EditText
             *
             * @param payload string payload
             * @return Builder with the payload set
             */
            public Builder setPayload(String payload) {
                this.payload = payload;
                return this;
            }

            /**
             * Sets the config of the dialog that was shown before the current one
             *
             * @param previousConfig previous config
             * @return Builder with the previous config set
             */
            public Builder setPreviousConfig(DialogContent.Config previousConfig) {
                this.previousConfig = previousConfig;
                return this;
            }

            public DialogItemClicked build() {
                return new DialogItemClicked(timestamp, config, isPositive, payload, previousConfig);
            }
        }
    }
}