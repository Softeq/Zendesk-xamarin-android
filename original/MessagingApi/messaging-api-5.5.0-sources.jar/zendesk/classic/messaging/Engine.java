package zendesk.classic.messaging;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * Interface defining the functionality of an Engine which can be used for driving a conversation in the Unified SDK.
 *
 * Integrators should extend {@link ObservableEngine} rather than directly implementing this Interface.
 */
@RestrictTo(LIBRARY_GROUP)
public interface Engine {

    /**
     * Notifies the engine to start talking.
     *
     * @param messagingApi API to update the Messaging stream.
     */
    void start(@NonNull MessagingApi messagingApi);

    /**
     * Notifies the engine to stop talking.
     */
    void stop();

    /**
     * Gets an unique identifier of the Engine.
     *
     * @return Unique {@link String} that identifies this {@link Engine}.
     */
    @NonNull
    String getId();

    /**
     * Returns details of the available transfer option supported by the Engine. An Engine which can be transferred to
     * from other Engines (such as Answer Bot transferring to Support, or to Chat), should return a non-null value
     * for this method.
     * <p>
     * The returned {@link TransferOptionDescription} object should include the ID of the Engine and a
     * localised string. The string will be shown on-screen to the user, in a view which the user clicks to trigger a
     * transfer to that Engine.
     * <p>
     * An Engine that does not support being transferred to (such as Answer Bot), should return null.
     * Null TransferOptionDescription objects are filtered from the list before transfer options are
     * presented to the end user.
     *
     * @return {@link TransferOptionDescription}.
     */
    @Nullable
    TransferOptionDescription getTransferOptionDescription();

    /**
     * Return {@code true} if this engine has an ongoing conversation to continue, or {@code false} if it does not
     *
     * @deprecated in 5.0.0. This method is no longer called. Integrators should implement
     * {@link #isConversationOngoing(ConversationOnGoingCallback) instead}
     */
    @Deprecated
    boolean isConversationOngoing();

    /**
     * Check if this Engine has an ongoing conversation to restore.
     * <p>
     * The completion is provided as this may require an asynchronous check, to the network or to restore from disk.
     * An Engine must call the given completion when it has determined if it has a conversation to restore
     *
     * @param conversationOnGoingCallback the completion for the Engine to notify
     */
    void isConversationOngoing(ConversationOnGoingCallback conversationOnGoingCallback);

    /**
     * Notifies this engine that an event has occurred
     *
     * @param event the event which has occurred
     */
    void onEvent(@NonNull Event event);

    /**
     * Registers an observer to be notified of any updates this Engine may have
     *
     * @param updateObserver the UpdateObserver to register
     * @return {@code true} if the UpdateObserver was registered successfully, or {@code false} if it was not
     */
    boolean registerObserver(UpdateObserver updateObserver);

    /**
     * Unregisters an observer to no longer be notified of any updates this Engine may have
     *
     * @param updateObserver the UpdateObserver to unregister
     * @return {@code true} if the UpdateObserver was unregistered successfully, or {@code false} if it was not
     */
    boolean unregisterObserver(UpdateObserver updateObserver);

    /**
     * Notifies all registered UpdateObservers of an Update
     *
     * @param update the Update about which to notify UpdateObservers
     */
    void notifyObservers(Update update);

    /**
     * Holds information describing the available transfer option supported by the {@link Engine}.
     */
    @RestrictTo(LIBRARY_GROUP)
    class TransferOptionDescription {

        private final String engineId;
        private final String displayName;

        public TransferOptionDescription(String engineId, @NonNull String displayName) {
            this.engineId = engineId;
            this.displayName = displayName;
        }

        /**
         * Gets the ID of the Engine
         *
         * @return the ID of the Engine
         */
        public String getEngineId() {
            return engineId;
        }

        /**
         * Gets a display name of the Engine.
         *
         * @return Localized {@link String}.
         */
        @NonNull
        public String getDisplayName() {
            return displayName;
        }
    }

    @RestrictTo(LIBRARY_GROUP)
    interface UpdateObserver {
        void update(Update update);
    }

    /**
     * Provides a callback so Engines can inform a caller of whether they have an ongoing conversation to restore
     */
    @RestrictTo(LIBRARY_GROUP)
    interface ConversationOnGoingCallback {

        /**
         * Callback to inform a caller of {@link Engine#isConversationOngoing(ConversationOnGoingCallback)}  of
         * whether an Engine has an ongoing conversation to restore
         *
         * @param engine                the Engine calling the callback
         * @param isConversationOngoing whether there is an ongoing conversation to restore
         */
        void onConversationOngoing(Engine engine, boolean isConversationOngoing);
    }

}
