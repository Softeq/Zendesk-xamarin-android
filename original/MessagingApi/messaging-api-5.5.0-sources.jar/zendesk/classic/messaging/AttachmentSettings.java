package zendesk.classic.messaging;

public class AttachmentSettings {

    private final long maxFileSize;
    private final boolean sendingEnabled;

    /**
     * Constructs an instance of {@link AttachmentSettings}
     *
     * @param maxFileSize    the maximum allowed file size in bytes
     * @param sendingEnabled true if attachment sending is enabled, false otherwise
     */
    public AttachmentSettings(long maxFileSize, boolean sendingEnabled) {
        this.maxFileSize = maxFileSize;
        this.sendingEnabled = sendingEnabled;
    }

    /**
     * @return the max allowable file size in bytes
     */
    public long getMaxFileSize() {
        return maxFileSize;
    }

    /**
     * @return true if attachment sending is enabled, false otherwise
     */
    public boolean isSendingEnabled() {
        return sendingEnabled;
    }

}
