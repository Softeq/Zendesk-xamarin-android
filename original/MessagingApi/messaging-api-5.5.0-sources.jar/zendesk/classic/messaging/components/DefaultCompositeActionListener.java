package zendesk.classic.messaging.components;

import androidx.annotation.RestrictTo;

import java.util.ArrayList;
import java.util.List;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public final class DefaultCompositeActionListener<T> extends CompositeActionListener<T> {

    private final List<ActionListener<T>> listeners = new ArrayList<>();

    @Override
    public void onAction(T data) {
        synchronized (listeners) {
            for (ActionListener<T> listener : listeners) {
                listener.onAction(data);
            }
        }
    }

    @Override
    public void addListener(ActionListener<T> listener) {
        synchronized (listeners) {
            listeners.add(listener);
        }
    }

    @Override
    public void clearListeners() {
        listeners.clear();
    }
}
