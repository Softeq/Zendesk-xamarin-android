package zendesk.classic.messaging.components;

import androidx.annotation.RestrictTo;
import android.view.View;

/**
 * Action listener to which other ActionListeners can "subscribe"
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public abstract class CompositeActionListener<T> implements ActionListener<T> {

    /**
     * Returns a {@link View.OnClickListener} that will relay clicks to the given {@link CompositeActionListener}.
     */
    public static View.OnClickListener clicks(final CompositeActionListener<Void> observer) {
        return clicks(null, observer);
    }

    /**
     * Returns a {@link View.OnClickListener} that will relay data to the given {@link CompositeActionListener}
     * when a click happens
     */
    public static <T> View.OnClickListener clicks(final T data, final CompositeActionListener<T> observer) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                observer.onAction(data);
            }
        };
    }

    /**
     * Creates a default composite action listener
     */
    public static <T> CompositeActionListener<T> create() {
        return new DefaultCompositeActionListener<>();
    }

    /**
     * Add listener to be notified of updates
     * @param listener the listener to add
     */
    public abstract void addListener(ActionListener<T> listener);

    /**
     * Removes all currently registered listeners from this observer
     */
    public abstract void clearListeners();
}
