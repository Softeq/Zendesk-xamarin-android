package zendesk.classic.messaging.components;

import androidx.annotation.RestrictTo;

import java.util.UUID;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public interface IdProvider {

    String getNewId();

    IdProvider UUID_PROVIDER = new IdProvider() {
        @Override
        public String getNewId() {
            return UUID.randomUUID().toString();
        }
    };
}