package zendesk.classic.messaging.components;

import androidx.annotation.RestrictTo;

/**
 * Listener that can pass a generic type
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public interface ActionListener<T> {

    void onAction(T data);
}
