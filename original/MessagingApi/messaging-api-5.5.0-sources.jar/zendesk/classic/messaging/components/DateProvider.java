package zendesk.classic.messaging.components;

import androidx.annotation.RestrictTo;

import java.util.Date;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class DateProvider {

    public DateProvider() { /* Intentionally empty, here so Dagger can instantiate the class */ }

    public Date now() {
        return new Date();
    }

}
