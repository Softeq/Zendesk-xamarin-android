package zendesk.classic.messaging.components.bot;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.TimeUnit;

import zendesk.classic.messaging.Update;
import zendesk.classic.messaging.components.ActionListener;
import zendesk.classic.messaging.components.Timer;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class BotMessageDispatcher<T> {

    private final MessageIdentifier<T> messageIdentifier;
    private final ActionListener<ConversationState<T>> stateActionListener;
    private final ActionListener<Update> updateActionListener;

    private boolean showTypingIndicator;

    private static final int TYPING_INDICATOR_DELAY = (int) TimeUnit.MILLISECONDS.toMillis(1200);

    private List<T> messages = new ArrayList<>();

    private Queue<Dispatch<T>> messageQueue = new LinkedList<>();

    private boolean messageProcessing = false;

    private Timer.Factory timerFactory;

    public BotMessageDispatcher(MessageIdentifier<T> messageIdentifier,
                                ActionListener<ConversationState<T>> stateActionListener,
                                ActionListener<Update> updateActionListener,
                                Timer.Factory timerFactory) {
        this.messageIdentifier = messageIdentifier;
        this.stateActionListener = stateActionListener;
        this.updateActionListener = updateActionListener;
        this.timerFactory = timerFactory;
    }

    private void processMessage() {
        final Dispatch<T> dispatch = messageQueue.poll();
        if (dispatch != null) {
            messageProcessing = true;
            showTypingIndicator = true;
            dispatchState();

            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    BotMessageDispatcher.this.messages.addAll(dispatch.messages);
                    for (Update update : dispatch.updates) {
                        if (update != null) {
                            dispatchUpdate(update);
                        }
                    }
                    messageProcessing = false;
                    showTypingIndicator = false;
                    dispatchState();
                    processMessage();
                    if (dispatch.dispatchListener != null) {
                        dispatch.dispatchListener.onDispatch();
                    }
                }
            };

            Timer timer = timerFactory.create(runnable, TYPING_INDICATOR_DELAY);

            timer.start();
        }
    }

    public void removeMessage(@NonNull String id) {
        for (T message : messages) {
            if (id.equals(messageIdentifier.getId(message))) {
                messages.remove(message);
                dispatchState();
                return;
            }
        }
    }

    public void addMessageWithTypingIndicator(T message, Update... updates) {
        addMessagesWithTypingIndicator(Collections.singletonList(message), null, updates);
    }

    public void addMessageWithTypingIndicator(T message, DispatchListener listener) {
        addMessagesWithTypingIndicator(Collections.singletonList(message), listener);
    }

    public void addMessageWithTypingIndicator(T message, DispatchListener listener, Update... updates) {
        addMessagesWithTypingIndicator(Collections.singletonList(message), listener, updates);
    }

    public void addMessagesWithTypingIndicator(List<T> messages, Update... updates) {
        addMessagesWithTypingIndicator(messages, null, updates);
    }

    /**
     * Sends a list of messages to the dispatcher, which will be dispatched after {@link #TYPING_INDICATOR_DELAY}
     * milliseconds.
     *
     * @param messages         the messages to be dispatched
     * @param dispatchListener a listener which will be notified once the given messages have been dispatched
     * @param updates          an optional varargs of Updates which will be dispatched once the given messages have
     *                         been dispatched
     */
    public void addMessagesWithTypingIndicator(
            List<T> messages,
            @Nullable DispatchListener dispatchListener,
            Update... updates) {
        messageQueue.add(new Dispatch<>(messages, dispatchListener, Arrays.asList(updates)));
        if (!messageProcessing) {
            processMessage();
        }
    }

    public void addMessage(T message) {
        if (message != null) {
            messages.add(message);
        }
        dispatchState();

    }

    public void replaceMessage(String id, T message) {
        removeMessage(id);
        messages.add(message);
        dispatchState();
    }

    public void dispatchState() {
        stateActionListener.onAction(new ConversationState<>(getCopyOfMessages(), showTypingIndicator));
    }

    public void dispatchUpdate(Update update) {
        updateActionListener.onAction(update);
    }

    public void removeLastMessages(int countToRemove) {
        if (countToRemove <= 0) {
            return;
        }

        if (messages.size() < countToRemove) {
            messages.clear();
        } else {
            messages = messages.subList(0, messages.size() - countToRemove);
        }
        dispatchState();
    }

    @NonNull
    private List<T> getCopyOfMessages() {
        return CollectionUtils.copyOf(messages);
    }

    @Nullable
    public T getMessageById(String id) {
        for (T message : messages) {
            if (messageIdentifier.getId(message).equals(id)) {
                return message;
            }
        }
        return null;
    }

    @Nullable
    public T getLastMessage() {
        if (CollectionUtils.isEmpty(messages)) {
            return null;
        }

        return messages.get(messages.size() - 1);
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static class ConversationState<T> {

        @NonNull
        private final List<T> messages;
        private final boolean typingIndicator;

        ConversationState(@NonNull List<T> messages, boolean typingIndicator) {
            this.messages = messages;
            this.typingIndicator = typingIndicator;
        }

        @NonNull
        public List<T> getMessages() {
            return messages;
        }

        public boolean shouldShowTypingIndicator() {
            return typingIndicator;
        }
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public interface MessageIdentifier<T> {
        String getId(T t);
    }

    static class Dispatch<T> {
        private final List<T> messages;
        private final DispatchListener dispatchListener;
        private final List<Update> updates;

        Dispatch(List<T> messages, DispatchListener dispatchListener, List<Update> updates) {
            this.messages = messages;
            this.dispatchListener = dispatchListener;
            this.updates = updates;
        }
    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public interface DispatchListener {
        void onDispatch();
    }
}
