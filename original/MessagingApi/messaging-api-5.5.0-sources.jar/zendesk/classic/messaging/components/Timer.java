package zendesk.classic.messaging.components;

import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class Timer {

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static class Factory {

        private final Handler handler;

        public Factory(@NonNull Handler handler) {
            this.handler = handler;
        }

        public Timer create(@NonNull Runnable runnable, int timeout) {
            return new Timer(handler, runnable, timeout);
        }
    }

    private final Handler handler;
    private final Runnable runnable;
    private final int timeout;
    private boolean isEnabled = true;
    private boolean isCompleted = false;

    public Timer(@NonNull Handler handler, @NonNull final Runnable runnable, int timeout) {
        this.handler = handler;
        this.runnable = new Runnable() {
            @Override
            public void run() {
                runnable.run();
                isCompleted = true;
            }
        };
        this.timeout = timeout;
    }

    /**
     * Start the timer, if it is enabled and not completed.
     *
     * @return true if the timer was started, and false if it wasn't (ie, if it wasn't enabled or
     * was already completed).
     */
    public boolean start() {
        if (isEnabled && !isCompleted) {
            handler.removeCallbacks(runnable);
            handler.postDelayed(runnable, timeout);
            return true;
        } else {
            return false;
        }
    }

    public void disable() {
        handler.removeCallbacks(runnable);
        isEnabled = false;
    }
}