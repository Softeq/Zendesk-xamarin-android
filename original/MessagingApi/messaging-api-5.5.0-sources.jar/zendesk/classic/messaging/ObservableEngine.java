package zendesk.classic.messaging;

import androidx.annotation.RestrictTo;

import java.util.HashSet;
import java.util.Set;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * Abstract implementation of the {@link Engine} interface which manages observers for the Engine's updates,
 * registering, unregistering and notifying them of Updates
 */
@RestrictTo(LIBRARY_GROUP)
public abstract class ObservableEngine implements Engine {

    private final Set<UpdateObserver> updateObservers;

    public ObservableEngine() {
        updateObservers = new HashSet<>();
    }

    @Override
    public boolean registerObserver(UpdateObserver updateObserver) {
        return updateObservers.add(updateObserver);
    }

    @Override
    public boolean unregisterObserver(UpdateObserver updateObserver) {
        return updateObservers.remove(updateObserver);
    }

    @Override
    public void notifyObservers(Update update) {
        for (UpdateObserver observer : updateObservers) {
            observer.update(update);
        }
    }

    /**
     * Default implementation, this method is deprecated as of 5.0.0 and should not be used or overriden.
     *
     * @deprecated in 5.0.0. This method is no longer called. Integrators should implement
     * {@link #isConversationOngoing(ConversationOnGoingCallback) instead}
     */
    @Override
    public boolean isConversationOngoing() {
        return false;
    }

    /**
     * Default implementation, presumes the engine does not have a conversation to observe. Subclasses can override
     * this if they wish to provide their own logic for this.
     *
     * @param conversationOnGoingCallback the completion for the Engine to notify
     */
    @Override
    public void isConversationOngoing(ConversationOnGoingCallback conversationOnGoingCallback) {
        conversationOnGoingCallback.onConversationOngoing(this, false);
    }
}
