package zendesk.classic.messaging;

import androidx.annotation.StringRes;

/**
 * Model for the menu item.
 */
public class MenuItem {

    private final int itemId;
    private final int labelId;

    public MenuItem(int itemId, int labelId) {
        this.itemId = itemId;
        this.labelId = labelId;
    }

    /**
     * Gets the identifier of this menu item.
     *
     * @return int value guaranteed to be unique for each menu item.
     */
    public int getItemId() {
        return itemId;
    }

    /**
     * Gets the label of this menu item.
     *
     * @return The string resource identifier
     */
    @StringRes
    public int getLabelId() {
        return labelId;
    }
}