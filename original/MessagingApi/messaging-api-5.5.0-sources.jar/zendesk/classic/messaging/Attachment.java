package zendesk.classic.messaging;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import java.io.File;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * An attachment model describing basic properties of the shared file.
 */
@RestrictTo(LIBRARY_GROUP)
public class Attachment {

    private final String name;
    private final long size;
    private final String url;
    private final File file;

    public Attachment(String name,
                      long size,
                      @Nullable String url,
                      @Nullable File file) {
        this.name = name;
        this.size = size;
        this.url = url;
        this.file = file;
    }

    /**
     * Gets the name of the shared file.
     *
     * @return The file name with the extension, e.g. notes.txt
     */
    @NonNull
    public String getName() {
        return name;
    }

    /**
     * Gets the size of the shared file in bytes.
     *
     * @return File size in bytes, e.g. 1048576.
     */
    public long getSize() {
        return size;
    }

    /**
     * Gets the remote url to download the shared file.
     *
     * @return An URL or {@code null} if file has not been uploaded yet.
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the local file represented by this attachment.
     *
     * @return {@link File} if attachment was sent from this device and remains cached or {@code null} otherwise.
     */
    @Nullable
    public File getFile() {
        return file;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Attachment that = (Attachment) o;

        if (size != that.size) {
            return false;
        }
        if (name != null ? !name.equals(that.name) : that.name != null) {
            return false;
        }
        if (url != null ? !url.equals(that.url) : that.url != null) {
            return false;
        }
        return file != null ? file.equals(that.file) : that.file == null;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (int) (size ^ (size >>> 32));
        result = 31 * result + (url != null ? url.hashCode() : 0);
        result = 31 * result + (file != null ? file.hashCode() : 0);
        return result;
    }
}
