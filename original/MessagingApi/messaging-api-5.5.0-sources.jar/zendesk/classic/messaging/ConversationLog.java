package zendesk.classic.messaging;

import androidx.annotation.RestrictTo;

/**
 * Defines the functionality required to provide a log of all messages and events in a conversation
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public interface ConversationLog {

    /**
     * Returns the log of the conversation as a formatted string
     */
    String getLog();

}
