package zendesk.classic.messaging;

/**
 * Enumeration of all possible states of the connection.
 */
public enum ConnectionState {

    CONNECTING,

    CONNECTED,

    RECONNECTING,

    FAILED,

    DISCONNECTED,

    UNREACHABLE
}
