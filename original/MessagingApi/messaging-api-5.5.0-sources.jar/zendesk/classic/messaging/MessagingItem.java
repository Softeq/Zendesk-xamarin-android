package zendesk.classic.messaging;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import java.io.File;
import java.util.Date;
import java.util.List;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * Base representation of the message in a Messaging SDK.
 * <p>
 * All different types of the messages must extend this class.
 */
@RestrictTo(LIBRARY_GROUP)
public abstract class MessagingItem implements MessagingEvent {

    private final Date timestamp;
    private final String id;

    MessagingItem(Date timestamp, String id) {
        this.timestamp = timestamp;
        this.id = id;
    }

    @Override
    public Date getTimestamp() {
        return timestamp;
    }

    public String getId() {
        return id;
    }

    /**
     * Base representation of the message submitted by the end user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public abstract static class Query extends MessagingItem {

        /**
         * Describes the delivery status of a {@link MessagingItem}.
         */
        @RestrictTo(LIBRARY_GROUP)
        public enum Status {

            /**
             * The item is currently being delivered.
             */
            PENDING,

            /**
             * The item has been successfully delivered.
             */
            DELIVERED,

            /**
             * The item has failed to deliver successfully and can be retried.
             */
            FAILED,

            /**
             * The item has failed to deliver successfully and cannot be retried. This status should
             * only be used for attachments, other types will default to using {@link #FAILED}
             */
            FAILED_NO_RETRY
        }

        private final Status status;

        Query(Date timestamp, String id, Status status) {
            super(timestamp, id);
            this.status = status;
        }

        public Status getStatus() {
            return status;
        }
    }

    /**
     * Text message submitted by the end user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class TextQuery extends Query {

        private final String message;

        public TextQuery(
                Date timestamp,
                String id,
                Status status,
                String message) {
            super(timestamp, id, status);
            this.message = message;
        }

        public String getMessage() {
            return message;
        }

    }

    /**
     * Image attachment submitted by the end user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ImageQuery extends FileQuery {

        public ImageQuery(Date timestamp,
                          String id,
                          Status status,
                          Attachment attachment,
                          @Nullable FailureReason failureReason) {
            super(timestamp, id, status, attachment, failureReason);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #ImageQuery(Date, String, Status, Attachment, FailureReason)} instead.
         */
        @Deprecated
        public ImageQuery(Date timestamp,
                          String id,
                          Status status,
                          @Nullable File localFile,
                          @Nullable String remotePath,
                          @Nullable FailureReason failureReason) {
            super(timestamp, id, status, localFile, remotePath, failureReason);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #ImageQuery(Date, String, Status, Attachment, FailureReason)} instead.
         */
        @Deprecated
        public ImageQuery(Date timestamp,
                          String id,
                          Status status,
                          @NonNull File localFile,
                          @Nullable FailureReason failureReason) {
            super(timestamp, id, status, localFile, failureReason);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #ImageQuery(Date, String, Status, Attachment, FailureReason)} instead.
         */
        @Deprecated
        public ImageQuery(Date timestamp,
                          String id,
                          Status status,
                          @NonNull String remotePath,
                          @Nullable FailureReason failureReason) {
            super(timestamp, id, status, remotePath, failureReason);
        }
    }

    /**
     * File attachment submitted by the end user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class FileQuery extends Query {

        @RestrictTo(LIBRARY_GROUP)
        public enum FailureReason {
            FILE_SIZE_TOO_LARGE,
            FILE_SENDING_DISABLED,
            UNSUPPORTED_FILE_TYPE
        }

        private final Attachment attachment;
        private final FailureReason failureReason;

        public FileQuery(Date timestamp,
                         String id,
                         Status status,
                         Attachment attachment,
                         @Nullable FailureReason failureReason) {
            super(timestamp, id, status);
            this.attachment = attachment;
            this.failureReason = failureReason;
        }

        /**
         * @deprecated As of 4.2.0, use {@link #FileQuery(Date, String, Status, Attachment, FailureReason)} instead.
         */
        @Deprecated
        public FileQuery(Date timestamp,
                         String id,
                         Status status,
                         @Nullable File localFile,
                         @Nullable String remotePath,
                         @Nullable FailureReason failureReason) {
            super(timestamp, id, status);

            String name;
            long size;
            if (localFile != null) {
                name = localFile.getName();
                size = localFile.length();
            } else {
                //noinspection ConstantConditions
                name = new File(remotePath).getName();
                size = -1;
            }

            this.attachment = new Attachment(name, size, remotePath, localFile);
            this.failureReason = failureReason;
        }

        /**
         * @deprecated As of 4.2.0, use {@link #FileQuery(Date, String, Status, Attachment, FailureReason)} instead.
         */
        @Deprecated
        public FileQuery(Date timestamp,
                         String id,
                         Status status,
                         @NonNull File localFile,
                         @Nullable FailureReason failureReason) {
            this(timestamp, id, status, localFile, null, failureReason);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #FileQuery(Date, String, Status, Attachment, FailureReason)} instead.
         */
        @Deprecated
        public FileQuery(Date timestamp,
                         String id,
                         Status status,
                         @NonNull String remotePath,
                         @Nullable FailureReason failureReason) {
            this(timestamp, id, status, null, remotePath, failureReason);
        }

        /**
         * Gets the attachment describing the shared file.
         *
         * @return {@link Attachment}
         */
        @NonNull
        public Attachment getAttachment() {
            return attachment;
        }

        /**
         * Gets the locally cached file.
         *
         * @return {@link File} if attachment was sent from this device and remains cached or {@code null} otherwise.
         * @deprecated As of 4.2.0, use {@link #getAttachment()} and {@link Attachment#getFile()} instead.
         */
        @Deprecated
        @Nullable
        public File getLocalFile() {
            return attachment.getFile();
        }

        /**
         * Gets the URL to download the shared file.
         *
         * @return An URL or {@code null} if file has not been uploaded yet.
         * @deprecated As of 4.2.0, use {@link #getAttachment()} and {@link Attachment#getUrl()} instead.
         */
        @Deprecated
        @Nullable
        public String getRemotePath() {
            return attachment.getUrl();
        }

        @Nullable
        public FailureReason getFailureReason() {
            return failureReason;
        }
    }

    /**
     * Base representation of the message submitted by an agent.
     */
    @RestrictTo(LIBRARY_GROUP)
    public abstract static class Response extends MessagingItem {

        private final AgentDetails agentDetails;

        public Response(Date timestamp,
                        String id,
                        AgentDetails agentDetails) {
            super(timestamp, id);
            this.agentDetails = agentDetails;
        }

        public AgentDetails getAgentDetails() {
            return agentDetails;
        }

    }

    @RestrictTo(LIBRARY_GROUP)
    public static class TextResponse extends Response {

        private final String message;

        public TextResponse(Date timestamp, String id, AgentDetails agentDetails, String message) {
            super(timestamp, id, agentDetails);
            this.message = message;
        }

        public String getMessage() {
            return message;
        }
    }

    /**
     * Image attachment submitted by an agent to the end user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ImageResponse extends FileResponse {

        public ImageResponse(Date timestamp,
                             String id,
                             AgentDetails agentDetails,
                             Attachment attachment) {
            super(timestamp, id, agentDetails, attachment);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #ImageResponse(Date, String, AgentDetails, Attachment)}
         */
        @Deprecated
        public ImageResponse(Date timestamp,
                             String id,
                             AgentDetails agentDetails,
                             @Nullable File localFile,
                             @Nullable String remotePath) {
            super(timestamp, id, agentDetails, localFile, remotePath);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #ImageResponse(Date, String, AgentDetails, Attachment)}
         */
        @Deprecated
        public ImageResponse(Date timestamp,
                             String id,
                             AgentDetails agentDetails,
                             @NonNull File localFile) {
            super(timestamp, id, agentDetails, localFile);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #ImageResponse(Date, String, AgentDetails, Attachment)}
         */
        @Deprecated
        public ImageResponse(Date timestamp,
                             String id,
                             AgentDetails agentDetails,
                             @NonNull String remotePath) {
            super(timestamp, id, agentDetails, remotePath);
        }

    }

    /**
     * File attachment submitted by an agent to the end user.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class FileResponse extends Response {

        private final Attachment attachment;

        public FileResponse(Date timestamp,
                            String id,
                            AgentDetails agentDetails,
                            Attachment attachment) {
            super(timestamp, id, agentDetails);
            this.attachment = attachment;
        }

        /**
         * @deprecated As of 4.2.0, use {@link #FileResponse(Date, String, AgentDetails, Attachment)}
         */
        @Deprecated
        public FileResponse(Date timestamp,
                            String id,
                            AgentDetails agentDetails,
                            @Nullable File localFile,
                            @Nullable String remotePath) {
            super(timestamp, id, agentDetails);
            String name;
            long size;
            if (localFile != null) {
                name = localFile.getName();
                size = localFile.length();
            } else {
                //noinspection ConstantConditions
                name = new File(remotePath).getName();
                size = -1;
            }
            this.attachment = new Attachment(name, size, remotePath, localFile);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #FileResponse(Date, String, AgentDetails, Attachment)}
         */
        @Deprecated
        public FileResponse(Date timestamp,
                            String id,
                            AgentDetails agentDetails,
                            @NonNull File localFile) {
            this(timestamp, id, agentDetails, localFile, null);
        }

        /**
         * @deprecated As of 4.2.0, use {@link #FileResponse(Date, String, AgentDetails, Attachment)}
         */
        @Deprecated
        public FileResponse(Date timestamp,
                            String id,
                            AgentDetails agentDetails,
                            @NonNull String remotePath) {
            this(timestamp, id, agentDetails, null, remotePath);
        }

        /**
         * Gets the attachment describing the shared file.
         *
         * @return {@link Attachment}
         */
        @NonNull
        public Attachment getAttachment() {
            return attachment;
        }

        /**
         * Gets the locally cached file.
         *
         * @return {@link File} if attachment was sent from this device and remains cached or {@code null} otherwise.
         * @deprecated As of 4.2.0, use {@link #getAttachment()} and {@link Attachment#getFile()} instead.
         */
        @Deprecated
        @Nullable
        public File getLocalFile() {
            return attachment.getFile();
        }

        /**
         * Gets the URL to download the shared file.
         *
         * @return An URL or {@code null} if file has not been uploaded yet.
         * @deprecated As of 4.2.0, use {@link #getAttachment()} and {@link Attachment#getUrl()} instead.
         */
        @Deprecated
        @Nullable
        public String getRemotePath() {
            return attachment.getUrl();
        }
    }

    /**
     * Structural message containing an articles submitted by an agent.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ArticlesResponse extends Response {

        private final List<ArticleSuggestion> articleSuggestions;

        public ArticlesResponse(Date timestamp,
                                String id,
                                AgentDetails agentDetails,
                                List<ArticleSuggestion> articleSuggestions) {
            super(timestamp, id, agentDetails);
            this.articleSuggestions = articleSuggestions;
        }

        public List<ArticleSuggestion> getArticleSuggestions() {
            return articleSuggestions;
        }

        @RestrictTo(LIBRARY_GROUP)
        public static class ArticleSuggestion {

            private final String articleInteractionId;
            private final String articleUrl;
            private final long articleId;
            private final String title;
            private final String snippet;

            public ArticleSuggestion(
                    String articleInteractionId,
                    String articleUrl,
                    long articleId,
                    String title,
                    String snippet) {
                this.articleInteractionId = articleInteractionId;
                this.articleUrl = articleUrl;
                this.articleId = articleId;
                this.title = title;
                this.snippet = snippet;
            }

            public String getArticleInteractionId() {
                return articleInteractionId;
            }

            public String getArticleUrl() {
                return articleUrl;
            }

            public long getArticleId() {
                return articleId;
            }

            public String getTitle() {
                return title;
            }

            public String getSnippet() {
                return snippet;
            }
        }
    }

    /**
     * Structural message containing available transfer options submitted by an agent.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class TransferResponse extends Response {

        private final String message;
        private final List<Engine.TransferOptionDescription> engineOptions;
        private final boolean enabled;

        public TransferResponse(Date timestamp,
                                String id,
                                AgentDetails agentDetails,
                                String message,
                                List<Engine.TransferOptionDescription> engineOptions) {
            this(timestamp, id, agentDetails, message, engineOptions, true);
        }


        public TransferResponse(Date timestamp,
                                String id,
                                AgentDetails agentDetails,
                                String message,
                                List<Engine.TransferOptionDescription> engineOptions,
                                boolean enabled) {
            super(timestamp, id, agentDetails);
            this.message = message;
            this.engineOptions = engineOptions;
            this.enabled = enabled;
        }

        public String getMessage() {
            return message;
        }

        public List<Engine.TransferOptionDescription> getEngineOptions() {
            return engineOptions;
        }

        public boolean isEnabled() {
            return enabled;
        }
    }

    /**
     * Structural message containing available actions presented by an Engine. It contains a message,
     * to be shown on-screen to the end-user with the provided list of {@link MessagingItem.Action}s
     * available for selection.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class ActionResponse extends Response {

        private final String message;
        private List<MessagingItem.Action> actions;

        public ActionResponse(Date timestamp,
                              String id,
                              AgentDetails agentDetails,
                              String message,
                              List<MessagingItem.Action> actions) {
            super(timestamp, id, agentDetails);
            this.message = message;
            this.actions = actions;
        }

        public String getMessage() {
            return message;
        }

        public List<MessagingItem.Action> getActions() {
            return actions;
        }
    }

    /**
     * Structural message containing available response options submitted by an agent.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class OptionsResponse extends MessagingItem {

        private final List<Option> options;

        public OptionsResponse(Date timestamp,
                               String id,
                               List<Option> options) {
            super(timestamp, id);
            this.options = options;
        }

        public List<Option> getOptions() {
            return options;
        }

    }

    /**
     * Representation of the message issued by the system.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class SystemMessage extends MessagingItem {

        private final String systemMessage;

        public SystemMessage(Date timestamp, String id, String systemMessage) {
            super(timestamp, id);
            this.systemMessage = systemMessage;
        }

        public String getSystemMessage() {
            return systemMessage;
        }
    }

    /**
     * Representation of an action presented by the system. It consists of an ID and a display name.
     * The display name is shown on-screen to the end-user.
     * <p>
     * The ID is to be used by the current {@link Engine} when it receives the
     * {@link Event.ActionOptionClicked} event in its {@link Engine#onEvent} method,
     * to identify the action that was selected.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class Action {

        private final String actionId;
        private final String displayName;

        public Action(String actionId, String displayName) {
            this.actionId = actionId;
            this.displayName = displayName;
        }

        public String getActionId() {
            return actionId;
        }

        public String getDisplayName() {
            return displayName;
        }
    }

    /**
     * Structural message representing a response option.
     */
    @RestrictTo(LIBRARY_GROUP)
    public static class Option {

        private final String id;
        private final String text;

        public Option(@NonNull String id, @NonNull String text) {
            this.id = id;
            this.text = text;
        }

        public String getId() {
            return id;
        }

        public String getText() {
            return text;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            Option that = (Option) o;

            if (!id.equals(that.id)) {
                return false;
            }
            return text.equals(that.text);
        }

        @Override
        public int hashCode() {
            int result = id.hashCode();
            result = 31 * result + text.hashCode();
            return result;
        }
    }
}
