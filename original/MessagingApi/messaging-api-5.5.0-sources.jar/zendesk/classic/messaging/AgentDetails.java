package zendesk.classic.messaging;

import androidx.annotation.DrawableRes;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import java.io.Serializable;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * State of the agent label.
 */
@RestrictTo(LIBRARY_GROUP)
public class AgentDetails implements Serializable {

    private final String agentName;
    private final String agentId;
    private final boolean isBot;
    @Nullable
    @DrawableRes
    private final Integer avatarDrawableRes;
    @Nullable
    private final String avatarPath;


    public AgentDetails(String agentName, String agentId, boolean isBot) {
        this(agentName, agentId, isBot, null, null);
    }

    public AgentDetails(String agentName, String agentId, boolean isBot, @DrawableRes Integer avatarDrawableRes) {
        this(agentName, agentId, isBot, avatarDrawableRes, null);
    }

    public AgentDetails(String agentName, String agentId, boolean isBot, String avatarPath) {
        this(agentName, agentId, isBot, null, avatarPath);
    }

    private AgentDetails(String agentName,
                         String agentId,
                         boolean isBot,
                         @Nullable @DrawableRes Integer avatarDrawableRes,
                         @Nullable String avatarPath) {
        this.agentName = agentName;
        this.agentId = agentId;
        this.isBot = isBot;
        this.avatarDrawableRes = avatarDrawableRes;
        this.avatarPath = avatarPath;
    }

    public String getAgentName() {
        return agentName;
    }

    public boolean isBot() {
        return isBot;
    }

    public String getAgentId() {
        return agentId;
    }

    @Nullable
    public Integer getAvatarDrawableRes() {
        return avatarDrawableRes;
    }

    @Nullable
    public String getAvatarPath() {
        return avatarPath;
    }
}
