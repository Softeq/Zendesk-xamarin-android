package zendesk.classic.messaging;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

import java.util.List;

import zendesk.configurations.Configuration;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * API used by the {@link Engine} to communicate changes to the Messaging SDK.
 */
@RestrictTo(LIBRARY_GROUP)
public interface MessagingApi {

    /**
     * Gets the list of {@link Engine.TransferOptionDescription}s which represent the Engines available for
     * transfer.
     *
     * This method is populated by calling {@link Engine#getTransferOptionDescription()} on each Engine
     * in the messaging session (ie, all of the Engines passed when starting MessagingActivity). All non-null
     * {@link Engine.TransferOptionDescription} objects are included in the returned list.
     *
     * @return the list of {@link Engine.TransferOptionDescription} representing available Engine transfer options.
     */
    @NonNull
    List<Engine.TransferOptionDescription> getTransferOptionDescriptions();

    @NonNull
    ConversationLog getConversationLog();

    @NonNull
    AgentDetails getBotAgentDetails();

    @NonNull
    List<Configuration> getConfigurations();

}
