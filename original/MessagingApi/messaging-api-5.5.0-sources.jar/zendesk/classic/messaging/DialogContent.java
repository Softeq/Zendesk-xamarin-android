package zendesk.classic.messaging;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

/**
 * Data class that represents the content of a Messaging dialog.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class DialogContent {

    private final String title;
    private final String message;
    private final String negativeText;
    private final String positiveText;
    private final Config config;
    private final Config previousConfig;

    private DialogContent(String title,
                  String message,
                  @Nullable String negativeText,
                  @Nullable String positiveText,
                  Config config,
                  @Nullable Config previousConfig) {

        this.title = title;
        this.message = message;
        this.negativeText = negativeText;
        this.positiveText = positiveText;
        this.config = config;
        this.previousConfig = previousConfig;
    }

    public String getTitle() {
        return title;
    }

    public String getMessage() {
        return message;
    }

    public String getNegativeText() {
        return negativeText;
    }

    public String getPositiveText() {
        return positiveText;
    }

    public Config getConfig() {
        return config;
    }

    public Config previousConfig() {
        return previousConfig;
    }

    /**
     * Builder for creating {@link zendesk.classic.messaging.DialogContent}
     */
    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public static class Builder {

        private String title;
        private String message;
        private String negativeText = null;
        private String positiveText = null;
        private final Config config;
        private Config previousConfig = null;

        public Builder(@NonNull Config config) {
            this.config = config;
        }

        /**
         * Set the title of the alert dialog.
         *
         * @param title string representation of the title.
         * @return Builder with the title set.
         */
        public Builder withTitle(String title) {
            this.title = title;
            return this;
        }

        /**
         * Sets the message to be displayed by the alert dialog.
         *
         * @param message string representation of the message
         * @return Builder with the message set.
         */
        public Builder withMessage(String message) {
            this.message = message;
            return this;
        }

        /**
         * Sets the text of the negative button on the dialog.
         *
         * @param negativeText string representation of the button text.
         * @return Builder with negative button text set.
         */
        public Builder withNegativeText(String negativeText) {
            this.negativeText = negativeText;
            return this;
        }

        /**
         * Sets the text of the positive button on the dialog.
         *
         * @param positiveText string representation of the button text.
         * @return Builder with positive button text set.
         */
        public Builder withPositiveText(String positiveText) {
            this.positiveText = positiveText;
            return this;
        }

        /**
         * Sets the {@link Config} of the dialog that was shown before the current one.
         * Useful for determining the flow if multiple dialogs have been shown.
         *
         * @param previousConfig {@link Config} of the last dialog
         * @return Builder with previous config set.
         */
        public Builder withPreviousConfig(Config previousConfig) {
            this.previousConfig = previousConfig;
            return this;
        }

        /**
         * Constructs a new instance of {@link zendesk.classic.messaging.DialogContent}
         *
         * @return newly constructed DialogContent
         */
        public DialogContent build() {
            return new DialogContent(
                    title,
                    message,
                    negativeText,
                    positiveText,
                    config,
                    previousConfig);
        }

    }

    @RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
    public enum Config {
        /**
         * Generic dialog with a title and label
         */
        TRANSCRIPT_PROMPT,

        /**
         * Dialog with an email address edit text field
         */
        TRANSCRIPT_EMAIL
    }
}
