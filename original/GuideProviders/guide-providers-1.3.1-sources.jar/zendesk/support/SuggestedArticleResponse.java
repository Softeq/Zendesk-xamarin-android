package zendesk.support;

import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * Wrapper class to encapsulate a list {@link SimpleArticle}
 * received from {@link HelpCenterProvider#getSuggestedArticles(SuggestedArticleSearch, ZendeskCallback)}
 */
@SuppressWarnings("unused")
public class SuggestedArticleResponse {

    private List<SimpleArticle> results;

    /**
     * Get a list of suggested articles.
     *
     * @return The list of simplified articles.
     */
    public List<SimpleArticle> getResults() {
        return CollectionUtils.copyOf(results);
    }
}
