package zendesk.support;

import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.google.gson.annotations.SerializedName;

import java.util.Locale;

import zendesk.core.Settings;

/**
 * Models the Help Center settings which will be used by the {@code SupportActivity}. These settings
 * are populated by downloading your applications' settings.
 */
@SuppressWarnings("unused")
public class HelpCenterSettings implements Settings {

    private boolean enabled;

    @SerializedName("help_center_article_voting_enabled")
    private boolean articleVotingEnabled;

    private String locale;

    private static HelpCenterSettings DEFAULT = new HelpCenterSettings();

    static HelpCenterSettings defaultSettings() {
        return DEFAULT;
    }

    @VisibleForTesting
    HelpCenterSettings(boolean enabled, boolean articleVotingEnabled, String locale) {
        this.enabled = enabled;
        this.articleVotingEnabled = articleVotingEnabled;
        this.locale = locale;
    }

    @VisibleForTesting
    HelpCenterSettings() {
        // intentionally empty
    }

    /**
     * Determines whether the Help Center feature is enabled or not.
     *
     * @return true if help center is enabled, false otherwise.
     */
    public boolean isEnabled() {
        return enabled;
    }

    /**
     * Gets the locale that we should request Help Center content in by default.
     * <p>
     * This locale will be the "best" fit as determined by Zendesk based on the locale that
     * was supplied during the call to get your applications' settings. This is the device
     * locale by default, but can be overridden by calling
     * {@link Guide#setHelpCenterLocaleOverride(Locale)}
     * </p>
     *
     * @return The default locale that should be used when requesting Help Center content
     */
    @Nullable
    public String getLocale() {
        return locale;
    }

    /**
     * Determines whether the Help Center voting feature is enabled or not.
     *
     * @return true if help center voting is enabled, false otherwise.
     */
    public boolean isArticleVotingEnabled() {
        return articleVotingEnabled;
    }
}
