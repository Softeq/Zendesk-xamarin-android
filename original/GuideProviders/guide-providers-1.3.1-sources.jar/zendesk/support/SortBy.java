package zendesk.support;

import java.util.Locale;

/**
 * This enum models the sorting types available in Help Center
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/articles#sorting">Sorting</a>
 */
@SuppressWarnings({"unused"})
public enum SortBy {
    POSITION, TITLE, CREATED_AT, UPDATED_AT;

    /**
     * Gets the value used by the API. This will be the enum's name in lower case.
     *
     * @return The value to use in an API call.
     */
    public String getApiValue() {
        return this.name().toLowerCase(Locale.US);
    }
}
