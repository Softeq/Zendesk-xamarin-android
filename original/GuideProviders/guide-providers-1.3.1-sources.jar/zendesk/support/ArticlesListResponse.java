package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.List;

import zendesk.core.User;

/**
 * This is a class model for a response for requesting articles. This object will be created by
 * {@link HelpCenterProvider}
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/help_center/introduction">Help Center REST APIs</a>
 */
@SuppressWarnings({"unused"})
class ArticlesListResponse implements ArticlesResponse {

    private List<Article> articles;

    private List<Category> categories;

    private List<Section> sections;

    private List<User> users;

    private String nextPage;

    private String previousPage;

    @NonNull
    @Override
    public List<Article> getArticles() {
        return CollectionUtils.copyOf(articles);
    }

    @NonNull
    @Override
    public List<Category> getCategories() {
        return CollectionUtils.copyOf(categories);
    }

    @NonNull
    @Override
    public List<Section> getSections() {
        return CollectionUtils.copyOf(sections);
    }

    @NonNull
    @Override
    public List<User> getUsers() {
        return CollectionUtils.copyOf(users);
    }

    /**
     * Gets the URL of the next page of results
     *
     * <p>
     * If this method returns null it means there is no next page for the given parameters
     * specified in a {@link HelpCenterSearch}
     * </p>
     *
     * @return The URL of the next page or null if there is no next page
     * @see <a href="https://developer.zendesk.com/rest_api/docs/core/introduction#pagination">Pagination</a>
     */
    @Nullable
    public String getNextPage() {
        return nextPage;
    }

    /**
     * Gets the URL of the previous page of results
     *
     * <p>
     * If this method returns null it means you are on the first page.
     * </p>
     *
     * @return The URL of the previous page of results or null if this is the first page
     * @see <a href="https://developer.zendesk.com/rest_api/docs/core/introduction#pagination">Pagination</a>
     */
    @Nullable
    public String getPreviousPage() {
        return previousPage;
    }
}
