package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;

/**
 * Models the response from the creation of a {@link ArticleVote}.
 *
 * <p>
 * This response is generated from {@link HelpCenterProvider#upvoteArticle(Long, ZendeskCallback)}
 * or {@link HelpCenterProvider#downvoteArticle(Long, ZendeskCallback)}
 * </p>
 */
@SuppressWarnings({"unused"})
class ArticleVoteResponse {

    private ArticleVote vote;

    /**
     * Gets the {@link ArticleVote}
     *
     * @return the {@link ArticleVote}
     */
    @Nullable
    ArticleVote getVote() {
        return vote;
    }
}
