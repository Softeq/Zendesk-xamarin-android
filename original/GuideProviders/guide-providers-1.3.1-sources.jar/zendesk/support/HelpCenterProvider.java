package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

import java.util.List;
import java.util.Locale;

/**
 * <p>
 * A provider which will offer a higher level of abstraction compared to the {@link HelpCenterService}.
 * <br>
 * You can create an instance of HelpCenterProvider like this:
 *
 * <pre>
 *      import zendesk.support.HelpCenterProvider;
 *      import zendesk.support.Support;
 *      ...
 *      HelpCenterProvider provider = Support.INSTANCE.provider().helpCenterProvider();
 *      ...
 * </pre>
 *
 * <p>
 * Once you have an instance of the provider you can call methods on it and handle the results
 * in callbacks. A success callback will give you the resource(s) that you are requesting, like
 * categories, sections, votes, and so on. The error callback will be called if there was some
 * issue with the method call and it will define details about the error in an
 * {@link ErrorResponse}
 * </p>
 * <p>
 * For example you can list the Categories in your Help Center like this:
 *
 * <pre>
 *   provider.getCategories(new ZendeskCallback{@literal <List<Category>>}() {
 *       {@literal @Override}
 *       public void onSuccess(List&lt;Category&gt; categories) {
 *           // Handle the success
 *       }
 *
 *       {@literal @Override}
 *       public void onError(ErrorResponse errorResponse) {
 *           // Handle the error
 *       }
 *   });
 * </pre>
 */
@SuppressWarnings("unused")
public interface HelpCenterProvider {

    /**
     * Gets a list of help items representing a flattened Help Center structure.
     *
     * @param request  The request
     * @param callback Callback that will deliver a list of view items
     */
    void getHelp(@NonNull HelpRequest request,
                 @Nullable ZendeskCallback<List<HelpItem>> callback);

    /**
     * Fetch a list of categories from a Help Center instance.
     *
     * @param callback Callback that will deliver a list of categories available on the instance of the Help Center
     *                 for the provided locale
     * @since 1.0.0.1
     */
    void getCategories(@Nullable ZendeskCallback<List<Category>> callback);

    /**
     * Fetch a list of sections for a given categoryId from a Help Center instance
     *
     * @param categoryId Long to specify what sections should be returned, only sections belonging to the category
     *                   will be returned
     * @param callback   Callback that will deliver a list of sections available on the instance of the Help Center
     *                   for the provided locale and categoryId
     * @since 1.0.0.1
     */
    void getSections(@NonNull Long categoryId, @Nullable ZendeskCallback<List<Section>> callback);

    /**
     * Fetch a list of articles for a given sectionId from a Help Center instance
     *
     * @param sectionId Long to specify what articles should be returned, only articles belonging to the section will
     *                 be returned
     * @param callback  Callback that will deliver a list of articles available on the instance of the Help Center
     *                  for the provided locale and sectionId
     * @since 1.0.0.1
     */
    void getArticles(@NonNull Long sectionId, @Nullable ZendeskCallback<List<Article>> callback);

    /**
     * Fetch a list of articles for a given sectionId from a Help Center instance
     *
     * @param sectionId  Long to specify what articles should be returned, only articles belonging to the section
     *                   will be returned
     * @param labelNames The label names to include in the query as a CSV string
     * @param callback   Callback that will deliver a list of articles available on the instance of the Help Center
     *                   for the provided locale and sectionId
     * @since 1.0.0.1
     */
    void getArticles(@NonNull Long sectionId, @Nullable String labelNames, @Nullable ZendeskCallback<List<Article>>
            callback);

    /**
     * Lists articles that match the parameters in the query.
     *
     * @param query    The query
     * @param callback The callback which will be called upon a successful or an erroneous response.
     * @since 1.1.0.1
     */
    void listArticles(@NonNull ListArticleQuery query, @Nullable ZendeskCallback<List<SearchArticle>> callback);

    /**
     * This method returns a list of flatArticles which are objects containing an article, section and category
     * all relevant to each other from a Help Center instance.
     *
     * @param query    The query
     * @param callback The callback which will be called upon a successful or an erroneous response.
     * @since 1.4.0.1
     */
    void listArticlesFlat(@NonNull ListArticleQuery query, @Nullable ZendeskCallback<List<FlatArticle>> callback);

    /**
     * This method searches your Help Center instance for articles that match the specified parameters
     *
     * @param search   The search parameters used to perform the search
     * @param callback The callback which will be called upon a successful or an erroneous response.
     * @since 1.0.0.1
     */
    void searchArticles(@NonNull HelpCenterSearch search, @Nullable ZendeskCallback<List<SearchArticle>> callback);

    /**
     * This method returns a single article from a Help Center instance based on the articleId provided
     * <p>
     * This method will also sideload users so that there is a User model available for the author of the article<br>
     * See: {@link Article#getAuthor()}
     * </p>
     * <p>
     * For more information on <a href="https://developer.zendesk.com/rest_api/docs/core/side_loading">Side-Loading</a>
     * </p>
     *
     * @param articleId the identifier to be used to retrieve an article from a Help Center instance
     * @param callback  the callback that is invoked when a request has either completed successfully or has errors
     * @since 1.0.0.1
     */
    void getArticle(@NonNull Long articleId, @Nullable ZendeskCallback<Article> callback);

    /**
     * This method searches your Help Center instance for a section that matches the specified section ID.
     *
     * @param sectionId The section Id will specify the ID of the particular section to be retrieved.
     * @param callback  The callback which will be called upon a successful or an erroneous response.
     * @since 1.4.0.1
     */
    void getSection(@NonNull Long sectionId, @Nullable ZendeskCallback<Section> callback);

    /**
     * This method searches your Help Center instance for a category that matches the specified category ID.
     *
     * @param categoryId The category Id will specify the ID of the particular category to be retrieved.
     * @param callback   The callback which will be called upon a successful or an erroneous response.
     * @since 1.4.0.1
     */
    void getCategory(@NonNull Long categoryId, @Nullable ZendeskCallback<Category> callback);


    /**
     * This method returns a list of attachments for a single article.
     * <p>
     * This method can fetch a variety of attachment types, see <br>
     * See: {@link AttachmentType}
     * </p>
     *
     * @param articleId      the identifier to be used to retrieve an article from a Help Center instance
     * @param attachmentType the type of attachments to retrieve for the given article
     * @param callback       the callback that is invoked when a request is either successful or has errors
     * @since 1.0.0.1
     */
    void getAttachments(@NonNull Long articleId, @NonNull AttachmentType attachmentType, @Nullable
            ZendeskCallback<List<HelpCenterAttachment>> callback);

    /**
     * This method marks as article as helpful
     *
     * @param articleId The id of the article to mark as helpful
     * @param callback  The callback that is invoked when a request is either successful or has errors
     * @since 1.2.0.1
     */
    void upvoteArticle(@NonNull Long articleId, @Nullable ZendeskCallback<ArticleVote> callback);

    /**
     * This method marks as article as unhelpful
     *
     * @param articleId The id of the article to mark as unhelpful
     * @param callback  The callback that is invoked when a request is either successful or has errors
     * @since 1.2.0.1
     */
    void downvoteArticle(@NonNull Long articleId, @Nullable ZendeskCallback<ArticleVote> callback);

    /**
     * This method will delete a vote with the given ID
     * <p>
     * As of 1.6.0.1, the Callback is of `Void` type.
     *
     * @param voteId   The ID of the vote to delete
     * @param callback The callback that is invoked when a request is either successful or has errors
     * @since 1.2.0.1
     */
    void deleteVote(@NonNull Long voteId, @Nullable ZendeskCallback<Void> callback);

    /**
     * This method returns a list of suggested articles.
     *
     * @param suggestedArticleSearch The search parameters used to perform the search
     * @param callback               The callback that is invoked when a request is either successful or has errors
     * @since 1.2.0.1
     */
    void getSuggestedArticles(@NonNull SuggestedArticleSearch suggestedArticleSearch, @Nullable
            ZendeskCallback<SuggestedArticleResponse> callback);

    /**
     * This method submits a record article view that is used for reporting.
     * <p>
     * As of 1.6.0.1, the Callback is of `Void` type.
     *
     * @param article  The viewed article.
     * @param locale   The locale of the viewed article
     * @param callback The callback that is invoked when a request is either successful or has errors.
     * @since 1.3.1.1
     */
    void submitRecordArticleView(@NonNull Article article,
                                 @NonNull Locale locale,
                                 @Nullable ZendeskCallback<Void> callback);

}
