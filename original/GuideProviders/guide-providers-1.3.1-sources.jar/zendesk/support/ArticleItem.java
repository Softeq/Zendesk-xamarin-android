package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;
import com.zendesk.util.StringUtils;

/**
 * A {@link HelpItem} for Help Center articles
 */
@SuppressWarnings("unused")
public class ArticleItem implements HelpItem {

    private Long id;

    @SerializedName("section_id")
    private Long sectionId;

    private String name;

    public ArticleItem(Long id, Long sectionId, String name) {
        this.id = id;
        this.sectionId = sectionId;
        this.name = name;
    }

    @Override
    public int getViewType() {
        return TYPE_ARTICLE;
    }

    @NonNull
    @Override
    public String getName() {
        return name == null ? StringUtils.EMPTY_STRING : name;
    }

    @Nullable
    @Override
    public Long getId() {
        return id;
    }

    @Nullable
    @Override
    public Long getParentId() {
        return sectionId;
    }

    @SuppressWarnings("SimplifiableIfStatement")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ArticleItem that = (ArticleItem) o;

        if (id != null ? !id.equals(that.id) : that.id != null) {
            return false;
        }
        return sectionId != null ? sectionId.equals(that.sectionId) : that.sectionId == null;

    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (sectionId != null ? sectionId.hashCode() : 0);
        return result;
    }
}
