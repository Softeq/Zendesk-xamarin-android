package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;

import java.util.Arrays;
import java.util.Date;

/**
 * This is a class model for an Article vote. Votes are typically returned as a response from
 * {@link HelpCenterProvider#upvoteArticle(Long, ZendeskCallback)} or
 * {@link HelpCenterProvider#downvoteArticle(Long, ZendeskCallback)}
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/votes#json-format">Article Vote JSON format</a>
 */
@SuppressWarnings("unused")
public class ArticleVote {

    private Long id;

    private String url;

    private Long userId;

    private Integer value;

    private Long itemId;

    private String itemType;

    private Date createdAt;

    private Date updatedAt;

    /**
     * Gets the ID of the Vote
     *
     * @return the ID of the vote
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the API URL of the Vote resource
     *
     * @return the API URL of the Vote resource
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the ID of the {@link zendesk.support.User} who created the Vote
     *
     * @return the ID of the {@link zendesk.support.User} who created the Vote
     */
    @Nullable
    public Long getUserId() {
        return userId;
    }

    /**
     * Gets the value of the Vote
     *
     * @return 1 for a positive vote, -1 for a negative vote
     */
    @Nullable
    public Integer getValue() {
        return value;
    }

    /**
     * Gets the id of the item for which the Vote was cast
     *
     * @return the id of the item for which the Vote was cast
     */
    @Nullable
    public Long getItemId() {
        return itemId;
    }

    /**
     * Gets the type of the item. Can be "Article", "Post" or "PostComment"
     *
     * @return the type of the item. Can be "Article", "Post" or "PostComment"
     */
    @Nullable
    public String getItemType() {
        return itemType;
    }

    /**
     * Gets the time at which the vote was created
     *
     * @return the time at which the vote was created
     */
    @Nullable
    public Date getCreatedAt() {
        return createdAt == null ? null : new Date(createdAt.getTime());
    }

    /**
     * Gets the time at which the vote was updated
     *
     * @return the time at which the vote was updated
     */
    @Nullable
    public Date getUpdatedAt() {
        return updatedAt == null ? null : new Date(updatedAt.getTime());
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ArticleVote that = (ArticleVote) o;

        if (id != null ? !id.equals(that.id) : that.id != null) {
            return false;
        }
        if (url != null ? !url.equals(that.url) : that.url != null) {
            return false;
        }
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) {
            return false;
        }
        if (value != null ? !value.equals(that.value) : that.value != null) {
            return false;
        }
        if (itemId != null ? !itemId.equals(that.itemId) : that.itemId != null) {
            return false;
        }
        if (itemType != null ? !itemType.equals(that.itemType) : that.itemType != null) {
            return false;
        }
        if (createdAt != null ? !createdAt.equals(that.createdAt) : that.createdAt != null) {
            return false;
        }
        return updatedAt != null ? updatedAt.equals(that.updatedAt) : that.updatedAt == null;
    }

    @Override
    public int hashCode() {
        Object[] o = new Object[]{id, url, userId, value, itemId, itemType, createdAt, updatedAt};
        return Arrays.hashCode(o);
    }
}
