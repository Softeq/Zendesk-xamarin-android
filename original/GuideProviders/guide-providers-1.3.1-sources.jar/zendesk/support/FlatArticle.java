package zendesk.support;

import androidx.annotation.NonNull;

/**
 * This is a model class for a FlatArticle object which contains an Article object, its relevant
 * Section object and its relevant Category object for ease of use. It will be created by
 * the {@link HelpCenterProvider}.
 * <p>
 * Created by Zendesk.
 */
public class FlatArticle implements Comparable<FlatArticle> {

    private Category category;
    private Section section;
    private Article article;

    /**
     * Creates an instance of FlatArticle from the given category, section and article
     *
     * @param category The category which the article belongs to
     * @param section  The section which the article belongs to
     * @param article  The article to wrap in this FlatArticle
     */
    public FlatArticle(Category category, Section section, Article article) {
        this.category = (category == null) ? new Category() : category;
        this.section = (section == null) ? new Section() : section;
        this.article = (article == null) ? new Article() : article;
    }

    /**
     * Gets the category which this article belongs to
     *
     * @return the category which this article belongs to
     */
    @NonNull
    public Category getCategory() {
        return category;
    }

    /**
     * Gets the section which this article belongs to
     *
     * @return the section which this article belongs to
     */
    @NonNull
    public Section getSection() {
        return section;
    }

    /**
     * The article object which this flat article is wrapping
     *
     * @return article object which this flat article is wrapping
     */
    @NonNull
    public Article getArticle() {
        return article;
    }

    @Override
    public String toString() {
        return (this.category.getName() + ", " + this.section.getName() + ", " + this.article.getTitle());
    }

    @Override
    public int compareTo(@NonNull FlatArticle flatArticle) {

        //noinspection ConstantConditions
        if (flatArticle == null) {
            return -1;
        }

        return this.toString().compareTo(flatArticle.toString());
    }
}
