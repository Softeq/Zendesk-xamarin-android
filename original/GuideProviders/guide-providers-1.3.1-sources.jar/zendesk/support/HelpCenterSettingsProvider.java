package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;

/**
 * This provider is used internally by the SDK and does not need to be called explicitly.
 */
public interface HelpCenterSettingsProvider {

    /**
     * Retrieves the {@link HelpCenterSettings}object.
     *
     * @param callback A callback which will be notified of the result of the call.
     */
    void getSettings(@Nullable ZendeskCallback<HelpCenterSettings> callback);
}
