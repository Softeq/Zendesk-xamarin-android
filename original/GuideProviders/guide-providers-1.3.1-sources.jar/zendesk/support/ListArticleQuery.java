package zendesk.support;

import com.zendesk.service.ZendeskCallback;

import java.util.Locale;

/**
 * This class encapsulates the parameters for listing Articles in Help Center.
 * <p>
 * This class is what is used when searching Help Center with a {@link HelpCenterProvider},
 * specifically with the {@link HelpCenterProvider#listArticles(ListArticleQuery, ZendeskCallback)} method
 * </p>
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/articles.html#list-articles">Listing
 * Articles in Help Center</a>
 */
@SuppressWarnings("unused")
public class ListArticleQuery {

    private String labelNames;

    private Locale locale;

    private String include;

    private SortBy sortBy;

    private SortOrder sortOrder;

    private Integer page;

    private Integer resultsPerPage;

    /**
     * Gets the label names for this query as a CSV string
     *
     * @return The label names for this query as a CSV string
     */
    public String getLabelNames() {
        return labelNames;
    }

    /**
     * Gets the locale for this query
     *
     * @return The locale for this query
     */
    public Locale getLocale() {
        return locale;
    }

    /**
     * Gets the includes for this query
     *
     * @return The includes for this query
     */
    public String getInclude() {
        return include;
    }

    /**
     * Gets the sort method for this query
     *
     * @return The sort method for this query
     */
    public SortBy getSortBy() {
        return sortBy;
    }

    /**
     * Gets the sort order for this query
     *
     * @return The sort order for this query
     */
    public SortOrder getSortOrder() {
        return sortOrder;
    }

    /**
     * Gets the page for this query
     *
     * @return The page for this query
     */
    public Integer getPage() {
        return page;
    }

    /**
     * Gets the results per page for this query
     *
     * @return The results per page for this query
     */
    public Integer getResultsPerPage() {
        return resultsPerPage;
    }

    /**
     * Sets the label names to include in the query as a CSV string
     *
     * <p>
     * e.g. "label1" or "label1,label2,label3"
     * </p>
     *
     * @param labelNames The label names to include in the query as a CSV string
     */
    public void setLabelNames(String labelNames) {
        this.labelNames = labelNames;
    }

    /**
     * Sets the locale for this query
     *
     * @param locale the locale to set for this query
     */
    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    /**
     * Sets the includes for this query
     *
     * @param include The includes for this query
     */
    public void setInclude(String include) {
        this.include = include;
    }

    /**
     * Sets the sort method for this query
     *
     * @param sortBy the sort method for this query
     */
    public void setSortBy(SortBy sortBy) {
        this.sortBy = sortBy;
    }

    /**
     * Specifies the sort order for this query
     *
     * @param sortOrder the sort order for this query
     */
    public void setSortOrder(SortOrder sortOrder) {
        this.sortOrder = sortOrder;
    }

    /**
     * Specifies the page for this query
     *
     * @param page The page for this query
     */
    public void setPage(Integer page) {
        this.page = page;
    }

    /**
     * Specifies the number of results per page for this query
     *
     * @param resultsPerPage The number of results per page for this query
     */
    public void setResultsPerPage(Integer resultsPerPage) {
        this.resultsPerPage = resultsPerPage;
    }
}
