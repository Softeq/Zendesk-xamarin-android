package zendesk.support;

import javax.inject.Singleton;

import zendesk.core.CoreModule;

import dagger.Component;

@Component(modules = {
        CoreModule.class,
        GuideProviderModule.class
})
@Singleton
interface GuideSdkProvidersComponent {

    Guide inject(Guide guide);
}
