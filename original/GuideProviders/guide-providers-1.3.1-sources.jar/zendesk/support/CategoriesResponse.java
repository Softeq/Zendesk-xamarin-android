package zendesk.support;

import androidx.annotation.NonNull;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * This is a class model for a response for requesting categories. This object will be created by
 * {@link zendesk.support.HelpCenterService}
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/help_center/introduction">Help Center REST APIs</a>
 */
@SuppressWarnings({"unused"})
class CategoriesResponse {

    private List<Category> categories;

    /**
     * Gets the list of Category objects from the response
     *
     * @return the list of Category objects from the response
     */
    @NonNull
    List<Category> getCategories() {
        return CollectionUtils.copyOf(categories);
    }
}
