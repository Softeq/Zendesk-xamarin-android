package zendesk.support;


/**
 * Provides storage of an {@link ArticleVote} for each article with an article id.
 */
public interface ArticleVoteStorage {

    /**
     * Stores an {@link ArticleVote} on the device
     *
     * @param articleId   The id of the article containing the vote
     * @param articleVote The article vote to store
     */
    void storeArticleVote(Long articleId, ArticleVote articleVote);

    /**
     * Gets a stored {@link ArticleVote} from the device
     *
     * @param articleId The id of the article containing the vote
     * @return The stored {@link ArticleVote} or null if one
     * is not stored or if the storage is unavailable.
     */
    ArticleVote getStoredArticleVote(Long articleId);

    /**
     * Removes an {@link ArticleVote} from the device
     *
     * @param articleId The id of the article whose vote is to be removed
     */
    void removeStoredArticleVote(Long articleId);

}
