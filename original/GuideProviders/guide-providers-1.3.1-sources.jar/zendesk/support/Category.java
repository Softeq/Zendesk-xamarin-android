package zendesk.support;

import androidx.annotation.Nullable;

import java.io.Serializable;
import java.util.Date;

/**
 * This is a model class for a Category object that will be created by the
 * {@link HelpCenterProvider}.
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/help_center/categories">Categories</a>
 */
@SuppressWarnings({"unused"})
public class Category implements Serializable {

    private Long id;
    private String url;
    private String htmlUrl;
    private int position;
    private Date createdAt;
    private Date updatedAt;
    private String name;
    private String description;
    private String locale;
    private String sourceLocale;
    private boolean outdated;

    /**
     * Gets the ID of the category
     *
     * @return the ID of the category
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the API URL of the category
     *
     * @return the API URL of the category
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the URL of the category that can be opened in a web browser
     *
     * @return the URL of the category that can be opened in a web browser
     */
    @Nullable
    public String getHtmlUrl() {
        return htmlUrl;
    }

    /**
     * Gets the position of the category. This is applicable if the categories are manually sorted.
     *
     * @return the position of the category
     */
    public int getPosition() {
        return position;
    }

    /**
     * Gets the date that the category was created at.
     *
     * @return the date that the category was created at.
     */
    @Nullable
    public Date getCreatedAt() {
        return createdAt == null ? null : new Date(createdAt.getTime());
    }

    /**
     * Gets the date that the category was updated at.
     *
     * @return the date that the category was updated at.
     */
    @Nullable
    public Date getUpdatedAt() {
        return updatedAt == null ? null : new Date(updatedAt.getTime());
    }

    /**
     * Gets the name of the category
     *
     * @return the name of the category
     */
    @Nullable
    public String getName() {
        return name;
    }

    /**
     * Gets the description of the category
     *
     * @return the description of the category
     */
    @Nullable
    public String getDescription() {
        return description;
    }

    /**
     * Gets the locale of the category in the form of ll-CC, e.g. en-US
     *
     * @return the locale of the category in the form of ll-CC, e.g. en-US
     */
    @Nullable
    public String getLocale() {
        return locale;
    }

    /**
     * Gets the source locale of the category in the form of ll-CC, e.g. en-US
     *
     * @return the source locale of the category in the form of ll-CC, e.g. en-US
     */
    @Nullable
    public String getSourceLocale() {
        return sourceLocale;
    }

    /**
     * Checks whether the category is outdated or not
     *
     * @return true if the category is outdated, false otherwise
     */
    public boolean isOutdated() {
        return outdated;
    }
}
