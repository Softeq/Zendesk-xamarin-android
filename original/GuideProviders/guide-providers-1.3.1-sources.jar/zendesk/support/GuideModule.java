package zendesk.support;

import java.util.UUID;

import dagger.Module;
import dagger.Provides;
import okhttp3.OkHttpClient;

/**
 * Module holding references to internal dependencies.
 */
@Module
public class GuideModule {

    private final HelpCenterProvider helpCenterProvider;
    private final HelpCenterSettingsProvider settingsProvider;
    private final HelpCenterBlipsProvider blipsProvider;
    private final HelpCenterTracker helpCenterTracker;
    private final ArticleVoteStorage articleVoteStorage;
    private final OkHttpClient okHttpClient;
    private final UUID id;

    public GuideModule(HelpCenterProvider helpCenterProvider,
                       HelpCenterSettingsProvider settingsProvider,
                       HelpCenterBlipsProvider blipsProvider,
                       HelpCenterTracker helpCenterTracker,
                       ArticleVoteStorage articleVoteStorage,
                       OkHttpClient okHttpClient) {
        this.helpCenterProvider = helpCenterProvider;
        this.settingsProvider = settingsProvider;
        this.blipsProvider = blipsProvider;
        this.helpCenterTracker = helpCenterTracker;
        this.articleVoteStorage = articleVoteStorage;
        this.okHttpClient = okHttpClient;
        this.id = UUID.randomUUID();
    }

    @Provides
    HelpCenterProvider providesHelpCenterProvider() {
        return helpCenterProvider;
    }

    @Provides
    ArticleVoteStorage providesArticleVoteStorage() {
        return articleVoteStorage;
    }

    @Provides
    HelpCenterSettingsProvider providesSettingsProvider() {
        return settingsProvider;
    }

    @Provides
    HelpCenterTracker providesHelpCenterTracker() {
        return helpCenterTracker;
    }

    @Provides
    HelpCenterBlipsProvider providesBlipsProvider() {
        return blipsProvider;
    }

    @Provides
    OkHttpClient providesOkHttpClient() {
        return okHttpClient;
    }

    public UUID getId() {
        return id;
    }
}
