package zendesk.support;

import androidx.annotation.IntDef;
import androidx.annotation.NonNull;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * A Provider for tracking user actions and page views.
 * <p>
 * This is used internally by the Guide SDK and should not be called directly by an integrator.
 */
public interface HelpCenterBlipsProvider {

    @IntDef({ArticleVote.ARTICLE_VOTE_UP, ArticleVote.ARTICLE_VOTE_DOWN})
    @Retention(RetentionPolicy.SOURCE)
    @interface ArticleVote {
        int ARTICLE_VOTE_UP = 1;
        int ARTICLE_VOTE_DOWN = -1;
    }

    /**
     * Tracks a Help Center search as a UserAction blip.
     *
     * @param query the search query to be tracked in the Blip
     */
    void helpCenterSearch(@NonNull String query);

    /**
     * Tracks a view of a Help Center article as a PageView blip.
     *
     * @param article the viewed article.
     */
    void articleView(@NonNull Article article);

    /**
     * Tracks a vote on a Help Center article as a UserAction blip.
     *
     * @param articleId the ID of the article on which the vote has been cast
     * @param vote      an integer representation of the vote's direction. +1 for an upvote, -1 for a
     *                  downvote, 0 for a deleted vote.
     */
    void articleVote(Long articleId, @ArticleVote int vote);

}
