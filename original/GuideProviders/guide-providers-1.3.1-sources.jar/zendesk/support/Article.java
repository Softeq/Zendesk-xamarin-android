package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import zendesk.core.User;

/**
 * This is a model class for an Article object that will be created by the
 * {@link HelpCenterProvider}.
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/help_center/articles">Articles</a>
 */
@SuppressWarnings("unused")
public class Article implements Serializable {

    public static final int UNKNOWN_VOTE_COUNT = -1;

    private static final String LOG_TAG = "Article";

    private Long id;
    private String url;
    private String htmlUrl;
    private Long authorId;
    private boolean commentsDisabled;
    private List<String> labelNames;
    private boolean draft;
    private Integer voteSum;
    private Integer voteCount;
    private Long sectionId;
    private Date createdAt;
    private Date updatedAt;
    private String title;
    private String body;
    private String sourceLocale;
    private String locale;
    private boolean outdated;
    private User author;
    private Integer position;

    /**
     * Gets the ID of the article
     *
     * @return the ID of the article
     * @since 1.0.0.1
     */
    public Long getId() {
        return id;
    }

    /**
     * Gets the API URL of the article
     *
     * @return the API URL of the article
     * @since 1.0.0.1
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the html URL of the article. This is the URL that can be used to open the article
     * in a browser.
     *
     * @return the html URL of the article
     * @since 1.0.0.1
     */
    @Nullable
    public String getHtmlUrl() {
        return htmlUrl;
    }

    /**
     * Gets the ID of the author of the article
     *
     * @return the ID of the author of the article
     * @since 1.0.0.1
     */
    @Nullable
    public Long getAuthorId() {
        return authorId;
    }

    /**
     * Checks whether comments are disabled or not
     *
     * @return true if comments are disabled, false otherwise
     * @since 1.0.0.1
     */
    public boolean isCommentsDisabled() {
        return commentsDisabled;
    }

    /**
     * Gets the label names of the article
     *
     * @return the label names of the article. The list will be unmodifiable.
     * @since 1.0.0.1
     */
    @NonNull
    public List<String> getLabelNames() {
        return CollectionUtils.copyOf(labelNames);
    }

    /**
     * Checks if the article is a draft or not
     *
     * @return true if the article is a draft, false otherwise
     * @since 1.0.0.1
     */
    public boolean isDraft() {
        return draft;
    }

    /**
     * Gets the sum of votes. Unhelpful votes are taken as -1 value and helpful votes are taken as
     * +1 value.
     *
     * <p>
     * For example, if there are 3 unhelpful votes and 5 helpful votes then the vote sum is
     * (-1 * 3) + (+1 * 5) = 2
     * </p>
     *
     * @return The sum of votes. Unhelpful ones are -1, helpful ones are +1
     * @since 1.1.0.1
     */
    public int getVoteSum() {
        return voteSum == null ? 0 : voteSum;
    }

    /**
     * Gets the total number of votes that have been cast for this article.
     *
     * <p>
     * For example, if there are 3 unhelpful votes and 5 helpful votes then the total number
     * of votes is 3 + 5 = 8.
     * </p>
     *
     * @return the total number of votes that have been cast for this article.
     * @since 1.0.0.1
     */
    public int getVoteCount() {
        return voteCount == null ? 0 : voteCount;
    }

    /**
     * Gets the ID of the section that the article belongs to
     *
     * @return the ID of the section that the article belongs to
     * @since 1.0.0.1
     */
    @Nullable
    public Long getSectionId() {
        return sectionId;
    }

    /**
     * Gets the date that the article was created at.
     *
     * @return the date that the article was created at. Unmodifiable.
     * @since 1.0.0.1
     */
    @Nullable
    public Date getCreatedAt() {

        if (createdAt == null) {
            return null;
        }

        return new Date(createdAt.getTime());
    }

    /**
     * Gets the date that the article was updated at.
     *
     * @return the date that the article was created at. Unmodifiable.
     * @since 1.0.0.1
     */
    @Nullable
    public Date getUpdatedAt() {

        if (updatedAt == null) {
            return null;
        }

        return new Date(updatedAt.getTime());
    }

    /**
     * Gets the title of the article
     *
     * @return the title of the article
     * @since 1.0.0.1
     */
    @Nullable
    public String getTitle() {
        return title;
    }

    /**
     * Gets the body of the article in plain text
     *
     * @return the body of the article in plain text
     * @since 1.0.0.1
     */
    @Nullable
    public String getBody() {
        return body;
    }

    /**
     * Gets the source locale of the article in the form of ll-CC, e.g. en-US
     *
     * @return the source locale of the article in the form of ll-CC, e.g. en-US
     * @since 1.0.0.1
     */
    @Nullable
    public String getSourceLocale() {
        return sourceLocale;
    }

    /**
     * Gets the locale of the article in the form of ll-CC, e.g. en-US
     *
     * @return the locale of the article in the form of ll-CC, e.g. en-US
     * @since 1.0.0.1
     */
    @Nullable
    public String getLocale() {
        return locale;
    }

    /**
     * Checks whether the article is outdated or not
     *
     * @return true if the article is outdated, false otherwise
     * @since 1.0.0.1
     */
    public boolean isOutdated() {
        return outdated;
    }

    /**
     * Gets the author of this article
     *
     * @return the author of this article
     * @since 1.0.0.1
     */
    @Nullable
    public User getAuthor() {
        return author;
    }

    /**
     * Sets the author of this article.
     * <p>
     * This method is used by the providers to populate this object for convenience.
     * </p>
     *
     * @param author The author to set
     * @since 1.0.0.1
     */
    public void setAuthor(User author) {
        this.author = author;
    }

    /**
     * Gets the position of this article in the article list. 0 by default
     *
     * @return the position of this article in the article list. 0 by default
     * @since 4.1.0
     */
    public Integer getPosition() {
        return position == null ? 0 : position;
    }

    /**
     * Gets the number of upvotes for this article.
     *
     * <p>
     * The formula that is used is {@code ((vote_sum + vote_count) / 2)}
     * </p>
     *
     * @return The number of upvotes for this article or {@link #UNKNOWN_VOTE_COUNT} if the
     * number of upvotes cannot be determined due to an API error.
     * @since 1.2.0.1
     */
    public int getUpvoteCount() {

        if (voteSum == null || voteCount == null) {
            Logger.e(
                    LOG_TAG,
                    "Cannot determine vote count because vote_sum and / or vote_count are null");

            return UNKNOWN_VOTE_COUNT;
        }

        return ((voteSum + voteCount) / 2);
    }

    /**
     * Gets the number of downvotes for this article
     *
     * <p>
     * The formula that is used is {@code abs(vote_sum - vote_count) / 2}
     * </p>
     *
     * @return The number of downvotes for this article or {@link #UNKNOWN_VOTE_COUNT} if the
     * number of downvotes cannot be determined due to an API error.
     * @since 1.2.0.1
     */
    public int getDownvoteCount() {

        if (voteSum == null || voteCount == null) {
            Logger.e(
                    LOG_TAG,
                    "Cannot determine vote count because vote_sum and / or vote_count are null");

            return UNKNOWN_VOTE_COUNT;
        }

        return Math.abs((voteSum - voteCount)) / 2;
    }
}
