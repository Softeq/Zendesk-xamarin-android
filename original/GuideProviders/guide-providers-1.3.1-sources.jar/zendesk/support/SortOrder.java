package zendesk.support;

/**
 * This enum models the sorting types available in Help Center
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/articles#sorting">Sorting</a>
 */
@SuppressWarnings({"unused"})
public enum SortOrder {
    ASCENDING("asc"), DESCENDING("desc");

    private final String apiValue;

    SortOrder(String apiValue) {
        this.apiValue = apiValue;
    }

    /**
     * This returns the value to use in an API call for this enum
     *
     * @return The value to use in an API call for this enum.
     */
    public String getApiValue() {
        return apiValue;
    }
}
