package zendesk.support;

/**
 * Internal enum used to represent the allowed individual types of attachments that can be fetched
 * from a Help Center instance.
 * <p>
 * Possible attachment types
 * <ul>
 * <li><a href="https://developer.zendesk.com/rest_api/docs/help_center/article_attachments#list-article-inline-attachments">Inline attachments</a></li>
 * <li><a href="https://developer.zendesk.com/rest_api/docs/help_center/article_attachments#list-article-block-attachments">Block attachments</a></li>
 * </ul>
 */
@SuppressWarnings({"unused"})
public enum AttachmentType {
    INLINE("inline"),
    BLOCK("block");

    private String attachmentType;

    AttachmentType(String attachmentType) {
        this.attachmentType = attachmentType;
    }

    /**
     * Gets the value that is used in the API to represent this attachment type
     *
     * @return the value that is used in the API to represent this attachment type
     */
    public String getAttachmentType() {
        return this.attachmentType;
    }
}
