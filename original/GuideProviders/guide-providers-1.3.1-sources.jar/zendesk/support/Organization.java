package zendesk.support;

import androidx.annotation.Nullable;

/**
 * This is a model class for a Organization object that will be created by the
 * {@link RequestProvider} as part of {@link CommentsResponse}.
 *
 * @see <a href ="http://developer.zendesk.com/documentation/rest_api/organizations.html">Organization</a>
 */
@SuppressWarnings({"unused"})
public class Organization {

    private Long id;
    private String name;

    /**
     * Gets the ID of the organization
     *
     * @return the ID of the organization
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the name of the organization
     *
     * @return the name of the organization
     */
    @Nullable
    public String getName() {
        return name;
    }
}
