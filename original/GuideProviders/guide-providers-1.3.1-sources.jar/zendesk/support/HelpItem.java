package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

/**
 * Model representing items in the HelpCenter UI.
 */
public interface HelpItem {

    int TYPE_CATEGORY = 1;
    int TYPE_SECTION = 2;
    int TYPE_ARTICLE = 3;
    int TYPE_SEE_ALL = 4;
    int TYPE_LOADING = 5;
    int TYPE_NO_RESULTS = 7;
    int TYPE_PADDING = 8;

    /**
     * Gets the type of the item
     *
     * @return the type of the item
     */
    int getViewType();

    /**
     * Gets the name of the item
     *
     * @return the name of the item, or an empty String if there is no name.
     */
    @NonNull
    String getName();

    /**
     * Gets the ID of this item.
     *
     * @return The ID of this item, or null if there is none.
     */
    @Nullable
    Long getId();

    /**
     * Returns the ID of the parent item.
     *
     * @return the ID of the parent item, or null if there is none.
     */
    @Nullable
    Long getParentId();
}
