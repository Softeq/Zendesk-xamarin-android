package zendesk.support;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * This is a class model for a response for requesting sections. This object will be created by
 * {@link HelpCenterService}
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/help_center/introduction">Help Center REST APIs</a>
 */
@SuppressWarnings("unused")
class SectionsResponse {

    List<Section> sections;

    /**
     * Gets the list of sections contained in this response
     *
     * @return the list of sections contained in this response
     */
    List<Section> getSections() {
        return CollectionUtils.copyOf(sections);
    }
}
