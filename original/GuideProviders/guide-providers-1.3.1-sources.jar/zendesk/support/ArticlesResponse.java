package zendesk.support;

import androidx.annotation.NonNull;

import java.util.List;

import zendesk.core.User;

/**
 * Defines the behaviour of a articles response from Help Center.
 */
interface ArticlesResponse {
    /**
     * Gets a list of the {@link Article}s returned from a call to search articles from the network.
     *
     * @return The list of articles.  This will be an empty list if there were no results.
     */
    @NonNull
    List<Article> getArticles();

    /**
     * Gets a list of {@link Category} returned as a result
     * of specifying <pre>categories</pre> as a part of a sideload operation when searching or
     * listing articles.
     *
     * @return The list of categories.  This will be an empty list if there were no results or if categories were not
     * side-loaded.
     */
    @NonNull
    List<Category> getCategories();

    /**
     * Gets a list of {@link Section} returned as a result
     * of specifying <pre>sections</pre> as a part of a sideload operation when searching or listing
     * articles.
     *
     * @return The list of sections.  This will be an empty list if there were no results or if sections were not
     * side-loaded.
     */
    @NonNull
    List<Section> getSections();

    /**
     * Gets a list of {@link User} returned as a result
     * of specifying <pre>users</pre> as a part of a sideload operation when searching or listing
     * articles.
     *
     * @return The list of users.  This will be an empty list if there were no results or if users were not side-loaded.
     */
    @NonNull
    List<User> getUsers();
}
