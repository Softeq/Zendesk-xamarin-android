package zendesk.support;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 * Defines the operations that can be carried out on Help Center.
 * <p>
 * For more information on the APIs available see:
 * <a href="https://developer.zendesk.com/rest_api/docs/help_center/introduction">Help Center REST API Documentation</a>
 * </p>
 * <p>
 * Currently this is defined using retrofit annotations but this could be changed in the
 * future as long as these signatures remain.
 * </p>
 * <p>
 * Locale should be in the format of: "en" or "en-us", this is a requirement of the REST API being called.
 * </p>
 */
@SuppressWarnings("unused")
interface HelpCenterService {

    @GET("/hc/api/mobile/{locale}/article_tree.json")
    Call<HelpResponse> getHelp(
            @Path("locale") String locale,
            @Query("category_ids") String categoryIds,
            @Query("section_ids") String sectionIds,
            @Query("include") String sideLoadsToBeIncluded,
            @Query("limit") int articlesPerSectionLimit,
            @Query("article_labels") String articleLabels,
            @Query("per_page") int numberPerPage,
            @Query("sort_by") String sortBy,
            @Query("sort_order") String sortOrder
    );

    @GET("/api/v2/help_center/{locale}/categories.json?per_page=1000")
    Call<CategoriesResponse> getCategories(
            @Path("locale") String locale);

    @SuppressWarnings("SameParameterValue")
    @GET("/api/v2/help_center/{locale}/categories/{id}/sections.json")
    Call<SectionsResponse> getSections(
            @Path("locale") String locale,
            @Path("id") Long categoryId,
            @Query("per_page") int numberPerPage);


    @SuppressWarnings("SameParameterValue")
    @GET("/api/v2/help_center/{locale}/sections/{id}/articles.json?respect_sanitization_settings=true")
    Call<ArticlesListResponse> getArticles(
            @Path("locale") String locale,
            @Path("id") Long sectionId,
            @Query("label_names") String labelNames,
            @Query("include") String sideLoadsToBeIncluded,
            @Query("per_page") int numberPerPage);

    /**
     * Lists articles for the supplied query parameters
     *
     * @param labelNames     A comma-separated list of labels to restrict the search to. An article must
     *                       have ALL of the labels specified in order to be matched
     * @param locale         The locale to limit search results to.
     * @param include        The comma-separated elements to sideload in the search
     * @param sortBy         What the results will be sorted by.
     * @param sortOrder      The order to display the results in
     * @param page           The page to request
     * @param resultsPerPage The amount of results to display per page.
     * @return The Call object for the API call, before it has been executed or enqueued.
     * @see <a href="https://developer.zendesk.com/rest_api/docs/core/side_loading">Sideloading</a>
     */
    @GET("/api/v2/help_center/{locale}/articles.json?respect_sanitization_settings=true")
    Call<ArticlesListResponse> listArticles(
            @Path("locale") String locale,
            @Query("label_names") String labelNames,
            @Query("include") String include, @Query("sort_by") String sortBy,
            @Query("sort_order") String sortOrder,
            @Query("page") Integer page, @Query("per_page") Integer resultsPerPage);

    /**
     * Searches for articles.
     *
     * @param query          The search query
     * @param locale         The locale to limit search results to.
     * @param include        The comma-separated elements to sideload in the search
     * @param labelNames     A comma-separated list of labels to restrict the search to. An article must
     *                       have ALL of the labels specified in order to be matched
     * @param categoryIds    The IDs of the categories used to scope the search
     * @param sectionIds     The IDs of the sections used to scope the search
     * @param page           The page to request
     * @param resultsPerPage The amount of results to display per page.
     * @return The Call object for the API call, before it has been executed or enqueued.
     * @see <a href="https://developer.zendesk.com/rest_api/docs/core/side_loading">Sideloading</a>
     */
    @GET("/api/v2/help_center/articles/search.json?respect_sanitization_settings=true&origin=mobile_sdk")
    Call<ArticlesSearchResponse> searchArticles(
            @Query("query") String query,
            @Query("locale") String locale,
            @Query("include") String include,
            @Query("label_names") String labelNames,
            @Query("category") String categoryIds,
            @Query("section") String sectionIds,
            @Query("page") Integer page,
            @Query("per_page") Integer resultsPerPage);

    @GET("/hc/api/mobile/{locale}/articles/{article_id}.json?respect_sanitization_settings=true")
    Call<ArticleResponse> getArticle(
            @Path("locale") String locale,
            @Path("article_id") Long articleId,
            @Query("include") String sideLoadsToBeIncluded);

    /**
     * Search for a section for a particular section Id.
     *
     * @param locale    The locale to limit search results to.
     * @param sectionId The article ID to mark as helpful
     * @return The Call object for the API call, before it has been executed or enqueued.
     */
    @GET("/api/v2/help_center/{locale}/sections/{section_id}.json")
    Call<SectionResponse> getSectionById(
            @Path("locale") String locale,
            @Path("section_id") Long sectionId);

    /**
     * Search for a category for a particular category Id.
     *
     * @param locale     The locale to limit search results to.
     * @param categoryId The category ID to mark as helpful
     * @return The Call object for the API call, before it has been executed or enqueued.
     */
    @GET("/api/v2/help_center/{locale}/categories/{category_id}.json")
    Call<CategoryResponse> getCategoryById(
            @Path("locale") String locale,
            @Path("category_id") Long categoryId);

    @GET("/api/v2/help_center/{locale}/articles/{article_id}/attachments/{attachment_type}.json")
    Call<AttachmentResponse> getAttachments(
            @Path("locale") String locale,
            @Path("article_id") Long articleId,
            @Path("attachment_type") String attachmentType);


    /**
     * Marks an article as helpful.
     *
     * @param articleId The article ID to mark as helpful
     * @param body      The body of the request. This should be an empty json body '{}'
     * @return The Call object for the API call, before it has been executed or enqueued.
     * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/votes#create-vote">Creating votes</a>
     */
    @POST("/api/v2/help_center/articles/{article_id}/up.json")
    Call<ArticleVoteResponse> upvoteArticle(@Path("article_id") Long articleId, @Body String body);

    /**
     * Marks an article as unhelpful.
     *
     * @param articleId The article ID to mark as unhelpful
     * @param body      The body of the request. This should be an empty json body '{}'
     * @return The Call object for the API call, before it has been executed or enqueued.
     * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/votes#create-vote">Creating votes</a>
     */
    @POST("/api/v2/help_center/articles/{article_id}/down.json")
    Call<ArticleVoteResponse> downvoteArticle(@Path("article_id") Long articleId, @Body String body);

    /**
     * Deletes a vote
     *
     * @param voteId The ID of the vote to delete
     * @return The Call object for the API call, before it has been executed or enqueued.
     */
    @DELETE("/api/v2/help_center/votes/{vote_id}.json")
    Call<Void> deleteVote(@Path("vote_id") Long voteId);


    /**
     * Gets a list of suggested articles.
     *
     * @param query      The search query.
     * @param locale     The locale to limit search results to.
     * @param labelNames A comma-separated list of labels to restrict the search to. An article must.
     *                   have ALL of the labels specified in order to be matched.
     * @param category   The id of the category used to scope the search.
     * @param section    The id of the section used to scope the search.
     * @return The Call object for the API call, before it has been executed or enqueued.
     */
    @GET("/api/mobile/help_center/search/deflect.json?respect_sanitization_settings=true")
    Call<SuggestedArticleResponse> getSuggestedArticles(
            @Query("query") String query,
            @Query("locale") String locale,
            @Query("label_names") String labelNames,
            @Query("category") Long category,
            @Query("section") Long section);


    /**
     * Submit a record article view.
     *
     * @param articleId                The id of a viewed article.
     * @param locale                   The locale of the article.
     * @param recordArticleViewRequest An object holding information about last search query.
     * @return The Call object for the API call, before it has been executed or enqueued.
     */
    @POST("/api/v2/help_center/{locale}/articles/{article_id}/stats/view.json")
    Call<Void> submitRecordArticleView(
            @Path("article_id") Long articleId,
            @Path("locale") String locale,
            @Body RecordArticleViewRequest recordArticleViewRequest
    );

}
