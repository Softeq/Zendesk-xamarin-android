package zendesk.support;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;
import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * Models the response from API calls to get a flattened Help Center structure
 */
@SuppressWarnings("unused")
class HelpResponse {

    @SerializedName("category_count")
    private int categoryCount;

    private List<CategoryItem> categories;

    /**
     * Gets the CategoryItems
     *
     * @return The CategoryItems, or an empty list if there were none.
     */
    @NonNull
    public List<CategoryItem> getCategories() {
        return CollectionUtils.copyOf(categories);
    }

    public int getCategoryCount() {
        return categoryCount;
    }
}
