package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.List;

/**
 * A {@link HelpItem} for Help Center categories
 */
@SuppressWarnings("unused")
public class CategoryItem implements HelpItem {

    private boolean expanded = true;

    @SerializedName("id")
    private Long id;

    @SerializedName("name")
    private String name;

    @SerializedName("section_count")
    private int sectionCount;

    private List<SectionItem> sections;

    @NonNull
    @Override
    public String getName() {
        return name == null ? StringUtils.EMPTY_STRING : name;
    }

    @Nullable
    @Override
    public Long getId() {
        return id;
    }

    @Nullable
    @Override
    public Long getParentId() {
        return null; // null because a category has no parent
    }

    public List<SectionItem> getSections() {
        return CollectionUtils.copyOf(sections);
    }

    /**
     * Sets the sections to set as the children of the category
     *
     * @param sections The sections to set as children
     */
    public void setSections(List<SectionItem> sections) {
        this.sections = CollectionUtils.copyOf(sections);
    }

    /**
     * Checks if the category is expanded
     *
     * @return true if the category is expanded, false otherwise
     */
    public boolean isExpanded() {
        return expanded;
    }

    /**
     * Sets the expanded state. Set this to true to mark the category as expanded, false otherwise.
     *
     * @param expanded the state to set for expanded. true for expanded, false for contracted
     * @return the state of expanded after calling this method
     */
    public boolean setExpanded(boolean expanded) {
        this.expanded = expanded;
        return this.expanded;
    }

    @Override
    public int getViewType() {
        return HelpItem.TYPE_CATEGORY;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CategoryItem that = (CategoryItem) o;

        return id != null ? id.equals(that.id) : that.id == null;

    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
