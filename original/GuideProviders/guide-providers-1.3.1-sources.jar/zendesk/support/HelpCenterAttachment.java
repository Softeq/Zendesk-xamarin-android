package zendesk.support;

import androidx.annotation.Nullable;

import java.util.Date;

/**
 * This is a model class for an HelpCenterAttachment object that will be created by the
 * {@link HelpCenterProvider}.
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/help_center/article_attachments">Article Attachments</a>
 */
@SuppressWarnings({"unused"})
public class HelpCenterAttachment {

    private Long id;
    private String url;
    private Long articleId;
    private String fileName;
    private String contentUrl;
    private String contentType;
    private Long size;
    private Date createdAt;
    private Date updatedAt;

    /**
     * Gets the ID of the attachment
     *
     * @return the ID of the attachment
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the API URL of the attachment
     *
     * @return the API URL of the attachment
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the ID of the Article that the attachment is associated with
     *
     * @return the ID of the Article that the attachment is associated with
     */
    @Nullable
    public Long getArticleId() {
        return articleId;
    }

    /**
     * Gets the filename of the attachment
     *
     * @return the filename of the attachment
     */
    @Nullable
    public String getFileName() {
        return fileName;
    }

    /**
     * Gets the URL which can be used to download the attachment
     *
     * @return the URL which can be used to download the attachment
     */
    @Nullable
    public String getContentUrl() {
        return contentUrl;
    }

    /**
     * Gets the content type of the attachment. E.g. image/png
     *
     * @return the content type of the attachment. E.g. image/png
     */
    @Nullable
    public String getContentType() {
        return contentType;
    }

    /**
     * Gets the size of the attachment in bytes
     *
     * @return the size of the attachment in bytes
     */
    @Nullable
    public Long getSize() {
        return size;
    }

    /**
     * Gets the date that the attachment was created at
     *
     * @return the date that the attachment was created at
     */
    @Nullable
    public Date getCreatedAt() {
        return createdAt == null ? null : new Date(createdAt.getTime());
    }

    /**
     * Gets the date that the attachment was updated at
     *
     * @return the date that the attachment was updated at
     */
    @Nullable
    public Date getUpdatedAt() {
        return updatedAt == null ? null : new Date(updatedAt.getTime());
    }
}
