package zendesk.support;

/**
 * This is a class model for a response for a Section. This object will be created by
 * {@link HelpCenterService}
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/sections#show-section">Show Section API
 * documentation</a>
 */
@SuppressWarnings("unused")
class SectionResponse {

    private Section section;

    /**
     * Gets the section contained in this response
     *
     * @return the section contained in this response
     */
    Section getSection() {
        return section;
    }
}
