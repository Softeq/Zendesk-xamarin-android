package zendesk.support;

import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.Date;

/**
 * This is a model class for a Section object that will be created by the {@link HelpCenterProvider}.
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/help_center/sections">Sections</a>
 */
@SuppressWarnings({"unused"})
public class Section implements Serializable {

    private Long id;
    private String url;
    private String htmlUrl;
    private Long categoryId;
    private int position;
    private String sorting;
    private Date createdAt;
    private Date updatedAt;
    private String name;
    private String description;
    private String locale;
    private String sourceLocale;
    private boolean outdated;
    @SerializedName("article_count")
    private int articlesCount;

    /**
     * Gets the ID of the section
     *
     * @return the ID of the section
     */
    @Nullable
    public Long getId() {
        return id;
    }

    /**
     * Gets the API URL of the section
     *
     * @return the API URL of the section
     */
    @Nullable
    public String getUrl() {
        return url;
    }

    /**
     * Gets the html URL of the section, which can be used to open the section in a web browser
     *
     * @return the html URL of the section
     */
    @Nullable
    public String getHtmlUrl() {
        return htmlUrl;
    }

    /**
     * Gets the id of the Category that this section belongs to
     *
     * @return the id of the Category that this section belongs to
     */
    @Nullable
    public Long getCategoryId() {
        return categoryId;
    }

    /**
     * Gets the sorting position of the section. Only applicable if the sections are manually sorted
     * in the category.
     *
     * @return the sorting position of the section
     */
    public int getPosition() {
        return position;
    }

    /**
     * Gets the sorting of the section, e.g. 'manual'
     *
     * @return the sorting of the section
     */
    @Nullable
    public String getSorting() {
        return sorting;
    }

    /**
     * Gets the date that the section was created at
     *
     * @return the date that the section was created at
     */
    @Nullable
    public Date getCreatedAt() {
        return createdAt == null ? null : new Date(createdAt.getTime());
    }

    /**
     * Gets the date that the section was updated at
     *
     * @return the date that the section was updated at
     */
    public Date getUpdatedAt() {
        return updatedAt == null ? null : new Date(updatedAt.getTime());
    }

    /**
     * Gets the name of the section
     *
     * @return the name of the section
     */
    @Nullable
    public String getName() {
        return name;
    }

    /**
     * Gets the description of the section
     *
     * @return the description of the section
     */
    @Nullable
    public String getDescription() {
        return description;
    }

    /**
     * Gets the locale of the section in the form of ll-CC, e.g. en-US
     *
     * @return the locale of the section in the form of ll-CC, e.g. en-US
     */
    @Nullable
    public String getLocale() {
        return locale;
    }

    /**
     * Gets the source locale of the section in the form of ll-CC, e.g. en-US
     *
     * @return the source locale of the section in the form of ll-CC, e.g. en-US
     */
    @Nullable
    public String getSourceLocale() {
        return sourceLocale;
    }

    /**
     * Checks whether the section is outdated or not
     *
     * @return true if the section is outdated, false otherwise
     */
    public boolean isOutdated() {
        return outdated;
    }

    /**
     * Gets the number of articles in this section
     *
     * @return the number of articles in this section
     */
    public int getArticlesCount() {
        return articlesCount;
    }
}
