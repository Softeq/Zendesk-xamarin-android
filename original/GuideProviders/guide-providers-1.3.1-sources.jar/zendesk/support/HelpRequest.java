package zendesk.support;

import com.zendesk.util.StringUtils;

import java.util.List;

/**
 * Models a request for a flattened view of Help Center
 */
public class HelpRequest {

    private static final int DEFAULT_ARTICLES_PER_SECTION = 5;

    private static final String LOG_TAG = "HelpRequest";

    private static final String INCLUDE_ALL = "categories,sections";
    private static final String INCLUDE_CATEGORIES = "categories";
    private static final String INCLUDE_SECTIONS = "sections";

    private String categoryIds;
    private String sectionIds;
    private String includes;
    private String[] labelNames;
    private int articlesPerPageLimit;

    /**
     * Builder for the request.
     * <p>
     * Intentionally private.
     *
     * @param builder The builder
     */
    private HelpRequest(Builder builder) {
        this.categoryIds = builder.categoryIds;
        this.sectionIds = builder.sectionIds;
        this.includes = builder.includes;
        this.articlesPerPageLimit = builder.articlesPerSectionLimit;
        this.labelNames = builder.labelNames;
    }

    /**
     * Gets the category IDs as a CSV string
     *
     * @return the category IDs as a CSV string
     */
    public String getCategoryIds() {
        return categoryIds;
    }

    /**
     * Gets the section IDs as a CSV string
     *
     * @return the section IDs as a CSV string
     */
    public String getSectionIds() {
        return sectionIds;
    }

    /**
     * Gets the includes (side-loads) as a CSV string
     *
     * @return the Gets the includes (side-loads) as a CSV string
     */
    public String getIncludes() {
        return includes;
    }

    /**
     * Gets the maximum number of articles per page
     *
     * @return the maximum number of articles per page
     */
    public int getArticlesPerPageLimit() {
        return articlesPerPageLimit;
    }

    /**
     * Gets the label names to which the search will be restricted.
     *
     * @return the array of label names
     */
    public String[] getLabelNames() {
        return labelNames;
    }

    /**
     * This builder is used to create a {@link HelpRequest}
     */
    public static class Builder {
        private String categoryIds;
        private String sectionIds;
        private String includes;
        private String[] labelNames;
        private int articlesPerSectionLimit = DEFAULT_ARTICLES_PER_SECTION;

        /**
         * Specifies the category IDs to include in the request
         *
         * @param ids The category IDs to include in the request
         * @return the builder
         */
        public Builder withCategoryIds(List<Long> ids) {
            categoryIds = StringUtils.toCsvStringNumber(ids);
            return this;
        }

        /**
         * Specifies the section IDs to include in the request
         *
         * @param ids The section IDs to include in the request
         * @return the builder
         */
        public Builder withSectionIds(List<Long> ids) {
            sectionIds = StringUtils.toCsvStringNumber(ids);
            return this;
        }

        /**
         * Specifies that categories should be included as a side-load
         *
         * @return the builder
         */
        public Builder includeCategories() {
            if (StringUtils.isEmpty(includes)) {
                includes = INCLUDE_CATEGORIES;
            } else if (includes.equals(INCLUDE_SECTIONS)) {
                includes = INCLUDE_ALL;
            }
            return this;
        }

        /**
         * Specifies that sections should be included as a side-load
         *
         * @return the builder
         */
        public Builder includeSections() {
            if (StringUtils.isEmpty(includes)) {
                includes = INCLUDE_SECTIONS;
            } else if (includes.equals(INCLUDE_CATEGORIES)) {
                includes = INCLUDE_ALL;
            }
            return this;
        }

        /**
         * Specifies the maximum number of articles to request per section
         *
         * @param articlesPerSection The maximum number of articles to request per section
         * @return the builder
         */
        public Builder withArticlesPerSectionLimit(int articlesPerSection) {
            this.articlesPerSectionLimit = articlesPerSection;
            return this;
        }

        /**
         * Specifies the label names to which the search will be restricted.
         *
         * @param labelNames The label names to be used to filter the search results.
         * @return the builder
         */
        public Builder withLabelNames(String... labelNames) {
            this.labelNames = labelNames;
            return this;
        }

        /**
         * Builds the {@link HelpRequest} request
         *
         * @return the request
         */
        public HelpRequest build() {
            return new HelpRequest(this);
        }
    }
}
