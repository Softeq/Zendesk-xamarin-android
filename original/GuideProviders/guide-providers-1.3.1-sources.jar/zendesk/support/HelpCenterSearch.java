package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.io.Serializable;
import java.util.List;
import java.util.Locale;

/**
 * This class encapsulates the parameters for searching Help Center.
 * <p>
 * This class is what is used when searching Help Center with a {@link HelpCenterProvider},
 * specifically with the {@link HelpCenterProvider#searchArticles(HelpCenterSearch, ZendeskCallback)} method
 * </p>
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/search">Searching Help Center</a>
 */
public class HelpCenterSearch implements Serializable, Cloneable {

    private String query;

    private Locale locale;

    private String include;

    private String labelNames;

    private String categoryIds;

    private String sectionIds;

    private Integer page;

    private Integer perPage;

    private HelpCenterSearch() {
        // Intentionally private and empty
    }

    /**
     * Returns the free-form text query
     *
     * @return the query
     */
    @Nullable
    public String getQuery() {
        return query;
    }


    /**
     * Returns the locale to search in
     *
     * @return the locale to search in
     */
    @Nullable
    public Locale getLocale() {
        return locale;
    }

    /**
     * Returns the includes to specify. (a.k.a side-loads)
     *
     * @return the includes to specify
     */
    @Nullable
    public String getInclude() {
        return include;
    }

    /**
     * Returns the label names to specify.
     *
     * @return the label names to specify
     */
    @Nullable
    public String getLabelNames() {
        return labelNames;
    }

    /**
     * Returns the category IDs to specify
     *
     * @return the category IDs to specify
     */
    @Nullable
    public String getCategoryIds() {
        return categoryIds;
    }

    /**
     * Returns the section IDs to specify
     *
     * @return the section IDs to specify
     */
    @Nullable
    public String getSectionIds() {
        return this.sectionIds;
    }

    /**
     * Returns the page to specify
     *
     * @return the page to specify
     */
    @Nullable
    public Integer getPage() {
        return page;
    }

    /**
     * The amount of results per page to specify
     *
     * @return the amount of results per page to specify
     */
    @Nullable
    public Integer getPerPage() {
        return perPage;
    }

    /**
     * Clones the current search and sets the query on it
     *
     * @param query The query to set
     * @return a clone of the current search with the query set
     */
    public HelpCenterSearch withQuery(String query) {

        HelpCenterSearch search = new HelpCenterSearch();

        try {
            search = (HelpCenterSearch) this.clone();
            search.query = query;
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return search;
    }

    /**
     * This is a builder class which is used to generate a {@link HelpCenterSearch}
     */
    public static class Builder {

        private String query;
        private Locale locale;
        private String[] include;
        private String[] labelNames;
        private String categoryIds;
        private String sectionIds;
        private Integer page;
        private Integer perPage;

        public Builder() {
            // Intentionally empty
        }

        /**
         * Specifies the free-form query to perform.
         *
         * @param query The free-form query to perform
         * @return The Builder
         */
        public Builder withQuery(String query) {
            this.query = query;
            return this;
        }

        /**
         * Specifies the locale to perform the search in. Note that this must be a supported locale
         * by your Help Center instance
         *
         * @param locale The locale to search in
         * @return The Builder
         */
        public Builder forLocale(Locale locale) {
            this.locale = locale;
            return this;
        }

        /**
         * Specifies the includes to be returned by the search.
         *
         * @param includes The includes to be returned by the search
         * @return The Builder
         * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/articles#sideloads">Includes
         * documentation</a>
         */
        public Builder withIncludes(String... includes) {
            this.include = includes;
            return this;
        }

        /**
         * Specifies the label names to restrict the results to. Note that ALL label names must
         * match for an article to be includes in the search results.
         *
         * @param labelNames The label names to restrict the results to
         * @return The builder
         */
        public Builder withLabelNames(String... labelNames) {
            this.labelNames = labelNames;
            return this;
        }

        /**
         * Specifies the category id to restrict the results to.
         *
         * @param categoryId The category id to restrict the results to
         * @return The builder
         */
        public Builder withCategoryId(Long categoryId) {
            if (categoryId != null) {
                this.categoryIds = Long.toString(categoryId);
            }
            return this;
        }

        /**
         * Specifies the category IDs to restrict the results to.
         *
         * @param categoryIds The category IDs to restrict the results to
         * @return The builder
         */
        public Builder withCategoryIds(List<Long> categoryIds) {
            this.categoryIds = StringUtils.toCsvStringNumber(CollectionUtils.copyOf(categoryIds));
            return this;
        }

        /**
         * Specifies the section id to restrict the results to.
         *
         * @param sectionId The section id to restrict the results to
         * @return The builder
         */
        public Builder withSectionId(Long sectionId) {
            if (sectionId != null) {
                this.sectionIds = Long.toString(sectionId);
            }
            return this;
        }

        /**
         * Specifies the section IDs to restrict the results to.
         *
         * @param sectionIds The section IDs to restrict the results to
         * @return The builder
         */
        public Builder withSectionIds(List<Long> sectionIds) {
            this.sectionIds = StringUtils.toCsvStringNumber(CollectionUtils.copyOf(sectionIds));
            return this;
        }

        /**
         * Specifies which page of results to request.
         *
         * @param page The page of results to request
         * @return the builder
         */
        public Builder page(Integer page) {
            this.page = page;
            return this;
        }

        /**
         * Specifies the number of results to display per page
         *
         * @param perPage The number of results to display per page
         * @return the builder
         */
        public Builder perPage(Integer perPage) {
            this.perPage = perPage;
            return this;
        }

        /**
         * Builds a {@link HelpCenterSearch} object with the
         * specified parameters.
         *
         * @return the {@link HelpCenterSearch}
         */
        public HelpCenterSearch build() {
            HelpCenterSearch helpCenterSearch = new HelpCenterSearch();

            helpCenterSearch.query = this.query;
            helpCenterSearch.locale = this.locale;
            helpCenterSearch.include = StringUtils.toCsvString(this.include);
            helpCenterSearch.labelNames = StringUtils.toCsvString(this.labelNames);
            helpCenterSearch.categoryIds = this.categoryIds;
            helpCenterSearch.sectionIds = this.sectionIds;
            helpCenterSearch.page = this.page;
            helpCenterSearch.perPage = this.perPage;

            return helpCenterSearch;
        }
    }
}
