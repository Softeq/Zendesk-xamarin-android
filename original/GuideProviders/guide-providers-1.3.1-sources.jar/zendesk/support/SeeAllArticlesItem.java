package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.StringUtils;

/**
 * A {@link HelpItem} for a 'See all articles' item
 */
public class SeeAllArticlesItem implements HelpItem {

    private SectionItem section;

    private boolean isLoading;

    public SeeAllArticlesItem(SectionItem sectionItem) {
        this.section = sectionItem;
    }

    @Override
    public int getViewType() {
        return TYPE_SEE_ALL;
    }

    @NonNull
    @Override
    public String getName() {
        return StringUtils.EMPTY_STRING;
    }

    @Nullable
    @Override
    public Long getId() {
        return section.getId();
    }

    @Nullable
    @Override
    public Long getParentId() {
        return section.getParentId();
    }

    /**
     * Gets the SectionItem related to this SeeAllArticlesItem
     *
     * @return the SectionItem related to this SeeAllArticlesItem
     */
    public SectionItem getSection() {
        return section;
    }

    public boolean isLoading() {
        return isLoading;
    }

    public void setLoading(boolean loading) {
        isLoading = loading;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SeeAllArticlesItem that = (SeeAllArticlesItem) o;

        return section != null ? section.equals(that.section) : that.section == null;

    }

    @Override
    public int hashCode() {
        return section != null ? section.hashCode() : 0;
    }
}
