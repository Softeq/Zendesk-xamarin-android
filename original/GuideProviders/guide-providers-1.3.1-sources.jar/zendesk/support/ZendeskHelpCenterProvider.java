package zendesk.support;

import android.annotation.SuppressLint;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ErrorResponseAdapter;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.LocaleUtil;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import zendesk.core.User;

class ZendeskHelpCenterProvider implements HelpCenterProvider {

    private static final String LOG_TAG = "ZendeskHelpCenterProvider";
    private static final String EMPTY_JSON_BODY = "{}";

    private final HelpCenterSettingsProvider settingsProvider;
    private final HelpCenterBlipsProvider blipsProvider;
    private final ZendeskHelpCenterService helpCenterService;
    private final HelpCenterSessionCache helpCenterSessionCache;
    private final HelpCenterTracker helpCenterTracker;

    ZendeskHelpCenterProvider(
            HelpCenterSettingsProvider settingsProvider,
            HelpCenterBlipsProvider blipsProvider,
            ZendeskHelpCenterService helpCenterService,
            HelpCenterSessionCache helpCenterSessionCache,
            HelpCenterTracker helpCenterTracker) {
        this.settingsProvider = settingsProvider;
        this.blipsProvider = blipsProvider;
        this.helpCenterService = helpCenterService;
        this.helpCenterSessionCache = helpCenterSessionCache;
        this.helpCenterTracker = helpCenterTracker;
    }

    @Override
    public void getHelp(@NonNull final HelpRequest request,
                        @Nullable final ZendeskCallback<List<HelpItem>> callback) {

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    helpCenterService.getHelp(
                            getLocale(helpCenterSettings),
                            request.getCategoryIds(),
                            request.getSectionIds(),
                            request.getIncludes(),
                            request.getArticlesPerPageLimit(),
                            StringUtils.toCsvString(request.getLabelNames()),
                            new ZendeskCallbackSuccess<HelpResponse>(callback) {
                                @Override
                                public void onSuccess(HelpResponse helpResponse) {
                                    helpCenterTracker.helpCenterLoaded();

                                    if (callback != null) {
                                        callback.onSuccess(convert(helpResponse));
                                    }
                                }
                            });
                }
            }
        });
    }

    private List<HelpItem> convert(HelpResponse helpResponse) {

        if (helpResponse == null) {
            return Collections.emptyList();
        }

        List<HelpItem> helpItems = new ArrayList<>();

        for (CategoryItem category : helpResponse.getCategories()) {
            helpItems.add(category);
            for (SectionItem sectionItem : category.getSections()) {
                helpItems.add(sectionItem);
                helpItems.addAll(sectionItem.getChildren());
            }
        }

        return helpItems;
    }

    @Override
    public void getCategories(@Nullable final ZendeskCallback<List<Category>> callback) {

        if (sanityCheck(callback)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    helpCenterService.getCategories(getLocale(helpCenterSettings), callback);
                }
            }
        });
    }

    @Override
    public void getSections(@Nullable final Long categoryId, @Nullable final ZendeskCallback<List<Section>> callback) {

        if (sanityCheck(callback, categoryId)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    helpCenterService.getSectionsForCategory(categoryId, getLocale(helpCenterSettings), callback);
                }
            }
        });
    }

    @Override
    public void getArticles(@NonNull final Long sectionId, @Nullable final ZendeskCallback<List<Article>> callback) {
        getArticles(sectionId, null, callback);
    }

    @Override
    public void getArticles(@NonNull final Long sectionId, @Nullable final String labelNames,
                            @Nullable final ZendeskCallback<List<Article>> callback) {

        if (sanityCheck(callback, sectionId)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    final String include = "users";
                    helpCenterService.getArticlesForSection(sectionId, getLocale(helpCenterSettings),
                            include, labelNames, callback);
                }
            }
        });
    }

    @Override
    public void listArticles(@NonNull final ListArticleQuery query,
                             @Nullable final ZendeskCallback<List<SearchArticle>> callback) {

        if (sanityCheck(callback, query)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    final String include =
                            query.getInclude() == null
                                    ? StringUtils.toCsvString("categories", "sections", "users")
                                    : query.getInclude();

                    Locale queryLocale = query.getLocale() == null ? getLocale(helpCenterSettings) : query.getLocale();

                    String sortBy = (query.getSortBy() == null ? SortBy.CREATED_AT : query.getSortBy()).getApiValue();
                    String sortOrder =
                            (query.getSortOrder() == null ? SortOrder.DESCENDING : query.getSortOrder()).getApiValue();

                    helpCenterService.listArticles(
                            StringUtils.toCsvString(query.getLabelNames()),
                            queryLocale, include, sortBy, sortOrder,
                            query.getPage(), query.getResultsPerPage(),
                            new ZendeskCallbackSuccess<ArticlesListResponse>(callback) {
                                @Override
                                public void onSuccess(final ArticlesListResponse articlesListResponse) {
                                    List<SearchArticle> searchArticles = asSearchArticleList(articlesListResponse);

                                    if (callback != null) {
                                        callback.onSuccess(searchArticles);
                                    }
                                }
                            });
                }
            }
        });
    }

    @Override
    public void listArticlesFlat(@NonNull final ListArticleQuery query,
                                 @Nullable final ZendeskCallback<List<FlatArticle>> callback) {

        if (sanityCheck(callback, query)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    // We know we have authorization
                    final String include = "categories,sections";

                    Locale queryLocale = query.getLocale() == null ? getLocale(helpCenterSettings) : query.getLocale();

                    String sortBy = (query.getSortBy() == null ? SortBy.CREATED_AT : query.getSortBy()).getApiValue();
                    String sortOrder =
                            (query.getSortOrder() == null ? SortOrder.DESCENDING : query.getSortOrder()).getApiValue();

                    helpCenterService.listArticles(
                            StringUtils.toCsvString(query.getLabelNames()),
                            queryLocale, include, sortBy, sortOrder,
                            query.getPage(), query.getResultsPerPage(),
                            new ZendeskCallbackSuccess<ArticlesListResponse>(callback) {
                                @Override
                                public void onSuccess(final ArticlesListResponse articlesListResponse) {
                                    final List<FlatArticle> flatArticles = asFlatArticleList(articlesListResponse);

                                    if (callback != null) {
                                        callback.onSuccess(flatArticles);
                                    }
                                }
                            });
                }
            }
        });
    }

    @Override
    public void searchArticles(@NonNull final HelpCenterSearch search,
                               @Nullable final ZendeskCallback<List<SearchArticle>> callback) {

        if (sanityCheck(callback, search)) {
            return;
        }

        blipsProvider.helpCenterSearch(search.getQuery());

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    @SuppressWarnings("ConstantConditions")
                    final String include = StringUtils.isEmpty(search.getInclude())
                            ? StringUtils.toCsvString("categories", "sections", "users")
                            : StringUtils.toCsvString(search.getInclude());

                    final String labelNames = StringUtils.isEmpty(search.getLabelNames())
                            ? null
                            : StringUtils.toCsvString(search.getLabelNames());

                    final Locale locale = search.getLocale() == null
                            ? getLocale(helpCenterSettings)
                            : search.getLocale();

                    helpCenterService.searchArticles(search.getQuery(), locale, include, labelNames,
                            search.getCategoryIds(), search.getSectionIds(), search.getPage(),
                            search.getPerPage(), new ZendeskCallbackSuccess<ArticlesSearchResponse>(callback) {
                                @Override
                                public void onSuccess(final ArticlesSearchResponse articlesSearchResponse) {
                                    helpCenterTracker.helpCenterSearched(search.getQuery());

                                    int size = 0;

                                    if (articlesSearchResponse != null && CollectionUtils
                                            .isNotEmpty(articlesSearchResponse.getArticles())) {
                                        size = articlesSearchResponse.getArticles().size();
                                    }

                                    helpCenterSessionCache.setLastSearch(search.getQuery(), size);

                                    List<SearchArticle> searchArticles = asSearchArticleList(articlesSearchResponse);

                                    if (callback != null) {
                                        /*
                                          We need to call onSuccess() here do to the nested callback
                                          which is processing and translating the result.
                                         */
                                        callback.onSuccess(searchArticles);
                                    }
                                }
                            });
                }
            }
        });
    }

    @Override
    public void getArticle(@NonNull final Long articleId, @Nullable final ZendeskCallback<Article> callback) {

        if (sanityCheck(callback, articleId)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    final String include = "users";
                    helpCenterService.getArticle(articleId,
                            getLocale(helpCenterSettings), include,
                            new ZendeskCallbackSuccess<Article>(callback) {
                                @Override
                                public void onSuccess(Article article) {

                                    submitRecordArticleView(
                                            article,
                                            LocaleUtil.forLanguageTag(article.getLocale()),
                                            new ZendeskCallback<Void>() {
                                                @Override
                                                public void onSuccess(final Void result) {
                                                    // intentionally empty
                                                }

                                                @Override
                                                public void onError(final ErrorResponse error) {
                                                    Logger.e(LOG_TAG,
                                                            "Error submitting Help Center reporting: [reason] %s "
                                                                    + "[isNetworkError] %s [status] %d",
                                                            error.getReason(),
                                                            error.isHttpError(),
                                                            error.getStatus());
                                                }
                                            }
                                    );
                                    if (callback != null) {
                                        callback.onSuccess(article);
                                    }
                                }
                            });
                }
            }
        });
    }

    @Override
    public void getSection(@NonNull final Long sectionId, @Nullable final ZendeskCallback<Section> callback) {

        if (sanityCheck(callback, sectionId)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    helpCenterService.getSectionById(sectionId, getLocale(helpCenterSettings), callback);
                }
            }
        });
    }

    @Override
    public void getCategory(@NonNull final Long categoryId, @Nullable final ZendeskCallback<Category> callback) {

        if (sanityCheck(callback, categoryId)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    helpCenterService.getCategoryById(categoryId, getLocale(helpCenterSettings), callback);
                }
            }
        });
    }

    @Override
    public void getAttachments(@NonNull final Long articleId,
                               @NonNull final AttachmentType attachmentType,
                               @Nullable final ZendeskCallback<List<HelpCenterAttachment>> callback) {

        if (sanityCheck(callback, articleId, attachmentType)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    helpCenterService
                            .getAttachments(getLocale(helpCenterSettings), articleId, attachmentType, callback);
                }
            }
        });
    }

    @Override
    public void upvoteArticle(@NonNull final Long articleId, @Nullable final ZendeskCallback<ArticleVote> callback) {

        if (sanityCheck(callback, articleId)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (checkSettingsAndVotingEnabled(callback, helpCenterSettings)) {
                    helpCenterService.upvoteArticle(articleId, EMPTY_JSON_BODY,
                            new ZendeskCallbackSuccess<ArticleVoteResponse>(callback) {
                                @Override
                                public void onSuccess(final ArticleVoteResponse articleVoteResponse) {
                                    if (callback != null) {
                                        callback.onSuccess(articleVoteResponse.getVote());
                                    }
                                    blipsProvider
                                            .articleVote(articleId,
                                                    HelpCenterBlipsProvider.ArticleVote.ARTICLE_VOTE_UP);
                                }
                            });
                }
            }
        });

    }

    @Override
    public void downvoteArticle(@NonNull final Long articleId, @Nullable final ZendeskCallback<ArticleVote> callback) {

        if (sanityCheck(callback, articleId)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (checkSettingsAndVotingEnabled(callback, helpCenterSettings)) {
                    helpCenterService.downvoteArticle(articleId, EMPTY_JSON_BODY,
                            new ZendeskCallbackSuccess<ArticleVoteResponse>(callback) {
                                @Override
                                public void onSuccess(final ArticleVoteResponse articleVoteResponse) {
                                    if (callback != null) {
                                        callback.onSuccess(articleVoteResponse.getVote());
                                    }
                                    blipsProvider
                                            .articleVote(articleId,
                                                    HelpCenterBlipsProvider.ArticleVote.ARTICLE_VOTE_DOWN);
                                }
                            });
                }
            }
        });
    }

    @Override
    public void deleteVote(@NonNull final Long voteId, @Nullable final ZendeskCallback<Void> callback) {

        if (sanityCheck(callback, voteId)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (checkSettingsAndVotingEnabled(callback, helpCenterSettings)) {
                    helpCenterService.deleteVote(voteId, new ZendeskCallbackSuccess<Void>(callback) {
                        @Override
                        public void onSuccess(Void isVoid) {
                            if (callback != null) {
                                callback.onSuccess(isVoid);
                            }
                        }
                    });
                }
            }
        });
    }

    @Override
    public void getSuggestedArticles(@NonNull final SuggestedArticleSearch suggestedArticleSearch,
                                     @Nullable final ZendeskCallback<SuggestedArticleResponse> callback) {

        if (sanityCheck(callback, suggestedArticleSearch)) {
            return;
        }

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {
                    final Locale queryLocale =
                            suggestedArticleSearch.getLocale() == null ? getLocale(helpCenterSettings)
                                    : suggestedArticleSearch.getLocale();

                    final String labelNames = StringUtils.isEmpty(suggestedArticleSearch.getLabelNames())
                            ? null
                            : StringUtils.toCsvString(suggestedArticleSearch.getLabelNames());

                    helpCenterService.getSuggestedArticles(
                            suggestedArticleSearch.getQuery(),
                            queryLocale,
                            labelNames,
                            suggestedArticleSearch.getCategoryId(),
                            suggestedArticleSearch.getSectionId(),
                            callback);
                }
            }
        });
    }

    @Override
    public void submitRecordArticleView(@NonNull final Article article,
                                        @NonNull final Locale locale,
                                        @Nullable final ZendeskCallback<Void> callback) {

        if (sanityCheck(callback, article)) {
            return;
        }

        helpCenterTracker.helpCenterArticleViewed();

        blipsProvider.articleView(article);

        settingsProvider.getSettings(new ZendeskCallbackSuccess<HelpCenterSettings>(callback) {
            @Override
            public void onSuccess(HelpCenterSettings helpCenterSettings) {
                if (!sanityCheckHelpCenterSettings(callback, helpCenterSettings)) {

                    final RecordArticleViewRequest recordArticleViewRequest = new RecordArticleViewRequest(
                            helpCenterSessionCache.getLastSearch(),
                            helpCenterSessionCache.isUniqueSearchResultClick()
                    );

                    helpCenterService.submitRecordArticleView(
                            article.getId(),
                            locale,
                            recordArticleViewRequest,
                            new ZendeskCallbackSuccess<Void>(callback) {
                                @Override
                                public void onSuccess(final Void genericResponse) {
                                    helpCenterSessionCache.unsetUniqueSearchResultClick();

                                    if (callback != null) {
                                        callback.onSuccess(genericResponse);
                                    }
                                }
                            }
                    );
                }
            }
        });
    }

    /**
     * Gets the locale to be used for Help Center requests. By default this is the device's locale.
     * If a locale override has been set on the Guide singleton using
     * {@link Guide#setHelpCenterLocaleOverride(Locale)}
     * then this will be used.
     *
     * @return The locale to use when requesting help center content.
     */
    Locale getLocale(HelpCenterSettings settings) {
        if (Guide.INSTANCE.getHelpCenterLocaleOverride() != null) {
            return Guide.INSTANCE.getHelpCenterLocaleOverride();
        } else {
            String helpCenterLocale = settings != null ? settings.getLocale() : StringUtils.EMPTY_STRING;
            return StringUtils.isEmpty(helpCenterLocale) ? Locale.getDefault()
                    : LocaleUtil.forLanguageTag(helpCenterLocale);
        }
    }

    /**
     * Performs basic checks on the request.
     * <p>
     * The tests that are performed are ones that are so basic that there's no point in doing
     * a network call because we know it won't work.
     * </p>
     *
     * @param callback The callback to alert the error to. This callback will never get a success from
     *                 this method
     * @return true if the caller should return, false otherwise
     */
    boolean sanityCheck(ZendeskCallback<?> callback, Object... nonNullArgs) {
        if (nonNullArgs != null) {
            boolean nonNull = true;
            for (Object o : nonNullArgs) {
                if (o == null) {
                    nonNull = false;
                }
            }

            if (!nonNull) {
                final String message = "One or more provided parameters are null.";
                Logger.e(LOG_TAG, message);

                if (callback != null) {
                    callback.onError(new ErrorResponseAdapter(message));
                }

                return true;
            }
        }

        return false;
    }

    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    boolean sanityCheckHelpCenterSettings(ZendeskCallback<?> callback, HelpCenterSettings settings) {
        if (settings == null) {
            final String message = "Help Center settings are null. Can not continue with the call";
            Logger.e(LOG_TAG, message);

            if (callback != null) {
                callback.onError(new ErrorResponseAdapter(message));
            }

            return true;
        }

        if (!settings.isEnabled()) {
            final String message = "Help Center is disabled in your app's settings. Can not continue with the call";
            Logger.e(LOG_TAG, message);

            if (callback != null) {
                callback.onError(new ErrorResponseAdapter(message));
            }

            return true;
        }

        return false;
    }

    private boolean checkSettingsAndVotingEnabled(ZendeskCallback<?> callback, HelpCenterSettings settings) {
        if (!sanityCheckHelpCenterSettings(callback, settings)) {
            if (settings.isArticleVotingEnabled()) {
                return true;
            } else {
                final String message =
                        "Help Center voting is disabled in your app's settings. Can not continue with the call";
                Logger.e(LOG_TAG, message);
                if (callback != null) {
                    callback.onError(new ErrorResponseAdapter(message));
                }
                return false;
            }
        } else {
            return false;
        }
    }

    @SuppressLint("UseSparseArrays")
    List<SearchArticle> asSearchArticleList(ArticlesResponse result) {
        List<SearchArticle> searchArticles = new ArrayList<>();

        if (result == null) {
            return searchArticles;
        }

        Map<Long, Section> sectionIdToSection = new HashMap<>();
        Map<Long, Category> categoryIdToCategory = new HashMap<>();
        Map<Long, User> userIdToUser = new HashMap<>();

        List<Article> articles = CollectionUtils.ensureEmpty(result.getArticles());
        List<Section> sections = CollectionUtils.ensureEmpty(result.getSections());
        List<Category> categories = CollectionUtils.ensureEmpty(result.getCategories());
        List<User> users = CollectionUtils.ensureEmpty(result.getUsers());

        for (Section section : sections) {
            if (section.getId() != null) {
                sectionIdToSection.put(section.getId(), section);
            }
        }

        for (Category category : categories) {
            if (category.getId() != null) {
                categoryIdToCategory.put(category.getId(), category);
            }
        }

        for (User user : users) {
            if (user.getId() != null) {
                userIdToUser.put(user.getId(), user);
            }
        }

        for (Article article : articles) {

            Section section = null;
            Category category = null;

            if (article.getSectionId() != null) {
                section = sectionIdToSection.get(article.getSectionId());
            } else {
                Logger.w(LOG_TAG, "Unable to determine section as section id was null.");
            }

            if (section != null && section.getCategoryId() != null) {
                category = categoryIdToCategory.get(section.getCategoryId());
            } else {
                Logger.w(LOG_TAG, "Unable to determine category as section was null.");
            }

            if (article.getAuthorId() != null) {
                article.setAuthor(userIdToUser.get(article.getAuthorId()));
            } else {
                Logger.w(LOG_TAG, "Unable to determine author as author id was null.");
            }


            SearchArticle searchArticle = new SearchArticle(article, section, category);
            searchArticles.add(searchArticle);
        }

        return searchArticles;
    }

    @SuppressLint("UseSparseArrays")
    List<FlatArticle> asFlatArticleList(final ArticlesResponse articlesListResponse) {

        if (articlesListResponse == null) {
            return new ArrayList<>();
        }

        List<Category> categories = articlesListResponse.getCategories();
        List<Section> sections = articlesListResponse.getSections();
        List<Article> articles = articlesListResponse.getArticles();

        Map<Long, Category> categoryMap = new HashMap<>();
        Map<Long, Section> sectionMap = new HashMap<>();

        // Build Flat Structure
        List<FlatArticle> flatArticles = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(articles)) {
            for (Category category : categories) {
                categoryMap.put(category.getId(), category);
            }

            for (Section section : sections) {
                sectionMap.put(section.getId(), section);
            }

            for (Article article : articles) {
                Section section = sectionMap.get(article.getSectionId());
                Category category = categoryMap.get(section.getCategoryId());

                FlatArticle flatArticle = new FlatArticle(category, section, article);
                flatArticles.add(flatArticle);
            }

        } else {
            Logger.d(LOG_TAG, "There are no articles contained in this account");
            flatArticles = Collections.emptyList();
        }

        Collections.sort(flatArticles);

        return flatArticles;
    }

    abstract static class ZendeskCallbackSuccess<E> extends ZendeskCallback<E> {

        private final ZendeskCallback callback;

        ZendeskCallbackSuccess(@Nullable ZendeskCallback callback) {
            this.callback = callback;
        }

        @Override
        public abstract void onSuccess(final E e);

        @Override
        public void onError(final ErrorResponse errorResponse) {
            if (callback != null) {
                callback.onError(errorResponse);
            }
        }
    }
}
