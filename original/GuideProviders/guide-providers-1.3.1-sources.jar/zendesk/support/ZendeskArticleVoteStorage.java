package zendesk.support;

import java.util.HashMap;
import java.util.Map;

import zendesk.core.BaseStorage;

class ZendeskArticleVoteStorage implements ArticleVoteStorage {

    private static final String ARTICLE_VOTE_KEY = "help_center_stored_article_votes";

    private final BaseStorage baseStorage;

    ZendeskArticleVoteStorage(BaseStorage baseStorage) {
        this.baseStorage = baseStorage;
    }

    @Override
    public void storeArticleVote(Long articleId, ArticleVote articleVote) {
        Map<Long, ArticleVote> articleVoteMap = getStoredArticleVotes();
        if (articleVoteMap == null) {
            articleVoteMap = new HashMap<>();
        }

        if (articleVote != null) {
            articleVoteMap.put(articleId, articleVote);
            storeArticleVoteHolder(articleVoteMap);
        }
    }

    @Override
    public ArticleVote getStoredArticleVote(Long articleId) {
        Map<Long, ArticleVote> articleVoteMap = getStoredArticleVotes();

        if (articleVoteMap != null && articleVoteMap.containsKey(articleId)) {
            return articleVoteMap.get(articleId);
        }
        return null;
    }

    @Override
    public void removeStoredArticleVote(Long articleId) {
        if (articleId != null) {
            Map<Long, ArticleVote> articleVoteMap = getStoredArticleVotes();

            if (articleVoteMap != null && articleVoteMap.containsKey(articleId)) {
                articleVoteMap.remove(articleId);
                storeArticleVoteHolder(articleVoteMap);
            }
        }
    }

    /**
     * Gets the list of article votes that are stored on the device
     *
     * @return A map containing {@link ArticleVote}s
     */
    private Map<Long, ArticleVote> getStoredArticleVotes() {
        ArticleVoteMapWrapper articleVoteMapWrapper =
                baseStorage.get(ARTICLE_VOTE_KEY, ArticleVoteMapWrapper.class);
        return articleVoteMapWrapper != null ? articleVoteMapWrapper.map : null;
    }

    /**
     * Wraps the articleVoteMap in a static class {@link ArticleVoteMapWrapper} to be serialised and stored
     *
     * @param articleVoteMap The map to be stored
     */
    private void storeArticleVoteHolder(Map<Long, ArticleVote> articleVoteMap) {
        ArticleVoteMapWrapper articleVoteMapWrapper = new ArticleVoteMapWrapper();
        articleVoteMapWrapper.map = articleVoteMap;
        baseStorage.put(ARTICLE_VOTE_KEY, articleVoteMapWrapper);
    }

    static class ArticleVoteMapWrapper {
        Map<Long, ArticleVote> map;
    }
}
