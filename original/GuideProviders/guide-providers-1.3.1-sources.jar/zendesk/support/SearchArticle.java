package zendesk.support;

import java.io.Serializable;

/**
 * This class will wrap a {@link Article}.
 * <p>
 * This wrapper class will add {@link Category} and {@link Section} information to an {@link Article}.
 * </p>
 * <p>
 * This class is not intended to be used directly in serialisation and deserialisation so it
 * uses the m prefix for fields.
 * </p>
 */
public class SearchArticle implements Serializable {

    private final Article article;

    private final Category category;

    private final Section section;

    /**
     * Wraps an {@link Article} and also includes information of the location structure of the {@link Article}.
     *
     * @param article  The original article that we are going to wrap
     * @param section  The section that this article belongs to
     * @param category The category that this article belongs to
     */
    public SearchArticle(Article article, Section section, Category category) {
        this.article = article;
        this.section = section;
        this.category = category;
    }

    /**
     * Gets the wrapped {@link Article} object.
     *
     * @return the original {@link Article} object
     */
    public Article getArticle() {
        return article;
    }

    /**
     * Gets the section that this article belongs in.
     *
     * @return The section that the article belongs in or null if there was an issue in determining
     * this.
     */
    public Section getSection() {
        return section;
    }

    /**
     * Gets the category that this article belongs in.
     *
     * @return The category that this article belongs in or null if there was an issue in determining
     * this.
     */
    public Category getCategory() {
        return category;
    }
}
