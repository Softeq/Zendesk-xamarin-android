package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.List;

import zendesk.core.User;

/**
 * This is a class model for a response for searching sections. This object will be created by
 * {@link HelpCenterProvider}
 * <p>
 * This class is a model that will be serialised to JSON and deserialised from JSON to this
 * model. As such it does not follow the m naming prefix for fields.
 * </p>
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/search">Search API documentation</a>
 */
@SuppressWarnings("unused")
class ArticlesSearchResponse implements ArticlesResponse {

    private List<Article> results;

    private List<Category> categories;

    private List<Section> sections;

    private List<User> users;

    private String nextPage;

    private String previousPage;

    @NonNull
    @Override
    public List<Article> getArticles() {
        return CollectionUtils.copyOf(results);
    }

    @NonNull
    @Override
    public List<Category> getCategories() {
        return CollectionUtils.copyOf(categories);
    }

    @NonNull
    @Override
    public List<Section> getSections() {
        return CollectionUtils.copyOf(sections);
    }

    @NonNull
    @Override
    public List<User> getUsers() {
        return CollectionUtils.copyOf(users);
    }

    /**
     * Gets the URL of the next page of results
     *
     * <p>
     * If this method returns null it means there is no next page for the given parameters
     * specified in a {@link HelpCenterSearch}
     * </p>
     *
     * @return The URL of the next page
     * @see <a href="https://developer.zendesk.com/rest_api/docs/core/introduction#pagination">Pagination</a>
     */
    @Nullable
    public String getNextPage() {
        return nextPage;
    }

    /**
     * gets the URL of the previous page of results
     *
     * <p>
     * If this method returns null it means you are on the first page.
     * </p>
     *
     * @return The URL of the previous page of results
     * @see <a href="https://developer.zendesk.com/rest_api/docs/core/introduction#pagination">Pagination</a>
     */
    @Nullable
    public String getPreviousPage() {
        return previousPage;
    }
}
