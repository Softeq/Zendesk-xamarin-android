package zendesk.support;

import androidx.annotation.Nullable;

/**
 * This class encapsulates information about the last Help Center search.
 */
@SuppressWarnings("unused")
class LastSearch {

    private final String query;
    private final int resultsCount;

    private final String origin = "mobile_sdk";

    /**
     * Creates an instance of LastSearch from the given query and result count
     *
     * @param query       The last used string to query the Help Center.
     * @param resultCount The result count of the last query.
     */
    LastSearch(final String query, final int resultCount) {
        this.query = query;
        this.resultsCount = resultCount;
    }

    /**
     * Gets the query terms of the last search
     *
     * @return the query terms of the last search
     */
    @Nullable
    String getQuery() {
        return query;
    }

    /**
     * Gets the number of results that the last search had
     *
     * @return the number of results that the last search had
     */
    int getResultsCount() {
        return resultsCount;
    }
}
