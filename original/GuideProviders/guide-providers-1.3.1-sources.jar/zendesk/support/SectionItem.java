package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.gson.annotations.SerializedName;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * A {@link HelpItem} for Help Center sections
 */
@SuppressWarnings("unused")
public class SectionItem implements HelpItem {

    @SerializedName("id")
    private Long sectionId;

    @SerializedName("article_count")
    private int totalArticlesCount;

    @SerializedName("name")
    private String name;

    @SerializedName("category_id")
    private Long categoryId;

    private List<ArticleItem> articles;

    @Override
    public int getViewType() {
        return TYPE_SECTION;
    }

    @NonNull
    @Override
    public String getName() {
        return name == null ? StringUtils.EMPTY_STRING : name;
    }

    @Nullable
    @Override
    public Long getId() {
        return sectionId;
    }

    @Nullable
    @Override
    public Long getParentId() {
        return categoryId;
    }

    @NonNull
    public List<HelpItem> getChildren() {
        List<HelpItem> helpItems = new ArrayList<>();
        helpItems.addAll(articles);
        if (articles.size() < totalArticlesCount) {
            helpItems.add(new SeeAllArticlesItem(this));
        }

        return helpItems;
    }

    public void addArticle(@NonNull ArticleItem articleItem) {
        if (articles == null) {
            articles = new ArrayList<>();
        }
        articles.add(articleItem);
    }

    /**
     * Gets the number of articles in this SectionItem
     *
     * @return the number of articles in this SectionItem
     */
    public int getTotalArticlesCount() {
        return totalArticlesCount;
    }

    @SuppressWarnings("SimplifiableIfStatement")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SectionItem that = (SectionItem) o;

        if (sectionId != null ? !sectionId.equals(that.sectionId) : that.sectionId != null) {
            return false;
        }
        return categoryId != null ? categoryId.equals(that.categoryId) : that.categoryId == null;

    }

    @Override
    public int hashCode() {
        int result = sectionId != null ? sectionId.hashCode() : 0;
        result = 31 * result + (categoryId != null ? categoryId.hashCode() : 0);
        return result;
    }
}
