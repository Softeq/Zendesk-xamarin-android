package zendesk.support;

import zendesk.core.CustomNetworkConfig;

import okhttp3.OkHttpClient;

/**
 * A {@link CustomNetworkConfig} with an interceptor to map the custom Help Center caching header
 * to the standard cache control header so that we can use OkHttp's built-in client-side caching
 * mechanism.
 * <p>
 * The standard cache control header is not usable for this because the Help Center API cannot be
 * allowed to provide client-side caching for  web. The custom header is used only by the Support
 * SDK.
 */

class HelpCenterCachingNetworkConfig extends CustomNetworkConfig {

    private HelpCenterCachingInterceptor interceptor;

    HelpCenterCachingNetworkConfig(HelpCenterCachingInterceptor interceptor) {
        this.interceptor = interceptor;
    }

    @Override
    public void configureOkHttpClient(OkHttpClient.Builder builder) {
        builder.addNetworkInterceptor(interceptor);
    }

}
