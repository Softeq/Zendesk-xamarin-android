package zendesk.support;

import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponse;
import com.zendesk.service.ZendeskCallback;

import java.util.Locale;

import zendesk.core.SettingsPack;
import zendesk.core.SettingsProvider;
import zendesk.core.ZendeskLocaleConverter;

class ZendeskHelpCenterSettingsProvider implements HelpCenterSettingsProvider {

    private static final String LOG_TAG = "HelpCenterSettingsProvider";
    private static final String HELP_CENTER_KEY = "help_center";

    private final SettingsProvider sdkSettingsProvider;
    private final ZendeskLocaleConverter localeConverter;
    private final Locale deviceLocale;

    ZendeskHelpCenterSettingsProvider(SettingsProvider sdkSettingsProvider,
                                             ZendeskLocaleConverter localeConverter, Locale deviceLocale) {
        this.sdkSettingsProvider = sdkSettingsProvider;
        this.localeConverter = localeConverter;
        this.deviceLocale = deviceLocale;
    }

    @Override
    public void getSettings(@Nullable final ZendeskCallback<HelpCenterSettings> callback) {
        sdkSettingsProvider.getSettingsForSdk(HELP_CENTER_KEY,
                HelpCenterSettings.class,
                new ZendeskCallback<SettingsPack<HelpCenterSettings>>() {
                    @Override
                    public void onSuccess(SettingsPack<HelpCenterSettings> helpCenterSettingsPack) {
                        logIfLocaleNotAvailable(helpCenterSettingsPack.getSettings());

                        Logger.d(LOG_TAG, "Successfully retrieved Help Center Settings");
                        if (callback != null) {
                            callback.onSuccess(helpCenterSettingsPack.getSettings());
                        }
                    }

                    @Override
                    public void onError(ErrorResponse errorResponse) {
                        if (callback != null) {
                            Logger.d(LOG_TAG, "Returning default Help Center Settings.");
                            final HelpCenterSettings defaultHelpCenterSettings = HelpCenterSettings.defaultSettings();

                            callback.onSuccess(defaultHelpCenterSettings);
                        }
                    }
                });
    }

    private void logIfLocaleNotAvailable(HelpCenterSettings helpCenterSettings) {
        if (helpCenterSettings != null && helpCenterSettings.getLocale() != null) {
            // If we're still getting an NPE on this method call, WTF is going on?!
            // This incredibly redundant variable is a stab-in-the-dark attempt to avoid the very
            // strange NPE we intermittently get on Jenkins.
            String settingsLocale = helpCenterSettings.getLocale();

            final String locale = localeConverter.toHelpCenterLocaleString(deviceLocale);
            boolean requestedLocaleIsNotAvailable = !locale.equals(settingsLocale);

            if (requestedLocaleIsNotAvailable) {
                Logger.w(LOG_TAG,
                        "No support for %s, Help Center is %s in your application settings",
                        locale, helpCenterSettings.isEnabled());
            }
        }
    }
}
