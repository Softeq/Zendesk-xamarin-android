package zendesk.support;

/**
 * Defines some operations which can be used for tracking or analytics purposes.
 */
interface HelpCenterTracker {

    /**
     * Called when the Help Center content is loaded
     */
    void helpCenterLoaded();

    /**
     * Called when a search is performed in Help Center
     */
    void helpCenterSearched(String query);

    /**
     * Called when an article is viewed in Help Center
     */
    void helpCenterArticleViewed();

    /**
     * A default, no-op implementation of the HelpCenterTracker interface. This is used by default when the Guide SDK is
     * initialized. Replace (or override) the DefaultTracker using the {@link Guide#installTracker(HelpCenterTracker)}
     * method.
     */
    class DefaultTracker implements HelpCenterTracker {
        @Override
        public void helpCenterLoaded() {
            // Intentionally empty.
        }

        @Override
        public void helpCenterSearched(String query) {
            // Intentionally empty.
        }

        @Override
        public void helpCenterArticleViewed() {
            // Intentionally empty.
        }
    }
}
