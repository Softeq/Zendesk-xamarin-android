package zendesk.support;

import androidx.annotation.NonNull;

import com.zendesk.util.CollectionUtils;

import java.util.List;

/**
 * This is a class model for a response for fetching attachments associated with an article. This
 * object will be created by {@link zendesk.support.HelpCenterService}.
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/article_attachments">HelpCenterAttachment
 * API documentation</a>
 */
@SuppressWarnings({"unused"})
class AttachmentResponse {

    private List<HelpCenterAttachment> articleAttachments;

    /**
     * Gets a list of the {@link HelpCenterAttachment} returned when fetching attachments for an article.
     *
     * @return The list of attachment.  This will be an empty list if there were no results.
     */
    @NonNull
    List<HelpCenterAttachment> getArticleAttachments() {
        return CollectionUtils.copyOf(articleAttachments);
    }
}
