package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.service.ErrorResponseAdapter;
import com.zendesk.service.RetrofitZendeskCallbackAdapter;
import com.zendesk.service.ZendeskCallback;
import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import zendesk.core.User;
import zendesk.core.ZendeskLocaleConverter;

/**
 * <p>
 * Service to provide operations for Help Center objects by wrapping the {@link HelpCenterService}
 * </p>
 */
class ZendeskHelpCenterService {

    private static final String LOG_TAG = "ZendeskHelpCenterService";

    private final HelpCenterService helpCenterService;
    private final ZendeskLocaleConverter localeConverter;
    private static final int NUMBER_PER_PAGE = 1000;

    ZendeskHelpCenterService(HelpCenterService helpCenterService,
                             ZendeskLocaleConverter localeConverter) {
        this.helpCenterService = helpCenterService;
        this.localeConverter = localeConverter;
    }

    void getHelp(final Locale locale, final String categoryIds, final String sectionIds,
                 final String include, int articlesPerPageLimit, String labelNames,
                 final ZendeskCallback<HelpResponse> callback) {

        helpCenterService
                .getHelp(localeConverter.toHelpCenterLocaleString(locale),
                        categoryIds,
                        sectionIds,
                        include,
                        articlesPerPageLimit,
                        labelNames,
                        NUMBER_PER_PAGE,
                        SortBy.CREATED_AT.getApiValue(),
                        SortOrder.DESCENDING.getApiValue())
                .enqueue(new RetrofitZendeskCallbackAdapter<HelpResponse, HelpResponse>(callback));
    }

    /**
     * Get list of categories in a Help Center instance
     *
     * @param locale   locale filter to request only sections for the given locale
     * @param callback callback called on the state change of the request being called
     */
    public void getCategories(final Locale locale, final ZendeskCallback<List<Category>> callback) {

        helpCenterService
                .getCategories(localeConverter.toHelpCenterLocaleString(locale))
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback,
                        new RetrofitZendeskCallbackAdapter.RequestExtractor<CategoriesResponse, List<Category>>() {
                            @Override
                            public List<Category> extract(final CategoriesResponse data) {
                                return data.getCategories();
                            }
                        }));
    }

    /**
     * Get list of sections in a Help Center instance
     *
     * @param categoryId categoryId to which sections will be retrieved
     * @param locale     locale filter to request only sections for the given locale
     * @param callback   callback called on the state change of the request being called
     */
    public void getSectionsForCategory(final Long categoryId,
                                       final Locale locale,
                                       final ZendeskCallback<List<Section>> callback) {

        helpCenterService
                .getSections(localeConverter.toHelpCenterLocaleString(locale), categoryId, NUMBER_PER_PAGE)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback,
                        new RetrofitZendeskCallbackAdapter.RequestExtractor<SectionsResponse, List<Section>>() {
                            @Override
                            public List<Section> extract(final SectionsResponse data) {
                                return data.getSections();
                            }
                        }));
    }

    /**
     * Get list of articles for a given section in a Help Center instance
     *
     * @param sectionId sectionId to which articles will be retrieved
     * @param locale    locale filter to request only sections for the given locale
     * @param include   The sideloads to include
     * @param callback  callback called on the state change of the request being called
     */
    void getArticlesForSection(final Long sectionId, final Locale locale, final String include,
                               String labelNames, final ZendeskCallback<List<Article>> callback) {

        helpCenterService
                .getArticles(localeConverter.toHelpCenterLocaleString(locale),
                        sectionId,
                        labelNames,
                        include,
                        NUMBER_PER_PAGE)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback,
                        new RetrofitZendeskCallbackAdapter.RequestExtractor<ArticlesListResponse, List<Article>>() {
                            @Override
                            public List<Article> extract(final ArticlesListResponse articlesListResponse) {
                                return matchArticlesWithUsers(articlesListResponse.getUsers(),
                                        articlesListResponse.getArticles());
                            }
                        }));
    }

    List<Article> matchArticlesWithUsers(final List<User> users, final List<Article> articles) {
        final Map<Long, User> mapOfUsers = new HashMap<>();

        for (User user : users) {
            mapOfUsers.put(user.getId(), user);
        }

        final List<Article> matchedArticles = new ArrayList<>();

        for (Article article : articles) {

            final User user = mapOfUsers.get(article.getAuthorId());
            if (user != null) {
                article.setAuthor(user);
            }

            matchedArticles.add(article);
        }

        return matchedArticles;
    }

    public void listArticles(String labelNames,
                             Locale locale,
                             String include,
                             String sortBy,
                             String sortOrder,
                             Integer page,
                             Integer resultsPerPage,
                             final ZendeskCallback<ArticlesListResponse> callback) {

        final String localeString = localeConverter.toHelpCenterLocaleString(locale);
        helpCenterService
                .listArticles(localeString, labelNames, include, sortBy, sortOrder, page, resultsPerPage)
                .enqueue(new RetrofitZendeskCallbackAdapter<ArticlesListResponse, ArticlesListResponse>(callback));
    }

    /**
     * Gets a list of articles matching the given search query in the given category and section.
     *
     * @param query          The query text that will be searched for.
     * @param locale         The locale that will limit results to articles with this locale.
     * @param include        The sideloads to include
     * @param labelNames     A comma-separated list of labels to restrict the search to. An article must
     *                       have ALL of the labels specified in order to be matched.
     * @param categoryIds    A comma-separated list of categories to restrict the search to. An article must
     *                       appear in one of the categories specified in order to be matched.
     * @param sectionIds     A comma-separated list of sections to restrict the search to. An article must
     *                       appear in one of the sections specified in order to be matched.
     * @param page           The page of the response to request.
     * @param resultsPerPage The number of articles to return per page of response.
     * @param callback       callback called on the state change of the request being called.
     */
    public void searchArticles(final String query, final Locale locale, final String include,
                               final String labelNames, final String categoryIds, final String sectionIds,
                               final Integer page, final Integer resultsPerPage,
                               final ZendeskCallback<ArticlesSearchResponse> callback) {

        final String localeString = localeConverter.toHelpCenterLocaleString(locale);
        helpCenterService
                .searchArticles(query, localeString, include, labelNames, categoryIds, sectionIds, page, resultsPerPage)
                .enqueue(new RetrofitZendeskCallbackAdapter<ArticlesSearchResponse, ArticlesSearchResponse>(callback));
    }

    /**
     * Get a single article based on the given article id
     *
     * @param articleId The article id to be used to fetch the individual article
     * @param locale    The locale that will limit results to articles with this locale.
     * @param include   The sideloads to include
     * @param callback  callback called on the state changes of the request being invoked
     */
    public void getArticle(final Long articleId,
                           final Locale locale,
                           final String include,
                           final ZendeskCallback<Article> callback) {

        final String localeString = localeConverter.toHelpCenterLocaleString(locale);

        final RetrofitZendeskCallbackAdapter.RequestExtractor<ArticleResponse, Article> requestExtractor =
                new RetrofitZendeskCallbackAdapter.RequestExtractor<ArticleResponse, Article>() {
                    @Override
                    public Article extract(final ArticleResponse articleResponse) {
                        return matchArticleWithUsers(articleResponse.getArticle(),
                                CollectionUtils.ensureEmpty(articleResponse.getUsers()));
                    }
                };

        RetrofitZendeskCallbackAdapter<ArticleResponse, Article> callbackAdapter =
                new RetrofitZendeskCallbackAdapter<>(callback, requestExtractor);


        helpCenterService
                .getArticle(localeString, articleId, include)
                .enqueue(callbackAdapter);
    }

    @NonNull
    Article matchArticleWithUsers(@Nullable Article article, @NonNull List<User> users) {

        if (article == null) {
            return new Article();
        }

        for (User user : users) {
            if (user.getId() != null && user.getId().equals(article.getAuthorId())) {
                article.setAuthor(user);
                break;
            }
        }
        return article;
    }

    /**
     * Get a single section based on the given section id
     *
     * @param sectionId The section id to be used to fetch the individual section
     * @param locale    The locale that will limit results to articles with this locale.
     * @param callback  callback called on the state changes of the request being invoked
     */
    public void getSectionById(final Long sectionId, final Locale locale, final ZendeskCallback<Section> callback) {

        final String localeString = localeConverter.toHelpCenterLocaleString(locale);
        helpCenterService
                .getSectionById(localeString, sectionId)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback,
                        new RetrofitZendeskCallbackAdapter.RequestExtractor<SectionResponse, Section>() {
                            @Override
                            public Section extract(final SectionResponse data) {
                                return data.getSection();
                            }
                        }));
    }

    /**
     * Get a single category based on the given category id
     *
     * @param categoryId The category id to be used to fetch the individual category
     * @param locale     The locale that will limit results to categories with this locale.
     * @param callback   callback called on the state changes of the request being invoked
     */
    public void getCategoryById(final Long categoryId, final Locale locale, final ZendeskCallback<Category> callback) {

        final String localeString = localeConverter.toHelpCenterLocaleString(locale);
        helpCenterService
                .getCategoryById(localeString, categoryId)
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback,
                        new RetrofitZendeskCallbackAdapter.RequestExtractor<CategoryResponse, Category>() {
                            @Override
                            public Category extract(final CategoryResponse data) {
                                return data.getCategory();
                            }
                        }));
    }

    /**
     * Get list of attachments for a given article from help center
     *
     * @param locale    The locale of the article that the attachment belongs to
     * @param articleId The article id to be used to filter which attachments should be fetched
     * @param type      set which type of tickets to be retrieved from
     * @param callback  callback called on the state change of the request being invoked
     */
    public void getAttachments(final Locale locale,
                               final Long articleId,
                               AttachmentType type,
                               final ZendeskCallback<List<HelpCenterAttachment>> callback) {

        if (type == null) {
            final String error = "getAttachments() was called with null attachment type";
            Logger.e(LOG_TAG, error);

            if (callback != null) {
                callback.onError(new ErrorResponseAdapter(error));
            }

            return;
        }

        final String localeString = localeConverter.toHelpCenterLocaleString(locale);
        helpCenterService
                .getAttachments(localeString, articleId, type.getAttachmentType())
                .enqueue(new RetrofitZendeskCallbackAdapter<>(callback,
                        new RetrofitZendeskCallbackAdapter.RequestExtractor<AttachmentResponse,
                                List<HelpCenterAttachment>>() {
                            @Override
                            public List<HelpCenterAttachment> extract(final AttachmentResponse data) {
                                return data.getArticleAttachments();
                            }
                        }));
    }

    public void upvoteArticle(final Long articleId,
                              final String body,
                              final ZendeskCallback<ArticleVoteResponse> callback) {

        if (articleId == null) {

            final String reason = "The article id was null, can not create up vote";

            Logger.e(LOG_TAG, reason);

            if (callback != null) {
                callback.onError(new ErrorResponseAdapter(reason));
            }

            return;
        }

        helpCenterService
                .upvoteArticle(articleId, body)
                .enqueue(new RetrofitZendeskCallbackAdapter<ArticleVoteResponse, ArticleVoteResponse>(callback));
    }

    public void downvoteArticle(final Long articleId,
                                final String body,
                                final ZendeskCallback<ArticleVoteResponse> callback) {

        if (articleId == null) {

            final String reason = "The article id was null, can not create down vote";

            Logger.e(LOG_TAG, reason);

            if (callback != null) {
                callback.onError(new ErrorResponseAdapter(reason));
            }

            return;
        }

        helpCenterService
                .downvoteArticle(articleId, body)
                .enqueue(new RetrofitZendeskCallbackAdapter<ArticleVoteResponse, ArticleVoteResponse>(callback));
    }

    public void deleteVote(final Long voteId, final ZendeskCallback<Void> callback) {

        if (voteId == null) {
            final String reason = "The vote id was null, can not delete the vote";

            Logger.e(LOG_TAG, reason);

            if (callback != null) {
                callback.onError(new ErrorResponseAdapter(reason));
            }

            return;
        }

        helpCenterService
                .deleteVote(voteId)
                .enqueue(new RetrofitZendeskCallbackAdapter<Void, Void>(callback));
    }


    /**
     * Get a list of suggested articles.
     *
     * @param query      The search query.
     * @param locale     The locale to limit search results to.
     * @param labelNames A comma-separated list of labels to restrict the search to. An article must
     *                   have ALL of the labels specified in order to be matched.
     * @param category   The id of the category used to scope the search.
     * @param section    The id of the section used to scope the search.
     * @param callback   The callback called upon a success or error response.
     */
    public void getSuggestedArticles(final String query,
                                     final Locale locale,
                                     final String labelNames,
                                     final Long category,
                                     final Long section,
                                     final ZendeskCallback<SuggestedArticleResponse> callback) {
        final String localeString = localeConverter.toHelpCenterLocaleString(locale);
        final RetrofitZendeskCallbackAdapter<SuggestedArticleResponse, SuggestedArticleResponse> callbackAdapter =
                new RetrofitZendeskCallbackAdapter<>(callback);

        helpCenterService
                .getSuggestedArticles(query, localeString, labelNames, category, section)
                .enqueue(callbackAdapter);
    }


    /**
     * Submit a record article view
     *
     * @param articleId                The id of a viewed article.
     * @param locale                   The locale of the article.
     * @param recordArticleViewRequest An object holding information about last search query.
     * @param callback                 The callback called upon a success or error response.
     */
    public void submitRecordArticleView(Long articleId,
                                        final Locale locale,
                                        RecordArticleViewRequest recordArticleViewRequest,
                                        @Nullable final ZendeskCallback<Void> callback) {
        helpCenterService.submitRecordArticleView(articleId,
                localeConverter.toHelpCenterLocaleString(locale),
                recordArticleViewRequest)
                .enqueue(new RetrofitZendeskCallbackAdapter<Void, Void>(callback));
    }

}
