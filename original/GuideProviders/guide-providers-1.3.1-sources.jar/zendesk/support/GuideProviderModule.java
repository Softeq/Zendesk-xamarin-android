package zendesk.support;

import com.zendesk.sdk.guide.providers.BuildConfig;

import java.util.Locale;

import javax.inject.Singleton;

import zendesk.core.BlipsProvider;
import zendesk.core.RestServiceProvider;
import zendesk.core.SessionStorage;
import zendesk.core.SettingsProvider;
import zendesk.core.ZendeskLocaleConverter;

import dagger.Module;
import dagger.Provides;
import dagger.Reusable;

@Module
class GuideProviderModule {

    private HelpCenterTracker tracker;

    GuideProviderModule(HelpCenterTracker tracker) {
        this.tracker = tracker;
    }

    @Provides
    @Singleton
    Locale provideDeviceLocale() {
        return Locale.getDefault();
    }

    @Provides
    @Singleton
    HelpCenterSettingsProvider provideSettingsProvider(SettingsProvider sdkSettingsProvider,
                                                       ZendeskLocaleConverter localeConverter, Locale locale) {
        return new ZendeskHelpCenterSettingsProvider(sdkSettingsProvider, localeConverter, locale);
    }

    @Provides
    @Singleton
    static ZendeskHelpCenterService provideZendeskHelpCenterService(
            HelpCenterService helpCenterService,
            ZendeskLocaleConverter localeConverter) {
        return new ZendeskHelpCenterService(helpCenterService, localeConverter);
    }


    @Provides
    @Singleton
    static HelpCenterService providesHelpCenterService(RestServiceProvider restServiceProvider,
                                                       HelpCenterCachingNetworkConfig helpCenterCachingNetworkConfig) {
        return restServiceProvider.createRestService(HelpCenterService.class,
                BuildConfig.VERSION_NAME, GuideConstants.USER_AGENT_VARIANT, helpCenterCachingNetworkConfig);
    }

    @Provides
    @Reusable
    static HelpCenterCachingNetworkConfig provideCustomNetworkConfig(HelpCenterCachingInterceptor
                                                                             helpCenterCachingInterceptor) {
        return new HelpCenterCachingNetworkConfig(helpCenterCachingInterceptor);
    }

    @Provides
    @Reusable
    static HelpCenterCachingInterceptor provideHelpCenterCachingInterceptor() {
        return new HelpCenterCachingInterceptor();
    }

    @Provides
    @Singleton
    HelpCenterProvider provideHelpCenterProvider(HelpCenterSettingsProvider settingsProvider,
                                                 HelpCenterBlipsProvider blipsProvider,
                                                 ZendeskHelpCenterService helpCenterService,
                                                 HelpCenterSessionCache helpCenterSessionCache) {
        return new ZendeskHelpCenterProvider(settingsProvider, blipsProvider, helpCenterService,
                helpCenterSessionCache, tracker);
    }

    @Provides
    @Singleton
    HelpCenterBlipsProvider providesHelpCenterBlipsProvider(BlipsProvider blipsProvider, Locale locale) {
        return new ZendeskHelpCenterBlipsProvider(blipsProvider, locale);
    }

    @Provides
    @Singleton
    static ZendeskLocaleConverter provideZendeskLocaleConverter() {
        return new ZendeskLocaleConverter();
    }

    @Provides
    @Singleton
    static HelpCenterSessionCache provideHelpCenterSessionCache() {
        return new ZendeskHelpCenterSessionCache();
    }

    @Provides
    @Singleton
    static ArticleVoteStorage provideArticleVoteStorage(SessionStorage baseStorage) {
        return new ZendeskArticleVoteStorage(baseStorage.getAdditionalSdkStorage());
    }

    @Provides
    @Singleton
    GuideModule provideGuideModule(HelpCenterProvider helpCenterProvider, HelpCenterSettingsProvider settingsProvider,
                                   HelpCenterBlipsProvider blipsProvider, ArticleVoteStorage articleVoteStorage,
                                   RestServiceProvider restServiceProvider) {
        return new GuideModule(helpCenterProvider, settingsProvider, blipsProvider,
                tracker, articleVoteStorage, restServiceProvider.getMediaOkHttpClient());
    }

}
