package zendesk.support;

import androidx.annotation.NonNull;

interface HelpCenterSessionCache {

    /**
     * Get the last Help Center search query.
     *
     * @return The last Help Center query.
     */
    @NonNull
    LastSearch getLastSearch();

    /**
     * Store the last successful search meta data.
     *
     * @param query       The used query string.
     * @param resultCount The number of results.
     */
    void setLastSearch(String query, int resultCount);

    /**
     * Un-sets the unique search result click flag
     */
    void unsetUniqueSearchResultClick();

    /**
     * @return true if an article was the first viewed from a search result, false otherwise
     */
    boolean isUniqueSearchResultClick();
}
