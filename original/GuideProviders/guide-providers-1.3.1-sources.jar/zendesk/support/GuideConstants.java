package zendesk.support;

/**
 * Constants required for network operations
 */
interface GuideConstants {

    /**
     * Header name for the custom Help Center cache control header.
     */
    String CUSTOM_HC_CACHING_HEADER = "X-ZD-Cache-Control";

    /**
     * Header name for the standard cache control header.
     */
    String STANDARD_CACHING_HEADER = "Cache-Control";

    /**
     * Header name for the standard cache control header.
     */
    String USER_AGENT_VARIANT = "Guide";

}
