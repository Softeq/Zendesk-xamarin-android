package zendesk.support;

import androidx.annotation.NonNull;

class ZendeskHelpCenterSessionCache implements HelpCenterSessionCache {

    public static final LastSearch DEFAULT_SEARCH = new LastSearch("", 0);

    private LastSearch lastSearch;

    private boolean uniqueSearchResultClick = false;

    @Override
    @NonNull
    public LastSearch getLastSearch() {
        return (lastSearch != null) ? lastSearch : DEFAULT_SEARCH;
    }

    /**
     * Store the last successful search meta data.
     * <p>
     * This method will also set the uniqueSearchResultClick to true.
     * </p>
     *
     * @param query       The used query string.
     * @param resultCount The number of results.
     */
    @Override
    public void setLastSearch(String query, int resultCount) {
        this.lastSearch = new LastSearch(query, resultCount);
        this.uniqueSearchResultClick = true;
    }

    @Override
    public void unsetUniqueSearchResultClick() {
        this.uniqueSearchResultClick = false;
    }

    @Override
    public boolean isUniqueSearchResultClick() {
        return uniqueSearchResultClick;
    }

}
