package zendesk.support;

import com.zendesk.service.ZendeskCallback;

import java.util.Locale;

/**
 * This class encapsulates the parameters for submitting information about the last search to Help Center.
 *
 * <p>
 * This class is what is used when reporting back to Help Center with a {@link HelpCenterProvider},
 * specifically with the {@link HelpCenterProvider#submitRecordArticleView(Article, Locale, ZendeskCallback)}
 * </p>
 */
@SuppressWarnings("unused")
class RecordArticleViewRequest {

    @SuppressWarnings("FieldCanBeLocal")
    private LastSearch lastSearch;

    @SuppressWarnings("FieldCanBeLocal")
    private boolean uniqueSearchResultClick;

    /**
     * Creates a RecordArticleViewRequest
     *
     * @param lastSearch              the last search object.
     * @param uniqueSearchResultClick the unique search result click flag
     */
    RecordArticleViewRequest(LastSearch lastSearch, boolean uniqueSearchResultClick) {
        this.lastSearch = lastSearch;
        this.uniqueSearchResultClick = uniqueSearchResultClick;
    }

}
