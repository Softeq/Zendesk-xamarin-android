package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.logger.Logger;
import com.zendesk.sdk.guide.providers.BuildConfig;
import com.zendesk.util.LocaleUtil;
import com.zendesk.util.StringUtils;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import zendesk.core.BlipsGroup;
import zendesk.core.BlipsProvider;
import zendesk.core.PageView;
import zendesk.core.UserAction;

class ZendeskHelpCenterBlipsProvider implements HelpCenterBlipsProvider {

    private static final String BLIPS_GUIDE_VERSION = BuildConfig.VERSION_NAME;
    private static final String BLIPS_GUIDE_CHANNEL = "guide_sdk";

    private static final String BLIPS_GUIDE_CATEGORY = "GuideSDK";

    private static final String BLIPS_GUIDE_ACTION_SEARCH = "search";
    private static final String BLIPS_GUIDE_ACTION_VOTE = "articleVote";

    private static final String BLIPS_GUIDE_LABEL_HELP_CENTER = "helpCenterForm";

    private static final String BLIPS_FIELD_NAME_QUERY = "query";
    private static final String BLIPS_FIELD_NAME_CODE = "code";
    private static final String BLIPS_FIELD_NAME_ARTICLE_ID = "articleId";
    private static final String BLIPS_FIELD_NAME_VOTE = "vote";

    private static final String BLIPS_FIELD_VALUE_CODE = "java";

    private BlipsProvider blipsProvider;
    private Locale locale;

    private static final String LOG_TAG = "HelpCenterBlipsProvider";

    ZendeskHelpCenterBlipsProvider(BlipsProvider blipsProvider, Locale locale) {
        this.blipsProvider = blipsProvider;
        this.locale = locale;
    }

    @Override
    public void helpCenterSearch(@NonNull String query) {
        if (!StringUtils.hasLength(query)) {
            return;
        }

        Map<String, Object> value = new HashMap<>();
        value.put(BLIPS_FIELD_NAME_QUERY, query);
        value.put(BLIPS_FIELD_NAME_CODE, BLIPS_FIELD_VALUE_CODE);

        sendUserAction(BlipsGroup.PATHFINDER, BLIPS_GUIDE_ACTION_SEARCH,
                BLIPS_GUIDE_LABEL_HELP_CENTER, value);
    }

    @Override
    @SuppressWarnings("ConstantConditions")
    public void articleView(@NonNull Article article) {
        if (article == null) {
            Logger.d(LOG_TAG, "Aborting articleView blip: Article is null");
            return;
        }

        String url = article.getHtmlUrl();
        String pageTitle = article.getTitle();
        String pageLocale = article.getLocale();

        if (!StringUtils.hasLengthMany(url, pageTitle, pageLocale)) {
            Logger.d(LOG_TAG, "Cannot blip articleView: Article required fields are null");
            return;
        }

        Long pageId = article.getId();

        if (pageId == null) {
            Logger.d(LOG_TAG, "Cannot blip articleView: Id is null");
            return;
        }

        Map<String, Object> value = new HashMap<>();
        value.put(BLIPS_FIELD_NAME_CODE, BLIPS_FIELD_VALUE_CODE);

        blipsProvider.sendBlip(new PageView(BLIPS_GUIDE_VERSION,
                        BLIPS_GUIDE_CHANNEL,
                        url,
                        LocaleUtil.toLanguageTag(locale),
                        pageTitle,
                        pageId,
                        pageLocale,
                        value),
                BlipsGroup.PATHFINDER);
    }

    @Override
    public void articleVote(Long articleId, int vote) {
        if (articleId == null) {
            return;
        }

        Map<String, Object> value = new HashMap<>();
        value.put(BLIPS_FIELD_NAME_ARTICLE_ID, articleId);
        value.put(BLIPS_FIELD_NAME_VOTE, vote);

        sendUserAction(BlipsGroup.BEHAVIOURAL, BLIPS_GUIDE_ACTION_VOTE, null, value);
    }

    private void sendUserAction(@NonNull BlipsGroup group, @NonNull String action,
                                @Nullable String label, @Nullable Map<String, Object> value) {
        blipsProvider.sendBlip(new UserAction(
                BLIPS_GUIDE_VERSION,
                BLIPS_GUIDE_CHANNEL,
                BLIPS_GUIDE_CATEGORY,
                action,
                label,
                value
        ), group);
    }

}
