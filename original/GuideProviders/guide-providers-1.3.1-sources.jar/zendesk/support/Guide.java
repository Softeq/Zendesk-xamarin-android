package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.VisibleForTesting;

import com.zendesk.logger.Logger;

import java.util.Locale;

import javax.inject.Inject;

import zendesk.core.CoreModule;
import zendesk.core.Zendesk;

public enum Guide {
    INSTANCE;

    private static final String LOG_TAG = "Guide";

    @Inject
    GuideModule guideModule;

    @Inject
    HelpCenterBlipsProvider blipsProvider;

    private Locale helpCenterLocaleOverride;
    private HelpCenterTracker helpCenterTracker;
    private boolean initialized;

    /**
     * Initialises the Guide SDK
     *
     * <p>
     * A lazy loading strategy is applied to all Provider calls to ensure that settings
     * are always present before a call to Zendesk.
     * </p>
     *
     * @param zendesk The instance of zendesk to initialize Guide with
     */
    @SuppressWarnings("SameParameterValue")
    public void init(@NonNull Zendesk zendesk) {

        if (helpCenterTracker == null) {
            helpCenterTracker = new HelpCenterTracker.DefaultTracker();
        }

        if (zendesk.isInitialized()) {
            initApplicationScope(zendesk.coreModule());
            initialized = true;
        } else {
            Logger.e(LOG_TAG, "Cannot use Guide SDK without initializing Zendesk. "
                    + "Call Zendesk.INSTANCE.init(...)");
        }
    }

    void initApplicationScope(CoreModule coreModule) {
        DaggerGuideSdkProvidersComponent
                .builder()
                .coreModule(coreModule)
                .guideProviderModule(new GuideProviderModule(helpCenterTracker))
                .build()
                .inject(this);
    }

    /**
     * Gets whether {@link #init(Zendesk)} was called or not.
     *
     * @return true if init was successfully called, false otherwise.
     */
    public boolean isInitialized() {
        return initialized;
    }

    /**
     * Set a locale override for Help Center content. By default, Help Center content will be
     * requested in the locale of the device. Use this method to force a specific locale to be used
     * when requesting Help Center content.
     *
     * <p>
     * Note that if you set a locale that is not supported on your Help Center, you will not
     * receive any content.
     * </p>
     *
     * @param locale the locale to force in all requests to Help Center.
     */
    public void setHelpCenterLocaleOverride(Locale locale) {
        helpCenterLocaleOverride = locale;

        initApplicationScope(Zendesk.INSTANCE.coreModule());
    }

    /**
     * Returns the override, if any, for the locale to be used in Help Center requests. If no
     * override has been set, the device locale will be used.
     *
     * @return the locale override, or null if no override has been set.
     */
    @Nullable
    public Locale getHelpCenterLocaleOverride() {
        return helpCenterLocaleOverride;
    }

    @Nullable
    public HelpCenterProvider provider() {
        if (!isInitialized()) {
            Logger.e(LOG_TAG, "Cannot get HelpCenterProvider before SDK has been initialized. init() must be " +
                    "called before provider().");
            return null;
        }

        return guideModule.providesHelpCenterProvider();
    }

    /**
     * Installs a tracker. Intentionally package-private
     *
     * @param tracker The tracker to install
     */
    void installTracker(HelpCenterTracker tracker) {
        helpCenterTracker = tracker;

        initApplicationScope(Zendesk.INSTANCE.coreModule());
    }

    /**
     * Not public intentionally. This method allows us to teardown the object and must only
     * be used for testing. If you make this public this kitten will die. Do you want that on
     * your conscience?
     * 　 ／l、
     * ﾞ（ﾟ､ ｡ ７
     * 　l、ﾞ ~ヽ
     * 　じしf_, )ノ
     */
    @VisibleForTesting
    void reset() {
        helpCenterTracker = null;
        helpCenterLocaleOverride = null;
        initialized = false;
    }

    public GuideModule guideModule() {
        return guideModule;
    }

}
