package zendesk.support;

import androidx.annotation.Nullable;

/**
 * This is a class model for a response for an Category. This object will be created by
 * {@link zendesk.support.HelpCenterService}
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/categories#show-category">Show Category API
 * documentation</a>
 */
@SuppressWarnings({"unused"})
class CategoryResponse {

    private Category category;

    /**
     * Gets the category contained in this response
     *
     * @return the category contained in this response
     */
    @Nullable
    Category getCategory() {
        return category;
    }
}
