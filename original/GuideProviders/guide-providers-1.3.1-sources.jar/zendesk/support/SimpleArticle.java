package zendesk.support;

import com.zendesk.service.ZendeskCallback;

import java.io.Serializable;

/**
 * This is a model class for an simplified Article object that will be created by the
 * {@link HelpCenterProvider#getSuggestedArticles(SuggestedArticleSearch, ZendeskCallback)}.
 *
 * @see <a href ="https://developer.zendesk.com/rest_api/docs/help_center/articles">Articles</a>
 */
@SuppressWarnings("unused")
public class SimpleArticle implements Serializable {

    private Long id;
    private String title;

    /**
     * Initialise a {@link SimpleArticle}
     *
     * @param id    The article id
     * @param title The article title
     */
    public SimpleArticle(final Long id, final String title) {
        this.id = id;
        this.title = title;
    }

    /**
     * Get the id of an article.
     *
     * @return The article id.
     */
    public Long getId() {
        return id;
    }

    /**
     * Get the title of an article.
     *
     * @return The article title.
     */
    public String getTitle() {
        return title;
    }
}
