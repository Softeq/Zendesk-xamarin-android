package zendesk.support;

import com.zendesk.util.StringUtils;

import java.util.Locale;

/**
 * This class models a search for suggested articles
 */
@SuppressWarnings("unused")
public class SuggestedArticleSearch {

    private String query;

    private Locale locale;

    private String labelNames;

    private Long categoryId;

    private Long sectionId;

    private SuggestedArticleSearch() {
        // Intentionally private and empty
    }

    /**
     * Returns the free-form text query.
     *
     * @return The query
     */
    public String getQuery() {
        return query;
    }

    /**
     * Returns the locale to search in.
     *
     * @return The locale to search in
     */
    public Locale getLocale() {
        return locale;
    }

    /**
     * Returns the label names to specify.
     *
     * @return The label names to specify
     */
    public String getLabelNames() {
        return labelNames;
    }

    /**
     * Returns the category ID to specify
     *
     * @return The category ID to specify
     */
    public Long getCategoryId() {
        return categoryId;
    }

    /**
     * Returns the section ID to specify
     *
     * @return The section ID to specify
     */
    public Long getSectionId() {
        return sectionId;
    }

    /**
     * This is a builder class which is used to generate a {@link SuggestedArticleSearch}
     */
    public static class Builder {

        private String query;
        private Locale locale;
        private String[] labelNames;
        private Long categoryId;
        private Long sectionId;

        public Builder() {
            // Intentionally empty
        }

        /**
         * Specifies the free-form query to perform.
         *
         * @param query The free-form query to perform
         * @return The Builder
         */
        public Builder withQuery(String query) {
            this.query = query;
            return this;
        }

        /**
         * Specifies the locale to perform the search in. Note that this must be a supported locale
         * by your Help Center instance
         *
         * @param locale The locale to search in
         * @return The Builder
         */
        public Builder forLocale(Locale locale) {
            this.locale = locale;
            return this;
        }

        /**
         * Specifies the label names to restrict the results to. Note that ALL label names must
         * match for an article to be includes in the search results.
         *
         * @param labelNames The label names to restrict the results to
         * @return The builder
         */
        public Builder withLabelNames(String... labelNames) {
            this.labelNames = labelNames;
            return this;
        }

        /**
         * Specifies the category id to restrict the results to.
         *
         * @param categoryId The category id to restrict the results to
         * @return The builder
         */
        public Builder withCategoryId(Long categoryId) {
            this.categoryId = categoryId;
            return this;
        }

        /**
         * Specifies the section id to restrict the results to.
         *
         * @param sectionId The section id to restrict the results to
         * @return The builder
         */
        public Builder withSectionId(Long sectionId) {
            this.sectionId = sectionId;
            return this;
        }


        /**
         * Builds a {@link HelpCenterSearch} object with the
         * specified parameters.
         *
         * @return the {@link HelpCenterSearch}
         */
        public SuggestedArticleSearch build() {
            final SuggestedArticleSearch suggestedArticleSearch = new SuggestedArticleSearch();

            suggestedArticleSearch.query = this.query;
            suggestedArticleSearch.locale = this.locale;
            suggestedArticleSearch.labelNames = StringUtils.toCsvString(this.labelNames);
            suggestedArticleSearch.categoryId = this.categoryId;
            suggestedArticleSearch.sectionId = this.sectionId;

            return suggestedArticleSearch;
        }
    }
}
