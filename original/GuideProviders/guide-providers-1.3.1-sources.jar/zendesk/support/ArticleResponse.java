package zendesk.support;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.zendesk.util.CollectionUtils;

import java.util.List;

import zendesk.core.User;

/**
 * This is a class model for a response for an Article. This object will be created by
 * {@link HelpCenterService}
 *
 * @see <a href="https://developer.zendesk.com/rest_api/docs/help_center/articles#show-article">Show Article API
 * documentation</a>
 */
@SuppressWarnings({"unused"})
class ArticleResponse {

    private Article article;
    private List<User> users;

    /**
     * Gets the article contained in this response
     *
     * @return the article
     */
    @Nullable
    Article getArticle() {
        return article;
    }

    /**
     * Gets a list of the {@link User} returned as a result of the possible side load which can be
     * included as part of getting articles from the network.
     *
     * @return The list of users. This will be an empty list if there were no users, either as a
     * result of not being side loaded or no user is found. The list returned is a copy.
     */
    @NonNull
    List<User> getUsers() {
        return CollectionUtils.copyOf(users);
    }
}
