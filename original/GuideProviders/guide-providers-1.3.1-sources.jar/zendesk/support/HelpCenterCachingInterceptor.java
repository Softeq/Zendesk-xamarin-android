package zendesk.support;

import com.zendesk.util.StringUtils;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Response;


class HelpCenterCachingInterceptor implements Interceptor {

    @Override
    public Response intercept(Chain chain) throws IOException {
        Response response = chain.proceed(chain.request());

        if (StringUtils.hasLength(response.headers().get(GuideConstants.CUSTOM_HC_CACHING_HEADER))) {
            return response.newBuilder()
                    .header(GuideConstants.STANDARD_CACHING_HEADER,
                            response.header(GuideConstants.CUSTOM_HC_CACHING_HEADER))
                    .build();
        } else {
            return response;
        }
    }
}
