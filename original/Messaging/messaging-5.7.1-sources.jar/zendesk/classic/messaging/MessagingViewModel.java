package zendesk.classic.messaging;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import java.util.List;

import javax.inject.Inject;

import zendesk.classic.messaging.ui.MessagingState;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Holds and updates {@link MessagingState} based on incoming state {@link Update}s.
 * <br>
 * Delegates translated UI events to {@link MessagingModel}.
 */

@RestrictTo(LIBRARY)
@MessagingScope
public class MessagingViewModel extends ViewModel implements EventListener {

    private final MessagingModel messagingModel;
    private final MediatorLiveData<MessagingState> liveMessagingState;
    private final LiveData<Update.Action.Navigation> liveNavigationStream;
    private final MediatorLiveData<DialogContent> liveDialogState;
    private final MediatorLiveData<Banner> liveBannersState;

    private final MutableLiveData<Integer> counterLiveData;


    @Inject
    @SuppressWarnings("ConstantConditions")
    MessagingViewModel(@NonNull final MessagingModel messagingModel) {
        this.messagingModel = messagingModel;
        this.liveMessagingState = new MediatorLiveData<>();
        this.liveNavigationStream = messagingModel.getLiveNavigationUpdates();
        this.liveMessagingState.setValue(new MessagingState.Builder().withEnabled(true).build());
        this.liveBannersState = new MediatorLiveData<>();
        this.liveDialogState = new MediatorLiveData<>();
        this.counterLiveData = new MutableLiveData<>();

        liveMessagingState.addSource(messagingModel.getLiveMessagingItems(),
                new Observer<List<MessagingItem>>() {
                    @Override
                    public void onChanged(@Nullable List<MessagingItem> messagingItems) {
                        final MessagingState newState = liveMessagingState.getValue()
                                .newBuilder()
                                .withMessagingItems(messagingItems)
                                .build();
                        liveMessagingState.setValue(newState);
                    }
                });

        liveMessagingState.addSource(messagingModel.getLiveComposerEnabled(),
                new Observer<Boolean>() {
                    @Override
                    public void onChanged(@Nullable Boolean enabled) {
                        final MessagingState newState = liveMessagingState.getValue()
                                .newBuilder()
                                .withEnabled(enabled)
                                .build();
                        liveMessagingState.setValue(newState);
                    }
                });

        liveMessagingState.addSource(messagingModel.getLiveTyping(), new Observer<Typing>() {
            @Override
            public void onChanged(@Nullable Typing typing) {
                final MessagingState newState = liveMessagingState.getValue()
                        .newBuilder()
                        .withTypingIndicatorState(new MessagingState.TypingState(
                                typing.isTyping(),
                                typing.getAgentDetails()))
                        .build();
                liveMessagingState.setValue(newState);
            }
        });

        liveMessagingState.addSource(messagingModel.getLiveConnection(),
                new Observer<ConnectionState>() {
                    @Override
                    public void onChanged(@Nullable ConnectionState connectionState) {
                        final MessagingState newState = liveMessagingState.getValue()
                                .newBuilder()
                                .withConnectionState(connectionState)
                                .build();
                        liveMessagingState.setValue(newState);
                    }
                });

        liveMessagingState.addSource(messagingModel.getLiveComposerHint(),
                new Observer<String>() {
                    @Override
                    public void onChanged(@Nullable String hint) {
                        final MessagingState newState = liveMessagingState.getValue()
                                .newBuilder()
                                .withComposerHint(hint)
                                .build();
                        liveMessagingState.setValue(newState);
                    }
                });

        liveMessagingState.addSource(messagingModel.getLiveKeyboardInputType(),
                new Observer<Integer>() {
                    @Override
                    public void onChanged(@Nullable Integer inputType) {
                        final MessagingState newState = liveMessagingState.getValue()
                                .newBuilder()
                                .withKeyboardInputType(inputType)
                                .build();
                        liveMessagingState.setValue(newState);
                    }
                });

        liveMessagingState.addSource(messagingModel.getLiveAttachmentSettings(),
                new Observer<AttachmentSettings>() {
                    @Override
                    public void onChanged(@Nullable AttachmentSettings attachmentSettings) {
                        final MessagingState newState = liveMessagingState.getValue()
                                .newBuilder()
                                .withAttachmentSettings(attachmentSettings)
                                .build();
                        liveMessagingState.setValue(newState);
                    }
                });

        liveBannersState.addSource(messagingModel.getLiveInterfaceUpdates(), new Observer<Banner>() {
            @Override
            public void onChanged(@Nullable Banner banner) {
                liveBannersState.setValue(banner);
            }
        });
    }

    /**
     * Starts the conversation.
     */
    void start() {
        this.messagingModel.start();
    }

    @NonNull
    public LiveData<MessagingState> getLiveMessagingState() {
        return liveMessagingState;
    }

    @NonNull
    LiveData<Update.Action.Navigation> getLiveNavigationStream() {
        return liveNavigationStream;
    }

    @NonNull
    LiveData<List<MenuItem>> getLiveMenuItems() {
        return messagingModel.getLiveMenuItems();
    }

    @NonNull
    SingleLiveEvent<DialogContent> getDialogUpdates() {
        return messagingModel.getLiveDialogUpdates();
    }

    @NonNull
    SingleLiveEvent<Banner> getLiveInterfaceUpdateItems() {
        return messagingModel.getLiveInterfaceUpdates();
    }

    @Override
    protected void onCleared() {
        messagingModel.stop();
    }

    @Override
    public void onEvent(@NonNull Event event) {
        messagingModel.onEvent(event);
    }

    public LiveData<Integer> getCounterLiveData() {
        return counterLiveData;
    }

    public void setCounterValue(int value) {
        counterLiveData.setValue(value);
    }
}
