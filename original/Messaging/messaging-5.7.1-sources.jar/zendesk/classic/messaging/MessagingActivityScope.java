package zendesk.classic.messaging;

import androidx.annotation.RestrictTo;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import javax.inject.Scope;

@Scope
@Retention(RetentionPolicy.RUNTIME)
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public @interface MessagingActivityScope {
    String QUICK_REPLY_WRAPPING_ENABLED = "Quick reply wrapping enabled";

}
