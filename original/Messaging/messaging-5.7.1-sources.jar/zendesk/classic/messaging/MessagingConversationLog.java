package zendesk.classic.messaging;

import androidx.annotation.NonNull;

import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.inject.Inject;

/**
 * Implementation of {@link ConversationLog} to provide a log of a Messaging SDK conversation
 */
@MessagingScope
class MessagingConversationLog implements ConversationLog {

    private static final Comparator<MessagingEvent> TIMESTAMP_COMPARATOR = new Comparator<MessagingEvent>() {
        @Override
        public int compare(MessagingEvent o1, MessagingEvent o2) {
            return o1.getTimestamp().compareTo(o2.getTimestamp());
        }
    };

    private final MessagingEventSerializer messagingEventSerializer;

    private final List<MessagingItem> messagingItems;
    private final List<Event> events;

    @Inject
    MessagingConversationLog(MessagingEventSerializer messagingEventSerializer) {
        this.messagingEventSerializer = messagingEventSerializer;
        messagingItems = new ArrayList<>();
        events = new ArrayList<>();
    }

    void setMessagingItems(List<MessagingItem> messagingItems) {
        this.messagingItems.clear();
        if (CollectionUtils.isNotEmpty(messagingItems)) {
            this.messagingItems.addAll(messagingItems);
        }
    }

    void addEvent(Event event) {
        events.add(event);
    }

    @NonNull
    @Override
    public String getLog() {

        List<MessagingEvent> messagingEvents = new ArrayList<>(messagingItems.size() + events.size());

        messagingEvents.addAll(messagingItems);
        messagingEvents.addAll(events);

        if (CollectionUtils.isEmpty(messagingEvents)) {
            return StringUtils.EMPTY_STRING;
        }

        Collections.sort(messagingEvents, TIMESTAMP_COMPARATOR);

        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < messagingEvents.size(); i++) {
            MessagingEvent messagingEvent = messagingEvents.get(i);
            String eventString = messagingEventSerializer.serialize(messagingEvent);
            if (StringUtils.hasLength(eventString)) {
                stringBuilder.append(eventString);
                // Append new line character if this is not the last one
                if (i < messagingEvents.size() - 1) {
                    stringBuilder.append("\n");
                }
            }
        }

        return stringBuilder.toString();
    }
}
