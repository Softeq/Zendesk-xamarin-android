package zendesk.classic.messaging;

import android.os.Handler;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;

import java.util.concurrent.TimeUnit;

import javax.inject.Inject;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * Dispatches a sequence of {@link Event.TypingStarted} and {@link Event.TypingStopped}
 * events based on the frequency of calls to {@link this#onTyping()}.
 */
@RestrictTo(LIBRARY_GROUP)
@MessagingActivityScope
public class TypingEventDispatcher {

    /**
     * A minimum delay between {@link Event.TypingStarted} and {@link Event.TypingStopped}.
     */
    @VisibleForTesting
    static final long TYPING_WINDOW = TimeUnit.SECONDS.toMillis(3);

    private final EventListener eventListener;
    private final Handler handler;
    private final EventFactory eventFactory;

    @VisibleForTesting
    final Runnable typingStopRunnable;
    @VisibleForTesting
    boolean isTyping;

    @Inject
    public TypingEventDispatcher(@NonNull final EventListener eventListener,
                                 @NonNull final Handler handler,
                                 @NonNull final EventFactory eventFactory) {
        this.eventListener = eventListener;
        this.handler = handler;
        this.eventFactory = eventFactory;
        this.typingStopRunnable = new Runnable() {
            @Override
            public void run() {
                eventListener.onEvent(eventFactory.typingStop());
                isTyping = false;
            }
        };
        this.isTyping = false;
    }

    /**
     * Dispatches {@link Event.TypingStarted} immediately when called for the first time
     * and schedules {@link Event.TypingStopped} to be dispatched after a few seconds.
     * <p>
     * When called again within a short time period, resets scheduled dispatch back to the initial timeout.
     */
    public void onTyping() {
        if (isTyping) {
            handler.removeCallbacks(typingStopRunnable);
            handler.postDelayed(typingStopRunnable, TYPING_WINDOW);
        } else {
            isTyping = true;
            eventListener.onEvent(eventFactory.typingStart());
            handler.postDelayed(typingStopRunnable, TYPING_WINDOW);
        }
    }
}
