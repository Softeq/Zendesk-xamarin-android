package zendesk.classic.messaging;

import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

@RestrictTo(LIBRARY_GROUP)
public class Typing {

    private final boolean isTyping;
    @Nullable
    private final AgentDetails agentDetails;

    public Typing(boolean isTyping) {
        this(isTyping, null);
    }

    public Typing(boolean isTyping, @Nullable AgentDetails agentDetails) {
        this.isTyping = isTyping;
        this.agentDetails = agentDetails;
    }

    public boolean isTyping() {
        return isTyping;
    }

    @Nullable
    public AgentDetails getAgentDetails() {
        return agentDetails;
    }
}
