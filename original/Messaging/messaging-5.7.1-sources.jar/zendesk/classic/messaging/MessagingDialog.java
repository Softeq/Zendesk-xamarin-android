package zendesk.classic.messaging;

import android.app.Dialog;
import androidx.lifecycle.Observer;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import javax.inject.Inject;

import zendesk.classic.messaging.components.DateProvider;

/**
 * Class to create and show a customisable dialog for the Messaging SDK
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
@MessagingActivityScope
class MessagingDialog implements Observer<DialogContent> {

    private final AppCompatActivity appCompatActivity;
    private final MessagingViewModel messagingViewModel;
    private final DateProvider dateProvider;

    @Inject
    public MessagingDialog(AppCompatActivity appCompatActivity,
                           MessagingViewModel messagingViewModel,
                           DateProvider dateProvider) {
        this.appCompatActivity = appCompatActivity;
        this.messagingViewModel = messagingViewModel;
        this.dateProvider = dateProvider;
    }

    @Override
    public void onChanged(@Nullable final DialogContent dialogContent) {
        if (dialogContent != null) {
            final Dialog dialog = new Dialog(appCompatActivity);
            dialog.setContentView(R.layout.zui_messaging_dialog);

            TextView dialogTitle = dialog.findViewById(R.id.zui_dialog_title);
            TextView dialogMessage = dialog.findViewById(R.id.zui_dialog_message);
            Button dialogPositiveButton = dialog.findViewById(R.id.zui_dialog_positive_button);
            Button dialogNegativeButton = dialog.findViewById(R.id.zui_dialog_negative_button);
            final TextInputEditText editTextField = dialog.findViewById(R.id.zui_dialog_input);
            final TextInputLayout textInputLayout = dialog.findViewById(R.id.zui_dialog_input_layout);


            dialogNegativeButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                    Event.DialogItemClicked dialogItemClicked =
                            new Event.DialogItemClicked.Builder(dateProvider.now(),
                                    dialogContent.getConfig(),
                                    false).build();
                    messagingViewModel.onEvent(dialogItemClicked);
                }
            });


            dialog.setTitle(dialogContent.getTitle());

            dialogMessage.setText(dialogContent.getMessage());
            dialogTitle.setText(dialogContent.getTitle());
            dialogNegativeButton.setText(R.string.zui_button_label_no);
            dialogPositiveButton.setText(R.string.zui_button_label_yes);

            switch (dialogContent.getConfig()) {

                case TRANSCRIPT_PROMPT:
                    dialogPositiveButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Event.DialogItemClicked dialogItemClicked =
                                    new Event.DialogItemClicked.Builder(dateProvider.now(),
                                            dialogContent.getConfig(),
                                            true).build();
                            messagingViewModel.onEvent(dialogItemClicked);
                            dialog.dismiss();
                        }
                    });
                    break;

                case TRANSCRIPT_EMAIL:
                    textInputLayout.setVisibility(View.VISIBLE);
                    dialogNegativeButton.setText(android.R.string.cancel);
                    dialogPositiveButton.setText(R.string.zui_label_send);
                    textInputLayout.setHint(appCompatActivity.getString(R.string.zui_dialog_email_hint));
                    dialogPositiveButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Editable email = editTextField.getText();
                            if (email != null
                                    && Patterns.EMAIL_ADDRESS.matcher(email.toString()).matches()) {

                                Event.DialogItemClicked dialogItemClicked =
                                        new Event.DialogItemClicked.Builder(dateProvider.now(),
                                                dialogContent.getConfig(),
                                                true)
                                                .setPayload(editTextField.getText().toString())
                                                .setPreviousConfig(dialogContent.previousConfig())
                                                .build();

                                messagingViewModel.onEvent(dialogItemClicked);
                                dialog.dismiss();

                            } else {
                                String error = appCompatActivity.getString(R.string.zui_dialog_email_error);
                                textInputLayout.setError(error);
                            }
                        }
                    });

                    break;
                default:
                    break;
            }

            dialog.show();
        }
    }
}
