package zendesk.classic.messaging;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import android.content.res.Resources;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import android.text.InputType;

import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import zendesk.configurations.Configuration;

import static zendesk.classic.messaging.Update.State.UpdateInputFieldState.updateInputFieldEnabled;

/**
 * Routes an incoming {@link Event}s to the {@link Engine}
 * and fan-outs a stream of {@link Update}s from the {@link Engine}.
 */
@MessagingScope
class MessagingModel implements MessagingApi, EventListener, Engine.UpdateObserver {

    private static final long DEFAULT_ATTACHMENT_SIZE = 0L;
    private static final boolean DEFAULT_ATTACHMENTS_ENABLED = false;
    private static final String DEFAULT_COMPOSER_HINT = StringUtils.EMPTY_STRING;
    private static final AttachmentSettings DEFAULT_ATTACHMENT_SETTINGS =
            new AttachmentSettings(DEFAULT_ATTACHMENT_SIZE, DEFAULT_ATTACHMENTS_ENABLED);
    private static final Update DEFAULT_INPUT_STATE_UPDATE =
            new Update.State.UpdateInputFieldState(DEFAULT_COMPOSER_HINT, true,
                    DEFAULT_ATTACHMENT_SETTINGS, (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE));
    private static final Update DEFAULT_MENU_ITEMS = new Update.ApplyMenuItems();

    @Nullable
    private Engine currentEngine;
    private final List<Engine> engines;
    private final Map<Engine, List<MessagingItem>> engineItems;
    private final MessagingConversationLog conversationLog;
    private final AgentDetails defaultAgentDetails;
    private final MutableLiveData<List<MessagingItem>> liveMessagingItems;
    private final MutableLiveData<List<MenuItem>> liveMenuItems;
    private final MutableLiveData<Typing> liveTyping;
    private final MutableLiveData<ConnectionState> liveConnection;
    private final MutableLiveData<String> liveComposerHint;
    private final MutableLiveData<Boolean> liveComposerEnabled;
    private final MutableLiveData<Integer> liveKeyboardInputType;
    private final MutableLiveData<AttachmentSettings> liveAttachmentSettings;
    private final SingleLiveEvent<Update.Action.Navigation> liveNavigationUpdates;
    private final SingleLiveEvent<Banner> liveInterfaceUpdates;
    private final SingleLiveEvent<DialogContent> liveDialogUpdates;
    private final List<Configuration> configurations;

    @Inject
    MessagingModel(@NonNull Resources resources,
                   @NonNull List<Engine> engines,
                   @NonNull MessagingConfiguration messagingConfiguration,
                   @NonNull MessagingConversationLog conversationLog) {
        // Filter out null engines
        this.engines = new ArrayList<>(engines.size());
        for (Engine engine : engines) {
            if (engine != null) {
                this.engines.add(engine);
            }
        }
        this.conversationLog = conversationLog;
        this.configurations = messagingConfiguration.getConfigurations();
        this.defaultAgentDetails = messagingConfiguration.getBotAgentDetails(resources);
        this.engineItems = new LinkedHashMap<>();
        this.liveMessagingItems = new MutableLiveData<>();
        this.liveMenuItems = new MutableLiveData<>();
        this.liveTyping = new MutableLiveData<>();
        this.liveConnection = new MutableLiveData<>();
        this.liveComposerHint = new MutableLiveData<>();
        this.liveKeyboardInputType = new MutableLiveData<>();
        this.liveComposerEnabled = new MutableLiveData<>();
        this.liveAttachmentSettings = new MutableLiveData<>();
        this.liveNavigationUpdates = new SingleLiveEvent<>();
        this.liveInterfaceUpdates = new SingleLiveEvent<>();
        this.liveDialogUpdates = new SingleLiveEvent<>();
    }

    @Override
    public void update(@NonNull Update update) {
        switch (update.getType()) {
            case Update.APPLY_MESSAGING_ITEMS: {
                final Update.State.ApplyMessagingItems itemsUpdate = (Update.State.ApplyMessagingItems) update;

                engineItems.put(currentEngine, itemsUpdate.getMessagingItems());

                final List<MessagingItem> combinedMessagingItems = new ArrayList<>();

                for (Map.Entry<Engine, List<MessagingItem>> entry : engineItems.entrySet()) {
                    for (MessagingItem messagingItem : entry.getValue()) {
                        if (messagingItem instanceof MessagingItem.TransferResponse) {
                            messagingItem = new MessagingItem.TransferResponse(
                                    messagingItem.getTimestamp(),
                                    messagingItem.getId(),
                                    ((MessagingItem.TransferResponse) messagingItem).getAgentDetails(),
                                    ((MessagingItem.TransferResponse) messagingItem).getMessage(),
                                    ((MessagingItem.TransferResponse) messagingItem).getEngineOptions(),
                                    currentEngine != null && entry.getKey().equals(currentEngine));
                        }
                        combinedMessagingItems.add(messagingItem);
                    }
                }

                liveMessagingItems.postValue(combinedMessagingItems);
                conversationLog.setMessagingItems(combinedMessagingItems);
                break;
            }

            case Update.APPLY_MENU_ITEMS: {
                final Update.State.ApplyMenuItems itemsUpdate = (Update.State.ApplyMenuItems) update;

                liveMenuItems.postValue(itemsUpdate.getMenuItems());
                break;
            }

            case Update.HIDE_TYPING: {
                liveTyping.postValue(new Typing(false));
                break;
            }

            case Update.SHOW_TYPING: {
                final Update.State.ShowTyping typing = (Update.State.ShowTyping) update;

                liveTyping.postValue(new Typing(true, typing.getAgentDetails()));

                break;
            }

            case Update.UPDATE_CONNECTION_STATE: {
                final Update.State.UpdateConnectionState updateConnectionState =
                        (Update.State.UpdateConnectionState) update;

                liveConnection.postValue(updateConnectionState.getConnectionState());

                break;
            }

            case Update.UPDATE_INPUT_FIELD_STATE: {
                final Update.State.UpdateInputFieldState updateInputFieldState =
                        (Update.State.UpdateInputFieldState) update;

                String hint = updateInputFieldState.getHint();
                if (hint != null) {
                    liveComposerHint.postValue(hint);
                }
                Boolean enabled = updateInputFieldState.isEnabled();
                if (enabled != null) {
                    liveComposerEnabled.postValue(enabled);
                }
                AttachmentSettings attachmentSettings = updateInputFieldState.getAttachmentSettings();
                if (attachmentSettings != null) {
                    liveAttachmentSettings.postValue(attachmentSettings);
                }
                Integer inputType = updateInputFieldState.getInputType();
                if (inputType != null) {
                    liveKeyboardInputType.postValue(inputType);
                } else {
                    liveKeyboardInputType.postValue((InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE));
                }
                break;
            }

            case Update.NAVIGATION: {
                final Update.Action.Navigation navigationUpdate = (Update.Action.Navigation) update;

                liveNavigationUpdates.postValue(navigationUpdate);

                break;
            }

            case Update.SHOW_BANNER: {
                final Update.ShowBanner interfaceUpdate = (Update.ShowBanner) update;

                liveInterfaceUpdates.postValue(interfaceUpdate.getBanner());
                break;
            }

            case Update.SHOW_DIALOG: {
                final Update.ShowDialog dialogUpdate = (Update.ShowDialog) update;
                liveDialogUpdates.postValue(dialogUpdate.getDialogContent());
                break;
            }
        }
    }

    @Override
    public void onEvent(@NonNull Event event) {
        conversationLog.addEvent(event);
        if (event.getType().equals(Event.TRANSFER_OPTION_CLICKED)) {
            Event.EngineSelection engineSelection = (Event.EngineSelection) event;
            for (Engine engine : engines) {
                if (engineSelection.getSelectedEngine().getEngineId().equals(engine.getId())) {
                    startEngine(engine);
                    break;
                }
            }
        } else {
            if (currentEngine != null) {
                currentEngine.onEvent(event);
            }
        }
    }

    /**
     * Starts the conversation.
     */
    void start() {
        update(updateInputFieldEnabled(false));
        startInitialEngine(engines);
    }

    private void startEngine(@NonNull Engine engine) {
        if (currentEngine != null && currentEngine != engine) {
            stopEngine(currentEngine);
        }
        this.currentEngine = engine;
        currentEngine.registerObserver(this);
        update(DEFAULT_INPUT_STATE_UPDATE);
        update(DEFAULT_MENU_ITEMS);
        engine.start(this);
    }

    void stop() {
        if (currentEngine != null) {
            currentEngine.stop();
            currentEngine.unregisterObserver(this);
        }
    }

    private void stopEngine(@NonNull Engine engine) {
        engine.stop();
        engine.unregisterObserver(this);
    }

    @NonNull
    LiveData<List<MessagingItem>> getLiveMessagingItems() {
        return liveMessagingItems;
    }

    @NonNull
    LiveData<List<MenuItem>> getLiveMenuItems() {
        return liveMenuItems;
    }

    @NonNull
    LiveData<Typing> getLiveTyping() {
        return liveTyping;
    }

    @NonNull
    LiveData<ConnectionState> getLiveConnection() {
        return liveConnection;
    }

    @NonNull
    MutableLiveData<String> getLiveComposerHint() {
        return liveComposerHint;
    }

    @NonNull
    public MutableLiveData<Integer> getLiveKeyboardInputType() {
        return liveKeyboardInputType;
    }

    @NonNull
    MutableLiveData<Boolean> getLiveComposerEnabled() {
        return liveComposerEnabled;
    }

    @NonNull
    MutableLiveData<AttachmentSettings> getLiveAttachmentSettings() {
        return liveAttachmentSettings;
    }

    @NonNull
    SingleLiveEvent<Update.Action.Navigation> getLiveNavigationUpdates() {
        return liveNavigationUpdates;
    }

    @NonNull
    SingleLiveEvent<DialogContent> getLiveDialogUpdates() {
        return liveDialogUpdates;
    }

    @NonNull
    SingleLiveEvent<Banner> getLiveInterfaceUpdates() {
        return liveInterfaceUpdates;
    }

    @Override
    @NonNull
    public List<Engine.TransferOptionDescription> getTransferOptionDescriptions() {
        List<Engine.TransferOptionDescription> transferOptions = new ArrayList<>(engines.size());
        for (Engine engine : engines) {
            if (!engine.equals(currentEngine) && engine.getTransferOptionDescription() != null) {
                transferOptions.add(engine.getTransferOptionDescription());
            }
        }
        return transferOptions;
    }

    @NonNull
    @Override
    public ConversationLog getConversationLog() {
        return conversationLog;
    }

    @NonNull
    @Override
    public AgentDetails getBotAgentDetails() {
        return defaultAgentDetails;
    }

    @NonNull
    @Override
    public List<Configuration> getConfigurations() {
        return configurations;
    }

    /**
     * @param engines list of engines for which to find the initial engine and start it.
     *                Throws {@link NullPointerException} if any of these Engines are null
     */
    private void startInitialEngine(final List<Engine> engines) {
        if (CollectionUtils.isEmpty(engines)) {
            return;
        }

        if (engines.size() == 1) {
            startEngine(engines.get(0));
            return;
        }

        final List<Engine> enginesToRestore = new ArrayList<>();

        final ObservableCounter counter = new ObservableCounter(new ObservableCounter.OnCountCompletedListener() {
            @Override
            public void onCountCompleted() {
                if (CollectionUtils.isNotEmpty(enginesToRestore)) {
                    startEngine(enginesToRestore.get(0));
                } else {
                    startEngine(engines.get(0));
                }
            }
        });

        counter.increment(engines.size());

        for (Engine engine : engines) {
            engine.isConversationOngoing(new Engine.ConversationOnGoingCallback() {
                @Override
                public void onConversationOngoing(Engine engine, boolean isConversationOngoing) {
                    if (isConversationOngoing) {
                        enginesToRestore.add(engine);
                    }
                    counter.decrement();
                }
            });
        }
    }

}