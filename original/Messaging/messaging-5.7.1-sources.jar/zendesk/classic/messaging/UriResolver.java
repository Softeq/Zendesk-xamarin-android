package zendesk.classic.messaging;

import android.net.Uri;

import com.zendesk.logger.Logger;

import java.io.File;
import java.util.List;
import java.util.concurrent.ExecutorService;

import javax.inject.Inject;

import zendesk.core.Callback;
import zendesk.core.MediaFileResolver;

@MessagingActivityScope
public class UriResolver {

    private final MediaFileResolver mediaFileResolver;
    private final ExecutorService executorService;

    private static final String TAG = "UriTaskResolver";

    @Inject
    public UriResolver(MediaFileResolver mediaFileResolver, ExecutorService executorService) {
        this.mediaFileResolver = mediaFileResolver;
        this.executorService = executorService;
    }

    public void start(List<Uri> uris, Callback<List<File>> callback) {
        executorService.execute(() -> {
            List<File> files = mediaFileResolver.fetchFilesFromUris(uris);
            if (callback != null) {
                Logger.d(TAG, "Sending to callback success");
                callback.internalSuccess(files);
            }
        });
    }
}

