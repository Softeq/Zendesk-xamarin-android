package zendesk.classic.messaging;

import androidx.annotation.RestrictTo;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

import android.net.Uri;

/**
 * A helper class that stores (in memory) and exposes selected, to be
 * shared between components that interact with Belvedere to avoid unwanted side-effects of passing
 * a list reference.
 */
@RestrictTo(LIBRARY_GROUP)
@MessagingScope
public class MediaInMemoryDataSource {

    @Inject
    public MediaInMemoryDataSource() {
    }

    private final List<Uri> selectedUris = new ArrayList<>();

    public List<Uri> getSelectedUris() {
        return new ArrayList<>(selectedUris);
    }

    public Integer getCount() {
        return selectedUris.size();
    }

    public void addAll(List<Uri> uris) {
        selectedUris.addAll(0, new ArrayList<>(uris));
    }

    public void add(Uri uri) {
        selectedUris.add(uri);
    }

    public void removeAll(List<Uri> uris) {
        selectedUris.removeAll(new ArrayList<>(uris));
    }

    /**
     * Clears the internal collection.
     */
    public void clear() {
        selectedUris.clear();
    }

}
