package zendesk.classic.messaging;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.Observer;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.Picasso;
import com.zendesk.logger.Logger;
import com.zendesk.util.CollectionUtils;

import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;

import zendesk.classic.messaging.ui.InputBox;
import zendesk.classic.messaging.ui.MessagingCellFactory;
import zendesk.classic.messaging.ui.MessagingComposer;
import zendesk.classic.messaging.ui.MessagingState;
import zendesk.classic.messaging.ui.MessagingView;
import zendesk.commonui.BottomSheetAttachmentAction;
import zendesk.commonui.BottomSheetAttachmentViewMenu;
import zendesk.commonui.CacheFragment;
import zendesk.commonui.InsetType;
import zendesk.commonui.PermissionsHandler;
import zendesk.commonui.PhotoPickerLifecycleObserver;
import zendesk.commonui.PhotoPickerSelectionCallback;
import zendesk.commonui.SystemWindowInsets;
import zendesk.configurations.ConfigurationHelper;
import zendesk.core.MediaFileResolver;

/**
 * This Activity is for presenting the Messaging screen to the user.
 * <p>
 * MessagingActivity is designed to be started with the {@link #builder()}.
 * </p>
 */
@SuppressLint("MissingInflatedId")
public class MessagingActivity extends AppCompatActivity implements PhotoPickerSelectionCallback {

    private static final String LOG_TAG = "MessagingActivity";

    private static final String COMPONENT_KEY = "messaging_component";
    public static final String NO_ENGINES_ERROR_LOG = "No Engines found in MessagingConfiguration. " +
            "Please use MessagingActivity.builder()";

    private static final String[] INPUT_DOCUMENT_MIME_TYPES = new String[]{"*/*"};

    private static final int REQUEST_CAMERA_PERMISSION = 1001;

    private static final String INPUT_URI = "INPUT_URI";

    /**
     * Create a new configuration builder for the MessagingActivity.
     */
    public static MessagingConfiguration.Builder builder() {
        return new MessagingConfiguration.Builder();
    }

    private Uri inputUri;

    @Inject
    MessagingViewModel viewModel;

    @Inject
    MessagingCellFactory messagingCellFactory;

    @Inject
    Picasso picasso;

    @Inject
    EventFactory eventFactory;

    @Inject
    MessagingComposer messagingComposer;

    @Inject
    MessagingDialog messagingDialog;

    @Inject
    MediaInMemoryDataSource mediaHolder;

    @Inject
    MediaFileResolver mediaFileResolver;

    @Inject
    PermissionsHandler permissionsHandler;

    private MessagingView messagingView;

    private PhotoPickerLifecycleObserver photoPicker;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState != null) {
            inputUri = savedInstanceState.getParcelable(INPUT_URI);
        }

        getTheme().applyStyle(R.style.ZendeskActivityDefaultTheme, true);
        photoPicker = new PhotoPickerLifecycleObserver(
                this.getActivityResultRegistry(),
                this,
                () -> inputUri
        );
        getLifecycle().addObserver(photoPicker);

        // Load Config
        ConfigurationHelper configurationHelper = new ConfigurationHelper();
        @SuppressLint("RestrictedApi")
        final MessagingConfiguration messagingConfiguration =
                configurationHelper.fromBundle(getIntent().getExtras(), MessagingConfiguration.class);

        if (messagingConfiguration == null) {
            Logger.e(LOG_TAG, "No configuration found. Please use MessagingActivity.builder()");
            finish();
            return;
        }

        final CacheFragment from = CacheFragment.from(this);

        MessagingComponent component = from.get(COMPONENT_KEY);

        if (component == null) {
            List<Engine> engines = messagingConfiguration.getEngines();

            if (CollectionUtils.isEmpty(engines)) {
                Logger.e(LOG_TAG, NO_ENGINES_ERROR_LOG);
                finish();
                return;
            }

            component = DaggerMessagingComponent
                    .builder()
                    .appContext(this.getApplicationContext())
                    .engines(engines)
                    .messagingConfiguration(messagingConfiguration)
                    .build();

            component.messagingViewModel().start();

            from.put(COMPONENT_KEY, component);
        }

        DaggerMessagingActivityComponent
                .builder()
                .messagingComponent(component)
                .activity(this)
                .build()
                .inject(this);

        setContentView(R.layout.zui_activity_messaging);
        messagingView = findViewById(R.id.zui_view_messaging);
        Toolbar toolbar = findViewById(R.id.zui_toolbar);
        AppBarLayout appBarLayout = findViewById(R.id.appbar_messaging);
        SystemWindowInsets.applyWindowInsets(appBarLayout, InsetType.TOP, InsetType.HORIZONTAL);

        View recyclerLayout = messagingView.findViewById(R.id.zui_recycler_view_layout);
        SystemWindowInsets.applyWindowInsets(recyclerLayout, InsetType.TOP, InsetType.HORIZONTAL);

        setSupportActionBar(toolbar); // overrides Toolbar#setNavigationOnClickListener
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        toolbar.setTitle(messagingConfiguration.getToolbarTitle(getResources()));

        InputBox inputBox = findViewById(R.id.zui_input_box);
        SystemWindowInsets.applyWindowInsets(inputBox, InsetType.BOTTOM);

        viewModel.getCounterLiveData().observe(this, inputBox::setAttachmentsCount);

        messagingComposer.bind(inputBox, createBottomSheetAttachmentMenu());
    }

    private BottomSheetAttachmentViewMenu createBottomSheetAttachmentMenu() {
        return new BottomSheetAttachmentViewMenu(
                this,/*Context*/
                Arrays.asList(
                        getString(R.string.zui_label_camera_menu),
                        getString(R.string.zui_label_gallery_menu),
                        getString(R.string.zui_label_document_menu)
                ),
                createBottomSheetAttachmentActionCallback()
        );
    }

    private BottomSheetAttachmentAction createBottomSheetAttachmentActionCallback() {
        return new BottomSheetAttachmentAction() {
            @Override
            public void onTakePhotoClicked() {
                inputUri = mediaFileResolver.createUriToSaveTakenPicture();
                if (permissionsHandler.checkPermission(Manifest.permission.CAMERA)) {
                    photoPicker.takePicture(inputUri);
                } else {
                    permissionsHandler.requestPermission(Manifest.permission.CAMERA, REQUEST_CAMERA_PERMISSION);
                }
            }

            @Override
            public void onSelectMediaClicked() {
                photoPicker.selectMedia();
            }

            @Override
            public void onSelectDocumentClicked() {
                photoPicker.selectDocument(INPUT_DOCUMENT_MIME_TYPES);
            }
        };
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                photoPicker.takePicture(inputUri);
            } else {
                Snackbar.make(findViewById(R.id.zui_recycler_view), R.string.zui_camera_permission_denied, Snackbar.LENGTH_LONG)
                        .setAction(getString(R.string.zui_camera_permission_denied_settings), v -> {
                            Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                            Uri uri = Uri.fromParts("package", getPackageName(), null);
                            intent.setData(uri);
                            startActivity(intent);
                        })
                        .show();
            }
        }
    }

    @Override
    public void onMediaSelected(@NonNull List<Uri> uris) {
        for (Uri uri : uris) {
            mediaHolder.add(uri);
        }
        viewModel.setCounterValue(uris.size());
    }

    @Override
    public void onPhotoTaken(@NonNull Uri inputUriPhotoTaken) {
        mediaHolder.add(inputUriPhotoTaken);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (viewModel != null) {
            viewModel.getLiveMessagingState().observe(this, new Observer<MessagingState>() {
                @Override
                public void onChanged(@Nullable MessagingState messagingState) {
                    messagingView.renderState(messagingState, messagingCellFactory, picasso,
                            viewModel, eventFactory);
                }
            });
            viewModel.getLiveNavigationStream().observe(this, new Observer<Update.Action.Navigation>() {
                @Override
                public void onChanged(@Nullable Update.Action.Navigation navigation) {
                    if (navigation != null) {
                        navigation.navigate(MessagingActivity.this);
                    }
                }
            });

            viewModel.getLiveInterfaceUpdateItems().observe(
                    this,
                    new Observer<Banner>() {
                        @Override
                        public void onChanged(@Nullable Banner banner) {
                            if (banner != null && banner.getPosition() == Banner.Position.BOTTOM) {
                                Snackbar.make(
                                        findViewById(R.id.zui_recycler_view),
                                        banner.getLabel(),
                                        Snackbar.LENGTH_LONG
                                ).show();
                            }
                        }
                    });

            viewModel.getLiveMenuItems().observe(this, new Observer<List<MenuItem>>() {
                @Override
                public void onChanged(@Nullable List<MenuItem> menuItems) {
                    invalidateOptionsMenu();
                }
            });

            viewModel.getDialogUpdates().observe(this, messagingDialog);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (viewModel != null) {
            viewModel.onEvent(eventFactory.onActivityResult(requestCode, resultCode, data));
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        if (viewModel == null) {
            return false;
        }

        menu.clear();

        final List<MenuItem> menuItems = viewModel.getLiveMenuItems().getValue();

        if (CollectionUtils.isEmpty(menuItems)) {
            Logger.d(LOG_TAG, "Menu: no items, hiding...");
            return false;
        }

        for (MenuItem menuItem : menuItems) {
            menu.add(Menu.NONE, menuItem.getItemId(), Menu.NONE, menuItem.getLabelId());
        }

        Logger.d(LOG_TAG, "Menu: items updated.");

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull android.view.MenuItem item) {
        super.onOptionsItemSelected(item);
        viewModel.onEvent(eventFactory.menuItemClicked(item.getItemId()));
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (isChangingConfigurations()) {
            return;
        }

        if (viewModel != null) {
            Logger.d(LOG_TAG, "onDestroy() called, clearing...");
            viewModel.onCleared();
        }

        getLifecycle().removeObserver(photoPicker);
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putParcelable(INPUT_URI, inputUri);
        super.onSaveInstanceState(outState);
    }
}
