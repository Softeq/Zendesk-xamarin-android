package zendesk.classic.messaging;

import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import zendesk.classic.messaging.components.DateProvider;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

@RestrictTo(LIBRARY_GROUP)
@MessagingActivityScope
public class EventFactory {

    private final DateProvider dateProvider;

    @Inject
    public EventFactory(DateProvider dateProvider) {
        this.dateProvider = dateProvider;
    }

    @NonNull
    public Event textInput(String text) {
        return new Event.MessageSubmitted(text, dateProvider.now());
    }

    @NonNull
    public Event typingStart() {
        return new Event.TypingStarted(dateProvider.now());
    }

    @NonNull
    public Event typingStop() {
        return new Event.TypingStopped(dateProvider.now());
    }

    @NonNull
    public Event transferOptionClick(Engine.TransferOptionDescription selectedEngine) {
        return new Event.EngineSelection(selectedEngine, dateProvider.now());
    }

    @NonNull
    public Event actionOptionClick(MessagingItem.Action selectedAction) {
        return new Event.ActionOptionClicked(selectedAction, dateProvider.now());
    }

    @NonNull
    public Event articleSuggestionClick(
            MessagingItem.ArticlesResponse.ArticleSuggestion articleSuggestion) {
        return new Event.ArticleSuggestionClicked(articleSuggestion, dateProvider.now());
    }

    @NonNull
    public Event deleteQueryClick(MessagingItem.Query failedQuery) {
        return new Event.MessageDeleted(failedQuery, dateProvider.now());
    }

    @NonNull
    public Event retryQueryClick(MessagingItem.Query failedQuery) {
        return new Event.MessageResent(failedQuery, dateProvider.now());
    }

    @NonNull
    public Event copyQueryClick(MessagingItem.Query textQuery) {
        return new Event.CopyQueryClick(textQuery, dateProvider.now());
    }

    @NonNull
    public Event formOptionClick(
            MessagingItem.OptionsResponse optionsResponse,
            MessagingItem.Option clickedOption) {
        return new Event.ResponseOptionClicked(optionsResponse, clickedOption, dateProvider.now());
    }

    @NonNull
    public Event reconnectButtonClick() {
        return new Event.ReconnectButtonClicked(dateProvider.now());
    }

    /**
     * Creates an instance of {@link Event.FileSelected} with the given {@link File}s, dated of
     * the current time.
     *
     * @param attachments a list of {@link File}s being sent
     * @return the {@link Event} created
     */
    @NonNull
    public Event sendAttachment(@NonNull List<File> attachments) {
        return new Event.FileSelected(new ArrayList<>(attachments), dateProvider.now());
    }

    /**
     * Creates an instance of {@link Event.RetrySendAttachmentClick} with the given
     * {@link MessagingItem.FileQuery}, dated of the current time.
     *
     * @param failedFileQuery the {@link MessagingItem.FileQuery} being retried
     * @return the {@link Event} created
     */
    @NonNull
    public Event retrySendAttachmentClick(MessagingItem.FileQuery failedFileQuery) {
        return new Event.RetrySendAttachmentClick(failedFileQuery, dateProvider.now());
    }

    Event onActivityResult(int requestCode, int resultCode, Intent data) {
        return new Event.ActivityResult(requestCode, resultCode, data, dateProvider.now());
    }

    Event menuItemClicked(int menuItemId) {
        return new Event.MenuItemClicked(dateProvider.now(), menuItemId);
    }
}
