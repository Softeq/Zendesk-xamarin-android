package zendesk.classic.messaging;

import androidx.appcompat.app.AppCompatActivity;

import dagger.BindsInstance;
import dagger.Component;

@MessagingActivityScope
@Component(dependencies = MessagingComponent.class, modules = MessagingActivityModule.class)
interface MessagingActivityComponent {

    @Component.Builder
    interface Builder {

        @BindsInstance
        Builder activity(AppCompatActivity activity);

        Builder messagingComponent(MessagingComponent messagingComponent);

        MessagingActivityComponent build();
    }

    void inject(MessagingActivity messagingActivity);
}
