package zendesk.classic.messaging;

import android.content.Context;
import android.content.res.Resources;

import com.squareup.picasso.Picasso;

import java.util.List;

import dagger.BindsInstance;
import dagger.Component;
import zendesk.core.MediaFileResolver;

@MessagingScope
@Component(modules = MessagingModule.class)
public interface MessagingComponent {

    @Component.Builder
    interface Builder {

        @BindsInstance
        Builder appContext(Context appContext);

        @BindsInstance
        Builder engines(List<Engine> engines);

        @BindsInstance
        Builder messagingConfiguration(MessagingConfiguration messagingConfiguration);

        MessagingComponent build();
    }

    MessagingConfiguration messagingConfiguration();

    Picasso picasso();

    Resources resources();

    MessagingViewModel messagingViewModel();

    MediaInMemoryDataSource mediaInMemoryDataSource();

    MediaFileResolver mediaFileResolver();

}