package zendesk.classic.messaging;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Enum singleton used to keep lists of {@link Engine}s alive in memory. This is useful for handling
 * configuration changes, since {@link Engine} is not {@link java.io.Serializable}, and enforcing
 * "serializability" on Engine forces it onto another objects an Engine might use, which could be
 * considerable.
 * <p>
 * The typical use of this Registry is to hide the non-serializable nature of Engines. We often wish
 * to hold a reference to a list of Engines in a {@link zendesk.configurations.Configuration}, which
 * is serializable. To use it like this, call {@link #register(List)} to register the Engines with
 * the Registry when creating the Configuration, and then construct your Configuration with the
 * RegistryKey. Expose a getEngines() method on the Configuration class and internally to that call
 * {@link #retrieveEngineList(String)} to fetch the Engines from the registry.
 *
 * See {@link MessagingConfiguration} for an example of this usage.
 */
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public enum EngineListRegistry {

    INSTANCE;

    private final Map<String, List<Engine>> enginesRegistry = new HashMap<>();


    /**
     * Registers a list of Engines in to the Registry
     *
     * @param engines the Engines to register
     * @return the registry key with which to retrieve the Engines
     */
    public String register(@NonNull List<Engine> engines) {
        String registryKey = UUID.randomUUID().toString();
        enginesRegistry.put(registryKey, engines);
        return registryKey;
    }

    /**
     * Gets the list of Engines stored against the given key. Once retrieved, these will be removed from the
     * registry.
     *
     * @param registryKey the key for which to retrieve Engines
     * @return the Engines stored against the given registry key, or null if there is nothing stored against the key
     */
    @Nullable
    public List<Engine> retrieveEngineList(@NonNull String registryKey) {
        return enginesRegistry.remove(registryKey);
    }

}
