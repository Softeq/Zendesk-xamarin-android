package zendesk.classic.messaging;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.StringRes;

import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.inject.Inject;

@MessagingScope
class MessagingEventSerializer {

    @StringRes
    private static final int DEFAULT_VISITOR_NAME = R.string.zui_message_log_default_visitor_name;
    @StringRes
    private static final int ARTICLE_SUGGESTIONS_MESSAGE = R.string.zui_message_log_article_suggestion_message;
    @StringRes
    private static final int ARTICLE_OPENED_FORMATTER = R.string.zui_message_log_article_opened_formatter;
    @StringRes
    private static final int TRANSFER_OPTION_SELECTION_FORMATTER =
            R.string.zui_message_log_transfer_option_selection_formatter;
    @StringRes
    private static final int MESSAGE_FAILED_TO_SEND_WARNING = R.string.zui_message_log_message_failed_to_send;

    private static final String BOT_LABEL = " [bot]";
    private static final String NEW_LINE_CHARACTER = "\n";
    private static final String LIST_ITEM_SYMBOL = "\t* ";

    private final Context context;
    private final TimestampFactory timestampFactory;

    @Inject
    MessagingEventSerializer(Context context, TimestampFactory timestampFactory) {
        this.context = context;
        this.timestampFactory = timestampFactory;
    }

    @NonNull
    String serialize(MessagingEvent messagingEvent) {
        if (messagingEvent instanceof Event) {
            return serializeEvent((Event) messagingEvent);
        } else if (messagingEvent instanceof MessagingItem) {
            return serializeMessagingItem((MessagingItem) messagingEvent);
        } else {
            return StringUtils.EMPTY_STRING;
        }
    }


    @NonNull
    private String serializeMessagingItem(MessagingItem messagingItem) {
        if (messagingItem instanceof MessagingItem.Response) {
            return serializeResponse((MessagingItem.Response) messagingItem);
        } else if (messagingItem instanceof MessagingItem.Query) {
            return serializeEndUserQuery((MessagingItem.Query) messagingItem);
        } else {
            return StringUtils.EMPTY_STRING;
        }
    }

    @NonNull
    private String serializeEndUserQuery(MessagingItem.Query query) {
        if (query instanceof MessagingItem.TextQuery) {
            String queryContent = ((MessagingItem.TextQuery) query).getMessage();
            return formatQuery(query, queryContent);
        } else if (query instanceof MessagingItem.ImageQuery) {
            String queryContent = ((MessagingItem.ImageQuery) query).getRemotePath();
            return formatQuery(query, queryContent);
        } else if (query instanceof MessagingItem.FileQuery) {
            String queryContent = ((MessagingItem.FileQuery) query).getRemotePath();
            return formatQuery(query, queryContent);
        } else {
            return StringUtils.EMPTY_STRING;
        }
    }

    private String formatQuery(MessagingItem.Query query, String queryContent) {
        Date timestamp = query.getTimestamp();
        String visitorName = context.getString(DEFAULT_VISITOR_NAME);
        String failedIndicator = query.getStatus() == MessagingItem.Query.Status.FAILED
                ? context.getString(MESSAGE_FAILED_TO_SEND_WARNING) + " " : StringUtils.EMPTY_STRING;
        return String.format(Locale.US, "%s %s%s: %s",
                formatTimestamp(timestamp), failedIndicator, visitorName, queryContent);

    }

    @NonNull
    private String serializeResponse(MessagingItem.Response response) {
        if (response instanceof MessagingItem.TextResponse) {
            return serializeTextResponse((MessagingItem.TextResponse) response);
        } else if (response instanceof MessagingItem.ImageResponse) {
            return serializeImageResponse((MessagingItem.ImageResponse) response);
        } else if (response instanceof MessagingItem.FileResponse) {
            return serializeFileResponse((MessagingItem.FileResponse) response);
        } else if (response instanceof MessagingItem.ArticlesResponse) {
            return serializeArticleResponse((MessagingItem.ArticlesResponse) response);
        } else if (response instanceof MessagingItem.TransferResponse) {
            return serializeTransferOptionsResponse((MessagingItem.TransferResponse) response);
        }
        return StringUtils.EMPTY_STRING;
    }

    @NonNull
    private String serializeTextResponse(@NonNull MessagingItem.TextResponse textResponse) {
        return formatResponse(textResponse, textResponse.getMessage());
    }

    @NonNull
    private String serializeFileResponse(@NonNull MessagingItem.FileResponse fileResponse) {
        return formatResponse(fileResponse, fileResponse.getRemotePath());
    }

    @NonNull
    private String serializeImageResponse(@NonNull MessagingItem.ImageResponse imageResponse) {
        return formatResponse(imageResponse, imageResponse.getRemotePath());
    }

    @NonNull
    private String serializeArticleResponse(@NonNull MessagingItem.ArticlesResponse articlesResponse) {
        String message = context.getString(ARTICLE_SUGGESTIONS_MESSAGE);
        List<MessagingItem.ArticlesResponse.ArticleSuggestion> articleSuggestions =
                articlesResponse.getArticleSuggestions();
        List<String> options = new ArrayList<>(articleSuggestions.size());
        for (MessagingItem.ArticlesResponse.ArticleSuggestion suggestion : articleSuggestions) {
            options.add(suggestion.getArticleUrl());
        }

        return formatResponseWithOptions(articlesResponse, message, options);
    }

    @NonNull
    private String serializeTransferOptionsResponse(@NonNull MessagingItem.TransferResponse transferResponse) {
        String message = transferResponse.getMessage();
        List<Engine.TransferOptionDescription> engineOptions = transferResponse.getEngineOptions();
        List<String> options = new ArrayList<>(engineOptions.size());
        for (Engine.TransferOptionDescription description : engineOptions) {
            options.add(description.getDisplayName());
        }

        return formatResponseWithOptions(transferResponse, message, options);

    }

    @NonNull
    private String formatResponseWithOptions(
            MessagingItem.Response response, String message, List<String> options) {

        StringBuilder responseContent = new StringBuilder(message);

        for (String option : options) {
            responseContent.append(NEW_LINE_CHARACTER);
            responseContent.append(LIST_ITEM_SYMBOL);
            responseContent.append(option);
        }

        return formatResponse(response, responseContent.toString());
    }

    @NonNull
    private String formatResponse(MessagingItem.Response response, String responseContent) {
        Date timestamp = response.getTimestamp();
        String agentUserName = getAgentUserName(response.getAgentDetails());

        return String.format(Locale.US, "%s %s: %s", formatTimestamp(timestamp), agentUserName, responseContent);

    }

    @NonNull
    private String serializeEvent(Event messagingEvent) {
        if (messagingEvent instanceof Event.ArticleSuggestionClicked) {
            return serializeArticleSuggestionSelectionEvent((Event.ArticleSuggestionClicked) messagingEvent);
        } else if (messagingEvent instanceof Event.EngineSelection) {
            return serializeEngineSelectionEvent((Event.EngineSelection) messagingEvent);
        } else {
            return StringUtils.EMPTY_STRING;
        }
    }

    @NonNull
    private String serializeArticleSuggestionSelectionEvent(
            @NonNull Event.ArticleSuggestionClicked articleSuggestionClicked) {
        Date timestamp = articleSuggestionClicked.getTimestamp();
        String visitorName = context.getString(DEFAULT_VISITOR_NAME);
        String articleUrl = articleSuggestionClicked.getArticleSuggestion().getArticleUrl();

        String selectionMessage = context.getString(ARTICLE_OPENED_FORMATTER, visitorName, articleUrl);
        return String.format(Locale.US, "%s %s", formatTimestamp(timestamp), selectionMessage);
    }

    @NonNull
    private String serializeEngineSelectionEvent(@NonNull Event.EngineSelection engineSelectionEvent) {
        Date timestamp = engineSelectionEvent.getTimestamp();
        String visitorName = context.getString(DEFAULT_VISITOR_NAME);
        String selectedEngine = engineSelectionEvent.getSelectedEngine().getDisplayName();

        String selectionMessage = context.getString(TRANSFER_OPTION_SELECTION_FORMATTER, visitorName, selectedEngine);
        return String.format(Locale.US, "%s %s", formatTimestamp(timestamp), selectionMessage);
    }

    @NonNull
    private String getAgentUserName(@NonNull AgentDetails agentDetails) {
        StringBuilder userName = new StringBuilder(agentDetails.getAgentName());
        if (agentDetails.isBot()) {
            userName.append(BOT_LABEL);
        }
        return userName.toString();
    }
    
    private String formatTimestamp(Date date) {
        return timestampFactory.createTimestamp(date);
    }

}
