package zendesk.classic.messaging;

import android.content.Context;
import android.content.res.Resources;

import com.squareup.picasso.Picasso;

import dagger.Module;
import dagger.Provides;

@Module
abstract class MessagingModule {

    @MessagingScope
    @Provides
    static Picasso picasso(Context context) {
        return new Picasso.Builder(context).build();
    }

    @MessagingScope
    @Provides
    static Resources resources(Context context) {
        return context.getResources();
    }
}
