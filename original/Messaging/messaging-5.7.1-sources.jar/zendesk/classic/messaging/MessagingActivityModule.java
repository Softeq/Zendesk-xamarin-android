package zendesk.classic.messaging;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import javax.inject.Named;

import dagger.Binds;
import dagger.Module;
import dagger.Provides;
import zendesk.classic.messaging.components.DateProvider;
import zendesk.commonui.PermissionsHandler;
import zendesk.core.MediaFileResolver;

@Module
abstract class MessagingActivityModule {

    private static final int THREAD_POOL_SIZE = 5;

    @Binds
    abstract EventListener eventListener(MessagingViewModel messagingViewModel);

    @MessagingActivityScope
    @Provides
    static Handler handler() {
        return new Handler(Looper.getMainLooper());
    }

    @MessagingActivityScope
    @Provides
    static DateProvider dateProvider() {
        return new DateProvider();
    }

    @MessagingActivityScope
    @Provides
    @Named(MessagingActivityScope.QUICK_REPLY_WRAPPING_ENABLED)
    static boolean multilineResponseOptionsEnabled(MessagingComponent messagingComponent) {
        return messagingComponent.messagingConfiguration().isMultilineResponseOptionsEnabled();
    }

    @MessagingActivityScope
    @Provides
    static UriResolver uriTaskResolver(MediaFileResolver mediaFileResolver, ExecutorService executorService) {
        return new UriResolver(
                mediaFileResolver,
                executorService
        );
    }

    @MessagingActivityScope
    @Provides
    static ScheduledExecutorService provideExecutor() {
        return Executors.newScheduledThreadPool(THREAD_POOL_SIZE, new ThreadFactory() {

            final AtomicInteger atomicInteger = new AtomicInteger(0);

            @Override
            public Thread newThread(@NonNull Runnable runnable) {
                Thread thread = new Thread(runnable,
                        String.format(Locale.ENGLISH, "ZendeskThread-%d", atomicInteger.getAndIncrement()));
                thread.setPriority(Process.THREAD_PRIORITY_BACKGROUND);
                return thread;
            }
        });
    }

    @MessagingActivityScope
    @Provides
    static ExecutorService executorService(ScheduledExecutorService scheduledExecutorService) {
        return scheduledExecutorService;
    }

    @MessagingActivityScope
    @Provides
    static PermissionsHandler permissionsHandler(AppCompatActivity activity) {
        return new PermissionsHandler(activity);
    }
}
