package zendesk.classic.messaging.ui;

import android.content.Context;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class EndUserMessageView extends LinearLayout implements Updatable<EndUserCellMessageState> {

    private TextView textField;
    private MessageStatusView statusView;
    private TextView label;

    private int textColor;
    private int errorTextColor;

    public EndUserMessageView(Context context) {
        super(context);
        init();
    }

    public EndUserMessageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public EndUserMessageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(VERTICAL);
        setGravity(Gravity.BOTTOM | Gravity.END);
        inflate(getContext(), R.layout.zui_view_end_user_message_cell_content, this);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        textField = findViewById(R.id.zui_end_user_message_cell_text_field);
        statusView = findViewById(R.id.zui_cell_status_view);
        label = findViewById(R.id.zui_cell_label_message);

        Context context = getContext();

        errorTextColor = UiUtils.resolveColor(R.color.zui_text_color_dark_primary, context);
        textColor = UiUtils.resolveColor(R.color.zui_text_color_light_primary, context);
    }

    @Override
    public void update(final EndUserCellMessageState state) {
        UtilsEndUserCellView.setClickListener(state, this);
        UtilsEndUserCellView.setLongClickListener(state, this);
        UtilsEndUserCellView.setLabelErrorMessage(state, label, getContext());
        UtilsEndUserCellView.setCellBackground(state, textField);

        MessagingItem.Query.Status status = state.getStatus();

        textField.setTextColor(UtilsEndUserCellView.isFailedCell(state) ? errorTextColor : textColor);

        textField.setText(state.getMessage());
        textField.setTextIsSelectable(status == MessagingItem.Query.Status.DELIVERED);
        textField.requestLayout();
        statusView.setStatus(status);

        state.getProps().apply(this, statusView);
    }

}