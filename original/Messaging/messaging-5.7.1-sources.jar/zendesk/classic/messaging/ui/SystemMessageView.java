package zendesk.classic.messaging.ui;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import android.widget.TextView;

import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class SystemMessageView extends LinearLayout implements Updatable<SystemMessageView.State> {

    private TextView systemMessage;

    public SystemMessageView(Context context) {
        super(context);
        init();
    }

    public SystemMessageView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SystemMessageView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(VERTICAL);
        inflate(getContext(), R.layout.zui_view_system_message, this);
        systemMessage = findViewById(R.id.zui_system_message_text);
    }

    @Override
    public void update(final State state) {
        state.props.apply(this);
        systemMessage.setText(state.getText());
    }

    static class State {

        private final String text;
        private final MessagingCellProps props;

        State(MessagingCellProps props, String text) {
            this.props = props;
            this.text = text;
        }

        public String getText() {
            return text;
        }

        public MessagingCellProps getProps() {
            return props;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            State state = (State) o;

            if (text != null ? !text.equals(state.text) : state.text != null) {
                return false;
            }
            return props != null ? props.equals(state.props) : state.props == null;
        }

        @Override
        public int hashCode() {
            int result = text != null ? text.hashCode() : 0;
            result = 31 * result + (props != null ? props.hashCode() : 0);
            return result;
        }
    }
}
