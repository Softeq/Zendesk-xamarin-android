package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zendesk.util.FileUtils;

import java.util.Locale;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.Attachment;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;
import static zendesk.classic.messaging.ui.UtilsAttachment.formatFileSize;

@RestrictTo(LIBRARY)
public class AgentFileCellView extends LinearLayout implements Updatable<AgentFileCellView.State> {

    private AvatarView avatarView;
    private LinearLayout bubble;

    private TextView fileName;
    private TextView fileDescriptor;

    private ImageView appIcon;
    private TextView labelField;
    private View labelContainer;
    private View botLabel;

    private Drawable defaultAppIcon;

    public AgentFileCellView(Context context) {
        super(context);
        init();
    }

    public AgentFileCellView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public AgentFileCellView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(HORIZONTAL);
        inflate(getContext(), R.layout.zui_view_agent_file_cell_content, this);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        avatarView = findViewById(R.id.zui_agent_message_avatar);
        bubble = findViewById(R.id.zui_cell_file_container);
        fileName = findViewById(R.id.zui_file_cell_name);
        fileDescriptor = findViewById(R.id.zui_cell_file_description);
        appIcon = findViewById(R.id.zui_cell_file_app_icon);
        labelContainer = findViewById(R.id.zui_cell_status_view);
        labelField = findViewById(R.id.zui_cell_label_text_field);
        botLabel = findViewById(R.id.zui_cell_label_supplementary_label);

        defaultAppIcon = ContextCompat.getDrawable(getContext(), R.drawable.zui_ic_insert_drive_file);
        int defaultDrawableColor =
                UiUtils.themeAttributeToColor(R.attr.colorPrimary, getContext(), R.color.zui_color_primary);
        UiUtils.setTint(defaultDrawableColor, defaultAppIcon, appIcon);
    }

    @Override
    public void update(State state) {
        fileName.setText(state.getAttachment().getName());
        fileDescriptor.setText(state.getFileDescriptor(getContext()));

        appIcon.setImageDrawable(defaultAppIcon);

        setBubbleClickListeners(state);

        labelField.setText(state.getLabel());
        botLabel.setVisibility(state.isBot() ? VISIBLE : GONE);

        state.getAvatarStateRenderer().render(state.getAvatarState(), avatarView);
        state.getProps().apply(this, labelContainer, avatarView);
    }

    private void setBubbleClickListeners(final State state) {
        bubble.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilsAttachment.openAttachment(v, state.getAttachment().getUrl());
            }
        });
    }

    static class State {

        private static final String FILE_DESCRIPTOR_FORMATTER = "%s %s";

        private final Attachment attachment;
        private final MessagingCellProps props;
        private final String label;
        private final boolean isBot;
        private final AvatarState avatarState;
        private final AvatarStateRenderer avatarStateRenderer;

        State(Attachment attachment,
                MessagingCellProps props,
                String label,
                boolean isBot,
                AvatarState avatarState,
                AvatarStateRenderer avatarStateRenderer) {
            this.attachment = attachment;
            this.props = props;
            this.label = label;
            this.isBot = isBot;
            this.avatarState = avatarState;
            this.avatarStateRenderer = avatarStateRenderer;
        }

        public Attachment getAttachment() {
            return attachment;
        }

        MessagingCellProps getProps() {
            return props;
        }

        String getFileDescriptor(Context context) {
            return String.format(
                    Locale.US,
                    FILE_DESCRIPTOR_FORMATTER,
                    formatFileSize(context, attachment.getSize()),
                    FileUtils.getFileExtension(attachment.getName())
            );
        }

        String getLabel() {
            return label;
        }

        boolean isBot() {
            return isBot;
        }

        AvatarState getAvatarState() {
            return avatarState;
        }

        AvatarStateRenderer getAvatarStateRenderer() {
            return avatarStateRenderer;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            State state = (State) o;

            if (isBot() != state.isBot()) {
                return false;
            }
            if (getAttachment() != null
                    ? !getAttachment().equals(state.getAttachment()) : state.getAttachment() != null) {
                return false;
            }
            if (getProps() != null ? !getProps().equals(state.getProps()) : state.getProps() != null) {
                return false;
            }
            if (getLabel() != null ? !getLabel().equals(state.getLabel()) : state.getLabel() != null) {
                return false;
            }
            return avatarState != null ? avatarState.equals(state.avatarState) : state.avatarState == null;
        }

        @Override
        public int hashCode() {
            int result = getAttachment() != null ? getAttachment().hashCode() : 0;
            result = 31 * result + (getProps() != null ? getProps().hashCode() : 0);
            result = 31 * result + (getLabel() != null ? getLabel().hashCode() : 0);
            result = 31 * result + (isBot() ? 1 : 0);
            result = 31 * result + (avatarState != null ? avatarState.hashCode() : 0);
            return result;
        }
    }
}
