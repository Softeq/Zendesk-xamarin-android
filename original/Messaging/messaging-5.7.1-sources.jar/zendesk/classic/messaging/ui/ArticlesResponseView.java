package zendesk.classic.messaging.ui;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.StringRes;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;
import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

@RestrictTo(LIBRARY)
public class ArticlesResponseView extends LinearLayout implements Updatable<ArticlesResponseView.State> {

    private AvatarView avatarView;
    private TextView header;
    private View firstArticleSuggestion;
    private View secondArticleSuggestion;
    private View thirdArticleSuggestion;
    private TextView labelField;
    private View labelContainer;
    private View botLabel;

    public ArticlesResponseView(Context context) {
        super(context);
    }

    public ArticlesResponseView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ArticlesResponseView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(HORIZONTAL);
        inflate(getContext(), R.layout.zui_view_articles_response_content, this);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        avatarView = findViewById(R.id.zui_agent_message_avatar);
        header = findViewById(R.id.zui_header_article_suggestions);
        firstArticleSuggestion = findViewById(R.id.zui_first_article_suggestion);
        secondArticleSuggestion = findViewById(R.id.zui_second_article_suggestion);
        thirdArticleSuggestion = findViewById(R.id.zui_third_article_suggestion);
        labelField = findViewById(R.id.zui_cell_label_text_field);
        botLabel = findViewById(R.id.zui_cell_label_supplementary_label);
        labelContainer = findViewById(R.id.zui_cell_status_view);
    }

    @Override
    public void update(State state) {
        labelField.setText(state.getLabel());
        botLabel.setVisibility(state.isBot() ? VISIBLE : GONE);
        state.getAvatarStateRenderer().render(state.getAvatarState(), avatarView);
        state.getProps().apply(this, labelContainer, avatarView);

        header.setText(state.getHeaderText());

        bindArticleSuggestion(state.getFirstArticleSuggestionViewState(), firstArticleSuggestion);
        bindArticleSuggestion(state.getSecondArticleSuggestionViewState(), secondArticleSuggestion);
        bindArticleSuggestion(state.getThirdArticleSuggestionViewState(), thirdArticleSuggestion);

        setSuggestionBackgrounds(state.getArticleSuggestionViewStates());
    }

    private void setSuggestionBackgrounds(List<ArticleSuggestionViewState> articleSuggestionViewStates) {
        List<View> suggestionViews =
                new ArrayList<>(Arrays.asList(firstArticleSuggestion, secondArticleSuggestion, thirdArticleSuggestion));

        for (View view : suggestionViews) {
            if (suggestionViews.indexOf(view) == articleSuggestionViewStates.size() - 1) {
                view.setBackgroundResource(R.drawable.zui_background_cell_options_footer);
            } else {
                view.setBackgroundResource(R.drawable.zui_background_cell_options_content);
            }
        }
    }

    private void bindArticleSuggestion(final ArticleSuggestionViewState articleSuggestionViewState,
                                       View articleSuggestionView) {

        articleSuggestionView.setVisibility(articleSuggestionViewState != null ? VISIBLE : GONE);
        if (articleSuggestionViewState == null) {
            return;
        }

        final TextView articleTitle = articleSuggestionView.findViewById(R.id.zui_article_title);
        final TextView articleSnippet = articleSuggestionView.findViewById(R.id.zui_article_snippet);
        final View.OnClickListener clickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                articleSuggestionViewState.getOnArticleSuggestionSelectionListener()
                        .onArticleSuggestionSelected(getContext());
            }
        };

        articleTitle.setText(articleSuggestionViewState.getTitle());
        articleSnippet.setText(articleSuggestionViewState.getSnippet());

        articleSuggestionView.setOnClickListener(clickListener);
    }

    @RestrictTo(LIBRARY_GROUP)
    public static class State {

        private final String label;
        private final boolean isBot;
        private final MessagingCellProps props;
        private final List<ArticleSuggestionViewState> articleSuggestionViewStates;
        private final AvatarState avatarState;
        private final AvatarStateRenderer avatarStateRenderer;

        public State(String label,
                     boolean isBot,
                     @NonNull MessagingCellProps props,
                     @NonNull List<ArticleSuggestionViewState> articleSuggestionViewStates,
                     AvatarState avatarState,
                     AvatarStateRenderer avatarStateRenderer) {
            this.label = label;
            this.isBot = isBot;
            this.props = props;
            this.articleSuggestionViewStates = articleSuggestionViewStates;
            this.avatarState = avatarState;
            this.avatarStateRenderer = avatarStateRenderer;
        }

        String getLabel() {
            return label;
        }

        boolean isBot() {
            return isBot;
        }

        MessagingCellProps getProps() {
            return props;
        }

        @StringRes
        int getHeaderText() {
            return articleSuggestionViewStates.size() == 1
                    ? R.string.zui_cell_text_suggested_article_header
                    : R.string.zui_cell_text_suggested_articles_header;
        }

        List<ArticleSuggestionViewState> getArticleSuggestionViewStates() {
            return articleSuggestionViewStates;
        }

        @Nullable
        ArticleSuggestionViewState getFirstArticleSuggestionViewState() {
            return articleSuggestionViewStates.size() >= 1 ? articleSuggestionViewStates.get(0) : null;
        }

        @Nullable
        ArticleSuggestionViewState getSecondArticleSuggestionViewState() {
            return articleSuggestionViewStates.size() >= 2 ? articleSuggestionViewStates.get(1) : null;
        }

        @Nullable
        ArticleSuggestionViewState getThirdArticleSuggestionViewState() {
            return articleSuggestionViewStates.size() >= 3 ? articleSuggestionViewStates.get(2) : null;
        }

        AvatarState getAvatarState() {
            return avatarState;
        }

        public AvatarStateRenderer getAvatarStateRenderer() {
            return avatarStateRenderer;
        }
    }

    static class ArticleSuggestionViewState {
        private final String title;
        private final String snippet;
        private final OnArticleSuggestionSelectionListener onArticleSuggestionSelectionListener;


        ArticleSuggestionViewState(String title,
                                   String snippet,
                                   OnArticleSuggestionSelectionListener onArticleSuggestionSelectionListener) {
            this.title = title;
            this.snippet = snippet;
            this.onArticleSuggestionSelectionListener = onArticleSuggestionSelectionListener;
        }

        String getTitle() {
            return title;
        }

        String getSnippet() {
            return snippet;
        }

        OnArticleSuggestionSelectionListener getOnArticleSuggestionSelectionListener() {
            return onArticleSuggestionSelectionListener;
        }
    }

}

