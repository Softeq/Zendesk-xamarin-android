package zendesk.classic.messaging.ui;

import androidx.annotation.NonNull;

import com.zendesk.util.StringUtils;

import javax.inject.Inject;

import zendesk.classic.messaging.AgentDetails;

class AvatarStateFactory {

    @Inject
    AvatarStateFactory() {
        // Empty constructor so Dagger can create
    }

    AvatarState createAvatarState(@NonNull AgentDetails agentDetails) {
        String firstLetter = StringUtils.hasLength(agentDetails.getAgentName())
                ? agentDetails.getAgentName().substring(0, 1) : StringUtils.EMPTY_STRING;

        return new AvatarState(agentDetails.getAgentId(),
                firstLetter,
                agentDetails.getAvatarPath(),
                agentDetails.getAvatarDrawableRes());
    }
}
