package zendesk.classic.messaging.ui;

import com.squareup.picasso.Picasso;

import zendesk.classic.messaging.Attachment;
import zendesk.classic.messaging.AttachmentSettings;
import zendesk.classic.messaging.MessagingItem;

/**
 * Describes the state for all image attachment end-user cell views
 */
class EndUserCellImageState extends EndUserCellFileState {

    private final Picasso picasso;

    /**
     * Constructs an instance of {@link EndUserCellImageState}
     *
     * @param id                    the id of the cell
     * @param props                 the {@link MessagingCellProps} of the cell
     * @param status                the {@link MessagingItem.Query.Status} of the messaging item
     * @param messageActionListener the {@link MessageActionListener} for the cell
     * @param attachment            the {@link Attachment} model
     * @param failureReason         the {@link MessagingItem.FileQuery.FailureReason} if
     *                              the attachment failed to send
     * @param attachmentSettings    the {@link AttachmentSettings} for this engine
     * @param picasso               an instance of {@link PicassoCompat}
     */
    EndUserCellImageState(
            String id,
            MessagingCellProps props,
            MessagingItem.Query.Status status,
            MessageActionListener messageActionListener,
            Attachment attachment,
            MessagingItem.FileQuery.FailureReason failureReason,
            AttachmentSettings attachmentSettings,
            Picasso picasso) {
        super(id, props, status, messageActionListener, attachment, failureReason, attachmentSettings);
        this.picasso = picasso;
    }

    /**
     * @return the instance of {@link PicassoCompat}
     */
    Picasso getPicasso() {
        return picasso;
    }

    @SuppressWarnings("EqualsReplaceableByObjectsCall")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        EndUserCellImageState that = (EndUserCellImageState) o;

        return picasso != null ? picasso.equals(that.picasso) : that.picasso == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (picasso != null ? picasso.hashCode() : 0);
        return result;
    }
}
