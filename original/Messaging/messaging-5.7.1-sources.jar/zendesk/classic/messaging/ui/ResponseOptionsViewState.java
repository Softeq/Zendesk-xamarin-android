package zendesk.classic.messaging.ui;

import androidx.annotation.Nullable;

import java.util.List;

import zendesk.classic.messaging.MessagingItem;

class ResponseOptionsViewState {

    private final List<MessagingItem.Option> options;
    private final ResponseOptionHandler listener;
    private final MessagingCellProps props;

    ResponseOptionsViewState(
            List<MessagingItem.Option> options,
            @Nullable ResponseOptionHandler listener,
            MessagingCellProps props) {
        this.options = options;
        this.listener = listener;
        this.props = props;
    }

    List<MessagingItem.Option> getOptions() {
        return options;
    }

    @Nullable
    ResponseOptionHandler getListener() {
        return listener;
    }

    MessagingCellProps getProps() {
        return props;
    }
}
