package zendesk.classic.messaging.ui;

import android.content.res.Resources;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import android.view.View;

import com.zendesk.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.MessagingActivityScope;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

@RestrictTo(LIBRARY_GROUP)
@MessagingActivityScope
public class MessagingCellPropsFactory {

    private final int groupSpacing;
    private final int defaultSpacing;

    private enum InteractionType {
        QUERY, RESPONSE, NONE
    }

    @Inject
    public MessagingCellPropsFactory(@NonNull Resources resources) {
        defaultSpacing = resources.getDimensionPixelSize(R.dimen.zui_cell_vertical_spacing_default);
        groupSpacing = resources.getDimensionPixelSize(R.dimen.zui_cell_vertical_spacing_group);
    }

    public List<MessagingCellProps> create(@NonNull final List<MessagingItem> interactions) {
        if (CollectionUtils.isEmpty(interactions)) {
            return Collections.emptyList();
        }

        final List<MessagingCellProps> propsList = new ArrayList<>(interactions.size());

        for (int i = 0; i < interactions.size(); i++) {
            final MessagingCellProps props = generateCellProps(
                    i > 0 ? interactions.get(i - 1) : null,
                    interactions.get(i),
                    i + 1 < interactions.size() ? interactions.get(i + 1) : null
            );

            propsList.add(props);
        }

        return propsList;
    }

    private MessagingCellProps generateCellProps(
            @Nullable MessagingItem previousInteraction,
            @NonNull MessagingItem currentInteraction,
            @Nullable MessagingItem nextInteraction) {
        return new MessagingCellProps(
                labelVisibility(currentInteraction, previousInteraction),
                cellSpacing(currentInteraction, nextInteraction),
                avatarVisibility(currentInteraction, nextInteraction)
        );
    }

    @VisibleForTesting
    int labelVisibility(@NonNull MessagingItem currentInteraction,
                        @Nullable MessagingItem previousInteraction) {

        InteractionType currentInteractionType = classifyInteraction(currentInteraction);
        if (currentInteractionType == InteractionType.QUERY || previousInteraction == null) {
            return View.VISIBLE;
        }

        InteractionType previousInteractionType = classifyInteraction(previousInteraction);
        if (currentInteractionType != previousInteractionType) {
            return View.VISIBLE;
        }

        if (currentInteraction instanceof MessagingItem.Response
                && previousInteraction instanceof MessagingItem.Response) {
            final String currentAgentId =
                    ((MessagingItem.Response) currentInteraction).getAgentDetails().getAgentId();
            final String previousAgentId =
                    ((MessagingItem.Response) previousInteraction).getAgentDetails().getAgentId();

            if (!currentAgentId.equals(previousAgentId)) {
                return View.VISIBLE;
            } else {
                return View.GONE;
            }
        }

        return View.GONE;
    }

    @VisibleForTesting
    int cellSpacing(@NonNull MessagingItem currentInteraction,
                    @Nullable MessagingItem nextInteraction) {
        if (nextInteraction == null) {
            return defaultSpacing;
        }

        if (nextInteraction instanceof MessagingItem.SystemMessage) {
            return groupSpacing;
        }

        final InteractionType currentInteractionType = classifyInteraction(currentInteraction);

        final InteractionType previousInteractionType = classifyInteraction(nextInteraction);

        if (currentInteractionType == previousInteractionType) {
            return groupSpacing;
        }

        return defaultSpacing;
    }

    @VisibleForTesting
    int avatarVisibility(@NonNull MessagingItem currentItem,
                         @Nullable MessagingItem nextItem) {

        final InteractionType currentItemType = classifyInteraction(currentItem);

        if (currentItemType == InteractionType.QUERY) {
            return View.INVISIBLE;
        }

        if (nextItem == null) {
            return View.VISIBLE;
        }

        final InteractionType nextItemType = classifyInteraction(nextItem);

        if (currentItemType != nextItemType) {
            return View.VISIBLE;
        }

        if (currentItem instanceof MessagingItem.Response
                && nextItem instanceof MessagingItem.Response) {
            final String currentAgentId =
                    ((MessagingItem.Response) currentItem).getAgentDetails().getAgentId();
            final String nextAgentId =
                    ((MessagingItem.Response) nextItem).getAgentDetails().getAgentId();

            if (currentAgentId.equals(nextAgentId)) {
                return View.INVISIBLE;
            } else {
                return View.VISIBLE;
            }
        }

        return View.INVISIBLE;
    }

    private static InteractionType classifyInteraction(@NonNull MessagingItem interaction) {

        if (interaction instanceof MessagingItem.Response) {
            return InteractionType.RESPONSE;
        } else if (interaction instanceof MessagingItem.Query
                || interaction instanceof MessagingItem.OptionsResponse) {
            return InteractionType.QUERY;
        } else {
            return InteractionType.NONE;
        }
    }
}