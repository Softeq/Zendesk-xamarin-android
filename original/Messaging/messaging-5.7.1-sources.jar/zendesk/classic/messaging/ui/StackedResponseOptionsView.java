package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.FrameLayout;

import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexboxItemDecoration;
import com.google.android.flexbox.FlexboxLayoutManager;

import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class StackedResponseOptionsView extends FrameLayout implements Updatable<ResponseOptionsViewState> {

    private ResponseOptionsAdapter adapter;

    public StackedResponseOptionsView(Context context) {
        super(context);
        init();
    }

    public StackedResponseOptionsView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public StackedResponseOptionsView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        inflate(getContext(), R.layout.zui_view_response_options_content, this);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        RecyclerView recyclerView = findViewById(R.id.zui_response_options_recycler);

        // Disable animations on the RecyclerView. This ensures that changes happen immediately rather than potentially
        // conflicting with the animations of the cell as a whole in the parent RecyclerView
        recyclerView.setItemAnimator(null);

        FlexboxItemDecoration flexboxItemDecoration = new FlexboxItemDecoration(getContext());

        flexboxItemDecoration.setOrientation(FlexboxItemDecoration.BOTH);
        Drawable divider = ContextCompat.getDrawable(getContext(),
                R.drawable.zui_view_stacked_response_options_divider);
        if (divider != null) {
            flexboxItemDecoration.setDrawable(divider);
        }

        recyclerView.setLayoutManager(new FlexboxLayoutManager(getContext(), FlexDirection.ROW_REVERSE));
        recyclerView.addItemDecoration(flexboxItemDecoration);

        adapter = new ResponseOptionsAdapter();
        recyclerView.setAdapter(adapter);
    }

    @Override
    public void update(final ResponseOptionsViewState state) {
        state.getProps().apply(this);
        adapter.setResponseOptionHandler(new ResponseOptionHandler() {
            @Override
            public void onResponseOptionSelected(MessagingItem.Option responseOption) {
                adapter.setSelectedOption(responseOption);
                state.getListener().onResponseOptionSelected(responseOption);
            }
        });
        adapter.submitList(state.getOptions());
    }

}
