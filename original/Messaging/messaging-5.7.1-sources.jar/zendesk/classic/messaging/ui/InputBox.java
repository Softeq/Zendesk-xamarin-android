package zendesk.classic.messaging.ui;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.List;

import zendesk.commonui.TextWatcherAdapter;
import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;
import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * For Zendesk internal use only.
 */
@RestrictTo(LIBRARY)
public class InputBox extends FrameLayout {

    @RestrictTo(LIBRARY_GROUP)
    public interface InputTextConsumer {
        /**
         * Called when the send button has been clicked
         * and the input text has passed the validation.
         *
         * @param text Validated input text.
         */
        boolean onConsumeText(@NonNull String text);
    }

    /**
     * Internal views
     **/
    private FrameLayout inputBox;
    private EditText inputTextField;
    private AttachmentsIndicator attachmentsIndicator;
    private ImageView sendButton;
    /**
     * Various listeners
     **/
    private InputTextConsumer inputTextConsumer;
    private TextWatcher inputTextWatcher;
    private OnClickListener attachmentsIndicatorClickListener;
    private final List<OnClickListener> sendButtonClickListeners = new ArrayList<>();

    public InputBox(Context context) {
        super(context);
        viewInit(context);
    }

    public InputBox(Context context, AttributeSet attrs) {
        super(context, attrs);
        viewInit(context);
    }

    public InputBox(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        viewInit(context);
    }

    @SuppressWarnings("unused")
    public InputBox(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        viewInit(context);
    }

    @VisibleForTesting
    InputBox(Context context, AttachmentsIndicator attachmentsIndicator, EditText editText, ImageView sendButton) {
        super(context);
        this.attachmentsIndicator = attachmentsIndicator;
        this.inputTextField = editText;
        this.sendButton = sendButton;
    }

    @Override
    public boolean dispatchKeyEventPreIme(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            inputTextField.clearFocus();
        }
        return super.dispatchKeyEventPreIme(event);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        return !isEnabled() || super.dispatchTouchEvent(event);
    }

    @Override
    public boolean requestFocus(int direction, Rect previouslyFocusedRect) {
        return inputTextField.requestFocus();
    }

    @Override
    public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        inputTextField.setEnabled(enabled);
        if (!enabled) {
            inputTextField.clearFocus();
        }
        inputBox.setEnabled(enabled);
        sendButton.setAlpha(enabled ? 1.0F : 0.2F);
        attachmentsIndicator.setAlpha(enabled ? 1.0F : 0.2F);
    }

    public void setInputTextWatcher(TextWatcher inputTextWatcher) {
        this.inputTextWatcher = inputTextWatcher;
    }

    /**
     * Sets a {@link OnClickListener} that will be notified when an attachments indicator is clicked.
     *
     * @param attachmentsIndicatorClickListener Null to hide {@link AttachmentsIndicator},
     *                                          an instance of {@link OnClickListener} to show it.
     */
    public void setAttachmentsIndicatorClickListener(@Nullable OnClickListener attachmentsIndicatorClickListener) {
        this.attachmentsIndicatorClickListener = attachmentsIndicatorClickListener;
        showAttachmentsIndicator(attachmentsIndicatorClickListener != null);
    }

    /**
     * Sets a {@link InputTextConsumer} that will be notified when input text passes validation
     * and send button is clicked.
     *
     * @param inputTextConsumer The consumer of input text.
     */
    public void setInputTextConsumer(InputTextConsumer inputTextConsumer) {
        this.inputTextConsumer = inputTextConsumer;
    }

    public boolean addSendButtonClickListener(View.OnClickListener onClickListener) {
        return sendButtonClickListeners.add(onClickListener);
    }

    /**
     * Sets the internal {@link AttachmentsIndicator} to display the counter
     * with a number of attachments.
     *
     * @param attachmentsCount The number of attachments that the counter will display.
     */
    public void setAttachmentsCount(int attachmentsCount) {
        attachmentsIndicator.setAttachmentsCount(attachmentsCount);
        final boolean hasText = StringUtils.hasLength(inputTextField.getText().toString());
        final boolean hasAttachments = attachmentsIndicator.getAttachmentsCount() > 0;
        updateSendBtn(hasText || hasAttachments);
    }

    public void setHint(String hint) {
        inputTextField.setHint(hint);
    }

    /**
     * Sets the input type to control what keyboard is shown to the user.
     *
     * @param inputType the {@link android.text.InputType} value
     */
    public void setInputType(Integer inputType) {
        inputTextField.setInputType(inputType);
    }

    private void viewInit(Context context) {
        inflate(context, R.layout.zui_view_input_box, this);

        if (isInEditMode()) {
            return;
        }

        bindViews();
        initListeners();
        showAttachmentsIndicator(false);
        updateSendBtn(false);
    }

    private void bindViews() {
        inputBox = findViewById(R.id.zui_view_input_box);
        inputTextField = findViewById(R.id.input_box_input_text);
        attachmentsIndicator = findViewById(R.id.input_box_attachments_indicator);
        sendButton = findViewById(R.id.input_box_send_btn);
    }

    private void initListeners() {
        inputBox.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                inputTextField.requestFocus();
                InputMethodManager imm =
                        (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                }
            }
        });
        attachmentsIndicator.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (attachmentsIndicatorClickListener != null) {
                    attachmentsIndicatorClickListener.onClick(v);
                }
            }
        });
        sendButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (inputTextConsumer != null) {
                    if (inputTextConsumer.onConsumeText(inputTextField.getText().toString().trim())) {
                        attachmentsIndicator.reset();
                        inputTextField.setText(null);
                    }
                }
                for (View.OnClickListener onClickListener : sendButtonClickListeners) {
                    onClickListener.onClick(v);
                }
            }
        });
        inputTextField.addTextChangedListener(new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                final boolean hasText = StringUtils.hasLength(s.toString());
                final boolean hasAttachments = attachmentsIndicator.getAttachmentsCount() > 0;
                updateSendBtn(hasText || hasAttachments);

                if (inputTextWatcher != null) {
                    inputTextWatcher.afterTextChanged(s);
                }
            }
        });
        inputTextField.setOnFocusChangeListener(new OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    inputBox.setBackgroundResource(R.drawable.zui_background_composer_selected);
                } else {
                    inputBox.setBackgroundResource(R.drawable.zui_background_composer_inactive);
                }
            }
        });
    }

    private void showAttachmentsIndicator(boolean show) {
        if (show) {
            attachmentsIndicator.setEnabled(true);
            attachmentsIndicator.setVisibility(VISIBLE);
            updateInputFieldPosition(true);
        } else {
            attachmentsIndicator.setEnabled(false);
            attachmentsIndicator.setVisibility(GONE);
            updateInputFieldPosition(false);
        }
    }

    private void updateInputFieldPosition(boolean isAttachmentsIndicatorShown) {
        final Resources r = getResources();
        final int etSideMarginWithoutAttachments = r.getDimensionPixelSize(R.dimen.zui_input_box_expanded_side_margin);
        final int etSideMarginWithAttachments = r.getDimensionPixelSize(R.dimen.zui_input_box_collapsed_side_margin);
        final FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) inputTextField.getLayoutParams();

        params.leftMargin = isAttachmentsIndicatorShown
                ? etSideMarginWithAttachments
                : etSideMarginWithoutAttachments;
        inputTextField.setLayoutParams(params);
    }

    private void updateSendBtn(boolean enabled) {
        final Context context = getContext();
        final int sendButtonColor = enabled
                ? UiUtils.themeAttributeToColor(R.attr.colorPrimary, context, R.color.zui_color_primary)
                : UiUtils.resolveColor(R.color.zui_color_disabled, context);

        sendButton.setEnabled(enabled);
        UiUtils.setTint(sendButtonColor, sendButton.getDrawable(), sendButton);
    }
}
