package zendesk.classic.messaging.ui;

import android.content.Context;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class ActionOptionsView extends LinearLayout implements Updatable<ActionOptionsView.State> {

    private AvatarView avatarView;
    private TextView actionOptionsHeader;
    private TextView labelField;
    private View labelContainer;
    private View botLabel;

    private ViewGroup actionOptionsContainer;

    public ActionOptionsView(Context context) {
        super(context);
        init();
    }

    public ActionOptionsView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ActionOptionsView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(HORIZONTAL);
        inflate(getContext(), R.layout.zui_view_action_options_content, this);
        avatarView = findViewById(R.id.zui_agent_message_avatar);
        actionOptionsHeader = findViewById(R.id.zui_answer_bot_action_options_header);
        labelContainer = findViewById(R.id.zui_cell_status_view);
        labelField = findViewById(R.id.zui_cell_label_text_field);
        botLabel = findViewById(R.id.zui_cell_label_supplementary_label);
        actionOptionsContainer = findViewById(R.id.zui_cell_action_options_container);
    }

    @Override
    public void update(State state) {
        actionOptionsHeader.setText(state.getHeader());
        labelField.setText(state.getLabel());
        botLabel.setVisibility(state.isBot() ? VISIBLE : GONE);

        updateActionOptions(state.getActionOptions(), state.isEnabled());

        state.getAvatarStateRenderer().render(state.getAvatarState(), avatarView);

        state.getProps().apply(this, labelContainer, avatarView);
    }

    private void updateActionOptions(List<ActionOptionState> actionOptionStates, boolean enabled) {
        actionOptionsContainer.removeAllViews();
        actionOptionsContainer.addView(actionOptionsHeader);

        LayoutInflater layoutInflater = LayoutInflater.from(getContext());

        for (ActionOptionState actionOptionState : actionOptionStates) {
            final View actionOptionView = layoutInflater.inflate(
                    R.layout.zui_view_action_option,
                    actionOptionsContainer,
                    false
            );
            final TextView actionOptionName = actionOptionView.findViewById(R.id.zui_action_option_name);
            actionOptionName.setText(actionOptionState.getActionOptionName());

            actionOptionView.setOnClickListener(actionOptionState.getOnClickListener());

            if (actionOptionStates.indexOf(actionOptionState) == actionOptionStates.size() - 1) {
                actionOptionView.setBackgroundResource(R.drawable.zui_background_cell_options_footer);
            }

            actionOptionView.setEnabled(enabled);

            actionOptionsContainer.addView(actionOptionView);
        }
    }

    static class State {

        private final String header;
        private final String label;
        private boolean isBot;
        private final MessagingCellProps props;
        private final List<ActionOptionState> actionOptions;
        private final boolean enabled;
        private final AvatarState avatarState;
        private final AvatarStateRenderer avatarStateRenderer;

        public State(String header,
                     String label,
                     boolean isBot,
                     MessagingCellProps props,
                     List<ActionOptionState> actionOptions,
                     boolean enabled,
                     AvatarState avatarState,
                     AvatarStateRenderer avatarStateRenderer) {
            this.header = header;
            this.label = label;
            this.isBot = isBot;
            this.props = props;
            this.actionOptions = actionOptions;
            this.enabled = enabled;
            this.avatarState = avatarState;
            this.avatarStateRenderer = avatarStateRenderer;
        }

        String getHeader() {
            return header;
        }

        String getLabel() {
            return label;
        }

        boolean isBot() {
            return isBot;
        }

        List<ActionOptionState> getActionOptions() {
            return actionOptions;
        }

        MessagingCellProps getProps() {
            return props;
        }

        boolean isEnabled() {
            return enabled;
        }

        AvatarState getAvatarState() {
            return avatarState;
        }

        public AvatarStateRenderer getAvatarStateRenderer() {
            return avatarStateRenderer;
        }
    }

    static class ActionOptionState {

        private final String actionOptionName;
        private final OnClickListener onClickListener;

        ActionOptionState(String actionOptionName,
                          OnClickListener onClickListener) {
            this.actionOptionName = actionOptionName;
            this.onClickListener = onClickListener;
        }

        String getActionOptionName() {
            return actionOptionName;
        }

        OnClickListener getOnClickListener() {
            return onClickListener;
        }
    }

}
