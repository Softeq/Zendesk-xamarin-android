package zendesk.classic.messaging.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.text.InputType;

import com.zendesk.util.CollectionUtils;

import java.util.List;

import zendesk.classic.messaging.AgentDetails;
import zendesk.classic.messaging.AttachmentSettings;
import zendesk.classic.messaging.ConnectionState;
import zendesk.classic.messaging.MessagingItem;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

@RestrictTo(LIBRARY_GROUP)
public class MessagingState {

    final List<MessagingItem> messagingItems;
    final boolean progressBarVisible;
    final boolean enabled;
    final TypingState typingState;
    final ConnectionState connectionState;
    final String hint;
    final AttachmentSettings attachmentSettings;
    final int keyboardInputType;

    private MessagingState(
            @NonNull List<MessagingItem> messagingItems,
            boolean progressBarVisible,
            boolean enabled,
            @NonNull TypingState typingState,
            ConnectionState connectionState,
            String hint,
            AttachmentSettings attachmentSettings,
            int keyboardInputType) {
        this.messagingItems = messagingItems;
        this.progressBarVisible = progressBarVisible;
        this.enabled = enabled;
        this.typingState = typingState;
        this.connectionState = connectionState;
        this.hint = hint;
        this.attachmentSettings = attachmentSettings;
        this.keyboardInputType = keyboardInputType;
    }

    public Builder newBuilder() {
        return new Builder(this);
    }

    @RestrictTo(LIBRARY_GROUP)
    public static class TypingState {

        private final boolean isTyping;
        @Nullable
        private final AgentDetails agentDetails;

        public TypingState(boolean isTyping) {
            this(isTyping, null);
        }

        public TypingState(boolean isTyping, @Nullable AgentDetails agentDetails) {
            this.isTyping = isTyping;
            this.agentDetails = agentDetails;
        }

        public boolean isTyping() {
            return isTyping;
        }

        @Nullable
        public AgentDetails getAgentDetails() {
            return agentDetails;
        }
    }

    @RestrictTo(LIBRARY_GROUP)
    public static class Builder {

        private List<MessagingItem> messagingItems;
        private boolean progressBarVisible;
        private boolean enabled;
        private TypingState typingState = new TypingState(false);
        private ConnectionState connectionState = ConnectionState.DISCONNECTED;
        private String hint;
        private AttachmentSettings attachmentSettings;
        private int keyboardInputType = (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);

        public Builder() {
            // Intentionally Empty
        }

        public Builder(@NonNull MessagingState state) {
            this.messagingItems = state.messagingItems;
            this.enabled = state.enabled;
            this.typingState = state.typingState;
            this.connectionState = state.connectionState;
            this.hint = state.hint;
            this.attachmentSettings = state.attachmentSettings;
            this.keyboardInputType = state.keyboardInputType;
        }

        public Builder withMessagingItems(@NonNull List<MessagingItem> messagingItems) {
            this.messagingItems = messagingItems;
            return this;
        }

        public Builder withEnabled(boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public Builder withProgressBarVisible(boolean progressBarVisible) {
            this.progressBarVisible = progressBarVisible;
            return this;
        }

        public Builder withTypingIndicatorState(@NonNull TypingState typingState) {
            this.typingState = typingState;
            return this;
        }

        public Builder withConnectionState(ConnectionState connectionState) {
            this.connectionState = connectionState;
            return this;
        }

        public Builder withComposerHint(String hint) {
            this.hint = hint;
            return this;
        }

        public Builder withAttachmentSettings(AttachmentSettings attachmentSettings) {
            this.attachmentSettings = attachmentSettings;
            return this;
        }

        public Builder withKeyboardInputType(int keyboardInputType) {
            this.keyboardInputType = keyboardInputType;
            return this;
        }

        @NonNull
        public MessagingState build() {
            return new MessagingState(
                    CollectionUtils.ensureEmpty(messagingItems),
                    progressBarVisible,
                    enabled,
                    typingState,
                    connectionState,
                    hint,
                    attachmentSettings,
                    keyboardInputType
            );
        }
    }
}