package zendesk.classic.messaging.ui;

import android.content.Context;

interface OnArticleSuggestionSelectionListener {
    void onArticleSuggestionSelected(Context context);
}
