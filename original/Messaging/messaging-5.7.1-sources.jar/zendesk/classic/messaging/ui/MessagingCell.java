package zendesk.classic.messaging.ui;

import androidx.annotation.LayoutRes;
import androidx.annotation.NonNull;
import android.view.View;

/**
 * Helper class used to manage rendering Message Items in to RecyclerViewItems.
 *
 * {@link #layoutRes} must be a layout in which the root view is of type V
 *
 * @param <T> the type of the data which will be rendered
 * @param <V> A View class capable of being updated with an instance of T
 */
class MessagingCell<T, V extends View & Updatable<T>> {

    private final String id;
    private final T state;
    private final int layoutRes;
    private final Class<V> viewClassType;

    MessagingCell(@NonNull String id,
                  @NonNull T state,
                  @LayoutRes int layoutRes,
                  @NonNull Class<V> viewClassType) {
        this.id = id;
        this.state = state;
        this.layoutRes = layoutRes;
        this.viewClassType = viewClassType;
    }

    @NonNull
    String getId() {
        return id;
    }

    boolean areContentsTheSame(@NonNull MessagingCell messagingCell) {
        return getId().equals(messagingCell.getId())
                && messagingCell.state.equals(state);
    }

    @LayoutRes
    int getLayoutRes() {
        return layoutRes;
    }

    void bind(@NonNull V view) {
        view.update(state);
    }

    public Class<V> getViewClassType() {
        return viewClassType;
    }
}
