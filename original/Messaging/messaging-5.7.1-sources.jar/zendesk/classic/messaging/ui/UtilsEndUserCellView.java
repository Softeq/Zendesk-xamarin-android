package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.zendesk.logger.Logger;

import java.util.HashSet;
import java.util.Set;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;

import static zendesk.classic.messaging.ui.UtilsAttachment.formatFileSize;
import static zendesk.classic.messaging.ui.UtilsAttachment.openAttachment;
import static zendesk.classic.messaging.MessagingItem.Query.Status.FAILED;
import static zendesk.classic.messaging.MessagingItem.Query.Status.FAILED_NO_RETRY;

class UtilsEndUserCellView {

    private static final String LOG_TAG = "UtilsEndUserCellView";

    @DrawableRes
    private static final int ERROR_BACKGROUND = R.drawable.zui_background_cell_errored;
    @DrawableRes
    private static final int FILE_BACKGROUND = R.drawable.zui_background_cell_file;
    @DrawableRes
    private static final int USER_MESSAGE_BACKGROUND = R.drawable.zui_background_end_user_cell;
    @StringRes
    private static final int TAP_TO_RETRY = R.string.zui_label_tap_retry;
    @StringRes
    private static final int EXCEEDING_MAX_FILE_SIZE = R.string.zui_message_log_message_file_exceeds_max_size;
    @StringRes
    private static final int ATTACHMENTS_NOT_SUPPORTED = R.string.zui_message_log_message_attachments_not_supported;
    @StringRes
    private static final int ATTACHMENT_TYPE_NOT_SUPPORTED =
            R.string.zui_message_log_message_attachment_type_not_supported;
    @StringRes
    private static final int ATTACHMENT_COULD_NOT_BE_SENT = R.string.zui_message_log_attachment_sending_failed;
    @ColorRes
    private static final int ERROR_BACKGROUND_COLOR = R.color.zui_error_background_color;
    @ColorRes
    private static final int PENDING_COLOR = R.color.zui_color_white_60;

    /**
     * Check if the end user cell {@link MessagingItem} failed send
     *
     * @param state the {@link EndUserCellBaseState} of the cell
     * @return true if the delivery was a failure, false otherwise
     */
    static boolean isFailedCell(EndUserCellBaseState state) {
        MessagingItem.Query.Status status = state.getStatus();
        return status == MessagingItem.Query.Status.FAILED
                || status == MessagingItem.Query.Status.FAILED_NO_RETRY;
    }

    /**
     * Set the appropriate background for the end user cell
     *
     * @param state the {@link EndUserCellBaseState} of the cell
     * @param view  the {@link View} to be updated
     */
    static void setCellBackground(EndUserCellBaseState state,
                                  View view) {
        if (isFailedCell(state)) {
            view.setBackgroundResource(ERROR_BACKGROUND);
        } else if (state instanceof EndUserCellFileState) {
            view.setBackgroundResource(FILE_BACKGROUND);
        } else {
            // We have to set these colors like this as on pre lollipop version,  referencing the theme attr in
            // the xml background drawable may cause a crash https://issuetracker.google.com/issues/36941443
            Drawable background = ContextCompat.getDrawable(view.getContext(), USER_MESSAGE_BACKGROUND);
            if (background != null) {
                int backgroundColor = UiUtils.themeAttributeToColor(
                        R.attr.colorPrimary, view.getContext(), R.color.zui_color_primary);
                background.setColorFilter(new PorterDuffColorFilter(backgroundColor, PorterDuff.Mode.SRC_ATOP));
                view.setBackground(background);
            } else {
                Logger.w(LOG_TAG, "Failed to set background, " +
                        "resource R.drawable.zui_background_end_user_cell could not be found");
            }
        }
    }

    /**
     * Set the background filter of the given {@link ImageView}
     *
     * @param state     the {@link EndUserCellBaseState} of the cell
     * @param imageView the {@link ImageView} to be updated
     * @param context   an instance of {@link Context}
     */
    static void setImageViewColorFilter(EndUserCellBaseState state,
                                        ImageView imageView,
                                        Context context) {
        if (isFailedCell(state)) {
            int failureColor = UiUtils.resolveColor(ERROR_BACKGROUND_COLOR, context);
            imageView.setColorFilter(failureColor, PorterDuff.Mode.MULTIPLY);
        } else if (state.getStatus() == MessagingItem.Query.Status.PENDING) {
            int pendingColor = UiUtils.resolveColor(PENDING_COLOR, context);
            imageView.setColorFilter(pendingColor, PorterDuff.Mode.MULTIPLY);
        } else {
            imageView.clearColorFilter();
        }
    }

    /**
     * Set the appropriate error message for the failure label
     *
     * @param state    the {@link EndUserCellBaseState} of the cell
     * @param textView the {@link TextView} to be updated
     * @param context  an instance of {@link Context}
     */
    static void setLabelErrorMessage(EndUserCellBaseState state,
                                     TextView textView,
                                     Context context) {
        if (!isFailedCell(state)) {
            textView.setVisibility(View.GONE);
            return;
        }
        textView.setVisibility(View.VISIBLE);
        if (state instanceof EndUserCellFileState) {
            textView.setText(getAttachmentLabelErrorMessage((EndUserCellFileState) state, context));
        } else {
            textView.setText(context.getString(TAP_TO_RETRY));
        }
    }

    /**
     * Get the label error message for a failed attachment delivery
     *
     * @param state   the {@link EndUserCellFileState} of the cell
     * @param context an instance of {@link Context}
     * @return the label message {@link String}
     */
    private static String getAttachmentLabelErrorMessage(EndUserCellFileState state,
                                                         Context context) {
        if (state.getStatus() == MessagingItem.Query.Status.FAILED) {
            return context.getString(TAP_TO_RETRY);
        } else {
            return getAttachmentNonRetryableErrorMessage(state, context);
        }
    }

    /**
     * Get the label error message for a non-retryable failed attachment delivery
     *
     * @param state   the {@link EndUserCellFileState} of the cell
     * @param context an instance of {@link Context}
     * @return the label message {@link String}
     */
    private static String getAttachmentNonRetryableErrorMessage(EndUserCellFileState state,
                                                                Context context) {

        final String defaultErrorMessage = context.getString(ATTACHMENT_COULD_NOT_BE_SENT);

        if (state.getFailureReason() == null) {
            return defaultErrorMessage;
        }

        switch (state.getFailureReason()) {
            case FILE_SIZE_TOO_LARGE:
                if (state.getAttachmentSettings() != null) {
                    return context.getString(
                            EXCEEDING_MAX_FILE_SIZE,
                            formatFileSize(context, state.getAttachmentSettings().getMaxFileSize())
                    );
                } else {
                    return defaultErrorMessage;
                }
            case FILE_SENDING_DISABLED:
                return context.getString(ATTACHMENTS_NOT_SUPPORTED);
            case UNSUPPORTED_FILE_TYPE:
                return context.getString(ATTACHMENT_TYPE_NOT_SUPPORTED);
            default:
                return defaultErrorMessage;
        }
    }

    /**
     * Set the retry click listener for an end user cell
     *
     * @param state the {@link EndUserCellBaseState} of the cell
     * @param view  the {@link View} to be updated
     */
    static void setClickListener(
            final EndUserCellBaseState state,
            final View view
    ) {
        if (state instanceof EndUserCellMessageState) {
            setMessageClickListener((EndUserCellMessageState) state, view);
        } else if (state instanceof EndUserCellFileState) {
            setAttachmentClickListener((EndUserCellFileState) state, view);
        }
    }

    /**
     * Sets the click listener for an end user text message cell
     *
     * @param state the {@link EndUserCellMessageState} of the cell
     * @param view  the {@link View} to be updated
     */
    private static void setMessageClickListener(final EndUserCellMessageState state,
                                                final View view) {
        if (state.getStatus() == FAILED || state.getStatus() == FAILED_NO_RETRY) {
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (state.getMessageActionListener() != null) {
                        state.getMessageActionListener().retry(state.getId());
                    }
                }
            });
        }
    }

    /**
     * Sets the click listener for an end user attachment cell
     *
     * @param state the {@link EndUserCellFileState} of the cell
     * @param view  the {@link View} to be updated
     */
    private static void setAttachmentClickListener(
            final EndUserCellFileState state,
            final View view
    ) {
        switch (state.getStatus()) {
            case PENDING:
            case FAILED_NO_RETRY: {
                view.setOnClickListener(null);
                break;
            }
            case FAILED: {
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (state.getMessageActionListener() != null) {
                            state.getMessageActionListener().retry(state.getId());
                        }
                    }
                });
                break;
            }
            case DELIVERED:
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        openAttachment(view, state.getAttachment().getUrl());
                    }
                });
                break;
        }
    }

    /**
     * Sets the long click listener for an end user cell
     *
     * @param state the {@link EndUserCellBaseState} of the cell
     * @param view  the {@link View} to be updated
     */
    static void setLongClickListener(final EndUserCellBaseState state,
            final View view) {
        view.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                MessagePopUpHelper.showPopUpMenu(
                        view,
                        getMenuOptions(state.getStatus()),
                        state.getMessageActionListener(),
                        state.getId());
                return true;
            }
        });
    }

    /**
     * Gets the possible menu options to be displayed on long click of a cell
     *
     * @param queryStatus The {@link zendesk.classic.messaging.MessagingItem.Query.Status} of
     * the {@link MessagingItem}.
     * @return a {@link Set} of {@link zendesk.classic.messaging.ui.MessagePopUpHelper.Option}s
     */
    private static Set<MessagePopUpHelper.Option> getMenuOptions(MessagingItem.Query.Status queryStatus) {
        Set<MessagePopUpHelper.Option> options = new HashSet<>(2);

        if (queryStatus == MessagingItem.Query.Status.FAILED) {
            options.add(MessagePopUpHelper.Option.DELETE);
            options.add(MessagePopUpHelper.Option.RETRY);
        } else if (queryStatus == MessagingItem.Query.Status.FAILED_NO_RETRY) {
            options.add(MessagePopUpHelper.Option.DELETE);
        }
        return options;
    }

    /**
     * Gets a placeholder drawable to be used when loading remote images
     *
     * @param context the Context through which to access resources
     * @return the placeholder drawable
     */
    static Drawable getImageLoadingPlaceholder(Context context) {

        // We have to create the drawable like this as on pre lollipop version,  referencing the theme attr in
        // an xml drawable may cause a crash https://issuetracker.google.com/issues/36941443
        int primaryColor = UiUtils.themeAttributeToColor(R.attr.colorPrimary, context, R.color.zui_color_primary);
        int primaryColorDark = UiUtils.themeAttributeToColor(
                R.attr.colorPrimaryDark, context, R.color.zui_color_primary_dark);
        float cornerRadius = context.getResources().getDimension(R.dimen.zui_cell_bubble_corner_radius);

        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{primaryColorDark, primaryColor, primaryColorDark});

        gradientDrawable.setCornerRadius(cornerRadius);

        return gradientDrawable;
    }

    private UtilsEndUserCellView() {
        // Intentionally empty
    }
}
