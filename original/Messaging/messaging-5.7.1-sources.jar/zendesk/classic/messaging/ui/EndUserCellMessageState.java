package zendesk.classic.messaging.ui;

import zendesk.classic.messaging.MessagingItem;

/**
 * Describes the state for all image attachment end-user cell views
 */
class EndUserCellMessageState extends EndUserCellBaseState {

    private final String message;

    /**
     * Constructs an instance of {@link EndUserCellMessageState}
     *
     * @param id                    the id of the cell
     * @param props                 the {@link MessagingCellProps} of the cell
     * @param status                the {@link MessagingItem.Query.Status} of the messaging item
     * @param messageActionListener the {@link MessageActionListener} for the cell
     * @param message               the message input by the end user
     */
    EndUserCellMessageState(String id,
                            MessagingCellProps props,
                            MessagingItem.Query.Status status,
                            MessageActionListener messageActionListener,
                            String message) {
        super(id, props, status, messageActionListener);
        this.message = message;
    }

    /**
     * @return the user message {@link String}
     */
    String getMessage() {
        return message;
    }

    @SuppressWarnings("EqualsReplaceableByObjectsCall")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        EndUserCellMessageState that = (EndUserCellMessageState) o;

        return message != null ? message.equals(that.message) : that.message == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (message != null ? message.hashCode() : 0);
        return result;
    }
}
