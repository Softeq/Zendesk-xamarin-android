package zendesk.classic.messaging.ui;

import zendesk.classic.messaging.MessagingItem;

/**
 * Describes the base state for all end-user cell views
 */
abstract class EndUserCellBaseState {

    private final String id;
    private final MessagingCellProps props;
    private final MessagingItem.Query.Status status;
    private final MessageActionListener messageActionListener;

    /**
     * Constructs a new instance of {@link EndUserCellBaseState}
     *
     * @param id                    the id of the cell
     * @param props                 the {@link MessagingCellProps} of the cell
     * @param status                the {@link MessagingItem.Query.Status} of the messaging item
     * @param messageActionListener the {@link MessageActionListener} for the cell
     */
    EndUserCellBaseState(String id,
                         MessagingCellProps props,
                         MessagingItem.Query.Status status,
                         MessageActionListener messageActionListener) {
        this.id = id;
        this.props = props;
        this.status = status;
        this.messageActionListener = messageActionListener;
    }

    /**
     * @return the id for this cell
     */
    String getId() {
        return id;
    }

    /**
     * @return the {@link MessagingCellProps} for this cell
     */
    MessagingCellProps getProps() {
        return props;
    }

    /**
     * @return the {@link zendesk.classic.messaging.MessagingItem.Query.Status} for this cell
     */
    MessagingItem.Query.Status getStatus() {
        return status;
    }

    /**
     * @return the {@link MessageActionListener} for this cell
     */
    MessageActionListener getMessageActionListener() {
        return messageActionListener;
    }

    @SuppressWarnings("EqualsReplaceableByObjectsCall")
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        EndUserCellBaseState that = (EndUserCellBaseState) o;

        if (id != null ? !id.equals(that.id) : that.id != null) {
            return false;
        }
        if (props != null ? !props.equals(that.props) : that.props != null) {
            return false;
        }
        if (status != that.status) {
            return false;
        }

        return (messageActionListener != null) == (that.messageActionListener == null);
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (props != null ? props.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (messageActionListener != null ? messageActionListener.hashCode() : 0);
        return result;
    }
}
