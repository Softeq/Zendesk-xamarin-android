package zendesk.classic.messaging.ui;

interface MessageActionListener {

    void delete(String messagingItemId);

    void retry(String messagingItemId);

    void copy(String messagingItemId);
    
}
