package zendesk.classic.messaging.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.text.format.Formatter;
import android.view.View;

import com.google.android.material.snackbar.Snackbar;
import com.zendesk.logger.Logger;
import com.zendesk.util.FileUtils;
import com.zendesk.util.MimeUtils;

import zendesk.classic.messaging.R;
  
class UtilsAttachment {

    static final String MESSAGING_BASE_PATH = "zendesk/messaging";
    private static final String LOG_TAG = "AttachmentUtils";


    /**
     * Formats a file size to be in form of bytes, kilobytes, megabytes, etc
     *
     * @param context  Context used to load localized units
     * @param fileSize File size to be formatted, in bytes
     * @return Formatted file size made of size value and localized unit, eg. 20Mt given Finnish language
     */
    static String formatFileSize(Context context, long fileSize) {
        // Formatter in O and later interprets file size in SI system instead of powers of 1024
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // convert into SI system
            fileSize = fileSize * 1000 * 1000 / 1024 / 1024;
        }

        return Formatter.formatFileSize(context, fileSize);
    }

    static void openAttachment(View view, String filePath) {
        final Context context = view.getContext();

        Uri fileUrl = Uri.parse(filePath);
        String contentType = getMimeTypeForFile(filePath);

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(fileUrl, contentType);

        if (contentType != null && contentType.startsWith("image")) {
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.LOLLIPOP) {
                intent.setData(fileUrl);
            }
            context.startActivity(intent);
            return;
        }

        intent.setData(fileUrl);
        if (intent.resolveActivity(context.getPackageManager()) != null) {
            context.startActivity(intent);
            return;
        }

        Logger.e(LOG_TAG, "Unable to open attachment. No app found that can receive the implicit intent");
        Snackbar.make(view, R.string.zui_unable_open_file, Snackbar.LENGTH_SHORT).show();
    }

    private static String getMimeTypeForFile(String path) {
        String extension = FileUtils.getFileExtension(path);
        return MimeUtils.guessMimeTypeFromExtension(extension);
    }

    private UtilsAttachment() {
        // Private constructor no instances plz
    }
}
