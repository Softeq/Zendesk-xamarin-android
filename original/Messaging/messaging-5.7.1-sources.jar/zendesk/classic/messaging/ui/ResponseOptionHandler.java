package zendesk.classic.messaging.ui;

import zendesk.classic.messaging.MessagingItem;

interface ResponseOptionHandler {

    void onResponseOptionSelected(MessagingItem.Option responseOption);

}
