package zendesk.classic.messaging.ui;

import android.graphics.drawable.Drawable;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.io.File;

import zendesk.commonui.PicassoTransformations;

class UtilsCellView {

    private UtilsCellView() {
    }

    /**
     * Load an image into the given {@link ImageView} from a remote URL
     *
     * @param Picasso an instance of {@link PicassoCompat} for loading the image
     * @param imagePath     the remote URL of the image
     * @param imageView     the {@link ImageView} to hold the image
     * @param cornerRadius  the corner radius for the resulting image
     * @param placeholder   the placeholder {@link Drawable} for use while loading the image
     */
    static void loadImageWithRoundedCorners(
            final Picasso picasso,
            final String imagePath,
            final ImageView imageView,
            final int cornerRadius,
            final Drawable placeholder) {

        imageView.post(new Runnable() {
            @Override
            public void run() {
                picasso.load(imagePath)
                        .placeholder(placeholder)
                        .resize(imageView.getMeasuredWidth(), imageView.getMeasuredHeight())
                        .transform(PicassoTransformations.getRoundedTransformation(cornerRadius))
                        .centerCrop()
                        .into(imageView);
            }
        });
    }

    /**
     * Load an image into the given {@link ImageView} from a local file
     *
     * @param Picasso an instance of {@link PicassoCompat} for loading the image
     * @param imageFile     the local {@link File} of the image
     * @param imageView     the {@link ImageView} to hold the image
     * @param cornerRadius  the corner radius for the resulting image
     * @param placeholder   the placeholder {@link Drawable} for use while loading the image
     */
    static void loadImageWithRoundedCornersFromFile(
            final Picasso picasso,
            final File imageFile,
            final ImageView imageView,
            final int cornerRadius,
            final Drawable placeholder) {

        imageView.post(new Runnable() {
            @Override
            public void run() {
                picasso.load(imageFile)
                        .placeholder(placeholder)
                        .resize(imageView.getMeasuredWidth(), imageView.getMeasuredHeight())
                        .transform(PicassoTransformations.getRoundedTransformation(cornerRadius))
                        .centerCrop()
                        .into(imageView);
            }
        });
    }
}
