package zendesk.classic.messaging.ui;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;

import com.squareup.picasso.Picasso;
import com.zendesk.util.StringUtils;

import javax.inject.Inject;

import zendesk.classic.messaging.MessagingActivityScope;
import zendesk.classic.messaging.R;

@MessagingActivityScope
class AvatarStateRenderer {

    private static final String LATIN_CHARACTER_REGEX = "[a-zA-Z]";
    @DrawableRes
    private static final int DEFAULT_AVATAR_DRAWABLE = R.drawable.zui_ic_default_avatar_16;

    private final Picasso picasso;

    @Inject
    public AvatarStateRenderer(@NonNull Picasso picasso) {
        this.picasso = picasso;
    }

    void render(@NonNull AvatarState avatarState, @NonNull AvatarView avatarView) {
        if (StringUtils.hasLength(avatarState.getAvatarUrl())) {
            avatarView.showImage(picasso, avatarState.getAvatarUrl());
        } else if (avatarState.getAvatarRes() != null) {
            avatarView.showDrawable(avatarState.getAvatarRes());
        } else if (StringUtils.hasLength(avatarState.getAvatarLetter())
                && avatarState.getAvatarLetter().matches(LATIN_CHARACTER_REGEX)) {
            avatarView.showLetter(avatarState.getAvatarLetter(), avatarState.getUniqueIdentifier());
        } else {
            avatarView.showDefault(DEFAULT_AVATAR_DRAWABLE, avatarState.getUniqueIdentifier());
        }
    }

}
