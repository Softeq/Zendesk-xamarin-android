package zendesk.classic.messaging.ui;

import androidx.lifecycle.Observer;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.annotation.VisibleForTesting;
import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;

import com.zendesk.util.StringUtils;

import javax.inject.Inject;

import zendesk.classic.messaging.MediaInMemoryDataSource;
import zendesk.classic.messaging.MessagingActivityScope;
import zendesk.classic.messaging.MessagingViewModel;
import zendesk.classic.messaging.TypingEventDispatcher;
import zendesk.commonui.BottomSheetAttachmentViewMenu;
import zendesk.commonui.TextWatcherAdapter;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

/**
 * A component to coordinate user input in a conversation. It can be bound to an {@link InputBox} so
 * it can have its behaviour set according to the current {@link zendesk.classic.messaging.Engine}.
 * <p>
 */
@RestrictTo(LIBRARY_GROUP)
@MessagingActivityScope
public class MessagingComposer {

    @VisibleForTesting
    static final int DEFAULT_HINT = R.string.zui_hint_type_message;

    private final AppCompatActivity activity;
    private final MessagingViewModel viewModel;
    private final MediaInMemoryDataSource mediaInMemoryDataSource;
    private final InputBoxConsumer inputBoxConsumer;
    private final TypingEventDispatcher typingEventDispatcher;

    @Inject
    public MessagingComposer(AppCompatActivity appCompatActivity,
                             MessagingViewModel messagingViewModel,
                             MediaInMemoryDataSource mediaInMemoryDataSource,
                             InputBoxConsumer inputBoxConsumer,
                             TypingEventDispatcher typingEventDispatcher) {
        this.activity = appCompatActivity;
        this.viewModel = messagingViewModel;
        this.mediaInMemoryDataSource = mediaInMemoryDataSource;
        this.inputBoxConsumer = inputBoxConsumer;
        this.typingEventDispatcher = typingEventDispatcher;
    }

    /**
     * Sets all required behaviours to the received {@link InputBox} as well as starts observing
     * state updates.
     *
     * @param inputBox an {@link InputBox} that is currently on the screen
     */
    public void bind(@NonNull final InputBox inputBox, BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu) {
        inputBox.setInputTextConsumer(inputBoxConsumer);
        inputBox.setInputTextWatcher(new TextWatcherAdapter() {
            @Override
            public void afterTextChanged(Editable s) {
                typingEventDispatcher.onTyping();
            }
        });

        inputBox.setAttachmentsCount(mediaInMemoryDataSource.getCount());

        viewModel.getLiveMessagingState().observe(activity, new Observer<MessagingState>() {
            @Override
            public void onChanged(@Nullable MessagingState messagingState) {
                renderState(messagingState, inputBox, bottomSheetAttachmentViewMenu);
            }
        });
    }

    /**
     * Updates the views according to the received {@link MessagingState} if it is not null.
     *
     * @param state    the new {@link MessagingState}
     * @param inputBox the {@link InputBox} to be updated
     */
    @VisibleForTesting
    void renderState(@Nullable MessagingState state, @NonNull InputBox inputBox, @NonNull BottomSheetAttachmentViewMenu bottomSheetAttachmentViewMenu) {
        if (state != null) {
            String hint = StringUtils.hasLength(state.hint) ? state.hint : activity.getString(DEFAULT_HINT);
            inputBox.setHint(hint);
            inputBox.setEnabled(state.enabled);
            inputBox.setInputType(state.keyboardInputType);

            if (state.attachmentSettings != null && state.attachmentSettings.isSendingEnabled()) {
                inputBox.setAttachmentsIndicatorClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        bottomSheetAttachmentViewMenu.showMenu();
                        viewModel.setCounterValue(0);
                        mediaInMemoryDataSource.clear();
                    }
                });
                inputBox.setAttachmentsCount(mediaInMemoryDataSource.getCount());
            } else {
                inputBox.setAttachmentsIndicatorClickListener(null);
            }
        }
    }
}
