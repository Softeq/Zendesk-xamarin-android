package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

import androidx.annotation.DimenRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;

import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class ResponseOptionsView extends FrameLayout implements Updatable<ResponseOptionsViewState> {

    private static final String LOG_TAG = "ResponseOptionsView";

    private ResponseOptionsAdapter adapter;

    public ResponseOptionsView(Context context) {
        super(context);
        init();
    }

    public ResponseOptionsView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ResponseOptionsView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        inflate(getContext(), R.layout.zui_view_response_options_content, this);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        RecyclerView recyclerView = findViewById(R.id.zui_response_options_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, true));

        adapter = new ResponseOptionsAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.addItemDecoration(new ItemOffsetDecoration(getContext(),
                R.dimen.zui_cell_response_options_horizontal_spacing));
    }

    @Override
    public void update(final ResponseOptionsViewState state) {
        state.getProps().apply(this);
        adapter.setResponseOptionHandler(new ResponseOptionHandler() {
            @Override
            public void onResponseOptionSelected(MessagingItem.Option responseOption) {
                adapter.submitList(Collections.singletonList(responseOption));
                state.getListener().onResponseOptionSelected(responseOption);
            }
        });
        adapter.submitList(state.getOptions());
    }

    private static class ItemOffsetDecoration extends RecyclerView.ItemDecoration {

        private int itemOffset;

        ItemOffsetDecoration(@NonNull Context context, @DimenRes int itemOffsetId) {
            itemOffset = context.getResources().getDimensionPixelSize(itemOffsetId);
        }

        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent,
                                   @NonNull RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);

            int position = parent.getChildAdapterPosition(view);

            if (position == -1) {
                return;
            }

            boolean isFirstItem = position == 0;

            boolean ltr = ViewCompat.getLayoutDirection(parent) == ViewCompat.LAYOUT_DIRECTION_LTR;

            if (ltr) {
                if (!isFirstItem) {
                    outRect.set(0, 0, itemOffset, 0);
                }
            } else {
                if (!isFirstItem) {
                    outRect.set(itemOffset, 0, 0, 0);
                }
            }
        }
    }
}
