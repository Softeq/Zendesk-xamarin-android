package zendesk.classic.messaging.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.transition.Slide;
import androidx.transition.Transition;
import androidx.transition.TransitionListenerAdapter;
import androidx.transition.TransitionManager;
import androidx.transition.TransitionSet;
import androidx.recyclerview.widget.RecyclerView;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.TextView;

import java.util.concurrent.atomic.AtomicReference;

import zendesk.classic.messaging.ConnectionState;
import zendesk.classic.messaging.R;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static zendesk.classic.messaging.ui.MessagingView.DEFAULT_ANIMATION_DURATION;
import static zendesk.classic.messaging.ui.ValueAnimators.topMarginAnimator;
import static zendesk.classic.messaging.ui.ValueAnimators.topPaddingAnimator;

/**
 * Banner displayed under the toolbar when connection gets lost.
 */
class LostConnectionBanner {

    static LostConnectionBanner create(ViewGroup rootView,
                                       RecyclerView recyclerView,
                                       InputBox inputBox) {
        return new LostConnectionBanner(
                rootView,
                recyclerView,
                inputBox,
                rootView.findViewById(R.id.zui_lost_connection_view)
        );
    }
    
    private final TransitionSet showAnimation;
    private final AnimatorSet hideAnimation;
    private final ViewGroup rootView;
    private final View lostConnectionBanner;
    private final TextView lostConnectionTextView;
    private final Button lostConnectionButton;
    private final AtomicReference<ConnectionState> currentConnectionState;
    private View.OnClickListener onRetryConnectionClickListener;
    private State state = State.EXITED;

    private LostConnectionBanner(final ViewGroup rootView,
                                 final RecyclerView recyclerView,
                                 final InputBox inputBox,
                                 final View lostConnectionBanner) {
        this.rootView = rootView;
        this.lostConnectionBanner = lostConnectionBanner;
        this.currentConnectionState = new AtomicReference<>(ConnectionState.DISCONNECTED);

        lostConnectionTextView = lostConnectionBanner
                .findViewById(R.id.zui_lost_connection_label);
        lostConnectionButton = lostConnectionBanner
                .findViewById(R.id.zui_lost_connection_button);

        lostConnectionBanner
                .findViewById(R.id.zui_lost_connection_button)
                .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (onRetryConnectionClickListener != null) {
                            onRetryConnectionClickListener.onClick(v);
                        }
                    }
                });

        showAnimation = new TransitionSet()
                .setOrdering(TransitionSet.ORDERING_TOGETHER)
                .addTransition(new Slide(Gravity.TOP))
                .setInterpolator(new DecelerateInterpolator())
                .setDuration(DEFAULT_ANIMATION_DURATION)
                .addListener(new TransitionListenerAdapter() {
                    final int originalPaddingTop = recyclerView.getPaddingTop();
                    
                    @Override
                    public void onTransitionEnd(@NonNull Transition transition) {
                        recyclerView.setPadding(
                                recyclerView.getPaddingLeft(),
                                recyclerView.getPaddingTop() + lostConnectionBanner.getHeight(),
                                recyclerView.getPaddingRight(),
                                Math.max(inputBox.getHeight(), recyclerView.getHeight()
                                        - recyclerView.computeVerticalScrollRange()
                                        - originalPaddingTop)
                        );
                        state = State.ENTERED;
                    }

                    @Override
                    public void onTransitionStart(@NonNull Transition transition) {
                        state = State.ENTERING;
                    }
                });

        final ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) lostConnectionBanner
                .getLayoutParams();

        hideAnimation = new AnimatorSet();
        hideAnimation.playTogether(
                topPaddingAnimator(
                        recyclerView,
                        recyclerView.getPaddingTop(),
                        recyclerView.getPaddingTop() - lostConnectionBanner.getHeight(),
                        DEFAULT_ANIMATION_DURATION),
                topMarginAnimator(
                        lostConnectionBanner,
                        params.topMargin,
                        params.topMargin - lostConnectionBanner.getHeight(),
                        DEFAULT_ANIMATION_DURATION
                )
        );

        hideAnimation.setInterpolator(new AccelerateInterpolator());
        hideAnimation.addListener(new AnimatorListenerAdapter() {
            private final int originalMargin = params.topMargin;
            private final int originalPaddingBottom = recyclerView.getPaddingBottom();

            @Override
            public void onAnimationEnd(Animator animation) {
                params.topMargin = originalMargin;
                lostConnectionBanner.setLayoutParams(params);
                lostConnectionBanner.setVisibility(GONE);
                recyclerView.setPadding(
                        recyclerView.getPaddingLeft(),
                        recyclerView.getPaddingTop(),
                        recyclerView.getPaddingRight(),
                        originalPaddingBottom + inputBox.getHeight()
                );
                state = State.EXITED;
            }

            @Override
            public void onAnimationStart(Animator animation) {
                state = State.EXITING;
            }
        });
    }

    /**
     * Sets a click listener to be called when retry button gets clicked.
     *
     * @param onRetryConnectionClickListener {@link View.OnClickListener} or null.
     */
    void setOnRetryConnectionClickListener(@Nullable View.OnClickListener onRetryConnectionClickListener) {
        this.onRetryConnectionClickListener = onRetryConnectionClickListener;
    }

    /**
     * Updates banner based on incoming connection state.
     *
     * @param connectionState Current connection state
     */
    void update(@NonNull ConnectionState connectionState) {
        if (currentConnectionState.getAndSet(connectionState) == connectionState) {
            return;
        }

        switch (connectionState) {
            case RECONNECTING:
                lostConnectionTextView.setText(R.string.zui_label_reconnecting);
                lostConnectionButton.setVisibility(GONE);
                show();
                return;
            case UNREACHABLE:
                lostConnectionTextView.setText(R.string.zui_label_reconnecting_failed);
                lostConnectionButton.setVisibility(GONE);
                show();
                return;
            case FAILED:
                lostConnectionTextView.setText(R.string.zui_label_reconnecting_failed);
                lostConnectionButton.setVisibility(VISIBLE);
                show();
                return;
            case CONNECTING:
            case CONNECTED:
            case DISCONNECTED:
                hide();
        }
    }

    /**
     * Slides the banner from under the toolbar.
     */
    void show() {
        switch (state) {
            case ENTERING:
            case ENTERED:
                return;
        }

        TransitionManager.beginDelayedTransition(rootView, showAnimation);
        lostConnectionBanner.setVisibility(VISIBLE);
    }

    /**
     * Slides the banner under the toolbar.
     */
    void hide() {
        switch (state) {
            case EXITED:
            case EXITING:
                return;
            case ENTERING:
                // hide banner once show animation finishes
                showAnimation.addListener(new TransitionListenerAdapter() {
                    @Override
                    public void onTransitionEnd(@NonNull Transition transition) {
                        hide();
                        showAnimation.removeListener(this);
                    }
                });
                return;
        }

        hideAnimation.start();
    }

    /**
     * All possible states of the banner.
     */
    private enum State {
        /**
         * Banner is entering by sliding from under the toolbar.
         */
        ENTERING,
        /**
         * Show animation finished and banner is now in the final position.
         */
        ENTERED,
        /**
         * Banner is exiting by sliding under the toolbar.
         */
        EXITING,
        /**
         * Banner is hidden.
         */
        EXITED
    }
}
