package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.PorterDuff;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.widget.ProgressBar;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * A simple, indeterminate circular progress bar to be displayed while attachments are uploaded.
 * <p>
 * Its color is determined by the theme.
 */
@RestrictTo(LIBRARY)
public class FileUploadProgressView extends ProgressBar {

    public FileUploadProgressView(Context context) {
        super(context);
        init();
    }

    public FileUploadProgressView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public FileUploadProgressView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setIndeterminate(true);

        int color = UiUtils.themeAttributeToColor(R.attr.colorPrimary, getContext(), R.color.zui_color_primary);
        getIndeterminateDrawable().setColorFilter(color, PorterDuff.Mode.SRC_IN);
    }
}
