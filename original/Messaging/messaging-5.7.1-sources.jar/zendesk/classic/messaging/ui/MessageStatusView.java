package zendesk.classic.messaging.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.widget.ImageViewCompat;
import android.util.AttributeSet;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class MessageStatusView extends androidx.appcompat.widget.AppCompatImageView {

    private int failedIconColor;
    private int deliveredIconColor;
    private int pendingIconColor;

    public MessageStatusView(Context context) {
        super(context);
        init();
    }

    public MessageStatusView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public MessageStatusView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        deliveredIconColor = UiUtils.themeAttributeToColor(
                R.attr.colorPrimary, getContext(), R.color.zui_color_primary);
        failedIconColor = UiUtils.resolveColor(R.color.zui_error_text_color, getContext());
        pendingIconColor = UiUtils.resolveColor(R.color.zui_cell_pending_indicator_color, getContext());
    }

    public void setStatus(MessagingItem.Query.Status status) {
        switch (status) {
            case FAILED:
            case FAILED_NO_RETRY:
                ImageViewCompat.setImageTintList(this, ColorStateList.valueOf(failedIconColor));
                setImageResource(R.drawable.zui_ic_status_fail);
                break;
            case DELIVERED:
                ImageViewCompat.setImageTintList(this, ColorStateList.valueOf(deliveredIconColor));
                setImageResource(R.drawable.zui_ic_status_sent);
                break;
            case PENDING:
                ImageViewCompat.setImageTintList(this, ColorStateList.valueOf(pendingIconColor));
                setImageResource(R.drawable.zui_ic_status_pending);
                break;
            default:
                setImageResource(0);
                break;
        }
    }

}
