package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.vectordrawable.graphics.drawable.Animatable2Compat;
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class TypingIndicatorView extends LinearLayout implements Updatable<TypingIndicatorView.State> {

    private AvatarView avatarView;
    private TextView labelField;
    private View labelContainer;
    private View botLabel;
    private ImageView typingIndicator;

    public TypingIndicatorView(@NonNull Context context) {
        super(context);
        init();
    }

    public TypingIndicatorView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public TypingIndicatorView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(HORIZONTAL);
        inflate(getContext(), R.layout.zui_view_typing_indicator_content, this);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        avatarView = findViewById(R.id.zui_agent_message_avatar);
        labelContainer = findViewById(R.id.zui_cell_status_view);
        labelField = findViewById(R.id.zui_cell_label_text_field);
        botLabel = findViewById(R.id.zui_cell_label_supplementary_label);
        typingIndicator = findViewById(R.id.zui_cell_typing_indicator_image);

        startAnimatedDrawable();
    }

    private void startAnimatedDrawable() {
        Drawable imageViewDrawable = typingIndicator.getDrawable();

        AnimatedVectorDrawableCompat.registerAnimationCallback(imageViewDrawable, animationLoopCallback);
        ((Animatable) imageViewDrawable).start();
    }

    private final Animatable2Compat.AnimationCallback animationLoopCallback =
            new Animatable2Compat.AnimationCallback() {
                @Override
                public void onAnimationEnd(final Drawable drawable) {
                    post(new Runnable() {
                        @Override
                        public void run() {
                            ((Animatable) drawable).start();
                        }
                    });
                }
            };

    @Override
    public void update(State state) {
        if (state.getLabel() != null) {
            labelField.setText(state.getLabel());
        }
        botLabel.setVisibility(state.isBot() ? VISIBLE : GONE);
        state.getAvatarStateRenderer().render(state.getAvatarState(), avatarView);
        state.getProps().apply(this, labelContainer, avatarView);
    }

    static class State {

        private final MessagingCellProps props;
        @Nullable
        private final String label;
        private final boolean isBot;
        private final AvatarState avatarState;
        private final AvatarStateRenderer avatarStateRenderer;

        State(MessagingCellProps props,
                @Nullable String label,
                boolean isBot,
                AvatarState avatarState,
                AvatarStateRenderer avatarStateRenderer) {
            this.props = props;
            this.label = label;
            this.isBot = isBot;
            this.avatarState = avatarState;
            this.avatarStateRenderer = avatarStateRenderer;
        }

        MessagingCellProps getProps() {
            return props;
        }

        @Nullable
        String getLabel() {
            return label;
        }

        boolean isBot() {
            return isBot;
        }

        AvatarState getAvatarState() {
            return avatarState;
        }

        AvatarStateRenderer getAvatarStateRenderer() {
            return avatarStateRenderer;
        }
    }
}
