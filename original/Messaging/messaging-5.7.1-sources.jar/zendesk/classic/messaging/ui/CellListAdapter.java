package zendesk.classic.messaging.ui;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

class CellListAdapter extends ListAdapter<MessagingCell, RecyclerView.ViewHolder> {

    CellListAdapter() {
        super(new CellDiffUtil());
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View view = LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false);
        return new RecyclerView.ViewHolder(view) {
            // Intentionally empty
        };
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        MessagingCell messagingCell = getItem(position);
        View itemView = holder.itemView;

        if (messagingCell.getViewClassType().isInstance(itemView)) {
            //noinspection unchecked the above instance check renders this safe
            messagingCell.bind(itemView);
        }
    }

    @Override
    public int getItemViewType(int position) {
        return getItem(position).getLayoutRes();
    }

    static class CellDiffUtil extends DiffUtil.ItemCallback<MessagingCell> {
        @Override
        public boolean areItemsTheSame(@NonNull MessagingCell oldItem, @NonNull MessagingCell newItem) {
            // Due to a bug with animations, this will remove all animations from the TypingIndicator cell.
            // This check should be removed when the underlying bug is fixed
            // See https://zendesk.atlassian.net/browse/SGA-831
            if (oldItem.getId().equals(MessagingCellFactory.TYPING_INDICATOR_ID)) {
                return false;
            }
            return oldItem.getId().equals(newItem.getId());
        }

        @Override
        public boolean areContentsTheSame(@NonNull MessagingCell oldItem, @NonNull MessagingCell newItem) {
            return oldItem.areContentsTheSame(newItem);
        }
    }
}
