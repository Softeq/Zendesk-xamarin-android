package zendesk.classic.messaging.ui;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.concurrent.TimeUnit;

import zendesk.classic.messaging.EventFactory;
import zendesk.classic.messaging.EventListener;
import zendesk.commonui.InsetType;
import zendesk.commonui.AlmostRealProgressBar;
import zendesk.classic.messaging.R;
import zendesk.commonui.SystemWindowInsets;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

@RestrictTo(LIBRARY_GROUP)
public class MessagingView extends CoordinatorLayout {

    public static final long DEFAULT_ANIMATION_DURATION = TimeUnit.MILLISECONDS.toMillis(300);

    private final AlmostRealProgressBar progressBar;
    private final CellListAdapter cellListAdapter;
    private final LostConnectionBanner lostConnectionBanner;

    public MessagingView(@NonNull Context context) {
        this(context, null);
    }

    public MessagingView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MessagingView(@NonNull Context context,
                         @Nullable AttributeSet attrs,
                         int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        LayoutInflater.from(context).inflate(R.layout.zui_view_messaging, this, true);

        progressBar = findViewById(R.id.zui_progressBar);
        cellListAdapter = new CellListAdapter();
        final LinearLayoutManager layoutManager = new LinearLayoutManager(context);
        final RecyclerView recyclerView = findViewById(R.id.zui_recycler_view);
        SystemWindowInsets.applyWindowInsets(recyclerView, InsetType.TOP);

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(cellListAdapter);
        /*
         Disable recycling for stacked response options due to an issue with calculating height
         There should never be more than one of these in the list at a time so should have little/no performance impact
        */
        recyclerView.getRecycledViewPool().setMaxRecycledViews(R.layout.zui_cell_response_options_stacked, 0);

        DefaultItemAnimator defaultItemAnimator = new DefaultItemAnimator();
        defaultItemAnimator.setAddDuration(DEFAULT_ANIMATION_DURATION);
        defaultItemAnimator.setChangeDuration(DEFAULT_ANIMATION_DURATION);
        defaultItemAnimator.setRemoveDuration(DEFAULT_ANIMATION_DURATION);
        defaultItemAnimator.setMoveDuration(DEFAULT_ANIMATION_DURATION);
        defaultItemAnimator.setSupportsChangeAnimations(false);
        recyclerView.setItemAnimator(defaultItemAnimator);

        final InputBox inputBox = findViewById(R.id.zui_input_box);
        lostConnectionBanner = LostConnectionBanner.create(this, recyclerView, inputBox);

        final RecyclerViewScroller scroller = new RecyclerViewScroller(recyclerView, layoutManager, cellListAdapter);
        scroller.install(inputBox);
    }

    public void renderState(@Nullable MessagingState state,
                            MessagingCellFactory messagingCellFactory,
                            Picasso picasso,
                            final EventListener eventListener,
                            final EventFactory eventFactory) {
        if (state == null) {
            return;
        }

        // do the magic
        cellListAdapter.submitList(messagingCellFactory.createCells(
                state.messagingItems,
                state.typingState,
                picasso,
                state.attachmentSettings));
        if (state.progressBarVisible) {
            progressBar.start(AlmostRealProgressBar.DONT_STOP_MOVING);
        } else {
            progressBar.stop(AlmostRealProgressBar.STOP_ANIMATION_DURATION);
        }

        lostConnectionBanner.update(state.connectionState);
        lostConnectionBanner.setOnRetryConnectionClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                eventListener.onEvent(eventFactory.reconnectButtonClick());
            }
        });
    }
}
