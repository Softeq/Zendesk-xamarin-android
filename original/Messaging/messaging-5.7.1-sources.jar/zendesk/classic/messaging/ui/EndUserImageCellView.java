package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;

@RestrictTo(RestrictTo.Scope.LIBRARY)
public class EndUserImageCellView extends LinearLayout implements Updatable<EndUserCellImageState> {

    private ImageView imageView;
    private FileUploadProgressView fileUploadProgressView;
    private MessageStatusView statusView;
    private TextView label;

    private int cornerRadiusPx;

    public EndUserImageCellView(@NonNull Context context) {
        super(context);
        init();
    }

    public EndUserImageCellView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public EndUserImageCellView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(VERTICAL);
        setGravity(Gravity.BOTTOM | Gravity.END);
        inflate(getContext(), R.layout.zui_view_end_user_image_cell_content, this);

        cornerRadiusPx = getResources().getDimensionPixelSize(R.dimen.zui_cell_bubble_corner_radius);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        imageView = findViewById(R.id.zui_image_cell_image);
        fileUploadProgressView = findViewById(R.id.zui_cell_file_upload_progress);
        statusView = findViewById(R.id.zui_cell_status_view);
        label = findViewById(R.id.zui_cell_label_message);
    }

    @Override
    public void update(final EndUserCellImageState state) {
        loadImageIntoImageView(state);

        if (state.getStatus() == MessagingItem.Query.Status.PENDING) {
            fileUploadProgressView.setVisibility(VISIBLE);
        } else {
            fileUploadProgressView.setVisibility(GONE);
        }

        statusView.setStatus(state.getStatus());

        UtilsEndUserCellView.setImageViewColorFilter(state, imageView, getContext());
        UtilsEndUserCellView.setLabelErrorMessage(state, label, getContext());
        UtilsEndUserCellView.setClickListener(state, this);
        UtilsEndUserCellView.setLongClickListener(state, this);

        state.getProps().apply(this, statusView);
    }

    /**
     * Load the local or remote image into the specified {@link ImageView}
     *
     * @param state the {@link EndUserCellImageState}
     */
    private void loadImageIntoImageView(EndUserCellImageState state) {
        Drawable placeholder = UtilsEndUserCellView.getImageLoadingPlaceholder(getContext());

        if (state.getAttachment().getFile() != null) {
            UtilsCellView.loadImageWithRoundedCornersFromFile(
                    state.getPicasso(),
                    state.getAttachment().getFile(),
                    imageView,
                    cornerRadiusPx,
                    placeholder
            );
        } else {
            UtilsCellView.loadImageWithRoundedCorners(
                    state.getPicasso(),
                    state.getAttachment().getUrl(),
                    imageView,
                    cornerRadiusPx,
                    placeholder
            );
        }
    }
}
