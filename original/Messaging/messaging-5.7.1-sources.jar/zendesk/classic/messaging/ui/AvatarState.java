package zendesk.classic.messaging.ui;

import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
class AvatarState {
    private final Object uniqueIdentifier;
    private final String avatarLetter;
    private final String avatarUrl;
    private final Integer avatarRes;

    public AvatarState(@NonNull Object uniqueIdentifier,
                       @Nullable String avatarLetter,
                       @Nullable String avatarUrl,
                       @Nullable @DrawableRes Integer avatarRes) {
        this.uniqueIdentifier = uniqueIdentifier;
        this.avatarLetter = avatarLetter;
        this.avatarUrl = avatarUrl;
        this.avatarRes = avatarRes;
    }

    Object getUniqueIdentifier() {
        return uniqueIdentifier;
    }

    String getAvatarLetter() {
        return avatarLetter;
    }

    String getAvatarUrl() {
        return avatarUrl;
    }

    Integer getAvatarRes() {
        return avatarRes;
    }
}
