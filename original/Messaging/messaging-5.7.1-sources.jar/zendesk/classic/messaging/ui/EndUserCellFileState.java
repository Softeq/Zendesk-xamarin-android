package zendesk.classic.messaging.ui;

import android.content.Context;
import androidx.annotation.Nullable;

import com.zendesk.util.FileUtils;

import java.util.Locale;

import zendesk.classic.messaging.Attachment;
import zendesk.classic.messaging.AttachmentSettings;
import zendesk.classic.messaging.MessagingItem;

import static zendesk.classic.messaging.ui.UtilsAttachment.formatFileSize;

/**
 * Describes the state for all file attachment end-user cell views
 */
class EndUserCellFileState extends EndUserCellBaseState {

    private static final String FILE_DESCRIPTOR_FORMATTER = "%s %s";

    private final Attachment attachment;
    @Nullable
    private final MessagingItem.FileQuery.FailureReason failureReason;
    @Nullable
    private final AttachmentSettings attachmentSettings;

    /**
     * Constructs an instance of {@link EndUserCellFileState}
     *
     * @param id                    the id of the cell
     * @param props                 the {@link MessagingCellProps} of the cell
     * @param status                the {@link MessagingItem.Query.Status} of the messaging item
     * @param messageActionListener the {@link MessageActionListener} for the cell
     * @param attachment            the {@link Attachment} describing the shared file
     * @param failureReason         the {@link MessagingItem.FileQuery.FailureReason} if
     *                              the attachment failed to send
     * @param attachmentSettings    the {@link AttachmentSettings} for this engine
     */
    EndUserCellFileState(String id,
                         MessagingCellProps props,
                         MessagingItem.Query.Status status,
                         MessageActionListener messageActionListener,
                         Attachment attachment,
                         @Nullable MessagingItem.FileQuery.FailureReason failureReason,
                         @Nullable AttachmentSettings attachmentSettings) {
        super(id, props, status, messageActionListener);
        this.attachment = attachment;
        this.failureReason = failureReason;
        this.attachmentSettings = attachmentSettings;
    }

    /**
     * @return the {@link Attachment} model
     */
    Attachment getAttachment() {
        return attachment;
    }

    /**
     * @return a {@link String} describing the file
     */
    String getFileDescriptor(Context context) {
        return String.format(
                Locale.US,
                FILE_DESCRIPTOR_FORMATTER,
                formatFileSize(context, attachment.getSize()),
                FileUtils.getFileExtension(attachment.getName())
        );
    }

    /**
     * @return the {@link zendesk.classic.messaging.MessagingItem.FileQuery.FailureReason}
     * if the attachment failed to send, null otherwise
     */
    @Nullable
    MessagingItem.FileQuery.FailureReason getFailureReason() {
        return failureReason;
    }

    @Nullable
    AttachmentSettings getAttachmentSettings() {
        return attachmentSettings;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        EndUserCellFileState that = (EndUserCellFileState) o;

        if (attachment != null ? !attachment.equals(that.attachment) : that.attachment != null) {
            return false;
        }
        if (failureReason != that.failureReason) {
            return false;
        }
        return attachmentSettings != null ? attachmentSettings.equals(that.attachmentSettings)
                : that.attachmentSettings == null;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (attachment != null ? attachment.hashCode() : 0);
        result = 31 * result + (failureReason != null ? failureReason.hashCode() : 0);
        result = 31 * result + (attachmentSettings != null ? attachmentSettings.hashCode() : 0);
        return result;
    }
}
