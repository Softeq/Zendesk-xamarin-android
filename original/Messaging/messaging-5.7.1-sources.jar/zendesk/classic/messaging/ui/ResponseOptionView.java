package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;

import androidx.annotation.RestrictTo;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import com.zendesk.logger.Logger;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.R;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ResponseOptionView extends AppCompatTextView {

    private static final String LOG_TAG = "ResponseOptionView";

    public ResponseOptionView(Context context) {
        super(context);
        init();
    }

    public ResponseOptionView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ResponseOptionView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {

        setBackgroundDrawable(ContextCompat.getDrawable(getContext(), R.drawable.zui_background_response_option));

        // We have to set these colors like this as on pre lollipop version,  referencing the theme attr in
        // the xml background drawable may cause a crash https://issuetracker.google.com/issues/36941443
        int primaryColor = UiUtils.themeAttributeToColor(
                R.attr.colorPrimary, getContext(), R.color.zui_color_primary);

        setTextColor(primaryColor);

        Drawable background = getBackground().mutate();
        if (background instanceof GradientDrawable) {
            int strokeWidth =
                    (int) getResources().getDimension(R.dimen.zui_cell_response_option_stroke_width);

            ((GradientDrawable) background).setStroke(strokeWidth, primaryColor);
        } else {
            Logger.w(LOG_TAG, "Unable to set stroke on background as background is not of type GradientDrawable");
        }
    }
}
