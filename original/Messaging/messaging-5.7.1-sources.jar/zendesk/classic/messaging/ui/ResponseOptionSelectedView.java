package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;

import androidx.annotation.RestrictTo;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.content.ContextCompat;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.R;

@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class ResponseOptionSelectedView extends AppCompatTextView {

    private static final String LOG_TAG = "ResponseOptionSelectedV";

    public ResponseOptionSelectedView(Context context) {
        super(context);
        init();
    }

    public ResponseOptionSelectedView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ResponseOptionSelectedView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setTextColor(ContextCompat.getColor(getContext(), R.color.zui_color_white_100));
        setBackgroundDrawable(ContextCompat.getDrawable(
                getContext(), R.drawable.zui_background_response_option_selected));

        // We have to set these colors like this as on pre lollipop version,  referencing the theme attr in
        // the xml background drawable may cause a crash https://issuetracker.google.com/issues/36941443
        int primaryColor = UiUtils.themeAttributeToColor(
                R.attr.colorPrimary, getContext(), R.color.zui_color_primary);

        Drawable background = getBackground().mutate();
        background.setColorFilter(new PorterDuffColorFilter(primaryColor, PorterDuff.Mode.SRC_ATOP));
    }
}
