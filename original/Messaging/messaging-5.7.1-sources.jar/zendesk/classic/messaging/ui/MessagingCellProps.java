package zendesk.classic.messaging.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

class MessagingCellProps {

    private final int labelVisibility;
    private final int cellSpacing;
    private final int avatarVisibility;


    MessagingCellProps(int labelVisibility,
                       int cellSpacing,
                       int avatarVisibility) {
        this.labelVisibility = labelVisibility;
        this.cellSpacing = cellSpacing;
        this.avatarVisibility = avatarVisibility;
    }

    void apply(@NonNull View view) {
        apply(view, null, null);
    }

    void apply(@NonNull View view,
               @Nullable View label) {
        apply(view, label, null);
    }

    void apply(@NonNull View view,
               @Nullable View label,
               @Nullable View avatarView) {
        if (label != null) {
            label.setVisibility(labelVisibility);
        }

        if (avatarView != null) {
            avatarView.setVisibility(avatarVisibility);
        }
        // apply bottom margin
        ((RecyclerView.LayoutParams) view.getLayoutParams()).bottomMargin = cellSpacing;
        view.requestLayout();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        MessagingCellProps props = (MessagingCellProps) o;

        //noinspection SimplifiableIfStatement
        if (labelVisibility != props.labelVisibility) {
            return false;
        }
        return cellSpacing == props.cellSpacing;
    }

    @Override
    public int hashCode() {
        int result = labelVisibility;
        result = 31 * result + cellSpacing;
        return result;
    }
}