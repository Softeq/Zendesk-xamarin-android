package zendesk.classic.messaging.ui;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

import java.util.List;

import javax.inject.Inject;

import zendesk.classic.messaging.MediaInMemoryDataSource;
import zendesk.classic.messaging.EventFactory;
import zendesk.classic.messaging.EventListener;
import zendesk.classic.messaging.MediaResolverCallback;
import zendesk.classic.messaging.MessagingActivityScope;
import zendesk.classic.messaging.Event;
import zendesk.classic.messaging.UriResolver;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;
import static com.zendesk.util.StringUtils.hasLength;

import android.net.Uri;

/**
 * <p>
 * If text is received then an {@link Event.MessageSubmitted} is sent to the
 * {@link EventListener}.
 * <p>
 */
@RestrictTo(LIBRARY_GROUP)
@MessagingActivityScope
public class InputBoxConsumer implements InputBox.InputTextConsumer {

    private final EventListener eventListener;
    private final EventFactory eventFactory;
    private final MediaInMemoryDataSource mediaInMemoryDataSource;
    private final UriResolver uriResolver;
    private final MediaResolverCallback callback;

    @Inject
    public InputBoxConsumer(EventListener eventListener,
                            EventFactory eventFactory,
                            MediaInMemoryDataSource mediaInMemoryDataSource,
                            UriResolver uriResolver,
                            MediaResolverCallback callback) {
        this.eventListener = eventListener;
        this.eventFactory = eventFactory;
        this.mediaInMemoryDataSource = mediaInMemoryDataSource;
        this.uriResolver = uriResolver;
        this.callback = callback;
    }

    @Override
    public boolean onConsumeText(@NonNull String text) {
        if (hasLength(text)) {
            eventListener.onEvent(eventFactory.textInput(text));
        }

        List<Uri> selectedAttachmentFiles = mediaInMemoryDataSource.getSelectedUris();

        if (!selectedAttachmentFiles.isEmpty()) {
            uriResolver.start(selectedAttachmentFiles, callback);

            mediaInMemoryDataSource.clear();
        }

        return true;
    }
}
