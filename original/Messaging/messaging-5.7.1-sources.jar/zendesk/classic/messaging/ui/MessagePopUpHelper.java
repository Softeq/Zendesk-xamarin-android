package zendesk.classic.messaging.ui;

import androidx.annotation.MenuRes;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.PopupMenu;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;

import java.util.Set;

import zendesk.classic.messaging.R;

class MessagePopUpHelper {

    private static final int COPY_MENU_ITEM_INDEX = 0;
    private static final int RETRY_MENU_ITEM_INDEX = 1;
    private static final int DELETE_MENU_ITEM_INDEX = 2;

    enum Option {
        COPY,
        RETRY,
        DELETE
    }

    static void showPopUpMenu(
            View targetView,
            final Set<Option> options,
            final MessageActionListener messageActionListener,
            final String messagingItemId) {

        PopupMenu.OnMenuItemClickListener onMenuItemClickListener =
                createOnMenuItemClickListener(messageActionListener, messagingItemId);

        PopupMenu popupMenu = createPopUpMenu(
                targetView,
                R.menu.zui_message_options_copy_retry_delete,
                onMenuItemClickListener);

        popupMenu.getMenu().getItem(COPY_MENU_ITEM_INDEX).setVisible(options.contains(Option.COPY));
        popupMenu.getMenu().getItem(RETRY_MENU_ITEM_INDEX).setVisible(options.contains(Option.RETRY));
        popupMenu.getMenu().getItem(DELETE_MENU_ITEM_INDEX).setVisible(options.contains(Option.DELETE));

        popupMenu.show();
    }

    private static PopupMenu createPopUpMenu(
            View view,
            @MenuRes int menuRes,
            PopupMenu.OnMenuItemClickListener onMenuItemClickListener) {

        PopupMenu popup = new PopupMenu(view.getContext(), view);
        popup.inflate(menuRes);
        popup.setOnMenuItemClickListener(onMenuItemClickListener);
        popup.setGravity(Gravity.END);
        return popup;
    }

    @Nullable
    private static PopupMenu.OnMenuItemClickListener createOnMenuItemClickListener(
            final MessageActionListener messageActionListener,
            final String messagingItemId) {

        if (messageActionListener == null) {
            return null;
        }
        return new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                if (menuItem.getItemId() == R.id.zui_failed_message_retry) {
                    messageActionListener.retry(messagingItemId);
                    return true;
                } else if (menuItem.getItemId() == R.id.zui_failed_message_delete) {
                    messageActionListener.delete(messagingItemId);
                    return true;
                } else if (menuItem.getItemId() == R.id.zui_message_copy) {
                    messageActionListener.copy(messagingItemId);
                    return true;
                } else {
                    return false;
                }
            }
        };
    }
}
