package zendesk.classic.messaging.ui;

/**
 * Marks a class as updatable with a given type. Used primarily for {@link MessagingCell} and implemented by all the
 * View classes we use to render a Messaging Conversation
 *
 * see {@link EndUserMessageView}
 * see {@link EndUserImageCellView}
 * see {@link EndUserFileCellView}
 * see {@link ResponseOptionsView}
 * see {@link AgentMessageView}
 * see {@link AgentImageCellView}
 * see {@link AgentFileCellView}
 * see {@link ArticlesResponseView}
 * see {@link ActionOptionsView}
 * see {@link SystemMessageView}
 *
 * @param <T>
 */
interface Updatable<T> {

    /**
     * Instructs the Updatable to update with the given data
     * @param t the data with which to Update
     */
    void update(T t);

}
