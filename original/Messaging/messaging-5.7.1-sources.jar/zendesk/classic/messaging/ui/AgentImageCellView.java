package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.content.ContextCompat;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import zendesk.classic.messaging.Attachment;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class AgentImageCellView extends LinearLayout implements Updatable<AgentImageCellView.State> {

    private final Drawable placeholder = ContextCompat.getDrawable(getContext(), R.drawable.zui_background_agent_cell);

    private AvatarView avatarView;
    private ImageView imageView;
    private TextView labelField;
    private View labelContainer;
    private View botLabel;

    private int cornerRadius;

    public AgentImageCellView(Context context) {
        super(context);
        init();
    }

    public AgentImageCellView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public AgentImageCellView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(HORIZONTAL);
        inflate(getContext(), R.layout.zui_view_agent_image_cell_content, this);
        cornerRadius = getResources().getDimensionPixelSize(R.dimen.zui_cell_bubble_corner_radius);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        avatarView = findViewById(R.id.zui_agent_message_avatar);
        imageView = findViewById(R.id.zui_image_cell_image);
        labelContainer = findViewById(R.id.zui_cell_status_view);
        labelField = findViewById(R.id.zui_cell_label_text_field);
        botLabel = findViewById(R.id.zui_cell_label_supplementary_label);
    }

    @Override
    public void update(final State state) {
        loadImageIntoImageView(state);

        labelField.setText(state.getLabel());
        botLabel.setVisibility(state.isBot() ? VISIBLE : GONE);

        imageView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                UtilsAttachment.openAttachment(v, state.getAttachment().getUrl());
            }
        });

        state.getAvatarStateRenderer().render(state.getAvatarState(), avatarView);
        state.getProps().apply(this, labelContainer, avatarView);
    }

    /**
     * Load the local or remote image into the specified {@link ImageView}
     *
     * @param state the {@link AgentImageCellView.State}
     */
    private void loadImageIntoImageView(AgentImageCellView.State state) {
        UtilsCellView.loadImageWithRoundedCorners(
                state.getPicasso(),
                state.getAttachment().getUrl(),
                imageView,
                cornerRadius,
                placeholder
        );
    }

    static class State {

        private final Picasso picasso;
        private final MessagingCellProps props;
        private final String label;
        private final boolean isBot;
        private final Attachment attachment;
        private final AvatarState avatarState;
        private final AvatarStateRenderer avatarStateRenderer;

        State(Picasso picasso,
                MessagingCellProps props,
                Attachment attachment,
                String label,
                boolean isBot,
                AvatarState avatarState,
                AvatarStateRenderer avatarStateRenderer) {
            this.picasso = picasso;
            this.props = props;
            this.attachment = attachment;
            this.label = label;
            this.isBot = isBot;
            this.avatarState = avatarState;
            this.avatarStateRenderer = avatarStateRenderer;
        }

        Picasso getPicasso() {
            return picasso;
        }

        MessagingCellProps getProps() {
            return props;
        }

        public Attachment getAttachment() {
            return attachment;
        }

        String getLabel() {
            return label;
        }

        boolean isBot() {
            return isBot;
        }

        AvatarState getAvatarState() {
            return avatarState;
        }

        AvatarStateRenderer getAvatarStateRenderer() {
            return avatarStateRenderer;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }

            State state = (State) o;

            if (isBot() != state.isBot()) {
                return false;
            }
            if (getPicasso() != null ? !getPicasso().equals(state.getPicasso()) : state.getPicasso() != null) {
                return false;
            }
            if (getProps() != null ? !getProps().equals(state.getProps()) : state.getProps() != null) {
                return false;
            }
            if (getLabel() != null ? !getLabel().equals(state.getLabel()) : state.getLabel() != null) {
                return false;
            }
            if (getAttachment() != null
                    ? !getAttachment().equals(state.getAttachment()) : state.getAttachment() != null) {
                return false;
            }
            return getAvatarState() != null
                    ? getAvatarState().equals(state.getAvatarState()) : state.getAvatarState() == null;
        }

        @Override
        public int hashCode() {
            int result = getPicasso() != null ? getPicasso().hashCode() : 0;
            result = 31 * result + (getProps() != null ? getProps().hashCode() : 0);
            result = 31 * result + (getLabel() != null ? getLabel().hashCode() : 0);
            result = 31 * result + (isBot() ? 1 : 0);
            result = 31 * result + (getAttachment() != null ? getAttachment().hashCode() : 0);
            result = 31 * result + (getAvatarState() != null ? getAvatarState().hashCode() : 0);
            return result;
        }
    }

}
