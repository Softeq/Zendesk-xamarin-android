package zendesk.classic.messaging.ui;

import android.content.Context;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

@RestrictTo(LIBRARY)
public class AgentMessageView extends LinearLayout implements Updatable<AgentMessageView.State> {

    private AvatarView avatarView;
    private TextView textField;
    private TextView labelField;
    private View labelContainer;
    private View botLabel;

    public AgentMessageView(Context context) {
        super(context);
        init();
    }

    public AgentMessageView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public AgentMessageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(HORIZONTAL);
        inflate(getContext(), R.layout.zui_view_text_response_content, this);
        setClickable(false);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        avatarView = findViewById(R.id.zui_agent_message_avatar);
        textField = findViewById(R.id.zui_agent_message_cell_text_field);
        labelContainer = findViewById(R.id.zui_cell_status_view);
        labelField = findViewById(R.id.zui_cell_label_text_field);
        botLabel = findViewById(R.id.zui_cell_label_supplementary_label);

        labelField.setTextColor(UiUtils.resolveColor(R.color.zui_text_color_dark_secondary, getContext()));
        textField.setTextColor(UiUtils.resolveColor(R.color.zui_text_color_dark_primary, getContext()));
    }

    @Override
    public void update(State state) {
        textField.setText(state.getMessage());
        textField.requestLayout();
        labelField.setText(state.getLabel());
        botLabel.setVisibility(state.isBot() ? VISIBLE : GONE);
        state.getAvatarStateRenderer().render(state.getAvatarState(), avatarView);
        state.getProps().apply(this, labelContainer, avatarView);
    }

    static class State {

        private final MessagingCellProps props;
        private final String message;
        private final String label;
        private final boolean isBot;
        private final AvatarState avatarState;
        private final AvatarStateRenderer avatarStateRenderer;

        public State(MessagingCellProps props,
                     String message,
                     String label,
                     boolean isBot,
                     AvatarState avatarState,
                     AvatarStateRenderer avatarStateRenderer) {
            this.props = props;
            this.message = message;
            this.label = label;
            this.isBot = isBot;
            this.avatarState = avatarState;
            this.avatarStateRenderer = avatarStateRenderer;
        }

        MessagingCellProps getProps() {
            return props;
        }

        String getMessage() {
            return message;
        }

        String getLabel() {
            return label;
        }

        boolean isBot() {
            return isBot;
        }

        AvatarState getAvatarState() {
            return avatarState;
        }

        public AvatarStateRenderer getAvatarStateRenderer() {
            return avatarStateRenderer;
        }
    }
}
