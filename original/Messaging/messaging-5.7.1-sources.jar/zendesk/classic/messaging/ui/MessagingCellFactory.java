package zendesk.classic.messaging.ui;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.view.View;

import com.squareup.picasso.Picasso;
import com.zendesk.util.CollectionUtils;
import com.zendesk.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.inject.Inject;
import javax.inject.Named;

import zendesk.classic.messaging.EventFactory;
import zendesk.classic.messaging.EventListener;
import zendesk.classic.messaging.MessagingActivityScope;
import zendesk.classic.messaging.AgentDetails;
import zendesk.classic.messaging.AttachmentSettings;
import zendesk.classic.messaging.Engine;
import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;
import zendesk.classic.messaging.components.DateProvider;

import static zendesk.classic.messaging.MessagingActivityScope.QUICK_REPLY_WRAPPING_ENABLED;
import static zendesk.classic.messaging.ui.ArticlesResponseView.ArticleSuggestionViewState;




@MessagingActivityScope
@RestrictTo(RestrictTo.Scope.LIBRARY_GROUP)
public class MessagingCellFactory {

    static final String TYPING_INDICATOR_ID = UUID.randomUUID().toString();

    private static final AgentDetails DEFAULT_TYPING_INDICATOR_LABEL_STATE =
            new AgentDetails(StringUtils.EMPTY_STRING, StringUtils.EMPTY_STRING, false);

    private final MessagingCellPropsFactory cellPropsFactory;
    private final DateProvider dateProvider;
    private final EventListener eventListener;
    private final EventFactory eventFactory;
    private final AvatarStateRenderer avatarStateRenderer;
    private final AvatarStateFactory avatarStateFactory;
    private final boolean multilineResponseOptionsEnabled;

    @Inject
    MessagingCellFactory(MessagingCellPropsFactory cellPropsFactory,
                         DateProvider dateProvider,
                         EventListener eventListener,
                         EventFactory eventFactory,
                         AvatarStateRenderer avatarStateRenderer,
                         AvatarStateFactory avatarStateFactory,
                         @Named(QUICK_REPLY_WRAPPING_ENABLED) boolean multilineResponseOptionsEnabled) {
        this.cellPropsFactory = cellPropsFactory;
        this.dateProvider = dateProvider;
        this.eventListener = eventListener;
        this.eventFactory = eventFactory;
        this.avatarStateRenderer = avatarStateRenderer;
        this.avatarStateFactory = avatarStateFactory;
        this.multilineResponseOptionsEnabled = multilineResponseOptionsEnabled;
    }

    List<MessagingCell> createCells(
            List<MessagingItem> messagingItems,
            MessagingState.TypingState typingState,
            Picasso picasso,
            AttachmentSettings attachmentSettings) {

        if (messagingItems == null) {
            return Collections.emptyList();
        }

        // Use copy to ensure the list itself is not modified
        messagingItems = CollectionUtils.copyOf(messagingItems);

        if (typingState != null && typingState.isTyping()) {
            AgentDetails labelState = typingState.getAgentDetails() != null
                    ? typingState.getAgentDetails() : DEFAULT_TYPING_INDICATOR_LABEL_STATE;
            messagingItems.add(new TypingItem(
                    dateProvider.now(), TYPING_INDICATOR_ID, labelState));
        }

        List<MessagingCellProps> propsList = cellPropsFactory.create(messagingItems);

        List<MessagingCell> messagingCells = new ArrayList<>(messagingItems.size());

        for (int i = 0; i < messagingItems.size(); i++) {

            MessagingCell messagingCell = createCell(
                    messagingItems.get(i),
                    propsList.get(i),
                    picasso,
                    attachmentSettings,
                    avatarStateRenderer,
                    avatarStateFactory,
                    eventListener,
                    eventFactory,
                    multilineResponseOptionsEnabled
            );
            if (messagingCell != null) {
                messagingCells.add(messagingCell);
            }
        }

        return messagingCells;
    }

    @Nullable
    private static MessagingCell createCell(
            MessagingItem item,
            MessagingCellProps props,
            Picasso picasso,
            AttachmentSettings attachmentSettings,
            AvatarStateRenderer avatarStateRenderer,
            AvatarStateFactory avatarStateFactory,
            EventListener eventListener,
            EventFactory eventFactory,
            boolean multilineResponseOptionsEnabled) {
        if (item instanceof MessagingItem.Query) {
            return createQueryCell(item, props, picasso, attachmentSettings, eventListener, eventFactory);
        } else if (item instanceof MessagingItem.Response) {
            return createResponseCell((MessagingItem.Response) item,
                    props,
                    picasso,
                    eventListener,
                    eventFactory,
                    avatarStateRenderer,
                    avatarStateFactory);
        } else if (item instanceof MessagingItem.OptionsResponse) {
            return createResponseOptionsCell((MessagingItem.OptionsResponse) item,
                    props,
                    eventListener,
                    eventFactory,
                    multilineResponseOptionsEnabled);
        } else if (item instanceof MessagingItem.SystemMessage) {
            return createSystemMessageCell((MessagingItem.SystemMessage) item, props);
        } else {
            return null;
        }
    }

    @Nullable
    private static MessagingCell createResponseCell(MessagingItem.Response cellData,
                                                    MessagingCellProps props,
                                                    Picasso picasso,
                                                    EventListener eventListener,
                                                    EventFactory eventFactory,
                                                    AvatarStateRenderer avatarStateRenderer,
                                                    AvatarStateFactory avatarStateFactory) {
        if (cellData instanceof MessagingItem.ArticlesResponse) {
            return createArticlesResponseCell((MessagingItem.ArticlesResponse) cellData,
                    props,
                    eventListener,
                    eventFactory,
                    avatarStateFactory,
                    avatarStateRenderer);
        } else if (cellData instanceof MessagingItem.TransferResponse) {
            return createActionOptionsCell((MessagingItem.TransferResponse) cellData,
                    props,
                    eventListener,
                    eventFactory,
                    avatarStateFactory,
                    avatarStateRenderer);
        } else if (cellData instanceof MessagingItem.ActionResponse) {
            return createActionOptionsCell((MessagingItem.ActionResponse) cellData,
                    props,
                    eventListener,
                    eventFactory,
                    avatarStateFactory,
                    avatarStateRenderer);
        } else if (cellData instanceof MessagingItem.ImageResponse) {
            return createAgentImageCell((MessagingItem.ImageResponse) cellData,
                    props,
                    picasso,
                    avatarStateFactory,
                    avatarStateRenderer);
        } else if (cellData instanceof MessagingItem.FileResponse) {
            return createAgentFileCell((MessagingItem.FileResponse) cellData,
                    props,
                    avatarStateFactory,
                    avatarStateRenderer);
        } else if (cellData instanceof TypingItem) {
            return createTypingIndicatorCell((TypingItem) cellData, props, avatarStateRenderer, avatarStateFactory);
        } else if (cellData instanceof MessagingItem.TextResponse) {
            return createTextResponseCell((MessagingItem.TextResponse) cellData,
                    props,
                    avatarStateRenderer,
                    avatarStateFactory);
        } else {
            return null;
        }
    }

    @Nullable
    private static MessagingCell createQueryCell(
            MessagingItem cellData,
            MessagingCellProps props,
            Picasso picasso,
            AttachmentSettings attachmentSettings,
            EventListener eventListener,
            EventFactory eventFactory) {
        if (cellData instanceof MessagingItem.TextQuery) {
            return createTextQueryCell((MessagingItem.TextQuery) cellData, props, eventListener, eventFactory);
        } else if (cellData instanceof MessagingItem.ImageQuery) {
            return createImageQueryCellForFile((MessagingItem.ImageQuery) cellData,
                    props,
                    picasso,
                    attachmentSettings,
                    eventListener,
                    eventFactory);
        } else if (cellData instanceof MessagingItem.FileQuery) {
            return createFileQueryCell((MessagingItem.FileQuery) cellData,
                    props,
                    attachmentSettings,
                    eventListener,
                    eventFactory);
        }
        return null;
    }

    private static MessagingCell<AgentFileCellView.State, AgentFileCellView> createAgentFileCell(
            MessagingItem.FileResponse cellData,
            MessagingCellProps props,
            AvatarStateFactory avatarStateFactory,
            AvatarStateRenderer avatarStateRenderer) {

        AgentFileCellView.State state = new AgentFileCellView.State(
                cellData.getAttachment(),
                props,
                cellData.getAgentDetails().getAgentName(),
                cellData.getAgentDetails().isBot(),
                avatarStateFactory.createAvatarState(cellData.getAgentDetails()),
                avatarStateRenderer);
        return new MessagingCell<>(cellData.getId(), state, R.layout.zui_cell_agent_file_view, AgentFileCellView.class);
    }

    private static MessagingCell<AgentImageCellView.State, AgentImageCellView> createAgentImageCell(
            MessagingItem.ImageResponse cellData,
            MessagingCellProps props,
            Picasso picasso,
            AvatarStateFactory avatarStateFactory,
            AvatarStateRenderer avatarStateRenderer) {
        AgentImageCellView.State state = new AgentImageCellView.State(
                picasso,
                props,
                cellData.getAttachment(),
                cellData.getAgentDetails().getAgentName(),
                cellData.getAgentDetails().isBot(),
                avatarStateFactory.createAvatarState(cellData.getAgentDetails()),
                avatarStateRenderer);

        return new MessagingCell<>(cellData.getId(), state, R.layout.zui_cell_agent_image_view,
                AgentImageCellView.class);
    }

    private static MessagingCell<EndUserCellImageState, EndUserImageCellView> createImageQueryCellForFile(
            MessagingItem.ImageQuery messagingItem,
            MessagingCellProps props,
            Picasso picasso,
            AttachmentSettings attachmentSettings,
            EventListener eventListener,
            EventFactory eventFactory) {
        return createImageQueryCell(messagingItem, props, picasso, attachmentSettings, eventListener, eventFactory);
    }

    private static MessagingCell<EndUserCellFileState, EndUserFileCellView> createFileQueryCell(
            final MessagingItem.FileQuery messagingItem,
            MessagingCellProps props,
            AttachmentSettings attachmentSettings,
            EventListener eventListener,
            EventFactory eventFactory) {
        EndUserCellFileState state = new EndUserCellFileState(
                messagingItem.getId(),
                props,
                messagingItem.getStatus(),
                new MessageActionAdapter(eventListener, messagingItem, eventFactory),
                messagingItem.getAttachment(),
                messagingItem.getFailureReason(),
                attachmentSettings);
        return new MessagingCell<>(messagingItem.getId(), state, R.layout.zui_cell_end_user_file_view,
                EndUserFileCellView.class);
    }

    @NonNull
    private static MessagingCell<EndUserCellImageState, EndUserImageCellView> createImageQueryCell(
            MessagingItem.ImageQuery messagingItem,
            MessagingCellProps props,
            Picasso picasso,
            AttachmentSettings attachmentSettings,
            EventListener eventListener,
            EventFactory eventFactory) {
        EndUserCellImageState state = new EndUserCellImageState(
                messagingItem.getId(),
                props,
                messagingItem.getStatus(),
                new MessageActionAdapter(eventListener, messagingItem, eventFactory),
                messagingItem.getAttachment(),
                messagingItem.getFailureReason(),
                attachmentSettings,
                picasso);
        return new MessagingCell<>(messagingItem.getId(), state, R.layout.zui_cell_end_user_image_view,
                EndUserImageCellView.class);
    }

    private static MessagingCell<TypingIndicatorView.State, TypingIndicatorView> createTypingIndicatorCell(
            TypingItem messagingItem,
            MessagingCellProps props,
            AvatarStateRenderer avatarStateRenderer,
            AvatarStateFactory avatarStateFactory) {
        TypingIndicatorView.State state = new TypingIndicatorView.State(
                props,
                messagingItem.getAgentDetails().getAgentName(),
                messagingItem.getAgentDetails().isBot(),
                avatarStateFactory.createAvatarState(messagingItem.getAgentDetails()),
                avatarStateRenderer);

        return new MessagingCell<>(TYPING_INDICATOR_ID, state, R.layout.zui_cell_typing_indicator,
                TypingIndicatorView.class);
    }

    private static MessagingCell<SystemMessageView.State, SystemMessageView> createSystemMessageCell(
            MessagingItem.SystemMessage item,
            MessagingCellProps props) {
        final SystemMessageView.State state = new SystemMessageView.State(props, item.getSystemMessage());
        return new MessagingCell<>(
                item.getId(),
                state,
                R.layout.zui_cell_system_message,
                SystemMessageView.class);
    }

    private static MessagingCell<AgentMessageView.State, AgentMessageView> createTextResponseCell(
            MessagingItem.TextResponse cellData,
            MessagingCellProps props,
            AvatarStateRenderer avatarStateRenderer,
            AvatarStateFactory avatarStateFactory) {
        AgentMessageView.State state = new AgentMessageView.State(props,
                cellData.getMessage(),
                cellData.getAgentDetails().getAgentName(),
                cellData.getAgentDetails().isBot(),
                avatarStateFactory.createAvatarState(cellData.getAgentDetails()),
                avatarStateRenderer);
        return new MessagingCell<>(cellData.getId(), state, R.layout.zui_cell_agent_message_view,
                AgentMessageView.class);
    }

    private static MessagingCell<EndUserCellMessageState, EndUserMessageView> createTextQueryCell(
            MessagingItem.TextQuery query,
            MessagingCellProps props,
            EventListener eventListener,
            EventFactory eventFactory) {

        EndUserCellMessageState state = new EndUserCellMessageState(
                query.getId(),
                props,
                query.getStatus(),
                new MessageActionAdapter(eventListener, query, eventFactory),
                query.getMessage()
        );
        return new MessagingCell<>(query.getId(), state, R.layout.zui_cell_end_user_message, EndUserMessageView.class);
    }

    private static MessagingCell<ArticlesResponseView.State, ArticlesResponseView> createArticlesResponseCell(
            MessagingItem.ArticlesResponse articlesResponse,
            MessagingCellProps props,
            EventListener eventListener,
            EventFactory eventFactory,
            AvatarStateFactory avatarStateFactory,
            AvatarStateRenderer avatarStateRenderer) {

        ArticlesResponseView.State state = new ArticlesResponseView.State(
                articlesResponse.getAgentDetails().getAgentName(),
                articlesResponse.getAgentDetails().isBot(),
                props,
                createArticleSuggestionViewStates(articlesResponse.getArticleSuggestions(),
                        eventListener,
                        eventFactory),
                avatarStateFactory.createAvatarState(articlesResponse.getAgentDetails()),
                avatarStateRenderer);
        return new MessagingCell<>(articlesResponse.getId(), state, R.layout.zui_cell_articles_response,
                ArticlesResponseView.class);
    }

    private static List<ArticleSuggestionViewState> createArticleSuggestionViewStates(
            List<MessagingItem.ArticlesResponse.ArticleSuggestion> suggestions,
            EventListener eventListener,
            EventFactory eventFactory) {
        List<ArticleSuggestionViewState> suggestionViewStates = new ArrayList<>(suggestions.size());
        for (MessagingItem.ArticlesResponse.ArticleSuggestion suggestion : suggestions) {
            suggestionViewStates.add(createArticleSuggestionViewState(suggestion, eventListener, eventFactory));
        }
        return suggestionViewStates;
    }

    private static ArticleSuggestionViewState createArticleSuggestionViewState(
            final MessagingItem.ArticlesResponse.ArticleSuggestion suggestion,
            final EventListener eventListener,
            final EventFactory eventFactory) {
        return new ArticleSuggestionViewState(
                suggestion.getTitle(),
                suggestion.getSnippet(),
                new OnArticleSuggestionSelectionListener() {
                    @Override
                    public void onArticleSuggestionSelected(Context context) {
                        eventListener.onEvent(eventFactory.articleSuggestionClick(suggestion));
                    }
                });
    }

    private static MessagingCell<ActionOptionsView.State, ActionOptionsView> createActionOptionsCell(
            MessagingItem.TransferResponse transferResponse,
            MessagingCellProps props,
            final EventListener eventListener,
            final EventFactory eventFactory,
            AvatarStateFactory avatarStateFactory,
            AvatarStateRenderer avatarStateRenderer) {

        List<ActionOptionsView.ActionOptionState> actionOptionStates = new ArrayList<>();

        for (final Engine.TransferOptionDescription description : transferResponse.getEngineOptions()) {
            actionOptionStates.add(new ActionOptionsView.ActionOptionState(
                    description.getDisplayName(),
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            eventListener.onEvent(eventFactory.transferOptionClick(description));
                        }
                    }
            ));
        }

        ActionOptionsView.State state = new ActionOptionsView.State(
                transferResponse.getMessage(),
                transferResponse.getAgentDetails().getAgentName(),
                transferResponse.getAgentDetails().isBot(),
                props,
                actionOptionStates,
                transferResponse.isEnabled(),
                avatarStateFactory.createAvatarState(transferResponse.getAgentDetails()),
                avatarStateRenderer
        );

        return new MessagingCell<>(transferResponse.getId(), state, R.layout.zui_cell_action_options,
                ActionOptionsView.class);
    }

    private static MessagingCell<ActionOptionsView.State, ActionOptionsView> createActionOptionsCell(
            MessagingItem.ActionResponse actionResponse,
            MessagingCellProps props,
            final EventListener eventListener,
            final EventFactory eventFactory,
            AvatarStateFactory avatarStateFactory,
            AvatarStateRenderer avatarStateRenderer) {
        List<ActionOptionsView.ActionOptionState> actionOptionStates = new ArrayList<>();

        for (final MessagingItem.Action action : actionResponse.getActions()) {
            actionOptionStates.add(new ActionOptionsView.ActionOptionState(action.getDisplayName(),
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            eventListener.onEvent(eventFactory.actionOptionClick(action));
                        }
                    }));
        }

        ActionOptionsView.State state = new ActionOptionsView.State(
                actionResponse.getMessage(),
                actionResponse.getAgentDetails().getAgentName(),
                actionResponse.getAgentDetails().isBot(),
                props,
                actionOptionStates,
                true,
                avatarStateFactory.createAvatarState(actionResponse.getAgentDetails()),
                avatarStateRenderer
        );

        return new MessagingCell<>(
                actionResponse.getId(),
                state,
                R.layout.zui_cell_action_options,
                ActionOptionsView.class);
    }

    private static MessagingCell<ResponseOptionsViewState, ?> createResponseOptionsCell(
            final MessagingItem.OptionsResponse optionsResponse,
            MessagingCellProps props,
            final EventListener eventListener,
            final EventFactory eventFactory,
            boolean multilineResponseOptionsEnabled) {
        ResponseOptionsViewState state = new ResponseOptionsViewState(
                optionsResponse.getOptions(),
                new ResponseOptionHandler() {
                    @Override
                    public void onResponseOptionSelected(MessagingItem.Option responseOption) {
                        eventListener.onEvent(eventFactory.formOptionClick(optionsResponse, responseOption));
                    }
                },
                props
        );
        if (multilineResponseOptionsEnabled) {
            return new MessagingCell<>(
                    optionsResponse.getId(),
                    state,
                    R.layout.zui_cell_response_options_stacked,
                    StackedResponseOptionsView.class);
        } else {
            return new MessagingCell<>(
                    optionsResponse.getId(),
                    state,
                    R.layout.zui_cell_response_options,
                    ResponseOptionsView.class);
        }
    }

    private static class TypingItem extends MessagingItem.Response {

        private TypingItem(Date date, String id, AgentDetails agentDetails) {
            super(date, id, agentDetails);
        }
    }

    static class MessageActionAdapter implements MessageActionListener {

        private final EventListener eventListener;
        private final MessagingItem.Query messagingItem;
        private final EventFactory eventFactory;

        MessageActionAdapter(EventListener eventListener,
                             MessagingItem.Query messagingItem,
                             EventFactory eventFactory) {
            this.eventListener = eventListener;
            this.messagingItem = messagingItem;
            this.eventFactory = eventFactory;
        }

        @Override
        public void delete(String messagingItemId) {
            eventListener.onEvent(eventFactory.deleteQueryClick(messagingItem));
        }

        @Override
        public void retry(String messagingItemId) {
            if (messagingItem instanceof MessagingItem.FileQuery) {
                eventListener.onEvent(eventFactory.retrySendAttachmentClick((MessagingItem.FileQuery) messagingItem));
            } else {
                eventListener.onEvent(eventFactory.retryQueryClick(messagingItem));
            }
        }

        @Override
        public void copy(String messagingItemId) {
            eventListener.onEvent(eventFactory.copyQueryClick(messagingItem));
        }
    }
}
