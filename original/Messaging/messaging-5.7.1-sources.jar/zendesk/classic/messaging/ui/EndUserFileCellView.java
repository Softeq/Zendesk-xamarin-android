package zendesk.classic.messaging.ui;

import android.content.Context;
import android.graphics.drawable.Drawable;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import androidx.core.content.ContextCompat;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;

@RestrictTo(RestrictTo.Scope.LIBRARY)
public class EndUserFileCellView extends LinearLayout implements Updatable<EndUserCellFileState> {

    private LinearLayout bubble;
    private TextView fileName;
    private TextView fileDescriptor;
    private ImageView appIcon;
    private FileUploadProgressView fileUploadProgressView;
    private MessageStatusView statusView;
    private TextView label;

    private Drawable defaultAppIcon;

    public EndUserFileCellView(Context context) {
        super(context);
        init();
    }

    public EndUserFileCellView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public EndUserFileCellView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setOrientation(VERTICAL);
        setGravity(Gravity.BOTTOM | Gravity.END);
        inflate(getContext(), R.layout.zui_view_end_user_file_cell_content, this);
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        bubble = findViewById(R.id.zui_cell_file_container);

        fileName = findViewById(R.id.zui_file_cell_name);
        fileDescriptor = findViewById(R.id.zui_cell_file_description);
        appIcon = findViewById(R.id.zui_cell_file_app_icon);
        fileUploadProgressView = findViewById(R.id.zui_cell_file_upload_progress);
        statusView = findViewById(R.id.zui_cell_status_view);
        label = findViewById(R.id.zui_cell_label_message);

        defaultAppIcon = ContextCompat.getDrawable(getContext(), R.drawable.zui_ic_insert_drive_file);
        if (defaultAppIcon != null) {
            int defaultDrawableColor =
                    UiUtils.themeAttributeToColor(R.attr.colorPrimary, getContext(), R.color.zui_color_primary);
            UiUtils.setTint(defaultDrawableColor, defaultAppIcon, appIcon);
        }
    }

    @Override
    public void update(EndUserCellFileState state) {
        UtilsEndUserCellView.setCellBackground(state, bubble);
        UtilsEndUserCellView.setLabelErrorMessage(state, label, getContext());
        UtilsEndUserCellView.setClickListener(state, this);
        UtilsEndUserCellView.setLongClickListener(state, this);

        statusView.setStatus(state.getStatus());
        fileName.setText(state.getAttachment().getName());
        fileDescriptor.setText(state.getFileDescriptor(getContext()));
        appIcon.setImageDrawable(defaultAppIcon);

        if (state.getStatus() == MessagingItem.Query.Status.PENDING) {
            fileUploadProgressView.setVisibility(VISIBLE);
            appIcon.setVisibility(GONE);
        } else {
            fileUploadProgressView.setVisibility(GONE);
            appIcon.setVisibility(VISIBLE);
        }

        state.getProps().apply(this, statusView);
    }

}
