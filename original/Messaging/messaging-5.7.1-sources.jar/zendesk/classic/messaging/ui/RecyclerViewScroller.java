package zendesk.classic.messaging.ui;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSmoothScroller;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;

/**
 * Helper class for implementing the scrolling behavior of our RecyclerView.
 */
class RecyclerViewScroller {

    private static final int SCROLL_INSTANT = 1;
    private static final int SCROLL_SMOOTH_FIXED_VELOCITY = 2;
    private static final int SCROLL_SMOOTH_FIXED_TIME = 3;
    private static final int FIXED_SCROLL_TIME = 50;

    private final RecyclerView recyclerView;
    private final LinearLayoutManager linearLayoutManager;
    private final RecyclerView.Adapter<RecyclerView.ViewHolder> adapter;

    private int lastCompletelyVisiblePosition = 0;
    private int secondCompletelyVisiblePosition = 0;

    RecyclerViewScroller(@NonNull final RecyclerView recyclerView,
                         @NonNull final LinearLayoutManager linearLayoutManager,
                         @NonNull final RecyclerView.Adapter<RecyclerView.ViewHolder> adapter) {
        this.recyclerView = recyclerView;
        this.linearLayoutManager = linearLayoutManager;
        this.adapter = adapter;

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                // Track the second most recent position, as we need this to handle keyboard events
                secondCompletelyVisiblePosition = lastCompletelyVisiblePosition;
                lastCompletelyVisiblePosition = linearLayoutManager.findLastCompletelyVisibleItemPosition();
            }
        });

        // scroll to bottom if keyboard appears and we are at the bottom of the list
        recyclerView.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {

            @Override
            public void onLayoutChange(@NonNull final View v,
                                       final int left, final int top,
                                       final int right, final int bottom,
                                       final int oldLeft, final int oldTop,
                                       final int oldRight, final int oldBottom) {
                // if keyboard is dismissing do nothing
                if (bottom >= oldBottom) {
                    return;
                }

                int lastAdapterIndex = adapter.getItemCount() - 1;

                // check against the second most recent position, as this will be the position *before* the keyboard
                // was shown
                if (lastAdapterIndex == secondCompletelyVisiblePosition) {
                    postScrollToBottom(SCROLL_INSTANT);
                }
            }
        });

        // retain scroll position at bottom if a new item was added to or removed from the stream
        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                if (!recyclerView.canScrollVertically(1)) {
                    postScrollToBottom(SCROLL_SMOOTH_FIXED_TIME);
                }
            }
        });
    }

    void install(@NonNull final InputBox inputBox) {
        // adjust bottom padding on recyclerView and ensure it retains scroll position when inputBox changes height
        inputBox.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(@NonNull final View v,
                                       final int left, final int top,
                                       final int right, final int bottom,
                                       final int oldLeft, final int oldTop,
                                       final int oldRight, final int oldBottom) {
                recyclerView.post(new Runnable() {
                    @Override
                    public void run() {
                        final int paddingLeft = recyclerView.getPaddingLeft();
                        final int paddingRight = recyclerView.getPaddingRight();
                        final int paddingTop = recyclerView.getPaddingTop();
                        final int paddingBottom = inputBox.getHeight();

                        if (paddingBottom != recyclerView.getPaddingBottom()) {
                            recyclerView.setPadding(paddingLeft, paddingTop, paddingRight, paddingBottom);
                            recyclerView.scrollBy(0, oldTop - top);
                        }
                    }
                });
            }
        });

        inputBox.addSendButtonClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postScrollToBottom(SCROLL_INSTANT);
            }
        });
    }

    private void scrollToBottom(final int scrollMode) {
        final int lastItem = adapter.getItemCount() - 1;
        if (lastItem >= 0) {
            if (scrollMode == SCROLL_INSTANT) {
                final RecyclerView.ViewHolder lastViewHolder = recyclerView.findViewHolderForAdapterPosition(lastItem);
                final int lastItemHeight = lastViewHolder != null ? lastViewHolder.itemView.getHeight() : 0;

                final int offset = (recyclerView.getPaddingBottom() + lastItemHeight) * -1;
                linearLayoutManager.scrollToPositionWithOffset(lastItem, offset);

            } else if (scrollMode == SCROLL_SMOOTH_FIXED_TIME) {
                final LinearSmoothScroller linearSmoothScroller = new LinearSmoothScroller(recyclerView.getContext()) {
                    @Override
                    protected int calculateTimeForScrolling(int dx) {
                        return FIXED_SCROLL_TIME;
                    }
                };

                linearSmoothScroller.setTargetPosition(lastItem);
                linearLayoutManager.startSmoothScroll(linearSmoothScroller);

            } else if (scrollMode == SCROLL_SMOOTH_FIXED_VELOCITY) {
                final LinearSmoothScroller linearSmoothScroller = new LinearSmoothScroller(recyclerView.getContext());
                linearSmoothScroller.setTargetPosition(lastItem);
                linearLayoutManager.startSmoothScroll(linearSmoothScroller);
            }
        }
    }

    private void postScrollToBottom(final int scrollMode) {
        recyclerView.post(new Runnable() {
            @Override
            public void run() {
                scrollToBottom(scrollMode);
            }
        });
    }
}
