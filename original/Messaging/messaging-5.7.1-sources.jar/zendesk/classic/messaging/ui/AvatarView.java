package zendesk.classic.messaging.ui;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RestrictTo;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import zendesk.commonui.UiUtils;
import zendesk.classic.messaging.R;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;
import static zendesk.commonui.PicassoTransformations.getRoundWithBorderTransformation;

@RestrictTo(LIBRARY)
public class AvatarView extends FrameLayout {

    private final ImageView imageView;
    private final TextView textView;
    private final int avatarSize;
    private final int[] colorPalette;
    private final int outlineSize;
    private final int outlineColor;

    public AvatarView(@NonNull Context context) {
        this(context, null, 0);
    }

    public AvatarView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public AvatarView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        inflate(context, R.layout.zui_view_avatar, this);

        final Resources resources = getResources();
        final int defaultTextColor = resources.getColor(R.color.zui_color_white_80);
        final int defaultOutlineWidth = resources.getDimensionPixelOffset(R.dimen.zui_avatar_view_outline);
        final int defaultOutlineColor = UiUtils.themeAttributeToColor(
                R.attr.colorPrimary,
                context,
                R.color.zui_color_primary);

        imageView = findViewById(R.id.zui_avatar_image);
        textView = findViewById(R.id.zui_avatar_letter);
        avatarSize = resources.getDimensionPixelSize(R.dimen.zui_avatar_view_size);

        final TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.AvatarView);
        final int defaultColorPaletteId = typedArray
                .getResourceId(R.styleable.AvatarView_colorPalette, R.array.zui_avatar_view__background_color_palette);
        colorPalette = resources.getIntArray(defaultColorPaletteId);
        outlineSize = typedArray.getDimensionPixelSize(R.styleable.AvatarView_outlineSize, defaultOutlineWidth);
        outlineColor = typedArray.getColor(R.styleable.AvatarView_outlineColor, defaultOutlineColor);
        int textColor = typedArray.getColor(R.styleable.AvatarView_textColor, defaultTextColor);

        textView.setTextColor(textColor);

        typedArray.recycle();
    }

    public void showLetter(@NonNull String letter, @NonNull Object uniqueIdentifier) {
        setBackground(generateBackground(uniqueIdentifier));
        textView.setText(letter);
        textView.setVisibility(VISIBLE);
        imageView.setVisibility(GONE);
    }

    public void showImage(@NonNull Picasso picasso, @NonNull final String imageUrl) {
        // Picasso throws exception when dimension <= 0
        if (avatarSize - outlineSize > 0) {

            setBackground(null);
            imageView.setImageResource(R.color.zui_color_transparent);
            imageView.setVisibility(VISIBLE);
            textView.setVisibility(GONE);
            picasso.load(imageUrl)
                    .resize(avatarSize - outlineSize, avatarSize - outlineSize)
                    .centerCrop()
                    .noPlaceholder()
                    .transform(getRoundWithBorderTransformation(avatarSize, outlineColor, outlineSize))
                    .into(imageView);
        }
    }

    public void showDrawable(@DrawableRes int imageRes) {
        setBackground(null);
        imageView.setImageResource(imageRes);
        textView.setVisibility(GONE);
        imageView.setVisibility(VISIBLE);
    }

    public void showDefault(@DrawableRes int imageRes, @NonNull Object uniqueIdentifier) {
        setBackground(generateBackground(uniqueIdentifier));
        imageView.setImageResource(imageRes);
        textView.setVisibility(GONE);
        imageView.setVisibility(VISIBLE);
    }

    private Drawable generateBackground(@NonNull Object uniqueIdentifier) {
        final int color = colorPalette[Math.abs(uniqueIdentifier.hashCode() % colorPalette.length)];
        final ShapeDrawable filledBackground = new ShapeDrawable(new OvalShape());

        filledBackground.getPaint().setColor(color);

        if (outlineSize > 0) {
            final ShapeDrawable outline = new ShapeDrawable(new OvalShape());
            final Paint paint = outline.getPaint();
            paint.setStyle(Paint.Style.STROKE);
            paint.setAntiAlias(true);
            paint.setColor(outlineColor);
            paint.setStrokeWidth(outlineSize);

            return new LayerDrawable(new Drawable[]{
                    filledBackground,
                    new InsetDrawable(outline, outlineSize / 2)
            });
        } else {
            return filledBackground;
        }
    }
}
