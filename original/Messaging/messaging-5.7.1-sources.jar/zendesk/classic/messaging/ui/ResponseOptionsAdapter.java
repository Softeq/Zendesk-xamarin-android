package zendesk.classic.messaging.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import zendesk.classic.messaging.MessagingItem;
import zendesk.classic.messaging.R;

class ResponseOptionsAdapter extends ListAdapter<MessagingItem.Option, RecyclerView.ViewHolder> {

    private static final String LOG_TAG = "ResponseOptionsAdapter";

    private ResponseOptionHandler responseOptionHandler;

    private boolean canSelectOption = true;
    private MessagingItem.Option selectedOption = null;

    ResponseOptionsAdapter() {
        super(new ResponseOptionsDiffCallback());
    }

    @Override
    public int getItemViewType(int position) {
        final MessagingItem.Option responseOption = getItem(position);

        if (responseOption == selectedOption) {
            return R.layout.zui_response_options_selected_option;
        } else {
            return R.layout.zui_response_options_option;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(viewType, parent, false);

        return new RecyclerView.ViewHolder(itemView) {
        };
    }

    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder viewHolder, int position) {
        TextView label = viewHolder.itemView.findViewById(R.id.zui_response_option_text);
        final MessagingItem.Option responseOption = getItem(position);
        label.setText(responseOption.getText());

        viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (canSelectOption) {
                    if (responseOptionHandler != null) {
                        viewHolder.itemView.post(new Runnable() {
                            @Override
                            public void run() {
                                responseOptionHandler.onResponseOptionSelected(responseOption);
                            }
                        });
                    }
                    canSelectOption = false;
                }
            }
        });
    }

    @Override
    public void submitList(@Nullable List<MessagingItem.Option> list) {
        super.submitList(list);
        // With a new state, presume we want to re-enable object selection
        this.canSelectOption = true;
        this.selectedOption = null;
    }

    private void notifyItemChanged(MessagingItem.Option option) {
        for (int i = 0; i < getItemCount(); i++) {
            MessagingItem.Option temp = getItem(i);
            if (temp.equals(option)) {
                notifyItemChanged(i);
                return;
            }
        }
    }

    void setResponseOptionHandler(ResponseOptionHandler responseOptionHandler) {
        this.responseOptionHandler = responseOptionHandler;
    }

    void setSelectedOption(MessagingItem.Option option) {
        this.selectedOption = option;
        notifyItemChanged(option);
    }

    /**
     * Implementation of DiffUtil Callback that ensures all items are rebound. This is because of a bug I can't fix in
     * a better way with selection states being retained when rebound to a new list.
     */
    private static class ResponseOptionsDiffCallback extends DiffUtil.ItemCallback<MessagingItem.Option> {

        @Override
        public boolean areItemsTheSame(@NonNull MessagingItem.Option s, @NonNull MessagingItem.Option t1) {
            return s.equals(t1);
        }

        @Override
        public boolean areContentsTheSame(@NonNull MessagingItem.Option s, @NonNull MessagingItem.Option t1) {
            return s.equals(t1);
        }
    }
}
