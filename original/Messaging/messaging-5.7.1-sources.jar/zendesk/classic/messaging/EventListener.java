package zendesk.classic.messaging;

import androidx.annotation.NonNull;
import androidx.annotation.RestrictTo;

import static androidx.annotation.RestrictTo.Scope.LIBRARY;

/**
 * Interface definition for a callback to be invoked when an event happens.
 */
@RestrictTo(LIBRARY)
public interface EventListener {

    /**
     * Called when an event has occurred.
     *
     * @param event An event that occurred.
     */
    void onEvent(@NonNull Event event);

}
