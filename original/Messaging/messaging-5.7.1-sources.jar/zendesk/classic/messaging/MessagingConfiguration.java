package zendesk.classic.messaging;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import zendesk.configurations.Configuration;
import zendesk.configurations.ConfigurationHelper;

import static com.zendesk.util.StringUtils.hasLength;

/**
 * Data class, that represents the initial configuration of {@link MessagingActivity}.
 * Use the {@link Builder} to create an instance.
 */
public class MessagingConfiguration implements Configuration {

    private static final String DEFAULT_AGENT_ID = "ANSWER_BOT";

    private final List<Configuration> configurations;
    private final String engineRegistryKey;
    @Nullable
    private final String toolbarTitle;
    @StringRes
    private final int toolbarTitleRes;
    @Nullable
    private final String botLabelString;
    @StringRes
    private final int botLabelStringRes;
    @DrawableRes
    private final int botAvatarDrawable;

    private final boolean multilineResponseOptionsEnabled;

    @Nullable
    private AgentDetails botAgentDetails;

    private MessagingConfiguration(@NonNull Builder builder,
                                   @NonNull String engineRegistryKey) {
        this.configurations = builder.configurations;
        this.engineRegistryKey = engineRegistryKey;
        this.toolbarTitle = builder.toolbarTitle;
        this.toolbarTitleRes = builder.toolbarTitleRes;
        this.botLabelString = builder.botLabelString;
        this.botLabelStringRes = builder.botLabelStringRes;
        this.botAvatarDrawable = builder.botAvatarDrawable;
        this.multilineResponseOptionsEnabled = builder.multilineResponseOptionsEnabled;
    }

    @Nullable
    List<Engine> getEngines() {
        return EngineListRegistry.INSTANCE.retrieveEngineList(engineRegistryKey);
    }

    @Override
    public List<Configuration> getConfigurations() {
        return ConfigurationHelper.get().addSelfIfNotInList(configurations, this);
    }

    String getToolbarTitle(Resources resources) {
        return hasLength(toolbarTitle) ? toolbarTitle : resources.getString(toolbarTitleRes);
    }

    @NonNull
    AgentDetails getBotAgentDetails(Resources resources) {
        if (botAgentDetails == null) {
            botAgentDetails = new AgentDetails(
                    getBotLabelString(resources), DEFAULT_AGENT_ID, true, botAvatarDrawable);
        }
        return botAgentDetails;
    }

    private String getBotLabelString(Resources resources) {
        return hasLength(botLabelString) ? botLabelString : resources.getString(botLabelStringRes);
    }

    @DrawableRes
    int getBotAvatarDrawable() {
        return botAvatarDrawable;
    }

    boolean isMultilineResponseOptionsEnabled() {
        return multilineResponseOptionsEnabled;
    }

    @SuppressWarnings("unused")
    public static class Builder {

        private List<Configuration> configurations = new ArrayList<>();
        private List<Engine> engines = new ArrayList<>();
        @StringRes
        private int toolbarTitleRes = R.string.zui_toolbar_title;
        private String toolbarTitle;
        @StringRes
        private int botLabelStringRes = R.string.zui_default_bot_name;
        private String botLabelString;
        private boolean multilineResponseOptionsEnabled = false;

        @DrawableRes
        private int botAvatarDrawable = R.drawable.zui_avatar_bot_default;

        /**
         * Specify a list of product specific {@link Engine}s.
         *
         * @param engines a list of engines
         * @return the builder
         */
        public Builder withEngines(List<Engine> engines) {
            this.engines = engines;
            return this;
        }

        /**
         * Specify a list of product specific {@link Engine}s.
         *
         * @param engines a list of engines
         * @return the builder
         */
        public Builder withEngines(Engine... engines) {
            this.engines = Arrays.asList(engines);
            return this;
        }

        /**
         * Specify the String to use as the title of the screen in the conversation interface.
         * This is "Contact us" by default.
         * <p>
         * If both this and #withToolbarTitle() are provided, the value passed to #withToolbarTitle takes precedence
         *
         * @param stringResourceId the String resource ID to be used as the title for the conversation screen
         * @return the builder
         */
        public Builder withToolbarTitleRes(@StringRes int stringResourceId) {
            this.toolbarTitleRes = stringResourceId;
            return this;
        }

        /**
         * Specify the String to use as the title of the screen in the conversation interface.
         * <p>
         * If both this and #withToolbarTitleRes() are provided, this takes precedence
         *
         * @param toolbarTitle the String to be used as the label for Bot messages
         * @return the builder
         */
        public Builder withToolbarTitle(String toolbarTitle) {
            this.toolbarTitle = toolbarTitle;
            return this;
        }

        /**
         * Specify the String resource to use as the label displayed on Bot messages in
         * the conversation interface. This is "Answer Bot" by default.
         * <p>
         * If both this and #withBotLabelString() are provided, the value passed to #withBotLabelString takes precedence
         *
         * @param stringResourceId the String resource ID to be used as the label for Bot messages
         * @return the builder
         */
        public Builder withBotLabelStringRes(@StringRes int stringResourceId) {
            this.botLabelStringRes = stringResourceId;
            return this;
        }

        /**
         * Specify the String to use as the label displayed on Bot messages in the conversation interface.
         * <p>
         * If both this and #withBotLabelStringRes() are provided, this takes precedence
         *
         * @param botLabelString the String to be used as the label for Bot messages
         * @return the builder
         */
        public Builder withBotLabelString(String botLabelString) {
            this.botLabelString = botLabelString;
            return this;
        }

        /**
         * Specify the Drawable resource to use as the avatar for Bots on the conversation
         * interface. This is the Answer Bot logo by default.
         *
         * @param avatarDrawableId the Drawable resource ID to be used as the avatar for Bots
         *                         in the conversation interface.
         * @return the builder
         */
        public Builder withBotAvatarDrawable(@DrawableRes int avatarDrawableId) {
            this.botAvatarDrawable = avatarDrawableId;
            return this;
        }

        /**
         * Specify whether to enable text wrapping for quick replies in the conversation interface.
         *
         * If this is enabled (true), quick replies will wrap so that they will all be on screen at once, if it is
         * disabled (false) they will show as a single horizontally scrollable line.
         *
         * Defaults to disabled (false).
         *
         * @param multilineResponseOptionsEnabled the flag for whether to enable quick reply text wrapping
         * @return the builder
         */
        public Builder withMultilineResponseOptionsEnabled(boolean multilineResponseOptionsEnabled) {
            this.multilineResponseOptionsEnabled = multilineResponseOptionsEnabled;
            return this;
        }

        /**
         * Display {@link MessagingActivity} to the user.
         *
         * @param context        The context which {@code startActivity} will be invoked on.
         * @param configurations Configurations for other Zendesk SDK activities that can be started from
         *                       ChatActivity.
         */
        public void show(@NonNull Context context, Configuration... configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Display {@link MessagingActivity} to the user.
         *
         * @param context        The context which {@code startActivity} will be invoked on.
         * @param configurations Configurations for other Zendesk SDK activities that can be started from
         *                       ChatActivity.
         */
        public void show(@NonNull Context context, List<Configuration> configurations) {
            context.startActivity(intent(context, configurations));
        }

        /**
         * Create a {@link Configuration} for the passed in configuration options.
         */
        @NonNull
        public Configuration config(Context context) {
            String registryId = EngineListRegistry.INSTANCE.register(engines);
            return new MessagingConfiguration(this, registryId);
        }

        /**
         * Create an {@link Intent} to start the {@link MessagingActivity} with the specified
         * configuration options.
         *
         * @param context        The context which {@code startActivity} will be invoked on.
         * @param configurations Configurations for screen that can be started from ChatActivity.
         * @return An {@link Intent} for {@link MessagingActivity} with the specified configuration
         * options.
         */
        public Intent intent(@NonNull Context context, @NonNull Configuration... configurations) {
            return intent(context, Arrays.asList(configurations));
        }

        /**
         * Create an {@link Intent} to start the {@link MessagingActivity} with the specified
         * configuration options.
         *
         * @param context        The context which {@code startActivity} will be invoked on.
         * @param configurations Configurations for screen that can be started from ChatActivity.
         * @return An {@link Intent} for {@link MessagingActivity} with the specified configuration
         * options.
         */
        @SuppressLint("RestrictedApi")
        public Intent intent(@NonNull Context context, @NonNull List<Configuration> configurations) {
            this.configurations = configurations;

            final Configuration configuration = config(context);
            final Intent intent = new Intent(context, MessagingActivity.class);

            ConfigurationHelper.get().addToIntent(intent, configuration);

            return intent;
        }
    }
}