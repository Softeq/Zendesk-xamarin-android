package zendesk.classic.messaging;

import androidx.annotation.RestrictTo;

import com.zendesk.logger.Logger;

import java.io.File;
import java.util.List;

import javax.inject.Inject;

import static androidx.annotation.RestrictTo.Scope.LIBRARY_GROUP;

import zendesk.core.Callback;

/**
 * <p>
 * Successfully resolved {@link android.net.Uri}s will have their associated {@link File} dispatched
 * as an {@link Event.FileSelected} to the {@link EventListener}.
 */
@RestrictTo(LIBRARY_GROUP)
public class MediaResolverCallback extends Callback<List<File>> {

    private static final String LOG_TAG = "MediaResolverCallback";

    private final EventListener eventListener;
    private final EventFactory eventFactory;

    @Inject
    public MediaResolverCallback(EventListener eventListener, EventFactory eventFactory) {
        this.eventListener = eventListener;
        this.eventFactory = eventFactory;
    }

    @Override
    public void success(List<File> files) {
        Logger.d(LOG_TAG, "Uris have been resolved, collecting files to send the event");

        if (files.isEmpty()) {
            Logger.w(LOG_TAG, "No files resolved. No event will be sent");
            return;
        }

        Logger.d(LOG_TAG, "Sending attachment event");
        eventListener.onEvent(eventFactory.sendAttachment(files));
    }
}
