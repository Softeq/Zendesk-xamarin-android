package zendesk.classic.messaging;

import android.content.Context;
import android.text.format.DateUtils;

import java.util.Date;

import javax.inject.Inject;

class TimestampFactory {

    /*
      These flags format the time as always showing the time and date, always including the year in the date, and using
      a numeric format for the date.
      For Locale.US and Date(0), output will be:
        * 01/01/1970, 00:00 (if the device's settings use 24 hour time)
        * 01/01/1970, 00:00AM (if the device's settings use 12 hour time)
     */
    private static final int FLAGS = DateUtils.FORMAT_SHOW_TIME | DateUtils.FORMAT_SHOW_DATE
            | DateUtils.FORMAT_SHOW_YEAR | DateUtils.FORMAT_NUMERIC_DATE;

    private final Context context;

    @Inject
    TimestampFactory(Context context) {
        this.context = context;
    }

    String createTimestamp(Date date) {
        return DateUtils.formatDateTime(context, date.getTime(), FLAGS);
    }
}
