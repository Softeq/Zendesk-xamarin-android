package zendesk.classic.messaging;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Simple counter class which provides a callback which is notified when the counter has been decremented to zero
 */
class ObservableCounter {

    private final AtomicInteger counter;
    private final OnCountCompletedListener onCountCompletedListener;

    ObservableCounter(OnCountCompletedListener onCountCompletedListener) {
        counter = new AtomicInteger();
        this.onCountCompletedListener = onCountCompletedListener;

    }

    void decrement() {
        int count = counter.decrementAndGet();
        if (count == 0) {
            onCountCompletedListener.onCountCompleted();
        }
    }

    void increment(int delta) {
        counter.addAndGet(delta);
    }

    interface OnCountCompletedListener {
        /**
         * Notifies the listener that the counter has been decremented to zero
         */
        void onCountCompleted();
    }
}
